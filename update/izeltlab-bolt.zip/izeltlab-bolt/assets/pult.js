/* Ízeltláb Bolt 1.2.0: the order desk ("Rendelés-pult"). A pill in a corner for shop managers (logged in), or the whole
   panel on the private phone page. Data from admin-ajax (izb_pult / izb_pult_t), refreshed every minute while the tab
   is visible. No jQuery. */
( function () {
	'use strict';
	var C = window.izbPult;
	if ( ! C || ! window.fetch ) {
		return;
	}
	var T = C.txt, PAGE = 'page' === C.mode;
	var data = null, isOpen = PAGE, tab = 'todo', got = 0, lastId = null, openIds = {}, shipIds = {}, busy = false;
	var pill, panel, body, head;

	function el( tag, cls, text ) {
		var n = document.createElement( tag );
		if ( cls ) {
			n.className = cls;
		}
		if ( null != text ) {
			n.textContent = text;
		}
		return n;
	}
	function icon( d ) {
		var s = document.createElementNS( 'http://www.w3.org/2000/svg', 'svg' );
		s.setAttribute( 'viewBox', '0 0 24 24' );
		s.setAttribute( 'aria-hidden', 'true' );
		s.innerHTML = d;
		return s;
	}
	var IC = {
		box: '<path d="M3 8l9-5 9 5v8l-9 5-9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
		x: '<path d="M6 6l12 12M18 6L6 18"/>',
		re: '<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 5v6h-6"/>',
		clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'
	};

	function req( action, params ) {
		var fd = new FormData();
		fd.append( 'action', action );
		if ( PAGE ) {
			fd.append( 'k', C.token );
		} else {
			fd.append( 'nonce', C.nonce );
		}
		Object.keys( params || {} ).forEach( function ( k ) {
			fd.append( k, params[ k ] );
		} );
		return fetch( C.ajax, { method: 'POST', body: fd, credentials: 'same-origin', cache: 'no-store' } ).then( function ( r ) {
			return r.json();
		} ).then( function ( r ) {
			if ( ! r || ! r.success ) {
				throw new Error( 'fail' );
			}
			return r.data;
		} );
	}

	function load() {
		if ( busy ) {
			return;
		}
		busy = true;
		if ( panel ) {
			panel.classList.add( 'is-busy' );
		}
		req( PAGE ? 'izb_pult_t' : 'izb_pult' ).then( function ( d ) {
			var fresh = d.latest && lastId !== null && d.latest.id > lastId;
			lastId = d.latest ? d.latest.id : 0;
			data = d;
			got = Date.now();
			render();
			if ( fresh ) {
				ding();
			}
		} ).catch( function () {
			if ( body && ! data ) {
				body.textContent = T.error;
			}
		} ).then( function () {
			busy = false;
			if ( panel ) {
				panel.classList.remove( 'is-busy' );
			}
		} );
	}

	// A new order since the last look: the pill hops (and beeps, if that is switched on).
	function ding() {
		if ( pill ) {
			pill.classList.remove( 'is-new' );
			void pill.offsetWidth;
			pill.classList.add( 'is-new' );
			pill.setAttribute( 'title', T.newOrder );
		}
		if ( C.sound && window.AudioContext ) {
			try {
				var a = new window.AudioContext(), o = a.createOscillator(), g = a.createGain();
				o.frequency.value = 880;
				g.gain.setValueAtTime( 0.12, a.currentTime );
				g.gain.exponentialRampToValueAtTime( 0.001, a.currentTime + 0.5 );
				o.connect( g ).connect( a.destination );
				o.start();
				o.stop( a.currentTime + 0.5 );
			} catch ( e ) {}
		}
	}

	/* ---------------------------------------------------------------- building */

	function build() {
		panel = el( 'section', 'izb-pult-panel' );
		panel.setAttribute( 'aria-label', T.title );
		head = el( 'header', 'izb-pult-head' );
		var h = el( 'p', 'izb-pult-h' );
		h.appendChild( icon( IC.box ) );
		h.appendChild( el( 'span', '', T.title ) );
		head.appendChild( h );
		head.appendChild( el( 'p', 'izb-pult-stats' ) );
		var re = el( 'button', 'izb-pult-ic izb-pult-re' );
		re.type = 'button';
		re.title = T.refresh;
		re.setAttribute( 'aria-label', T.refresh );
		re.appendChild( icon( IC.re ) );
		re.addEventListener( 'click', load );
		head.appendChild( re );
		if ( ! PAGE ) {
			var x = el( 'button', 'izb-pult-ic izb-pult-x' );
			x.type = 'button';
			x.setAttribute( 'aria-label', T.close );
			x.appendChild( icon( IC.x ) );
			x.addEventListener( 'click', function () {
				toggle( false );
			} );
			head.appendChild( x );
		}
		panel.appendChild( head );
		panel.appendChild( el( 'div', 'izb-pult-cut' ) );
		panel.appendChild( el( 'p', 'izb-pult-warn' ) );
		var tabs = el( 'div', 'izb-pult-tabs' );
		tabs.setAttribute( 'role', 'tablist' );
		[ [ 'todo', T.todo ], [ 'pick', T.pick ], [ 'stock', T.stock ] ].forEach( function ( t ) {
			var b = el( 'button', 'izb-pult-tab' );
			b.type = 'button';
			b.setAttribute( 'role', 'tab' );
			b.setAttribute( 'data-tab', t[ 0 ] );
			b.appendChild( el( 'span', '', t[ 1 ] ) );
			b.appendChild( el( 'b', 'izb-pult-n' ) );
			b.addEventListener( 'click', function () {
				tab = t[ 0 ];
				render();
			} );
			tabs.appendChild( b );
		} );
		panel.appendChild( tabs );
		body = el( 'div', 'izb-pult-body' );
		panel.appendChild( body );
		if ( PAGE ) {
			panel.appendChild( el( 'p', 'izb-pult-ro', T.readonly ) );
		}

		if ( PAGE ) {
			( document.getElementById( 'izb-pult-root' ) || document.body ).appendChild( panel );
			return;
		}
		var wrap = el( 'div', 'izb-pult is-c-' + ( C.corner || 'br' ) );
		pill = el( 'button', 'izb-pult-pill' );
		pill.type = 'button';
		pill.setAttribute( 'aria-expanded', 'false' );
		pill.setAttribute( 'aria-label', T.open );
		pill.appendChild( icon( IC.box ) );
		pill.appendChild( el( 'b', 'izb-pult-pn', '·' ) );
		pill.appendChild( el( 'span', 'izb-pult-pp' ) );
		pill.appendChild( el( 'span', 'izb-pult-pc' ) );
		pill.addEventListener( 'click', function () {
			toggle( ! isOpen );
		} );
		panel.hidden = true;
		wrap.appendChild( panel );
		wrap.appendChild( pill );
		document.body.appendChild( wrap );
		document.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key && isOpen ) {
				toggle( false );
				pill.focus();
			}
		} );
	}

	function toggle( v ) {
		isOpen = v;
		panel.hidden = ! v;
		pill.setAttribute( 'aria-expanded', v ? 'true' : 'false' );
		pill.classList.toggle( 'is-open', v );
		pill.classList.remove( 'is-new' );
		if ( v && ( ! data || Date.now() - got > 20000 ) ) {
			load();
		}
	}

	/* ---------------------------------------------------------------- drawing */

	function left() {
		if ( ! data || ! data.cut ) {
			return 0;
		}
		return Math.max( 0, data.cut.left - Math.round( ( Date.now() - got ) / 1000 ) );
	}
	function hm( s ) {
		var h = Math.floor( s / 3600 ), m = Math.floor( ( s % 3600 ) / 60 );
		return h ? h + ' ' + T.hour + ' ' + m + ' ' + T.min : m + ' ' + T.min;
	}

	function clock() {
		if ( ! data ) {
			return;
		}
		var s = left(), cut = panel.querySelector( '.izb-pult-cut' );
		cut.textContent = '';
		cut.className = 'izb-pult-cut';
		if ( s > 0 ) {
			cut.appendChild( icon( IC.clock ) );
			cut.appendChild( el( 'span', '', T.cutoff + ' ' ) );
			cut.appendChild( el( 'b', '', hm( s ) ) );
			var bar = el( 'i', 'izb-pult-cutbar' );
			bar.style.width = Math.max( 2, Math.min( 100, s / ( 6 * 3600 ) * 100 ) ) + '%'; // the last 6 hours before 14:00
			cut.appendChild( bar );
			cut.classList.toggle( 'is-hot', s < 1800 );
		} else {
			cut.appendChild( el( 'span', '', data.cut.ship ? T.closed : T.noship ) );
			cut.classList.add( 'is-off' );
		}
		if ( pill ) {
			var pc = pill.querySelector( '.izb-pult-pc' ), todayN = data.todo.filter( function ( o ) {
				return ! o.packed && ( 'today' === o.outk || 'late' === o.outk );
			} ).length;
			pc.textContent = s > 0 && todayN ? hm( s ) : '';
			pc.hidden = ! pc.textContent;
			pill.classList.toggle( 'is-hot', s > 0 && s < 1800 && todayN > 0 );
		}
	}

	function render() {
		if ( ! data ) {
			return;
		}
		var todo = data.todo, waiting = todo.filter( function ( o ) {
			return ! o.packed;
		} ).length;
		if ( pill ) {
			pill.querySelector( '.izb-pult-pn' ).textContent = String( todo.length );
			pill.classList.toggle( 'is-zero', ! todo.length );
			pill.querySelector( '.izb-pult-pp' ).textContent = data.latest ? data.latest.total : '';
			pill.title = data.latest ? '#' + data.latest.num + ' · ' + data.latest.name + ' · ' + data.latest.total : T.title;
		}
		head.querySelector( '.izb-pult-stats' ).textContent = T.today + ': ' + data.today.n + ' ' + T.orders + ' · ' + data.today.sum + ' · ' + data.now;
		var warn = panel.querySelector( '.izb-pult-warn' );
		warn.textContent = data.backup ? '⚠ ' + T.backup : '';
		warn.hidden = ! data.backup;
		var n = {
			todo: waiting,
			pick: data.pick.reduce( function ( a, p ) {
				return a + p.qty;
			}, 0 ),
			stock: data.stock.out.length + data.stock.low.length
		};
		panel.querySelectorAll( '.izb-pult-tab' ).forEach( function ( b ) {
			var k = b.getAttribute( 'data-tab' );
			b.setAttribute( 'aria-selected', k === tab ? 'true' : 'false' );
			b.querySelector( '.izb-pult-n' ).textContent = n[ k ] ? String( n[ k ] ) : '';
		} );
		var keep = body.scrollTop;
		body.textContent = '';
		( { todo: drawTodo, pick: drawPick, stock: drawStock } )[ tab ]();
		body.scrollTop = keep;
		clock();
	}

	function drawTodo() {
		if ( ! data.todo.length ) {
			body.appendChild( el( 'p', 'izb-pult-empty', T.none ) );
			return;
		}
		data.todo.forEach( function ( o ) {
			body.appendChild( card( o ) );
		} );
	}

	function ticks( id ) {
		try {
			return JSON.parse( localStorage.getItem( 'izb_pick_' + id ) || '[]' );
		} catch ( e ) {
			return [];
		}
	}
	function setTicks( id, list ) {
		try {
			localStorage.setItem( 'izb_pick_' + id, JSON.stringify( list ) );
		} catch ( e ) {}
	}

	function card( o ) {
		var d = el( 'details', 'izb-o' + ( o.packed ? ' is-packed' : '' ) + ( o.live ? ' is-live' : '' ) );
		d.open = !! openIds[ o.id ];
		d.addEventListener( 'toggle', function () {
			openIds[ o.id ] = d.open;
		} );
		var s = el( 'summary', 'izb-o-sum' );
		s.appendChild( el( 'span', 'izb-o-num', '#' + o.num ) );
		s.appendChild( el( 'span', 'izb-o-name', o.name ) );
		s.appendChild( el( 'span', 'izb-o-tot', o.total ) );
		var tag = el( 'span', 'izb-o-out is-' + ( o.outk || 'none' ), o.packed ? '✓ ' + T.packed : ( o.out ? T.ships + ': ' + o.out : o.status ) );
		s.appendChild( tag );
		d.appendChild( s );

		var b = el( 'div', 'izb-o-body' );
		// what to pick, with tick boxes (kept on this device only)
		b.appendChild( el( 'p', 'izb-o-h', T.items ) );
		var ul = el( 'ul', 'izb-o-items' ), done = ticks( o.id );
		o.items.forEach( function ( it ) {
			var li = el( 'li' ), lab = el( 'label' ), cb = el( 'input' );
			cb.type = 'checkbox';
			cb.checked = done.indexOf( it.id ) >= 0;
			cb.addEventListener( 'change', function () {
				var list = ticks( o.id ).filter( function ( x ) {
					return x !== it.id;
				} );
				if ( cb.checked ) {
					list.push( it.id );
				}
				setTicks( o.id, list );
				li.classList.toggle( 'is-ticked', cb.checked );
			} );
			li.classList.toggle( 'is-ticked', cb.checked );
			lab.appendChild( cb );
			lab.appendChild( el( 'b', 'izb-o-q', it.qty + '×' ) );
			lab.appendChild( el( 'span', '', it.name ) );
			if ( it.meta ) {
				lab.appendChild( el( 'small', '', it.meta ) );
			}
			if ( it.live ) {
				lab.appendChild( el( 'em', 'izb-o-live', T.live ) );
			}
			li.appendChild( lab );
			ul.appendChild( li );
		} );
		b.appendChild( ul );

		// where it goes
		b.appendChild( el( 'p', 'izb-o-h', T.to ) );
		var ad = el( 'div', 'izb-o-addr' ), lines = [ o.name ].concat( o.company ? [ o.company ] : [], o.addr );
		lines.forEach( function ( l, i ) {
			ad.appendChild( el( i ? 'span' : 'b', '', l ) );
		} );
		var cp = el( 'button', 'izb-pult-mini', T.copy );
		cp.type = 'button';
		cp.addEventListener( 'click', function () {
			var txt = lines.concat( o.phone ? [ o.phone ] : [] ).join( '\n' );
			( navigator.clipboard ? navigator.clipboard.writeText( txt ) : Promise.reject() ).then( function () {
				cp.textContent = T.copied;
				setTimeout( function () {
					cp.textContent = T.copy;
				}, 1500 );
			} ).catch( function () {} );
		} );
		ad.appendChild( cp );
		b.appendChild( ad );
		var facts = el( 'dl', 'izb-o-facts' );
		function fact( k, v, href ) {
			if ( ! v ) {
				return;
			}
			facts.appendChild( el( 'dt', '', k ) );
			var dd = el( 'dd' );
			if ( href ) {
				var a = el( 'a', '', v );
				a.href = href;
				dd.appendChild( a );
			} else {
				dd.textContent = v;
			}
			facts.appendChild( dd );
		}
		fact( T.carrier, o.method );
		if ( C.show.phone ) {
			fact( '☎', o.phone, 'tel:' + String( o.phone ).replace( /[^\d+]/g, '' ) );
		}
		if ( C.show.email ) {
			fact( '@', o.email, 'mailto:' + o.email );
		}
		if ( C.show.pay ) {
			fact( T.pay, o.pay );
		}
		fact( '', o.when + ' · ' + o.status );
		b.appendChild( facts );
		if ( C.show.note && o.note ) {
			b.appendChild( el( 'p', 'izb-o-note', T.note + ': ' + o.note ) );
		}

		// buttons
		var row = el( 'div', 'izb-o-btns' );
		if ( ! PAGE ) {
			var pk = el( 'button', 'izb-pult-btn' + ( o.packed ? ' is-on' : '' ), o.packed ? '✓ ' + T.packed : T.packed );
			pk.type = 'button';
			pk.title = o.packed ? T.unpack : T.packed;
			pk.addEventListener( 'click', function () {
				pk.disabled = true;
				req( 'izb_pult_pack', { id: o.id, on: o.packed ? '' : '1' } ).then( function ( no ) {
					data.todo = data.todo.map( function ( x ) {
						return x.id === o.id ? no : x;
					} );
					render();
				} ).catch( function () {
					pk.disabled = false;
				} );
			} );
			row.appendChild( pk );
			var sh = el( 'button', 'izb-pult-btn is-ship', T.ship );
			sh.type = 'button';
			sh.addEventListener( 'click', function () {
				shipIds[ o.id ] = ! shipIds[ o.id ];
				form.hidden = ! shipIds[ o.id ];
				if ( ! form.hidden ) {
					form.querySelector( 'input' ).focus();
				}
			} );
			row.appendChild( sh );
			if ( o.slip ) {
				var sl = el( 'a', 'izb-pult-btn is-light', T.slip );
				sl.href = o.slip;
				sl.target = '_blank';
				row.appendChild( sl );
			}
			var ed = el( 'a', 'izb-pult-btn is-light', T.edit );
			ed.href = o.edit;
			row.appendChild( ed );
		}
		b.appendChild( row );

		// "Shipped…": carrier + tracking number, then the status changes and the customer gets the mail
		var form = el( 'form', 'izb-o-ship' );
		form.hidden = ! shipIds[ o.id ];
		if ( ! PAGE ) {
			var sel = el( 'select' );
			sel.setAttribute( 'aria-label', T.carrier );
			Object.keys( C.carriers ).forEach( function ( k ) {
				var op = el( 'option', '', C.carriers[ k ] );
				op.value = k;
				op.selected = k === o.carrier;
				sel.appendChild( op );
			} );
			var inp = el( 'input' );
			inp.type = 'text';
			inp.placeholder = T.track;
			inp.value = o.track || '';
			inp.setAttribute( 'aria-label', T.track );
			inp.autocomplete = 'off';
			var go = el( 'button', 'izb-pult-btn is-ship', T.send );
			go.type = 'submit';
			form.appendChild( sel );
			form.appendChild( inp );
			form.appendChild( go );
			form.addEventListener( 'submit', function ( e ) {
				e.preventDefault();
				go.disabled = true;
				req( 'izb_pult_ship', { id: o.id, carrier: sel.value, track: inp.value.trim() } ).then( function () {
					shipIds[ o.id ] = false;
					load();
				} ).catch( function () {
					go.disabled = false;
				} );
			} );
			b.appendChild( form );
		}
		d.appendChild( b );
		return d;
	}

	function drawPick() {
		if ( ! data.pick.length ) {
			body.appendChild( el( 'p', 'izb-pult-empty', T.none ) );
			return;
		}
		body.appendChild( el( 'p', 'izb-pult-hint', T.pickHint ) );
		var ul = el( 'ul', 'izb-pick' );
		data.pick.forEach( function ( p ) {
			var li = el( 'li' );
			li.appendChild( el( 'b', 'izb-o-q', p.qty + '×' ) );
			li.appendChild( el( 'span', '', p.name ) );
			if ( p.meta ) {
				li.appendChild( el( 'small', '', p.meta ) );
			}
			if ( p.live ) {
				li.appendChild( el( 'em', 'izb-o-live', T.live ) );
			}
			ul.appendChild( li );
		} );
		body.appendChild( ul );
	}

	function drawStock() {
		var s = data.stock;
		if ( ! s.out.length && ! s.low.length ) {
			body.appendChild( el( 'p', 'izb-pult-empty', T.allgood ) );
			return;
		}
		var ul = el( 'ul', 'izb-stock' );
		s.out.forEach( function ( p ) {
			ul.appendChild( stockRow( p, 'is-out', T.out + ( p.wait ? ' · ' + p.wait + ' ' + T.waiting : '' ) ) );
		} );
		s.low.forEach( function ( p ) {
			ul.appendChild( stockRow( p, 'is-low', T.low + ( null !== p.qty ? ' · ' + p.qty : '' ) ) );
		} );
		body.appendChild( ul );
	}
	function stockRow( p, cls, label ) {
		var li = el( 'li', cls ), a = el( 'a', '', p.name );
		a.href = PAGE ? p.url : ( p.edit || p.url );
		li.appendChild( a );
		li.appendChild( el( 'span', 'izb-stock-t', label ) );
		return li;
	}

	/* ---------------------------------------------------------------- start */

	function start() {
		build();
		if ( PAGE ) {
			load();
		} else {
			// after the page has settled: the shop comes first
			( window.requestIdleCallback || function ( f ) {
				setTimeout( f, 1500 );
			} )( load, { timeout: 3000 } );
		}
		setInterval( function () {
			if ( ! document.hidden ) {
				load();
			}
		}, ( C.poll || 60 ) * 1000 );
		setInterval( function () {
			if ( ! document.hidden ) {
				clock();
			}
		}, 20000 );
		document.addEventListener( 'visibilitychange', function () {
			if ( ! document.hidden && Date.now() - got > 30000 ) {
				load();
			}
		} );
	}
	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', start );
	} else {
		start();
	}
}() );
