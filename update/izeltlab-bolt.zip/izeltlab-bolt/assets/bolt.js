/* Ízeltláb Bolt: cookie banner, analytics after consent, sign-up forms. No jQuery needed (uses it for the
   WooCommerce "added_to_cart" event when it is there). */
( function () {
	'use strict';
	var cfg = window.izbCfg || {}, KEY = 'izb_consent', MAX = 182 * 864e2;

	function get() {
		var m = document.cookie.match( /(?:^|;\s*)izb_consent=(needed|all)/ );
		return m ? m[ 1 ] : '';
	}
	function set( v ) {
		document.cookie = KEY + '=' + v + ';path=/;max-age=' + MAX + ';SameSite=Lax' + ( location.protocol === 'https:' ? ';Secure' : '' );
	}

	/* ---------------------------------------------------------------- analytics (only after "all") */
	var loaded = false, queue = [];
	function track( name, params ) {
		var t = cfg.tracks;
		if ( ! t || ! loaded ) {
			queue.push( [ name, params ] );
			return;
		}
		params = params || {};
		if ( t.ga4 && window.gtag ) {
			params.currency = t.cur;
			window.gtag( 'event', name, params );
		}
		if ( t.plausible && window.plausible ) {
			window.plausible( name, { props: { value: params.value || 0 } } );
		}
	}
	function load() {
		var t = cfg.tracks;
		if ( loaded || ! t || ( ! t.ga4 && ! t.plausible ) ) {
			return;
		}
		loaded = true;
		if ( t.ga4 ) {
			var s = document.createElement( 'script' );
			s.async = true;
			s.src = 'https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent( t.ga4 );
			document.head.appendChild( s );
			window.dataLayer = window.dataLayer || [];
			window.gtag = function () {
				window.dataLayer.push( arguments );
			};
			// 1.2.0: consent mode v2: the visitor said yes to statistics, no ads or ad personalisation are used
			window.gtag( 'consent', 'default', { analytics_storage: 'granted', ad_storage: 'denied', ad_user_data: 'denied', ad_personalization: 'denied' } );
			window.gtag( 'js', new Date() );
			window.gtag( 'config', t.ga4, { anonymize_ip: true } );
		}
		if ( t.plausible ) {
			var p = document.createElement( 'script' );
			p.defer = true;
			p.setAttribute( 'data-domain', t.plausible );
			p.src = 'https://plausible.io/js/script.js';
			document.head.appendChild( p );
			window.plausible = window.plausible || function () {
				( window.plausible.q = window.plausible.q || [] ).push( arguments );
			};
		}
		( window.izbEvents || [] ).forEach( function ( e ) {
			track( e[ 0 ], e[ 1 ] );
		} );
		queue.splice( 0 ).forEach( function ( e ) {
			track( e[ 0 ], e[ 1 ] );
		} );
	}

	/* ---------------------------------------------------------------- the banner */
	function banner() {
		var box = document.querySelector( '.izb-cookies' );
		if ( ! box ) {
			return;
		}
		function close( v ) {
			set( v );
			// 1.7.0: WooCommerce's order sources follow the choice at once (consent.php)
			if ( window.wc_order_attribution && window.wc_order_attribution.setOrderTracking ) {
				window.wc_order_attribution.setOrderTracking( 'all' === v );
			}
			box.classList.remove( 'is-in' );
			setTimeout( function () {
				box.hidden = true;
			}, 250 );
			if ( 'all' === v ) {
				load();
			}
		}
		function open() {
			box.hidden = false;
			requestAnimationFrame( function () {
				box.classList.add( 'is-in' );
			} );
		}
		box.addEventListener( 'click', function ( e ) {
			if ( e.target.closest( '.izb-ck-all' ) ) {
				close( 'all' );
			} else if ( e.target.closest( '.izb-ck-needed' ) ) {
				close( 'needed' );
			}
		} );
		document.addEventListener( 'click', function ( e ) {
			var a = e.target.closest( '[data-izb-cookies]' );
			if ( a ) {
				e.preventDefault();
				open();
			}
		} );
		if ( ! get() ) {
			setTimeout( open, 900 ); // after the page has drawn: the first look belongs to the shop
		}
	}

	/* ---------------------------------------------------------------- sign-up forms */
	function signups() {
		document.addEventListener( 'submit', function ( e ) {
			var f = e.target.closest && e.target.closest( '.izb-signup' );
			if ( ! f ) {
				return;
			}
			e.preventDefault();
			var msg = f.querySelector( '.izb-signup-msg' ), btn = f.querySelector( 'button' ), fd = new FormData( f );
			fd.append( 'action', 'izb_signup' );
			fd.append( 'nonce', cfg.nonce );
			fd.append( 'kind', f.getAttribute( 'data-kind' ) );
			fd.append( 'product', f.getAttribute( 'data-product' ) || 0 );
			btn.disabled = true;
			fetch( cfg.ajax, { method: 'POST', body: fd, credentials: 'same-origin' } ).then( function ( r ) {
				return r.json();
			} ).then( function ( r ) {
				if ( r && r.success ) {
					f.classList.add( 'is-done' );
					msg.textContent = cfg.txt.thanks;
					track( 'sign_up', { method: f.getAttribute( 'data-kind' ) } );
				} else {
					msg.textContent = ( r && r.data && r.data.msg ) || cfg.txt.error;
					btn.disabled = false;
				}
			} ).catch( function () {
				msg.textContent = cfg.txt.error;
				btn.disabled = false;
			} );
		} );
	}

	function start() {
		banner();
		signups();
		if ( ( ! cfg.cookie && cfg.tracks && cfg.tracks.plausible && ! cfg.tracks.ga4 ) || 'all' === get() ) {
			load(); // Plausible without a banner is cookie-less; everything else waits for "all"
		}
		if ( window.jQuery ) {
			window.jQuery( document.body ).on( 'added_to_cart', function ( e, f, h, $b, pid ) {
				var id = $b && $b.data ? $b.data( 'product_id' ) : pid; // 1.1.1: the theme's buy button sends the id as a 5th value
				track( 'add_to_cart', { items: [ { item_id: String( id || '' ) } ] } );
			} );
			// 1.2.0: the theme's free-shipping line reached the amount (once per page)
			var freeDone = false;
			window.jQuery( document.body ).on( 'izl_progress', function ( e, p, done ) {
				if ( done && ! freeDone ) {
					freeDone = true;
					track( 'free_shipping_reached' );
				}
			} );
		}
	}
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', start );
	} else {
		start();
	}
}() );
