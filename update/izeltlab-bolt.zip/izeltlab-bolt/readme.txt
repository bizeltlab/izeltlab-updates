=== Ízeltláb Bolt ===
Version: 1.7.0

Release copy: only the files the shop needs. The full notes, the translation sources (.po) and the build tools are in
izeltlab-bolt-source.zip of the same version, and every version's changes are in the patch notes.

Update: Settings → Ízeltláb updates → Update all. Or by hand: Plugins → Add New → Upload Plugin → izeltlab-bolt.zip → "Replace current with uploaded".
Settings and product data are stored on the site, not in the plugin, so they stay.
