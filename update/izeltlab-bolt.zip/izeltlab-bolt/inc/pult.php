<?php
// ==========================================================================
//  FILE: inc/pult.php   (Ízeltláb Bolt plugin)
//  WHAT: The "Rendelés-pult" (order desk): today's orders to pack and ship, on the shop for staff, on a
//        secret phone link, and in the morning mail.
//  SEEN: The small pill in the corner for staff; the secret phone page; the morning email.
//  SECTIONS IN THIS FILE:
//    1. Assets
//    2. The data
//    3. AJAX
//    4. The phone page (secret link, read only)
//    5. The morning mail
// ==========================================================================

/**
 * 1.2.0: the "Rendelés-pult" (order desk). For whoever can handle orders, a small pill sits in a corner of every page
 * of the shop (and of the dashboard): how many orders wait to be packed and the newest one's price. Opened, it lists the
 * orders to prepare (what to pick, name, address, phone, carrier, note), a pick list of everything to pack, the 14:00
 * cutoff countdown, and the sold-out / running-low species. Buttons: Packed, Shipped (+ tracking number, which sends
 * the "on its way" mail), packing slip, open in WooCommerce.
 * Also: a private phone page behind a secret link (read only, no login) and a morning summary mail.
 * Settings: WooCommerce → Ízeltláb Bolt → Order desk. Customers never see any of it.
 */

defined( 'ABSPATH' ) || exit;

function izb_pult_can() {
	return izb_opt( 'pult_on' ) && is_user_logged_in() && current_user_can( 'edit_shop_orders' );
}

// The statuses that mean "still to pack" (paid / waiting for a transfer).
function izb_pult_statuses() {
	$s = array_filter( array_map( 'sanitize_key', explode( ',', (string) izb_opt( 'pult_statuses' ) ) ) );
	return $s ? $s : array( 'processing', 'on-hold' );
}

// ==========================================================================
//  Assets
// ==========================================================================

function izb_pult_enqueue( $mode = 'pill' ) {
	wp_enqueue_style( 'izb-pult', IZB_URL . 'assets/pult.css', array(), IZB_VERSION );
	wp_enqueue_script( 'izb-pult', IZB_URL . 'assets/pult.js', array(), IZB_VERSION, true );
	wp_localize_script( 'izb-pult', 'izbPult', izb_pult_js_cfg( $mode ) );
}

add_action( 'wp_enqueue_scripts', function () {
	if ( izb_pult_can() && ! is_customize_preview() ) {
		izb_pult_enqueue();
	}
}, 40 );
add_action( 'admin_enqueue_scripts', function () {
	if ( izb_pult_can() && izb_opt( 'pult_admin' ) ) {
		izb_pult_enqueue();
	}
} );

function izb_pult_js_cfg( $mode, $token = '' ) {
	return array(
		'mode'   => $mode, // pill (logged in) or page (the phone link)
		'ajax'   => admin_url( 'admin-ajax.php', 'relative' ),
		'nonce'  => 'page' === $mode ? '' : wp_create_nonce( 'izb_pult' ),
		'token'  => $token,
		'corner' => (string) izb_opt( 'pult_corner' ),
		'sound'  => izb_opt( 'pult_sound' ) ? 1 : 0,
		'poll'   => 60,
		'show'   => array(
			'phone' => izb_opt( 'pult_phone' ) ? 1 : 0,
			'email' => izb_opt( 'pult_email' ) ? 1 : 0,
			'note'  => izb_opt( 'pult_note' ) ? 1 : 0,
			'pay'   => izb_opt( 'pult_pay' ) ? 1 : 0,
		),
		'carriers' => array_map( function ( $c ) {
			return $c[0];
		}, izb_carriers() ),
		'txt'    => array(
			'title'     => __( 'Order desk', 'izeltlab-bolt' ),
			'open'      => __( 'Open the order desk', 'izeltlab-bolt' ),
			'close'     => __( 'Close', 'izeltlab-bolt' ),
			'refresh'   => __( 'Refresh', 'izeltlab-bolt' ),
			'todo'      => __( 'To pack', 'izeltlab-bolt' ),
			'pick'      => __( 'Pick list', 'izeltlab-bolt' ),
			'stock'     => __( 'Stock', 'izeltlab-bolt' ),
			'none'      => __( 'Nothing to pack. Time for the isopods!', 'izeltlab-bolt' ),
			'today'     => __( 'Today', 'izeltlab-bolt' ),
			'orders'    => __( 'orders', 'izeltlab-bolt' ),
			'cutoff'    => __( 'Today\'s dispatch closes in', 'izeltlab-bolt' ),
			'closed'    => __( 'After 14:00: new orders go out on the next shipping day.', 'izeltlab-bolt' ),
			'noship'    => __( 'No dispatch today.', 'izeltlab-bolt' ),
			'ships'     => __( 'Ships', 'izeltlab-bolt' ),
			'late'      => __( 'late!', 'izeltlab-bolt' ),
			'items'     => __( 'Pick', 'izeltlab-bolt' ),
			'to'        => __( 'Send to', 'izeltlab-bolt' ),
			'copy'      => __( 'Copy', 'izeltlab-bolt' ),
			'copied'    => __( 'Copied', 'izeltlab-bolt' ),
			'carrier'   => __( 'Carrier', 'izeltlab-bolt' ),
			'note'      => __( 'Note', 'izeltlab-bolt' ),
			'pay'       => __( 'Payment', 'izeltlab-bolt' ),
			'packed'    => __( 'Packed', 'izeltlab-bolt' ),
			'unpack'    => __( 'Not packed yet', 'izeltlab-bolt' ),
			'ship'      => __( 'Shipped…', 'izeltlab-bolt' ),
			'track'     => __( 'Tracking number', 'izeltlab-bolt' ),
			'send'      => __( 'Mark shipped + send mail', 'izeltlab-bolt' ),
			'slip'      => __( 'Packing slip', 'izeltlab-bolt' ),
			'edit'      => __( 'Open', 'izeltlab-bolt' ),
			'live'      => __( 'live', 'izeltlab-bolt' ),
			'out'       => __( 'Sold out', 'izeltlab-bolt' ),
			'low'       => __( 'Running low', 'izeltlab-bolt' ),
			'waiting'   => __( 'waiting', 'izeltlab-bolt' ),
			'allgood'   => __( 'Everything is in stock.', 'izeltlab-bolt' ),
			'backup'    => __( 'No fresh backup for 2 days!', 'izeltlab-bolt' ),
			'newOrder'  => __( 'New order!', 'izeltlab-bolt' ),
			'error'     => __( 'Could not load. Try again.', 'izeltlab-bolt' ),
			'readonly'  => __( 'Phone view: read only. Log in to mark orders.', 'izeltlab-bolt' ),
			'pickHint'  => __( 'Everything in the orders to pack, added up.', 'izeltlab-bolt' ),
			'hour'      => __( 'h', 'izeltlab-bolt' ),
			'min'       => __( 'min', 'izeltlab-bolt' ),
		),
	);
}

// ==========================================================================
//  The data
// ==========================================================================

function izb_pult_now() {
	return new DateTimeImmutable( 'now', new DateTimeZone( 'Europe/Budapest' ) );
}

// "today" / "tomorrow" / "on Monday" / "late!" for a Y-m-d dispatch day.
function izb_pult_day_word( $ymd, $now ) {
	if ( ! $ymd ) {
		return array( '', '' );
	}
	$d    = DateTimeImmutable::createFromFormat( '!Y-m-d', $ymd, new DateTimeZone( 'Europe/Budapest' ) );
	$diff = (int) round( ( $d->getTimestamp() - $now->setTime( 0, 0 )->getTimestamp() ) / DAY_IN_SECONDS );
	$w    = function_exists( 'izl_ship_words' ) ? izl_ship_words() : array( 'today' => 'today', 'tomorrow' => 'tomorrow', 'on' => array_fill( 0, 8, '' ) );
	if ( $diff < 0 ) {
		return array( __( 'late!', 'izeltlab-bolt' ), 'late' );
	}
	if ( 0 === $diff ) {
		return array( $w['today'], 'today' );
	}
	if ( 1 === $diff ) {
		return array( $w['tomorrow'], 'soon' );
	}
	return array( $w['on'][ (int) $d->format( 'N' ) ] ? $w['on'][ (int) $d->format( 'N' ) ] : $d->format( 'm.d.' ), 'later' );
}

// The planned dispatch day of an order (saved at checkout; worked out again for orders made by hand).
function izb_pult_out_day( $order ) {
	$plan = $order->get_meta( '_izb_ship' );
	if ( is_array( $plan ) && ! empty( $plan['out'] ) ) {
		return array( $plan['out'], 'live' === ( $plan['type'] ?? '' ) );
	}
	if ( ! function_exists( 'izl_ship_plan' ) ) {
		return array( '', false );
	}
	$live = false;
	foreach ( $order->get_items() as $it ) {
		if ( 'live' === izl_ship_type( $it->get_product_id() ) ) {
			$live = true;
		}
	}
	$at = $order->get_date_created() ? ( new DateTimeImmutable( '@' . $order->get_date_created()->getTimestamp() ) )->setTimezone( new DateTimeZone( 'Europe/Budapest' ) ) : null;
	return array( izl_ship_plan( $live ? 'live' : 'normal', $at )[0]->format( 'Y-m-d' ), $live );
}

function izb_pult_money( $amount ) {
	return html_entity_decode( wp_strip_all_tags( wc_price( $amount ) ), ENT_QUOTES, 'UTF-8' );
}

function izb_pult_order( $o, $now ) {
	list( $out, $live ) = izb_pult_out_day( $o );
	$word  = izb_pult_day_word( $out, $now );
	$items = array();
	foreach ( $o->get_items() as $it ) {
		$meta    = wp_strip_all_tags( wc_display_item_meta( $it, array( 'echo' => false, 'separator' => ', ', 'before' => '', 'after' => '', 'label_before' => '', 'label_after' => ': ' ) ) );
		$items[] = array(
			'id'   => $it->get_id(),
			'name' => $it->get_name(),
			'meta' => $meta,
			'qty'  => (int) $it->get_quantity(),
			'live' => function_exists( 'izl_ship_type' ) && 'live' === izl_ship_type( $it->get_product_id() ),
		);
	}
	$ship  = $o->has_shipping_address();
	$addr  = array_filter( array(
		trim( ( $ship ? $o->get_shipping_postcode() : $o->get_billing_postcode() ) . ' ' . ( $ship ? $o->get_shipping_city() : $o->get_billing_city() ) ),
		$ship ? $o->get_shipping_address_1() : $o->get_billing_address_1(),
		$ship ? $o->get_shipping_address_2() : $o->get_billing_address_2(),
	) );
	$name  = trim( $ship ? $o->get_formatted_shipping_full_name() : $o->get_formatted_billing_full_name() );
	$meth  = $o->get_shipping_method();
	$car   = (string) $o->get_meta( '_izb_carrier' );
	if ( ! $car ) {
		$car = false !== stripos( $meth, 'gls' ) ? 'gls' : ( false !== stripos( $meth, 'foxpost' ) ? 'foxpost' : '' );
	}
	$co = $ship ? $o->get_shipping_company() : $o->get_billing_company();
	return array(
		'id'      => $o->get_id(),
		'num'     => $o->get_order_number(),
		'status'  => wc_get_order_status_name( $o->get_status() ),
		'st'      => $o->get_status(),
		'when'    => $o->get_date_created() ? wp_date( 'm.d. H:i', $o->get_date_created()->getTimestamp() ) : '',
		'total'   => izb_pult_money( $o->get_total() ),
		'name'    => $name ? $name : $o->get_billing_email(),
		'company' => $co,
		'addr'    => array_values( $addr ),
		'phone'   => $o->get_billing_phone(),
		'email'   => $o->get_billing_email(),
		'method'  => $meth,
		'carrier' => $car,
		'track'   => (string) $o->get_meta( '_izb_track' ),
		'note'    => $o->get_customer_note(),
		'pay'     => $o->get_payment_method_title(),
		'out'     => $word[0],
		'outk'    => $word[1],
		'live'    => $live,
		'packed'  => 'yes' === $o->get_meta( '_izb_packed' ),
		'items'   => $items,
		'edit'    => $o->get_edit_order_url(),
		'slip'    => wp_nonce_url( admin_url( 'admin-post.php?action=izb_slip&order=' . $o->get_id() ), 'izb_slip' ),
	);
}

function izb_pult_data() {
	$now   = izb_pult_now();
	$todo  = wc_get_orders( array( 'status' => izb_pult_statuses(), 'limit' => 60, 'orderby' => 'date', 'order' => 'ASC' ) );
	$list  = array();
	$pick  = array();
	foreach ( $todo as $o ) {
		$row    = izb_pult_order( $o, $now );
		$list[] = $row;
		foreach ( $o->get_items() as $it ) {
			$k = $it->get_product_id() . ':' . $it->get_variation_id();
			if ( ! isset( $pick[ $k ] ) ) {
				$meta       = wp_strip_all_tags( wc_display_item_meta( $it, array( 'echo' => false, 'separator' => ', ', 'before' => '', 'after' => '', 'label_before' => '', 'label_after' => ': ' ) ) );
				$pick[ $k ] = array( 'name' => $it->get_name(), 'meta' => $meta, 'qty' => 0, 'orders' => 0, 'live' => function_exists( 'izl_ship_type' ) && 'live' === izl_ship_type( $it->get_product_id() ) );
			}
			$pick[ $k ]['qty']    += (int) $it->get_quantity();
			$pick[ $k ]['orders'] += 1;
		}
	}
	// The packing order: late first, then today, then the rest; within a day the oldest order first.
	$rank = array( 'late' => 0, 'today' => 1, 'soon' => 2, 'later' => 3, '' => 4 );
	usort( $list, function ( $a, $b ) use ( $rank ) {
		return array( $rank[ $a['outk'] ] ?? 4, $a['packed'] ? 1 : 0, $a['id'] ) <=> array( $rank[ $b['outk'] ] ?? 4, $b['packed'] ? 1 : 0, $b['id'] );
	} );
	usort( $pick, function ( $a, $b ) {
		return strcmp( $a['name'], $b['name'] );
	} );

	// Today: every real order since midnight (Budapest), and the newest one.
	$since = $now->setTime( 0, 0 )->getTimestamp();
	$paid  = array_merge( izb_pult_statuses(), array( 'izb-shipped', 'completed', 'processing', 'on-hold' ) );
	$today = wc_get_orders( array( 'status' => array_unique( $paid ), 'date_created' => '>=' . $since, 'limit' => 200, 'return' => 'objects' ) );
	$sum   = 0;
	foreach ( $today as $o ) {
		$sum += (float) $o->get_total();
	}
	$latest = wc_get_orders( array( 'status' => array_unique( $paid ), 'limit' => 1, 'orderby' => 'date', 'order' => 'DESC' ) );
	$latest = $latest ? array( 'id' => $latest[0]->get_id(), 'num' => $latest[0]->get_order_number(), 'total' => izb_pult_money( $latest[0]->get_total() ), 'name' => $latest[0]->get_formatted_billing_full_name() ) : null;

	// The 14:00 cutoff: seconds left today (a shipping day for everything else, Mon-Fri, holidays excluded).
	$cut = array( 'left' => 0, 'ship' => false );
	if ( function_exists( 'izl_ship_plan' ) ) {
		$cut['ship'] = 0 === izl_ship_plan( 'normal', $now->setTime( 0, 0 ) )[2];
		$end         = $now->setTime( IZL_SHIP_CUTOFF, 0 );
		$cut['left'] = $cut['ship'] && $now < $end ? $end->getTimestamp() - $now->getTimestamp() : 0;
		$cut['live'] = 0 === izl_ship_plan( 'live', $now->setTime( 0, 0 ) )[2];
	}

	return array(
		'now'    => $now->format( 'H:i' ),
		'todo'   => $list,
		'pick'   => array_values( $pick ),
		'today'  => array( 'n' => count( $today ), 'sum' => izb_pult_money( $sum ) ),
		'latest' => $latest,
		'cut'    => $cut,
		'stock'  => izb_pult_stock(),
		'backup' => izb_backup_stale(),
	);
}

// Sold out (with how many wait for it) and running low (the Codex "Running low" switch, or a counted stock at or
// under the threshold).
function izb_pult_stock() {
	$wait = function_exists( 'izb_restock_waiting' ) ? izb_restock_waiting() : array();
	$out  = array();
	$low  = array();
	$ids  = wc_get_products( array( 'status' => 'publish', 'stock_status' => 'outofstock', 'limit' => 100, 'return' => 'ids', 'type' => array( 'simple', 'variable' ) ) );
	foreach ( $ids as $id ) {
		$out[] = array( 'name' => get_the_title( $id ), 'wait' => isset( $wait[ $id ] ) ? $wait[ $id ][0] : 0, 'url' => get_permalink( $id ), 'edit' => get_edit_post_link( $id, 'raw' ) );
	}
	$flag = get_posts( array( 'post_type' => 'product', 'post_status' => 'publish', 'fields' => 'ids', 'posts_per_page' => 100, 'meta_key' => '_fsz_low', 'meta_value' => 'yes' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	$th   = max( 0, (int) izb_opt( 'pult_low' ) );
	$cnt  = $th ? wc_get_products( array( 'status' => 'publish', 'stock_status' => 'instock', 'manage_stock' => true, 'stock_quantity' => $th, 'stock_compare' => '<=', 'limit' => 100, 'return' => 'ids' ) ) : array();
	foreach ( array_unique( array_merge( $flag, (array) $cnt ) ) as $id ) {
		$p = wc_get_product( $id );
		if ( ! $p || ! $p->is_in_stock() ) {
			continue;
		}
		$qty   = $p->managing_stock() ? (int) $p->get_stock_quantity() : null;
		$low[] = array( 'name' => $p->get_name(), 'qty' => $qty, 'url' => $p->get_permalink(), 'edit' => get_edit_post_link( $id, 'raw' ) );
	}
	return array( 'out' => $out, 'low' => $low );
}

// wc_get_products() has no stock_quantity compare by default: add it (only for the call above).
add_filter( 'woocommerce_product_data_store_cpt_get_products_query', function ( $q, $vars ) {
	if ( isset( $vars['stock_quantity'], $vars['stock_compare'] ) ) {
		$q['meta_query'][] = array( 'key' => '_stock', 'value' => (int) $vars['stock_quantity'], 'compare' => '<=' === $vars['stock_compare'] ? '<=' : '=', 'type' => 'NUMERIC' );
	}
	return $q;
}, 10, 2 );

// ==========================================================================
//  AJAX
// ==========================================================================

function izb_pult_json( $data ) {
	nocache_headers();
	wp_send_json_success( $data );
}

add_action( 'wp_ajax_izb_pult', function () {
	check_ajax_referer( 'izb_pult', 'nonce' );
	if ( ! izb_pult_can() ) {
		wp_send_json_error( null, 403 );
	}
	izb_pult_json( izb_pult_data() );
} );

// The phone page reads the same data with its secret instead of a login (read only).
add_action( 'wp_ajax_nopriv_izb_pult_t', 'izb_pult_token_ajax' );
add_action( 'wp_ajax_izb_pult_t', 'izb_pult_token_ajax' );
function izb_pult_token_ajax() {
	if ( ! izb_pult_token_ok( sanitize_text_field( wp_unslash( $_REQUEST['k'] ?? '' ) ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		wp_send_json_error( null, 403 );
	}
	$d = izb_pult_data();
	foreach ( $d['todo'] as &$o ) { // no links into the dashboard for a phone without a login
		$o['slip'] = '';
	}
	izb_pult_json( $d );
}

add_action( 'wp_ajax_izb_pult_pack', function () {
	check_ajax_referer( 'izb_pult', 'nonce' );
	$o = wc_get_order( absint( $_POST['id'] ?? 0 ) );
	if ( ! izb_pult_can() || ! $o ) {
		wp_send_json_error( null, 403 );
	}
	if ( ! empty( $_POST['on'] ) ) {
		$o->update_meta_data( '_izb_packed', 'yes' );
		$o->add_order_note( 'Packed (order desk).', 0, true );
	} else {
		$o->delete_meta_data( '_izb_packed' );
	}
	$o->save();
	izb_pult_json( izb_pult_order( $o, izb_pult_now() ) );
} );

add_action( 'wp_ajax_izb_pult_ship', function () {
	check_ajax_referer( 'izb_pult', 'nonce' );
	$o = wc_get_order( absint( $_POST['id'] ?? 0 ) );
	if ( ! izb_pult_can() || ! $o ) {
		wp_send_json_error( null, 403 );
	}
	$car = sanitize_key( wp_unslash( $_POST['carrier'] ?? '' ) );
	$o->update_meta_data( '_izb_track', sanitize_text_field( wp_unslash( $_POST['track'] ?? '' ) ) );
	if ( isset( izb_carriers()[ $car ] ) ) {
		$o->update_meta_data( '_izb_carrier', $car );
	}
	$o->update_meta_data( '_izb_packed', 'yes' );
	$o->save();
	$o->update_status( 'izb-shipped', 'Shipped (order desk).', true ); // sends the "on its way" mail with the tracking link
	izb_pult_json( array( 'id' => $o->get_id() ) );
} );

// ==========================================================================
//  The phone page (secret link, read only)
// ==========================================================================

function izb_pult_token( $new = false ) {
	$t = (string) get_option( 'izb_pult_token' );
	if ( $new || strlen( $t ) < 24 ) {
		$t = wp_generate_password( 32, false, false );
		update_option( 'izb_pult_token', $t, false );
	}
	return $t;
}

function izb_pult_link() {
	return add_query_arg( 'izb_pult', izb_pult_token(), home_url( '/' ) );
}

function izb_pult_token_ok( $k ) {
	if ( ! izb_opt( 'pult_on' ) || ! izb_opt( 'pult_link' ) || strlen( $k ) < 24 ) {
		return false;
	}
	$ip   = preg_replace( '/[^0-9a-f:.]/i', '', (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) );
	$key  = 'izb_pt_' . md5( $ip );
	$miss = (int) get_transient( $key );
	if ( $miss >= 8 ) {
		return false; // too many wrong links from this address: 30 minutes off
	}
	$t = (string) get_option( 'izb_pult_token' );
	if ( $t && hash_equals( $t, $k ) ) {
		return true;
	}
	set_transient( $key, $miss + 1, 30 * MINUTE_IN_SECONDS );
	return false;
}

add_action( 'template_redirect', function () {
	if ( ! isset( $_GET['izb_pult'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$k = sanitize_text_field( wp_unslash( $_GET['izb_pult'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true ); // 1.7.0: a page cache never keeps this page (names and addresses), whatever its settings
	}
	if ( ! izb_pult_token_ok( $k ) ) {
		status_header( 404 );
		nocache_headers();
		exit( 'Not found.' );
	}
	nocache_headers();
	header( 'X-Robots-Tag: noindex, nofollow' );
	header( 'Referrer-Policy: no-referrer' );
	$cfg = izb_pult_js_cfg( 'page', $k );
	echo '<!doctype html><html lang="hu"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">';
	echo '<meta name="robots" content="noindex,nofollow"><meta name="theme-color" content="#1F8A8A"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes">';
	echo '<meta name="apple-mobile-web-app-title" content="Pult"><title>' . esc_html( $cfg['txt']['title'] . ' · ' . get_bloginfo( 'name' ) ) . '</title>';
	if ( has_site_icon() ) {
		echo '<link rel="apple-touch-icon" href="' . esc_url( get_site_icon_url( 180 ) ) . '"><link rel="icon" href="' . esc_url( get_site_icon_url( 32 ) ) . '">';
	}
	echo '<link rel="stylesheet" href="' . esc_url( IZB_URL . 'assets/pult.css?ver=' . IZB_VERSION ) . '">';
	echo '</head><body class="izb-pult-page"><div id="izb-pult-root"></div>';
	echo '<script>var izbPult=' . wp_json_encode( $cfg ) . ';</script>';
	echo '<script src="' . esc_url( IZB_URL . 'assets/pult.js?ver=' . IZB_VERSION ) . '"></script></body></html>';
	exit;
}, 1 );

// ==========================================================================
//  The morning mail
// ==========================================================================

add_action( 'izb_pult_daily', 'izb_pult_mail' );

// (Re)plans the mail for the next set hour (Budapest), when it is on.
function izb_pult_schedule() {
	wp_clear_scheduled_hook( 'izb_pult_daily' );
	if ( ! izb_opt( 'pult_on' ) || ! izb_opt( 'pult_mail' ) ) {
		return;
	}
	$now  = izb_pult_now();
	$hour = max( 0, min( 23, (int) izb_opt( 'pult_mail_hour' ) ) );
	$next = $now->setTime( $hour, 0 );
	if ( $next <= $now ) {
		$next = $next->modify( '+1 day' );
	}
	wp_schedule_single_event( $next->getTimestamp(), 'izb_pult_daily' );
}
add_action( 'update_option_izb', 'izb_pult_schedule' );
add_action( 'init', function () {
	if ( izb_opt( 'pult_on' ) && izb_opt( 'pult_mail' ) && ! wp_next_scheduled( 'izb_pult_daily' ) ) {
		izb_pult_schedule();
	}
} );

function izb_pult_mail() {
	izb_pult_schedule(); // the next one first (a single event each day keeps it on the Budapest hour, summer time too)
	$now = izb_pult_now();
	if ( (int) $now->format( 'N' ) > 5 || ( function_exists( 'izl_is_closed' ) && izl_is_closed( $now->setTime( 0, 0 ) ) ) ) {
		return; // no mail on days nothing ships
	}
	$d    = izb_pult_data();
	$rows = '';
	foreach ( $d['todo'] as $o ) {
		$it = array();
		foreach ( $o['items'] as $i ) {
			$it[] = $i['qty'] . '× ' . $i['name'] . ( $i['meta'] ? ' (' . $i['meta'] . ')' : '' );
		}
		$rows .= '<tr><td style="padding:6px;border-bottom:1px solid #cfe0d9"><b>#' . esc_html( $o['num'] ) . '</b><br><small>' . esc_html( $o['out'] ) . '</small></td><td style="padding:6px;border-bottom:1px solid #cfe0d9">' . esc_html( $o['name'] ) . '<br><small>' . esc_html( implode( ', ', $o['addr'] ) ) . '</small></td><td style="padding:6px;border-bottom:1px solid #cfe0d9">' . esc_html( implode( '; ', $it ) ) . '</td><td style="padding:6px;border-bottom:1px solid #cfe0d9;white-space:nowrap">' . esc_html( $o['total'] ) . '</td></tr>';
	}
	$pick = '';
	foreach ( $d['pick'] as $p ) {
		$pick .= '<li><b>' . (int) $p['qty'] . '×</b> ' . esc_html( $p['name'] ) . ( $p['meta'] ? ' <small>(' . esc_html( $p['meta'] ) . ')</small>' : '' ) . '</li>';
	}
	$stock = '';
	foreach ( $d['stock']['out'] as $s ) {
		$stock .= '<li>' . esc_html( $s['name'] ) . ' · ' . esc_html__( 'Sold out', 'izeltlab-bolt' ) . ( $s['wait'] ? ' · ' . (int) $s['wait'] . ' ' . esc_html__( 'waiting', 'izeltlab-bolt' ) : '' ) . '</li>';
	}
	foreach ( $d['stock']['low'] as $s ) {
		$stock .= '<li>' . esc_html( $s['name'] ) . ' · ' . esc_html__( 'Running low', 'izeltlab-bolt' ) . '</li>';
	}
	/* translators: 1: number of orders to pack */
	$subj = sprintf( __( 'Order desk: %d to pack today', 'izeltlab-bolt' ), count( $d['todo'] ) );
	$html = '<div style="font-family:Arial,sans-serif;color:#17302E;max-width:680px">';
	$html .= '<h2 style="margin:0 0 6px">' . esc_html__( 'Good morning!', 'izeltlab-bolt' ) . '</h2>';
	/* translators: %d: number of orders */
	$html .= '<p>' . esc_html( sprintf( __( 'To pack: %d orders.', 'izeltlab-bolt' ), count( $d['todo'] ) ) ) . '</p>';
	if ( $rows ) {
		$html .= '<table style="border-collapse:collapse;width:100%;font-size:14px">' . $rows . '</table>';
	}
	if ( $pick ) {
		$html .= '<h3 style="margin:16px 0 4px">' . esc_html__( 'Pick list', 'izeltlab-bolt' ) . '</h3><ul>' . $pick . '</ul>';
	}
	if ( $stock ) {
		$html .= '<h3 style="margin:16px 0 4px">' . esc_html__( 'Stock', 'izeltlab-bolt' ) . '</h3><ul>' . $stock . '</ul>';
	}
	if ( $d['backup'] ) {
		$html .= '<p style="color:#b42323"><b>' . esc_html__( 'No fresh backup for 2 days!', 'izeltlab-bolt' ) . '</b></p>';
	}
	$html .= '<p style="margin-top:18px">';
	if ( izb_opt( 'pult_link' ) ) {
		$html .= '<a href="' . esc_url( izb_pult_link() ) . '" style="display:inline-block;padding:10px 16px;background:#F4D35E;color:#17302E;border:2px solid #17302E;border-radius:10px;font-weight:700;text-decoration:none">' . esc_html__( 'Open the order desk', 'izeltlab-bolt' ) . '</a> ';
	}
	$html .= '<a href="' . esc_url( admin_url( 'admin.php?page=wc-orders' ) ) . '">WooCommerce</a></p></div>';
	$to = izb_opt( 'pult_mail_to' ) ? sanitize_email( izb_opt( 'pult_mail_to' ) ) : izb_email();
	wp_mail( $to, $subj, $html, array( 'Content-Type: text/html; charset=UTF-8' ) );
}

// Settings page: the link box (shown under the settings form).
function izb_pult_settings_box() {
	if ( ! izb_opt( 'pult_on' ) ) {
		return;
	}
	echo '<h2>Order desk: phone link</h2>';
	if ( ! izb_opt( 'pult_link' ) ) {
		echo '<p>The phone link is off (tick "Phone link" above).</p>';
		return;
	}
	echo '<p>Open this on your phone and add it to the home screen (Safari: Share → Add to Home Screen; Chrome: ⋮ → Add to Home screen). It shows the orders to pack, the countdown and the stock, read only, without logging in. <b>Anyone with the link sees names and addresses</b>: keep it to yourself, and make a new one if it ever leaks.</p>';
	echo '<p><input type="text" readonly class="large-text code" value="' . esc_attr( izb_pult_link() ) . '" onclick="this.select()"></p>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wp_nonce_field( 'izb_pult_newlink' );
	echo '<input type="hidden" name="action" value="izb_pult_newlink"><button class="button" onclick="return confirm(\'The old link stops working. Make a new one?\')">Make a new link</button> ';
	echo '<a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=izb_pult_testmail' ), 'izb_pult_testmail' ) ) . '">Send the morning mail now (test)</a></form>';
}

add_action( 'admin_post_izb_pult_newlink', function () {
	check_admin_referer( 'izb_pult_newlink' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die();
	}
	izb_pult_token( true );
	izb_back( 'New phone link made. The old one no longer works.' );
} );
add_action( 'admin_post_izb_pult_testmail', function () {
	check_admin_referer( 'izb_pult_testmail' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die();
	}
	izb_pult_mail();
	izb_back( 'Morning mail sent (on a weekend or a holiday nothing is sent).' );
} );
