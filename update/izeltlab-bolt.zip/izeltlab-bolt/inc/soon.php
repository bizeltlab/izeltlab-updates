<?php
// ==========================================================================
//  FILE: inc/soon.php   (Ízeltláb Bolt plugin)
//  WHAT: The "Hamarosan nyitunk!" (coming soon) page for visitors, and "View as visitor" for the logged-in
//        owner.
//  SEEN: Every page while coming soon is on; the admin bar switch.
//  SECTIONS IN THIS FILE:
//    1. View as visitor
//    2. Coming soon
// ==========================================================================

/**
 * 1.6.0: "Hamarosan nyitunk!" (coming soon) and "View as visitor".
 *
 * Coming soon: visitors who are not logged in see one small page (the shop's colours, the walking isopod, the
 * newsletter sign-up) instead of the shop; search engines are told to come back later (503 + Retry-After, noindex).
 * Logged-in shop editors (anyone who can edit posts: Dan, a shop manager) see the real shop. Turned on and off in
 * WooCommerce → Ízeltláb Bolt → Coming soon; every change empties the page cache, so nobody gets an old copy.
 * Always reachable: the dashboard and login, the secret login address, cron, the order desk phone link, the privacy
 * notice (the sign-up box links to it), and the background calls that are not the shop's (1.7.0: the shop's own, cart,
 * checkout, product lists and search, are shut for visitors like the pages).
 *
 * View as visitor: a logged-in editor can look at the shop as a shopper does, without logging out (which would only
 * show the coming soon page). A switch in the admin bar ("View as visitor"); the page then has no admin bar, no Codex
 * edit tools, no Edit buttons, no order desk. A small "Editor view" chip in the bottom corner turns it back. It is a
 * cookie in that browser only, and only on shop pages: the dashboard is never affected.
 *
 * 1.10.0 (Dan): on a phone (or other small device) a logged-in editor ALWAYS sees the shop pages as a visitor: no admin
 * bar, no edit tools, nothing over the page. The dashboard on the phone works as before. The "Editor view" chip brings
 * the tools back on that phone until the browser is closed (cookie izb_editor); the setting "Admin tools on phones"
 * (Ízeltláb Bolt → Coming soon) turns the rule off for good.
 */

defined( 'ABSPATH' ) || exit;

// ==========================================================================
//  View as visitor
// ==========================================================================

// The cookie is read once; the editor check below uses the real rights (the visitor filter is off while it runs).
function izb_visitor_cookie() {
	return ! empty( $_COOKIE['izb_visitor'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
}

// Can this person see the shop behind the coming soon page and use the view switch? Real rights, not the visitor view.
function izb_is_editor() {
	if ( ! is_user_logged_in() ) {
		return false;
	}
	$GLOBALS['izb_visitor_off'] = true;
	$can = current_user_can( 'edit_posts' );
	$GLOBALS['izb_visitor_off'] = false;
	return $can;
}

// 1.10.0: a phone or other small device (WordPress's own check of the browser), where the editor did not ask for the
// tools with the "Editor view" chip and the setting does not keep them on phones.
function izb_phone_visitor() {
	return wp_is_mobile() && ! izb_opt( 'phone_tools' ) && empty( $_COOKIE['izb_editor'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
}

// A shop page (not the dashboard, not a background request).
function izb_front_request() {
	// 1.7.0: a WooCommerce background call has a name (?wc-ajax=get_refreshed_fragments). The bare word (?wc-ajax)
	// names none, WooCommerce then draws the normal page, so it counts as a page here too (it used to open the shop
	// behind the coming soon page).
	return ! is_admin() && ! wp_doing_ajax() && ! wp_doing_cron() && ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) && ! ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) && empty( $_GET['wc-ajax'] ); // phpcs:ignore WordPress.Security.NonceVerification
}

// Visitor view on: on shop pages this person has no rights beyond reading, so every edit tool stays away by itself
// (Codex edit mode, Edit buy box / photos, the order desk, WordPress's Edit links).
function izb_visitor_on() {
	return ( izb_visitor_cookie() || izb_phone_visitor() ) && izb_front_request() && empty( $GLOBALS['izb_visitor_off'] ) && is_user_logged_in();
}

add_filter( 'user_has_cap', function ( $all ) {
	if ( izb_visitor_on() ) {
		$keep = array();
		foreach ( array( 'read', 'exist' ) as $c ) {
			if ( ! empty( $all[ $c ] ) ) {
				$keep[ $c ] = true;
			}
		}
		return $keep;
	}
	return $all;
}, 999 );

add_filter( 'show_admin_bar', function ( $show ) {
	return izb_visitor_on() ? false : $show;
}, 999 );

// ?izb_view=visitor / ?izb_view=editor switches, then the same page again without it.
add_action( 'init', function () {
	if ( ! isset( $_GET['izb_view'] ) || ! izb_front_request() ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$to = sanitize_key( wp_unslash( $_GET['izb_view'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( izb_is_editor() ) {
		$path = COOKIEPATH ? COOKIEPATH : '/';
		if ( 'visitor' === $to ) {
			setcookie( 'izb_visitor', '1', 0, $path, COOKIE_DOMAIN, is_ssl(), true );
			setcookie( 'izb_editor', '', time() - 3600, $path, COOKIE_DOMAIN, is_ssl(), true );
		} else {
			setcookie( 'izb_visitor', '', time() - 3600, $path, COOKIE_DOMAIN, is_ssl(), true );
			if ( wp_is_mobile() ) {
				setcookie( 'izb_editor', '1', 0, $path, COOKIE_DOMAIN, is_ssl(), true ); // 1.10.0: tools on this phone until the browser closes
			}
		}
	}
	nocache_headers();
	wp_safe_redirect( remove_query_arg( 'izb_view' ) );
	exit;
}, 0 );

// The admin bar switch (shop pages only).
add_action( 'admin_bar_menu', function ( $bar ) {
	if ( is_admin() || ! izb_is_editor() ) {
		return;
	}
	$bar->add_node( array(
		'id'    => 'izb-visitor',
		'title' => '<span class="ab-icon dashicons dashicons-visibility" style="top:2px" aria-hidden="true"></span>' . esc_html__( 'View as visitor', 'izeltlab-bolt' ),
		'href'  => add_query_arg( 'izb_view', 'visitor' ),
		'meta'  => array( 'title' => __( 'See this page as a shopper sees it: no admin bar, no edit tools. You stay logged in.', 'izeltlab-bolt' ) ),
	) );
}, 90 );

// The way back: one small chip in the bottom right corner (the order desk's corner; the desk is hidden in the visitor
// view, the cookie banner sits on the left). Phone product page: under the header (the drawer owns the bottom).
// Only in the visitor view, only for an editor.
add_action( 'wp_footer', function () {
	if ( ! izb_visitor_on() || ! izb_is_editor() ) {
		return;
	}
	echo '<a class="izb-viewchip" href="' . esc_url( add_query_arg( 'izb_view', 'editor' ) ) . '" title="' . esc_attr__( 'Back to the editor view (admin bar and edit tools)', 'izeltlab-bolt' ) . '">'
		. '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 20l4-1 11-11-3-3L5 16z" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"/></svg>'
		. '<span>' . esc_html__( 'Editor view', 'izeltlab-bolt' ) . '</span></a>';
	echo '<style>.izb-viewchip{position:fixed;right:max(10px,env(safe-area-inset-right,0px));bottom:calc(10px + env(safe-area-inset-bottom,0px));z-index:99990;display:inline-flex;align-items:center;gap:6px;padding:6px 11px 6px 9px;border:2px solid #17302E;border-radius:999px;background:#F4D35E;color:#17302E;font:700 12px/1 system-ui,-apple-system,sans-serif;text-decoration:none;box-shadow:0 3px 0 #17302E;opacity:.92}'
		. '.izb-viewchip:hover,.izb-viewchip:focus-visible{opacity:1}.izb-viewchip:active{transform:translateY(2px);box-shadow:0 1px 0 #17302E}.izb-viewchip svg{width:14px;height:14px}'
		. 'body.izl-phone .izb-viewchip{bottom:auto;top:calc(var(--izl-top,60px) + 8px)}'
		// 1.10.0: on the phone product page only the small pencil, a little faded, so the page looks as a shopper's
		. 'body.izl-phone .izb-viewchip{padding:6px;opacity:.7}body.izl-phone .izb-viewchip span{display:none}</style>';
}, 99 );

// ==========================================================================
//  Coming soon
// ==========================================================================

function izb_soon_on() {
	return (bool) izb_opt( 'soon_on' );
}

add_action( 'template_redirect', function () {
	if ( ! izb_soon_on() || ! izb_front_request() || izb_is_editor() ) {
		return;
	}
	// the order desk phone link (pult.php), robots.txt, the privacy notice (the sign-up box links to it)
	if ( isset( $_GET['izb_pult'] ) || is_robots() || is_favicon() ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$privacy = (int) get_option( 'wp_page_for_privacy_policy' );
	if ( $privacy && is_page( $privacy ) && 'publish' === get_post_status( $privacy ) ) {
		return;
	}
	izb_soon_page();
	exit;
}, 0 );

/*
 * 1.7.0: while coming soon is on, the shop's background doors are shut for visitors too, not only its pages:
 * WooCommerce's cart and checkout calls (?wc-ajax=…, admin-ajax woocommerce_…), the public product list
 * (WooCommerce Store API, the product addresses of the WordPress REST API) and the live search. Before, the pages were
 * hidden but anyone could still list the products and fill a cart through these. Editors pass as on the pages; the
 * sign-up form of the coming soon page (admin-ajax izb_signup) and everything else (payment webhooks, cron, backups)
 * is untouched.
 */

// May this request see the shop? On pages: the logged-in editor. In background calls WordPress only "logs in" a
// request that carries a security code, and the live search sends none, so the login cookie itself is read there
// (reading only: nothing can be changed through this).
function izb_soon_pass() {
	if ( is_user_logged_in() ) {
		return izb_is_editor();
	}
	$uid = (int) wp_validate_auth_cookie( '', 'logged_in' );
	return $uid && user_can( $uid, 'edit_posts' );
}

function izb_soon_shut() {
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	status_header( 503 );
	header( 'Retry-After: 86400' );
	header( 'X-Robots-Tag: noindex' );
	nocache_headers();
	exit;
}

add_action( 'init', function () {
	if ( ! izb_soon_on() || is_admin() && ! wp_doing_ajax() || wp_doing_cron() ) {
		return;
	}
	// phpcs:disable WordPress.Security.NonceVerification
	$wc_ajax = ! empty( $_GET['wc-ajax'] );
	$action  = wp_doing_ajax() && isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : '';
	$shop    = $wc_ajax || 0 === strpos( $action, 'woocommerce_' );
	$fill    = isset( $_REQUEST['add-to-cart'] ) || isset( $_POST['woocommerce_checkout_place_order'] ) || isset( $_POST['woocommerce-process-checkout-nonce'] );
	if ( ( ! $shop && ! $fill ) || izb_soon_pass() ) {
		return;
	}
	if ( $shop ) {
		izb_soon_shut();
	}
	// a page address that would fill the cart or place an order: the page stays "coming soon", the order is dropped
	unset( $_GET['add-to-cart'], $_POST['add-to-cart'], $_REQUEST['add-to-cart'], $_POST['woocommerce_checkout_place_order'], $_REQUEST['woocommerce_checkout_place_order'], $_POST['woocommerce-process-checkout-nonce'], $_REQUEST['woocommerce-process-checkout-nonce'] );
	// phpcs:enable
}, 1 );

add_filter( 'rest_pre_dispatch', function ( $result, $server, $request ) {
	if ( null !== $result || ! izb_soon_on() ) {
		return $result;
	}
	$route = (string) $request->get_route();
	if ( ! preg_match( '#^/(wc/store|wc/v\d+/products|izl/v1|wp/v2/(product|product_cat|product_tag|product_variation|search))(/|$)#', $route ) || izb_soon_pass() ) {
		return $result;
	}
	return new WP_Error( 'izb_soon', __( 'Opening soon!', 'izeltlab-bolt' ), array( 'status' => 503 ) );
}, 5, 3 );

function izb_soon_page() {
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true ); // WP Super Cache and the others: never keep a copy of this page
	}
	status_header( 503 );
	header( 'Retry-After: 86400' );
	header( 'X-Robots-Tag: noindex' );
	header( 'Content-Type: text/html; charset=UTF-8' );
	nocache_headers();

	$title = trim( (string) izb_opt( 'soon_title' ) );
	$text  = trim( (string) izb_opt( 'soon_text' ) );
	$title = '' !== $title ? $title : izb_defaults()['soon_title'];
	$theme = get_stylesheet_directory_uri();
	$fonts = is_readable( get_stylesheet_directory() . '/assets/fonts.css' ) ? $theme . '/' . ( function_exists( 'izl_min' ) ? izl_min( 'assets/fonts.css' ) : 'assets/fonts.css' ) : ''; // the shop's fonts (Ízeltláb theme)
	$news  = izb_opt( 'soon_news' ) && function_exists( 'izb_form' );
	$mail  = izb_email();
	$icon  = get_site_icon_url( 192 );
	if ( ! $icon && is_readable( get_stylesheet_directory() . '/assets/icons/icon-192.png' ) ) {
		$icon = $theme . '/assets/icons/icon-192.png';
	}
	?><!doctype html>
<html lang="hu">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="robots" content="noindex">
<meta name="theme-color" content="#458B8B">
<title><?php echo esc_html( $title . ' · ' . get_bloginfo( 'name' ) ); ?></title>
<?php if ( $icon ) : ?><link rel="icon" href="<?php echo esc_url( $icon ); ?>"><?php endif; ?>
<?php if ( $fonts ) : ?><link rel="stylesheet" href="<?php echo esc_url( $fonts ); ?>"><?php endif; ?>
<?php if ( $news ) : ?><link rel="stylesheet" href="<?php echo esc_url( IZB_URL . 'assets/bolt.css?ver=' . IZB_VERSION ); ?>"><?php endif; ?>
<style>
:root{--ink:#17302E;--teal:#458B8B;--teal-dark:#2f6b6b;--mint:#E9F1EC;--yellow:#F4D35E;--mono:"Izeltlab Mono","Courier New",Courier,monospace;--sans:"Izeltlab Sans",system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif}
*{box-sizing:border-box}
html,body{margin:0;min-height:100%}
body{min-height:100vh;min-height:100dvh;display:flex;flex-direction:column;background:var(--mint);color:var(--ink);font:400 16px/1.55 var(--sans);-webkit-text-size-adjust:100%}
.top{background:var(--teal);border-bottom:3px solid #0e3534;padding:10px max(16px,env(safe-area-inset-left,0px)) 8px}
.logo{display:inline-block;color:#fff;text-decoration:none}
.logo-t{display:block;font:700 26px/1 'Izeltlab Logo','Space Mono',var(--mono);letter-spacing:0}
.seg{display:grid;grid-template-columns:repeat(8,1fr);height:5px;margin-top:5px}
.seg b{display:block;justify-self:center;width:78%;border-radius:2px 2px 3px 3px;background:var(--yellow)}
.seg b:nth-child(odd){background:#e9f6f2}
main{flex:1;display:flex;align-items:center;justify-content:center;padding:28px 16px 40px}
.box{width:100%;max-width:30rem;display:flex;flex-direction:column;align-items:center;gap:14px;padding:26px 22px 24px;background:#fff;border:2px solid var(--ink);border-radius:16px;box-shadow:6px 6px 0 var(--teal-dark);text-align:center}
h1{margin:0;font:700 clamp(22px,6vw,30px)/1.2 var(--mono);text-wrap:balance}
.text{margin:0;max-width:26rem;white-space:pre-line;text-wrap:pretty}
.walker{display:block;width:9.5rem;max-width:60%;height:auto;overflow:visible}
.walker .shell{fill:#7d8b72;stroke:var(--ink);stroke-width:3;stroke-linejoin:round}
.walker .ln{fill:none;stroke:var(--ink);stroke-width:2.5;stroke-linecap:round}
.walker .eye{fill:var(--ink)}
.walker .fb{opacity:0}
.walker .fa{animation:fa 1s steps(1,end) infinite}.walker .fb{animation:fb 1s steps(1,end) infinite}.walker .body{animation:bob 1s steps(1,end) infinite}
@keyframes fa{0%{opacity:1}50%{opacity:0}}@keyframes fb{0%{opacity:0}50%{opacity:1}}@keyframes bob{0%{transform:translateY(0)}50%{transform:translateY(1.5px)}}
@media (prefers-reduced-motion:reduce){.walker *{animation:none!important}.walker .fa{opacity:1}.walker .fb{opacity:0}}
.screen-reader-text{position:absolute!important;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
.news{width:100%;margin-top:6px;text-align:left}
.news input[type=email]{font:400 16px var(--sans);min-height:44px}
.news .button{display:inline-flex;align-items:center;justify-content:center;min-height:44px;padding:0 18px;border:2px solid var(--ink);border-radius:10px;background:var(--yellow);color:var(--ink);font:700 15px/1 var(--sans);box-shadow:0 4px 0 var(--ink);cursor:pointer;-webkit-tap-highlight-color:transparent}
.news .button:active{transform:translateY(3px);box-shadow:0 1px 0 var(--ink)}
.news .izb-signup{margin:0}
.mail{margin:0;font-size:14px;color:#3d5a57}
.mail a{color:var(--ink);font-weight:600}
footer{padding:0 16px calc(18px + env(safe-area-inset-bottom,0px));text-align:center;font:400 12px/1.4 var(--sans);color:#5b7773}
footer a{display:inline-block;margin-left:10px;padding:6px 2px;color:inherit;text-decoration:none}
footer a:hover,footer a:focus-visible{text-decoration:underline}
</style>
</head>
<body>
<header class="top"><span class="logo" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"><span class="logo-t" aria-hidden="true">ízeltláb</span><span class="seg" aria-hidden="true"><?php echo str_repeat( '<b></b>', 8 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></span></header>
<main>
<div class="box">
<svg class="walker" viewBox="0 0 150 86" aria-hidden="true" focusable="false"><g class="body"><path class="shell" d="M20 66C20 36 44 22 78 22C112 22 134 38 134 66Z"/><path class="ln" d="M54 25Q50 46 54 66M72 22Q68 46 72 66M90 22Q88 46 90 66M108 26Q108 46 110 66"/><circle class="eye" cx="36" cy="50" r="2.6"/><path class="ln fa" d="M24 48Q12 42 6 32"/><path class="ln fb" d="M24 48Q12 47 6 41"/></g><g class="fa"><path class="ln" d="M34 66v12M70 66v12M106 66v12"/><path class="ln" d="M52 66v6M88 66v6M122 66v6"/></g><g class="fb"><path class="ln" d="M52 66v12M88 66v12M122 66v12"/><path class="ln" d="M34 66v6M70 66v6M106 66v6"/></g></svg>
<h1><?php echo esc_html( $title ); ?></h1>
<?php if ( '' !== $text ) : ?><p class="text"><?php echo esc_html( $text ); ?></p><?php endif; ?>
<?php if ( $news ) : ?><div class="news"><?php echo izb_form( 'news' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div><?php endif; ?>
<p class="mail"><?php esc_html_e( 'Questions?', 'izeltlab-bolt' ); ?> <a href="mailto:<?php echo esc_attr( $mail ); ?>"><?php echo esc_html( $mail ); ?></a></p>
</div>
</main>
<?php // 1.9.0 (Dan, 2026-11-13): a quiet way in for the owner, in the footer's grey. It opens the WordPress login; the secret login address still guards it (inc/security.php: without the gate cookie it ends on the 404 page). ?>
<footer>© <?php echo esc_html( gmdate( 'Y' ) . ' ' . get_bloginfo( 'name' ) ); ?><a href="<?php echo esc_url( wp_login_url( home_url( '/' ) ) ); ?>" rel="nofollow"><?php esc_html_e( 'Log in', 'izeltlab-bolt' ); ?></a></footer>
<?php if ( $news ) : ?>
<script>var izbCfg=<?php echo wp_json_encode( izb_front_cfg() ); ?>;</script>
<script src="<?php echo esc_url( IZB_URL . 'assets/bolt.js?ver=' . IZB_VERSION ); ?>"></script>
<?php endif; ?>
</body>
</html>
	<?php
}

// Every change of the switch empties the page cache (a cached shop page would still reach visitors, or the other
// way round). The first run of this version does it once too: a manual upload has no automatic cache emptying.
add_action( 'update_option_izb', function ( $old, $new ) {
	$a = is_array( $old ) && ! empty( $old['soon_on'] );
	$b = is_array( $new ) && ! empty( $new['soon_on'] );
	if ( $a !== $b ) {
		izb_soon_purge();
	}
}, 10, 2 );
add_action( 'admin_init', function () {
	if ( get_option( 'izb_soon_seen' ) !== IZB_VERSION ) {
		update_option( 'izb_soon_seen', IZB_VERSION, false );
		izb_soon_purge();
	}
} );
function izb_soon_purge() {
	if ( class_exists( 'IZL_Updater' ) && method_exists( 'IZL_Updater', 'purge' ) ) {
		IZL_Updater::purge();
	} elseif ( function_exists( 'wp_cache_clear_cache' ) ) {
		wp_cache_clear_cache();
	}
}

// A reminder on the dashboard while it is on.
add_action( 'admin_notices', function () {
	if ( ! izb_soon_on() || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( $screen && ! in_array( $screen->id, array( 'dashboard', 'woocommerce_page_izeltlab-bolt' ), true ) ) {
		return;
	}
	echo '<div class="notice notice-info"><p><strong>' . esc_html__( 'Coming soon is on:', 'izeltlab-bolt' ) . '</strong> ' . esc_html__( 'visitors see only the "Hamarosan nyitunk!" page; you see the shop. Turn it off on launch day:', 'izeltlab-bolt' ) . ' <a href="' . esc_url( admin_url( 'admin.php?page=izeltlab-bolt#izb-soon_on' ) ) . '">' . esc_html__( 'Ízeltláb Bolt → Coming soon', 'izeltlab-bolt' ) . '</a></p></div>';
} );
