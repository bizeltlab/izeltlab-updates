<?php
/**
 * 1.2.0: daily backups with UpdraftPlus (free): the database every day, the files every week, 14 / 4 kept, stored on
 * Google Drive (bizeltlab@gmail.com), a report mail to the company email. "Apply backup settings" sets it; Dan then
 * presses "Authenticate with Google Drive" once in UpdraftPlus. The order desk and the dashboard warn when the last
 * backup is older than 2 days. The restore steps are in the launch guide (backup-restore-guide.md).
 */

defined( 'ABSPATH' ) || exit;

function izb_backup_plugin() {
	return class_exists( 'UpdraftPlus' ) || defined( 'UPDRAFTPLUS_DIR' );
}

function izb_backup_last() {
	$l = get_option( 'updraft_last_backup' );
	return is_array( $l ) && ! empty( $l['backup_time'] ) ? (int) $l['backup_time'] : 0;
}

// True when UpdraftPlus is there and its last backup is older than 2 days (or there was none since it was set up).
function izb_backup_stale() {
	if ( ! izb_backup_plugin() || ! get_option( 'izb_backup_set' ) ) {
		return false;
	}
	$t = izb_backup_last();
	$since = (int) get_option( 'izb_backup_set' );
	return time() - max( $t, $since ) > 2 * DAY_IN_SECONDS;
}

add_action( 'admin_notices', function () {
	if ( current_user_can( 'manage_options' ) && izb_backup_stale() ) {
		echo '<div class="notice notice-error"><p><b>Ízeltláb Bolt:</b> no backup for more than 2 days. Open <a href="' . esc_url( admin_url( 'options-general.php?page=updraftplus' ) ) . '">UpdraftPlus</a>: is Google Drive still connected?</p></div>';
	}
} );

add_action( 'admin_post_izb_backup_apply', function () {
	check_admin_referer( 'izb_backup_apply' );
	if ( ! current_user_can( 'manage_options' ) || ! izb_backup_plugin() ) {
		wp_die();
	}
	// UpdraftPlus plans its schedule again when these options change.
	update_option( 'updraft_interval_database', 'daily' );
	update_option( 'updraft_interval', 'weekly' );
	update_option( 'updraft_retain_db', 14 );
	update_option( 'updraft_retain', 4 );
	$svc = get_option( 'updraft_service' );
	if ( empty( $svc ) || 'none' === $svc || array( 'none' ) === $svc || array( '' ) === $svc ) {
		update_option( 'updraft_service', array( 'googledrive' ) );
	}
	update_option( 'updraft_email', izb_email() );
	update_option( 'izb_backup_set', time() );
	izb_back( 'Backup settings applied: database daily, files weekly, on Google Drive. Now open UpdraftPlus → Settings, press "Authenticate with Google Drive" (log in as ' . izb_email() . '), then "Backup Now" once.' );
} );

function izb_backup_box() {
	echo '<h2>Backups</h2>';
	if ( ! izb_backup_plugin() ) {
		echo '<p>Install the free <b>UpdraftPlus</b> plugin (live site only): <a class="button" href="' . esc_url( admin_url( 'plugin-install.php?s=updraftplus&tab=search&type=term' ) ) . '">Find UpdraftPlus</a>. Then come back here and press "Apply backup settings". If your host already makes daily backups that you can restore yourself, keep them too: two copies in two places.</p>';
		return;
	}
	$last = izb_backup_last();
	echo '<p><b>Last backup:</b> ' . ( $last ? esc_html( wp_date( 'Y.m.d. H:i', $last ) ) : 'none yet' ) . ( izb_backup_stale() ? ' <b style="color:#b42323">(too old)</b>' : '' ) . '</p>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wp_nonce_field( 'izb_backup_apply' );
	echo '<input type="hidden" name="action" value="izb_backup_apply"><button class="button button-primary">Apply backup settings</button> ';
	echo '<a class="button" href="' . esc_url( admin_url( 'options-general.php?page=updraftplus' ) ) . '">Open UpdraftPlus</a></form>';
	echo '<p class="description">Database every day (orders come in every day), files every week (photos change rarely), 14 and 4 kept, on Google Drive, report mail to ' . esc_html( izb_email() ) . '. To restore: UpdraftPlus → Backup / Restore → Existing backups → Restore (the guide has the steps).</p>';
}
