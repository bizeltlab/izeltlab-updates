<?php
/**
 * Shop emails: the retro look (teal head, mono headings, yellow button, mint frame), Reply-To = the company email,
 * a "Sets off … / expected …" line in the order mails, and a new order status "Shipped" (Feladva) with a tracking
 * number box on the order screen and its own customer mail ("Úton van a csomagod!").
 * Colours and sender are set by "Apply shop settings"; this file adds the rest.
 */

defined( 'ABSPATH' ) || exit;

/* ------------------------------------------------------------------ look */

add_filter( 'woocommerce_email_styles', function ( $css ) {
	return $css . '
#wrapper{background:#E9F1EC}
#template_container{border:2px solid #17302E!important;border-radius:12px!important;box-shadow:6px 6px 0 #14605F!important;overflow:hidden}
#template_header{background:#1F8A8A!important;border-bottom:4px solid #14605F;border-radius:0!important}
#template_header h1{font-family:"Courier New",Courier,monospace!important;font-weight:700;letter-spacing:-.5px;text-shadow:none!important}
h2,h3{font-family:"Courier New",Courier,monospace!important;color:#17302E!important}
#body_content table td,#body_content p{color:#17302E}
.td{border-color:#9FC3B8!important}
a{color:#14605F!important}
.izb-mail-ship{margin:0 0 18px;padding:12px 14px;background:#DDEFE3;border:2px solid #17302E;border-radius:10px}
.izb-mail-btn{display:inline-block;padding:12px 18px;background:#F4D35E;border:2px solid #17302E;border-radius:10px;color:#17302E!important;font-weight:700;text-decoration:none}
#template_footer #credit{color:#4E6663}';
} );

// Answers go to the company inbox.
add_filter( 'woocommerce_email_headers', function ( $headers, $id, $obj ) {
	if ( false === stripos( (string) $headers, 'reply-to' ) && 0 !== strpos( (string) $id, 'new_order' ) ) {
		$headers .= 'Reply-To: ' . get_bloginfo( 'name' ) . ' <' . izb_email() . ">\r\n";
	}
	return $headers;
}, 10, 3 );

/* ------------------------------------------------------------------ "sets off / expected" in the order mails */

add_action( 'woocommerce_email_before_order_table', function ( $order, $sent_to_admin, $plain, $email ) {
	if ( ! $order instanceof WC_Order || ! in_array( $email->id, array( 'customer_processing_order', 'customer_on_hold_order', 'new_order' ), true ) ) {
		return;
	}
	$plan = $order->get_meta( '_izb_ship' );
	if ( ! is_array( $plan ) || empty( $plan['out'] ) || ! function_exists( 'izl_arrive_words' ) ) {
		return;
	}
	$tz     = new DateTimeZone( 'Europe/Budapest' );
	$out    = izl_arrive_words( new DateTimeImmutable( $plan['out'], $tz ) );
	$arrive = izl_arrive_words( new DateTimeImmutable( $plan['arrive'], $tz ) );
	/* translators: 1: dispatch day ("on Monday, Nov 9"), 2: expected arrival day */
	$line = sprintf( __( 'Your parcel sets off %1$s and is expected %2$s.', 'izeltlab-bolt' ), $out, $arrive );
	if ( 'live' === ( $plan['type'] ?? '' ) ) {
		$line .= ' ' . __( 'Live animals travel Monday to Wednesday only, so they never spend a weekend in a depot.', 'izeltlab-bolt' );
	}
	echo $plain ? "\n" . $line . "\n\n" : '<p class="izb-mail-ship">' . esc_html( $line ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
}, 5, 4 );

/* ------------------------------------------------------------------ order status "Shipped" + tracking */

add_action( 'init', function () {
	register_post_status( 'wc-izb-shipped', array(
		'label'                     => _x( 'Shipped', 'Order status', 'izeltlab-bolt' ),
		'public'                    => false,
		'exclude_from_search'       => false,
		'show_in_admin_all_list'    => true,
		'show_in_admin_status_list' => true,
		/* translators: %s: number of orders */
		'label_count'               => _n_noop( 'Shipped <span class="count">(%s)</span>', 'Shipped <span class="count">(%s)</span>', 'izeltlab-bolt' ),
	) );
} );

add_filter( 'wc_order_statuses', function ( $s ) {
	$new = array();
	foreach ( $s as $k => $v ) {
		$new[ $k ] = $v;
		if ( 'wc-processing' === $k ) {
			$new['wc-izb-shipped'] = _x( 'Shipped', 'Order status', 'izeltlab-bolt' );
		}
	}
	return $new;
} );

// A shipped order counts as paid (reports, "My account") and can still be completed.
add_filter( 'woocommerce_order_is_paid_statuses', function ( $s ) {
	$s[] = 'izb-shipped';
	return $s;
} );
add_filter( 'bulk_actions-edit-shop_order', 'izb_bulk_shipped' );
add_filter( 'bulk_actions-woocommerce_page_wc-orders', 'izb_bulk_shipped' );
function izb_bulk_shipped( $a ) {
	$a['mark_izb-shipped'] = __( 'Change status to Shipped', 'izeltlab-bolt' );
	return $a;
}

function izb_carriers() {
	return array(
		'foxpost' => array( 'Foxpost', 'https://foxpost.hu/csomagkovetes/?code=%s' ),
		'gls'     => array( 'GLS', 'https://gls-group.com/HU/hu/csomagkovetes?match=%s' ),
	);
}

function izb_tracking_url( $order ) {
	$num = (string) $order->get_meta( '_izb_track' );
	$car = (string) $order->get_meta( '_izb_carrier' );
	$c   = izb_carriers();
	return $num && isset( $c[ $car ] ) ? sprintf( $c[ $car ][1], rawurlencode( $num ) ) : '';
}

// The box on the order screen (classic and HPOS).
add_action( 'add_meta_boxes', function () {
	$screen = function_exists( 'wc_get_page_screen_id' ) ? wc_get_page_screen_id( 'shop-order' ) : 'shop_order';
	add_meta_box( 'izb-track', 'Shipping / tracking', function ( $post_or_order ) {
		$order = $post_or_order instanceof WC_Order ? $post_or_order : wc_get_order( $post_or_order->ID );
		if ( ! $order ) {
			return;
		}
		$car = (string) $order->get_meta( '_izb_carrier' );
		wp_nonce_field( 'izb_track', 'izb_track_nonce' );
		echo '<p><label>Carrier<br><select name="izb_carrier" style="width:100%">';
		foreach ( izb_carriers() as $k => $c ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $car, $k, false ) . '>' . esc_html( $c[0] ) . '</option>';
		}
		echo '</select></label></p><p><label>Tracking number<br><input type="text" name="izb_track" style="width:100%" value="' . esc_attr( $order->get_meta( '_izb_track' ) ) . '"></label></p>';
		echo '<p class="description">Fill in, set the status to <b>Shipped</b> and save: the customer gets the "on its way" mail with the link.</p>';
		$plan = $order->get_meta( '_izb_ship' );
		if ( is_array( $plan ) && ! empty( $plan['out'] ) ) {
			echo '<p><b>Planned dispatch:</b> ' . esc_html( $plan['out'] ) . ( 'live' === $plan['type'] ? ' (live animals)' : '' ) . '</p>';
		}
		echo '<p><a class="button" target="_blank" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=izb_slip&order=' . $order->get_id() ), 'izb_slip' ) ) . '">Print packing slip</a></p>';
	}, $screen, 'side', 'high' );
} );

add_action( 'woocommerce_process_shop_order_meta', function ( $order_id ) {
	if ( empty( $_POST['izb_track_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['izb_track_nonce'] ), 'izb_track' ) ) {
		return;
	}
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}
	$order->update_meta_data( '_izb_track', sanitize_text_field( wp_unslash( $_POST['izb_track'] ?? '' ) ) );
	$order->update_meta_data( '_izb_carrier', sanitize_key( wp_unslash( $_POST['izb_carrier'] ?? '' ) ) );
	$order->save();
}, 5 );

// The tracking link on "My account" → order.
add_action( 'woocommerce_order_details_before_order_table', function ( $order ) {
	$url = izb_tracking_url( $order );
	if ( $url ) {
		echo '<p class="izb-track"><a class="button" href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html__( 'Follow the parcel', 'izeltlab-bolt' ) . '</a></p>';
	}
} );

/* ------------------------------------------------------------------ the "shipped" customer mail */

add_filter( 'woocommerce_email_classes', function ( $emails ) {
	if ( ! class_exists( 'IZB_Email_Shipped' ) ) {
		class IZB_Email_Shipped extends WC_Email {
			public function __construct() {
				$this->id             = 'izb_customer_shipped';
				$this->customer_email = true;
				$this->title          = 'Shipped (Ízeltláb)';
				$this->description    = 'Sent to the customer when the order is set to Shipped, with the tracking link.';
				$this->placeholders   = array( '{order_number}' => '' );
				add_action( 'woocommerce_order_status_izb-shipped_notification', array( $this, 'trigger' ), 10, 2 );
				parent::__construct();
			}
			public function get_default_subject() {
				return __( 'Your parcel is on its way! (order {order_number})', 'izeltlab-bolt' );
			}
			public function get_default_heading() {
				return __( 'On its way!', 'izeltlab-bolt' );
			}
			public function trigger( $order_id, $order = false ) {
				$this->setup_locale();
				$order = $order ? $order : wc_get_order( $order_id );
				if ( $order ) {
					$this->object                         = $order;
					$this->recipient                      = $order->get_billing_email();
					$this->placeholders['{order_number}'] = $order->get_order_number();
				}
				if ( $this->is_enabled() && $this->get_recipient() ) {
					$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
				}
				$this->restore_locale();
			}
			public function get_content_html() {
				ob_start();
				do_action( 'woocommerce_email_header', $this->get_heading(), $this );
				$o   = $this->object;
				$url = izb_tracking_url( $o );
				/* translators: %s: customer first name */
				echo '<p>' . esc_html( sprintf( __( 'Hello %s!', 'izeltlab-bolt' ), $o->get_billing_first_name() ) ) . '</p>';
				echo '<p>' . esc_html__( 'We have packed your order with care and handed it to the carrier. It usually arrives on the next working day.', 'izeltlab-bolt' ) . '</p>';
				if ( $url ) {
					echo '<p style="margin:20px 0"><a class="izb-mail-btn" href="' . esc_url( $url ) . '">' . esc_html__( 'Follow the parcel', 'izeltlab-bolt' ) . '</a></p>';
					/* translators: %s: tracking number */
					echo '<p>' . esc_html( sprintf( __( 'Tracking number: %s', 'izeltlab-bolt' ), $o->get_meta( '_izb_track' ) ) ) . '</p>';
				}
				if ( $this->has_live( $o ) ) {
					echo '<p>' . esc_html__( 'Live animals are inside: please take the parcel in as soon as you can and open it at room temperature.', 'izeltlab-bolt' ) . '</p>';
				}
				do_action( 'woocommerce_email_order_details', $o, false, false, $this );
				do_action( 'woocommerce_email_footer', $this );
				return ob_get_clean();
			}
			public function get_content_plain() {
				$o   = $this->object;
				$url = izb_tracking_url( $o );
				return $this->get_heading() . "\n\n" . __( 'We have packed your order with care and handed it to the carrier. It usually arrives on the next working day.', 'izeltlab-bolt' ) . ( $url ? "\n\n" . $url : '' ) . "\n";
			}
			private function has_live( $o ) {
				$plan = $o->get_meta( '_izb_ship' );
				return is_array( $plan ) && 'live' === ( $plan['type'] ?? '' );
			}
		}
	}
	$emails['IZB_Email_Shipped'] = new IZB_Email_Shipped();
	return $emails;
} );

add_filter( 'woocommerce_email_actions', function ( $a ) {
	$a[] = 'woocommerce_order_status_izb-shipped';
	return $a;
} );
