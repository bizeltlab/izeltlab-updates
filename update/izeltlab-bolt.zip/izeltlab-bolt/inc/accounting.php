<?php
/**
 * 1.2.0: for the accountant. The legal invoice comes from Számlázz.hu (its WooCommerce plugin, Dan 2026-11-05); this
 * file adds what is left:
 * - WooCommerce → Accountant export: a CSV of the orders of a period (Excel-ready: semicolons, accents right), one row
 *   per order with net, 27% VAT and gross for the products and the shipping, the payment method, the refunds and the
 *   Számlázz.hu invoice number when its plugin saved one; a totals row at the end.
 * - "Order summary (VAT)": a printable page per order (save as PDF from the print window) with the VAT lines. It is
 *   not an invoice; the page says so.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', function () {
	add_submenu_page( class_exists( 'WooCommerce' ) ? 'woocommerce' : 'options-general.php', 'Accountant export', 'Accountant export', 'view_woocommerce_reports', 'izb-accounting', 'izb_acc_page' );
}, 62 );

// [net, vat] of the products and of the shipping (+ fees with the products), in the order's currency.
function izb_acc_split( $o ) {
	$items_net = 0;
	$items_vat = 0;
	foreach ( $o->get_items( array( 'line_item', 'fee' ) ) as $it ) {
		$items_net += (float) $it->get_total();
		$items_vat += (float) $it->get_total_tax();
	}
	$ship_net = (float) $o->get_shipping_total();
	$ship_vat = (float) $o->get_shipping_tax();
	return array( $items_net, $items_vat, $ship_net, $ship_vat );
}

// A value some other plugin saved on the order, found by part of its key (Számlázz.hu invoice number, tax number).
function izb_acc_meta( $o, $needles ) {
	foreach ( $o->get_meta_data() as $m ) {
		$k = strtolower( (string) $m->key );
		foreach ( (array) $needles as $n ) {
			if ( preg_match( $n, $k ) && is_scalar( $m->value ) && '' !== (string) $m->value ) {
				return (string) $m->value;
			}
		}
	}
	return '';
}

function izb_acc_num( $n, $dec = 2 ) {
	return number_format( round( (float) $n, $dec ), $dec, ',', '' );
}

function izb_acc_page() {
	if ( ! current_user_can( 'view_woocommerce_reports' ) ) {
		return;
	}
	$first = wp_date( 'Y-m-01', strtotime( 'first day of last month' ) );
	$last  = wp_date( 'Y-m-t', strtotime( 'last day of last month' ) );
	echo '<div class="wrap"><h1>Accountant export</h1>';
	echo '<p>A CSV of the paid orders of a period (Excel opens it; semicolons, Hungarian accents), one row per order: products and shipping each with net, VAT (27%) and gross, payment method, refunds, and the Számlázz.hu invoice number once its plugin has made the invoice. Send it to the accountant with the invoices from Számlázz.hu.</p>';
	echo '<form method="get" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wp_nonce_field( 'izb_acc_csv' );
	echo '<input type="hidden" name="action" value="izb_acc_csv"><table class="form-table" role="presentation"><tr><th>From</th><td><input type="date" name="from" value="' . esc_attr( $first ) . '"></td></tr><tr><th>To</th><td><input type="date" name="to" value="' . esc_attr( $last ) . '"></td></tr>';
	echo '<tr><th>Orders</th><td><label><input type="radio" name="which" value="paid" checked> paid (processing, shipped, completed, refunded)</label><br><label><input type="radio" name="which" value="all"> every order, any status</label></td></tr></table>';
	submit_button( 'Download CSV', 'primary', '', false );
	echo '</form>';
	echo '<h2>Order summary (VAT)</h2><p>Every order screen has a "Print order summary (VAT)" button (save as PDF from the print window). It lists net, VAT and gross; it is not an invoice.</p></div>';
}

add_action( 'admin_post_izb_acc_csv', function () {
	check_admin_referer( 'izb_acc_csv' );
	if ( ! current_user_can( 'view_woocommerce_reports' ) ) {
		wp_die();
	}
	$tz   = new DateTimeZone( 'Europe/Budapest' );
	$from = DateTimeImmutable::createFromFormat( '!Y-m-d', sanitize_text_field( wp_unslash( $_GET['from'] ?? '' ) ), $tz );
	$to   = DateTimeImmutable::createFromFormat( '!Y-m-d', sanitize_text_field( wp_unslash( $_GET['to'] ?? '' ) ), $tz );
	if ( ! $from || ! $to ) {
		wp_die( 'Pick two dates.' );
	}
	$all      = 'all' === ( $_GET['which'] ?? '' );
	$statuses = $all ? array_keys( wc_get_order_statuses() ) : array_merge( wc_get_is_paid_statuses(), array( 'refunded' ) );
	$orders   = wc_get_orders( array(
		'status'       => array_map( function ( $s ) {
			return preg_replace( '/^wc-/', '', $s );
		}, $statuses ),
		'type'         => 'shop_order',
		'date_created' => $from->getTimestamp() . '...' . ( $to->modify( '+1 day' )->getTimestamp() - 1 ),
		'limit'        => -1,
		'orderby'      => 'date',
		'order'        => 'ASC',
	) );
	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=izeltlab-rendelesek-' . $from->format( 'Y-m-d' ) . '_' . $to->format( 'Y-m-d' ) . '.csv' );
	$out = fopen( 'php://output', 'w' ); // phpcs:ignore
	fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore
	fputcsv( $out, array(
		__( 'Order', 'izeltlab-bolt' ), __( 'Date', 'izeltlab-bolt' ), __( 'Paid', 'izeltlab-bolt' ), __( 'Status', 'izeltlab-bolt' ),
		__( 'Customer', 'izeltlab-bolt' ), __( 'Company', 'izeltlab-bolt' ), __( 'Tax number', 'izeltlab-bolt' ), __( 'Postcode', 'izeltlab-bolt' ), __( 'City', 'izeltlab-bolt' ), __( 'Address', 'izeltlab-bolt' ), __( 'Email', 'izeltlab-bolt' ),
		__( 'Payment method', 'izeltlab-bolt' ), __( 'Shipping method', 'izeltlab-bolt' ),
		__( 'Products net', 'izeltlab-bolt' ), __( 'Products VAT', 'izeltlab-bolt' ), __( 'Shipping net', 'izeltlab-bolt' ), __( 'Shipping VAT', 'izeltlab-bolt' ),
		__( 'Net total', 'izeltlab-bolt' ), __( 'VAT total', 'izeltlab-bolt' ), __( 'Gross total', 'izeltlab-bolt' ), __( 'Refunded', 'izeltlab-bolt' ), __( 'Currency', 'izeltlab-bolt' ), __( 'Invoice number', 'izeltlab-bolt' ),
	), ';' );
	$sum = array_fill( 0, 8, 0 );
	foreach ( $orders as $o ) {
		if ( ! $o instanceof WC_Order || $o instanceof WC_Order_Refund ) {
			continue;
		}
		list( $in, $iv, $sn, $sv ) = izb_acc_split( $o );
		$gross = (float) $o->get_total();
		$ref   = (float) $o->get_total_refunded();
		$row   = array( $in, $iv, $sn, $sv, $in + $sn, $iv + $sv, $gross, $ref );
		foreach ( $row as $i => $v ) {
			$sum[ $i ] += $v;
		}
		fputcsv( $out, izb_csv_row( array(
			$o->get_order_number(),
			$o->get_date_created() ? wp_date( 'Y.m.d. H:i', $o->get_date_created()->getTimestamp() ) : '',
			$o->get_date_paid() ? wp_date( 'Y.m.d.', $o->get_date_paid()->getTimestamp() ) : '',
			wc_get_order_status_name( $o->get_status() ),
			$o->get_formatted_billing_full_name(),
			$o->get_billing_company(),
			izb_acc_meta( $o, array( '/adoszam/', '/tax_?number/', '/vat_?number/' ) ),
			$o->get_billing_postcode(),
			$o->get_billing_city(),
			trim( $o->get_billing_address_1() . ' ' . $o->get_billing_address_2() ),
			$o->get_billing_email(),
			$o->get_payment_method_title(),
			$o->get_shipping_method(),
			izb_acc_num( $in ), izb_acc_num( $iv ), izb_acc_num( $sn ), izb_acc_num( $sv ),
			izb_acc_num( $in + $sn ), izb_acc_num( $iv + $sv ), izb_acc_num( $gross, wc_get_price_decimals() ), izb_acc_num( $ref, wc_get_price_decimals() ),
			$o->get_currency(),
			izb_acc_meta( $o, array( '/szamlazz.*(invoice|szamla).*(name|number|szam|id)/', '/szamlazz.*_name$/' ) ),
		) ), ';' );
	}
	fputcsv( $out, array_merge( array( __( 'Total', 'izeltlab-bolt' ), count( $orders ) ), array_fill( 0, 11, '' ), array(
		izb_acc_num( $sum[0] ), izb_acc_num( $sum[1] ), izb_acc_num( $sum[2] ), izb_acc_num( $sum[3] ), izb_acc_num( $sum[4] ), izb_acc_num( $sum[5] ), izb_acc_num( $sum[6], wc_get_price_decimals() ), izb_acc_num( $sum[7], wc_get_price_decimals() ),
	) ), ';' );
	exit;
} );

/* ------------------------------------------------------------------ Order summary (VAT), printable */

add_action( 'add_meta_boxes', function () {
	$screen = function_exists( 'wc_get_page_screen_id' ) ? wc_get_page_screen_id( 'shop-order' ) : 'shop_order';
	add_meta_box( 'izb-vat', 'Order summary (VAT)', function ( $post_or_order ) {
		$order = $post_or_order instanceof WC_Order ? $post_or_order : wc_get_order( $post_or_order->ID );
		if ( $order ) {
			echo '<p><a class="button" target="_blank" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=izb_vat&order=' . $order->get_id() ), 'izb_vat' ) ) . '">Print order summary (VAT)</a></p><p class="description">Net, 27% VAT, gross. Not an invoice (that comes from Számlázz.hu).</p>';
		}
	}, $screen, 'side', 'default' );
} );

add_action( 'admin_post_izb_vat', function () {
	check_admin_referer( 'izb_vat' );
	$o = wc_get_order( absint( $_GET['order'] ?? 0 ) );
	if ( ! $o || ! current_user_can( 'edit_shop_orders' ) ) {
		wp_die();
	}
	$co = izb_opt();
	list( $in, $iv, $sn, $sv ) = izb_acc_split( $o );
	$m = function ( $n ) {
		return esc_html( html_entity_decode( wp_strip_all_tags( wc_price( $n, array( 'decimals' => 2 ) ) ), ENT_QUOTES, 'UTF-8' ) );
	};
	header( 'Content-Type: text/html; charset=utf-8' );
	echo '<!doctype html><html lang="hu"><head><meta charset="utf-8"><title>Rendelés-összesítő #' . esc_html( $o->get_order_number() ) . '</title><style>
	body{font:13px/1.45 Arial,sans-serif;color:#17302E;margin:0}.page{width:190mm;margin:10mm auto}
	h1{font-size:20px;margin:0 0 2mm}.top{display:flex;justify-content:space-between;gap:8mm;border-bottom:2px solid #17302E;padding-bottom:4mm;margin-bottom:5mm}
	table{width:100%;border-collapse:collapse;margin:3mm 0}th,td{padding:2mm;border-bottom:1px solid #9FC3B8;text-align:left}th.n,td.n{text-align:right;white-space:nowrap}
	tfoot td{font-weight:700;border-top:2px solid #17302E}.not{margin-top:6mm;padding:3mm;border:1px dashed #9FC3B8;font-size:12px}
	@media print{.noprint{display:none}.page{margin:0 auto}}</style></head><body><p class="noprint" style="text-align:center"><button onclick="print()">Nyomtatás / mentés PDF-be</button></p><div class="page">';
	echo '<div class="top"><div><h1>Rendelés-összesítő</h1><div>#' . esc_html( $o->get_order_number() ) . ' · ' . esc_html( $o->get_date_created() ? wp_date( 'Y.m.d.', $o->get_date_created()->getTimestamp() ) : '' ) . '</div><div>Fizetés: ' . esc_html( $o->get_payment_method_title() ) . '</div></div>';
	echo '<div><b>' . esc_html( $co['co_name'] ? $co['co_name'] : get_bloginfo( 'name' ) ) . '</b><br>' . esc_html( $co['co_address'] ) . '<br>' . ( $co['co_tax'] ? 'Adószám: ' . esc_html( $co['co_tax'] ) . '<br>' : '' ) . esc_html( izb_email() ) . '</div>';
	echo '<div><b>Vevő</b><br>' . wp_kses_post( $o->get_formatted_billing_address() ) . '</div></div>';
	echo '<table><thead><tr><th>Tétel</th><th class="n">Db</th><th class="n">Nettó</th><th class="n">ÁFA</th><th class="n">ÁFA</th><th class="n">Bruttó</th></tr></thead><tbody>';
	foreach ( $o->get_items( array( 'line_item', 'fee' ) ) as $it ) {
		$net  = (float) $it->get_total();
		$tax  = (float) $it->get_total_tax();
		$rate = $net ? round( $tax / $net * 100 ) : 0;
		$meta = $it instanceof WC_Order_Item_Product ? wp_strip_all_tags( wc_display_item_meta( $it, array( 'echo' => false, 'separator' => ', ', 'before' => '', 'after' => '' ) ) ) : '';
		echo '<tr><td>' . esc_html( $it->get_name() ) . ( $meta ? '<br><small>' . esc_html( $meta ) . '</small>' : '' ) . '</td><td class="n">' . (int) ( $it instanceof WC_Order_Item_Product ? $it->get_quantity() : 1 ) . '</td><td class="n">' . $m( $net ) . '</td><td class="n">' . (int) $rate . '%</td><td class="n">' . $m( $tax ) . '</td><td class="n">' . $m( $net + $tax ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	if ( $sn || $sv ) {
		$rate = $sn ? round( $sv / $sn * 100 ) : 0;
		echo '<tr><td>Szállítás: ' . esc_html( $o->get_shipping_method() ) . '</td><td class="n">1</td><td class="n">' . $m( $sn ) . '</td><td class="n">' . (int) $rate . '%</td><td class="n">' . $m( $sv ) . '</td><td class="n">' . $m( $sn + $sv ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</tbody><tfoot><tr><td colspan="2">Összesen</td><td class="n">' . $m( $in + $sn ) . '</td><td></td><td class="n">' . $m( $iv + $sv ) . '</td><td class="n">' . $m( (float) $o->get_total() ) . '</td></tr></tfoot></table>'; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '<p class="not">Ez a rendelés összesítője, nem számla. A számlát a Számlázz.hu állítja ki és küldi el.</p></div></body></html>';
	exit;
} );
