<?php
// ==========================================================================
//  FILE: inc/speed.php   (Ízeltláb Bolt plugin)
//  WHAT: Photos that load fast without looking different: WebP copies, right sizes, "Optimise existing
//        photos" (1.13.0: every photo to the current standard, unused files removed), no 1536/2048px copies, a heavy
//        photo warning on the product's edit page.
//  SEEN: Behind the scenes; the button on the Ízeltláb Bolt settings page; the product edit page's notice.
//  SECTIONS IN THIS FILE:
//    1. The first photo of a product page loads first
//    2. Optimise existing photos (batches of 5, from the settings page; old files removed a day later since 1.19.4)
//    3. No 1536px and 2048px copies
//    4. Heavy photo warning on the product page in the dashboard
//    5. Share image (JPEG 1200×630, made once per photo + frame)
// ==========================================================================

/**
 * 1.2.0: photos that load fast, without looking different.
 * - New uploads: anything bigger than "Largest photo side" (2000 px) is scaled down (the original is kept), and every
 *   size WordPress makes is WebP (about a third of the JPEG weight at the same look). Browsers without WebP: none of
 *   the ones in use any more.
 * - "Optimise existing photos" (settings page) makes the WebP sizes for photos uploaded before; the old files stay on
 *   disk, so nothing that links them directly breaks.
 * - The first photo of a product page (the Codex card's, the biggest thing on the screen) loads first instead of lazily;
 *   every other photo stays lazy.
 * Share images (Facebook / Instagram / Messenger) are always JPEG: seo.php uses izb_share_image() below.
 */

defined( 'ABSPATH' ) || exit;

function izb_webp_ok() {
	static $ok = null;
	if ( null === $ok ) {
		$ok = function_exists( 'wp_image_editor_supports' ) && wp_image_editor_supports( array( 'mime_type' => 'image/webp' ) );
	}
	return $ok;
}

// Bigger uploads are scaled down to this (WordPress's own default is 2560).
add_filter( 'big_image_size_threshold', function ( $px ) {
	return izb_opt( 'img_on' ) ? max( 1200, (int) izb_opt( 'img_max' ) ) : $px;
} );

// JPEG/PNG uploads → WebP sizes.
add_filter( 'image_editor_output_format', function ( $formats ) {
	if ( izb_opt( 'img_on' ) && izb_opt( 'img_webp' ) && izb_webp_ok() && empty( $GLOBALS['izb_no_webp'] ) ) {
		$formats['image/jpeg'] = 'image/webp';
		$formats['image/png']  = 'image/webp';
	}
	return $formats;
} );

add_filter( 'wp_editor_set_quality', function ( $q, $mime = '' ) {
	if ( izb_opt( 'img_on' ) && 'image/webp' === $mime && ! empty( $GLOBALS['izb_img_q'] ) ) {
		return (int) $GLOBALS['izb_img_q']; // 1.14.0: a heavy photo's second, tighter try (izb_img_redo())
	}
	return izb_opt( 'img_on' ) && 'image/webp' === $mime ? max( 50, min( 95, (int) izb_opt( 'img_quality' ) ) ) : $q;
}, 10, 2 );

// ==========================================================================
//  The first photo of a product page loads first
// ==========================================================================

add_filter( 'wp_get_attachment_image_attributes', function ( $attr, $att ) {
	static $done = false;
	if ( $done || is_admin() || ! function_exists( 'is_product' ) || ! is_product() || empty( $attr['loading'] ) || 'lazy' !== $attr['loading'] ) {
		return $attr;
	}
	$pid   = get_queried_object_id();
	$first = function_exists( 'fsz_card_image_ids' ) && function_exists( 'izl_is_codex' ) && izl_is_codex( $pid ) ? fsz_card_image_ids( $pid ) : array( (int) get_post_thumbnail_id( $pid ) );
	if ( $first && (int) $att->ID === (int) reset( $first ) ) {
		$done                  = true;
		$attr['loading']       = 'eager';
		$attr['fetchpriority'] = 'high';
		$attr['decoding']      = 'async';
	}
	return $attr;
}, 30, 2 );

// ==========================================================================
//  Optimise existing photos (batches of 5, from the settings page; old files removed a day later since 1.19.4)
// ==========================================================================

// 1.13.0 (Dan, 2026-11-19: "find a long term solution to image delivery"): the button now brings EVERY photo to the
// shop's current standard, not only old JPEGs: photos uploaded as WebP before Bolt existed (October 2026) were saved by
// WordPress at its own quality (86), about a fifth heavier than Bolt's 80, and none had the 600px size the theme asks
// for since 3.14.0 (between 416 and 768: what most phones need). Pass 2 makes all sizes again from the original, then
// deletes the files the photo no longer uses (the 1536px and 2048px copies the shop never shows, and the old JPEG
// sizes the first pass kept), unless a page, product text or setting still links that file by name. When everything
// is done the page cache is emptied, so no cached page points at a file that is gone.
// A photo is done when it has _izb_photos = 2 (the version of the pass).
// 1.14.0 (pass 3, Dan's list 2026-11-19): a photo whose phone-size files are still heavy for their size (busy
// backgrounds: more than 0.16 bytes per dot, e.g. a 600x600 file over 58 KB) is made once more at quality 72 instead of
// 80; the front page's back cards had an 86 KB one. Other photos come out exactly as in pass 2.
// Filters: izb_heavy_bpp (0.16), izb_heavy_quality (72).
define( 'IZB_PHOTO_PASS', '3' );

function izb_img_todo( $limit = 5 ) {
	return get_posts( array(
		'post_type'      => 'attachment',
		'post_status'    => 'inherit',
		'post_mime_type' => array( 'image/jpeg', 'image/png', 'image/webp' ),
		'posts_per_page' => $limit,
		'fields'         => 'ids',
		'orderby'        => 'ID',
		'order'          => 'ASC',
		'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
			'relation' => 'OR',
			array( 'key' => '_izb_photos', 'compare' => 'NOT EXISTS' ),
			array( 'key' => '_izb_photos', 'value' => IZB_PHOTO_PASS, 'compare' => '!=' ),
		),
	) );
}

// The size files of a photo as listed in its data (file names only, without the folder).
function izb_img_size_files( $meta ) {
	$out = array();
	foreach ( (array) ( is_array( $meta ) && isset( $meta['sizes'] ) ? $meta['sizes'] : array() ) as $s ) {
		if ( ! empty( $s['file'] ) ) {
			$out[] = wp_basename( (string) $s['file'] );
		}
		foreach ( (array) ( isset( $s['sources'] ) ? $s['sources'] : array() ) as $alt ) { // WordPress's own WebP copies
			if ( ! empty( $alt['file'] ) ) {
				$out[] = wp_basename( (string) $alt['file'] );
			}
		}
	}
	return array_values( array_unique( $out ) );
}

function izb_img_bytes( $id ) {
	$meta = wp_get_attachment_metadata( $id );
	$file = get_attached_file( $id );
	if ( ! $file || ! is_array( $meta ) ) {
		return 0;
	}
	$dir   = trailingslashit( dirname( $file ) );
	$bytes = is_readable( $file ) ? filesize( $file ) : 0;
	foreach ( izb_img_size_files( $meta ) as $f ) {
		$bytes += is_readable( $dir . $f ) ? filesize( $dir . $f ) : 0;
	}
	return $bytes;
}

// Is this file name written anywhere in the site's texts, data or settings (a page, a product text, a Codex photo link,
// a widget, another photo)? Then it is kept even when the photo no longer lists it.
function izb_img_linked( $name ) {
	global $wpdb;
	$like = '%' . $wpdb->esc_like( $name ) . '%';
	// phpcs:disable WordPress.DB.DirectDatabaseQuery
	if ( $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type NOT IN ('revision','attachment') AND ( post_content LIKE %s OR post_excerpt LIKE %s ) LIMIT 1", $like, $like ) ) ) {
		return true;
	}
	// also any photo's own data (another upload that happens to use this name keeps it; this photo's new data no
	// longer lists it, as it is saved before anything is deleted)
	if ( $wpdb->get_var( $wpdb->prepare( "SELECT meta_id FROM {$wpdb->postmeta} WHERE meta_value LIKE %s LIMIT 1", $like ) ) ) {
		return true;
	}
	return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT option_id FROM {$wpdb->options} WHERE option_value LIKE %s LIMIT 1", $like ) );
	// phpcs:enable
}

// 1.14.0: true when one of the phone-size files (the 416, 600 and 768px ones) is heavy for its number of dots.
function izb_img_too_heavy( $meta, $dir ) {
	$bpp = (float) apply_filters( 'izb_heavy_bpp', 0.16 );
	foreach ( (array) ( isset( $meta['sizes'] ) ? $meta['sizes'] : array() ) as $sz ) {
		$w = isset( $sz['width'] ) ? (int) $sz['width'] : 0;
		$h = isset( $sz['height'] ) ? (int) $sz['height'] : 0;
		if ( $w < 400 || $w > 800 || $h < 1 || empty( $sz['file'] ) || ! is_readable( $dir . $sz['file'] ) ) {
			continue;
		}
		if ( filesize( $dir . $sz['file'] ) > $bpp * $w * $h ) {
			return true;
		}
	}
	return false;
}

// Makes the sizes again from the original photo, then removes the size files it no longer uses (see above).
// Returns [bytes before, bytes after] (after = what is left on disk for this photo).
function izb_img_redo( $id ) {
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$orig = function_exists( 'wp_get_original_image_path' ) ? wp_get_original_image_path( $id ) : get_attached_file( $id );
	if ( ! $orig || ! is_readable( $orig ) ) {
		update_post_meta( $id, '_izb_photos', IZB_PHOTO_PASS ); // nothing to work from: never asked again
		update_post_meta( $id, '_izb_webp', 'missing' );
		return array( 0, 0 );
	}
	$file   = get_attached_file( $id );
	$dir    = trailingslashit( dirname( $file ) );
	$old    = wp_get_attachment_metadata( $id );
	$before = izb_img_bytes( $id );
	// every size file of this photo on disk (name-WIDTHxHEIGHT.ext), also those the data forgot (the first pass's JPEGs)
	$stem    = preg_replace( '/(-scaled|-rotated)?\.[a-z0-9]+$/i', '', wp_basename( $orig ) );
	$on_disk = array();
	foreach ( (array) glob( $dir . $stem . '-*' ) as $path ) {
		$n = wp_basename( (string) $path );
		if ( preg_match( '/^' . preg_quote( $stem, '/' ) . '-\d+x\d+\.(jpe?g|png|webp|avif)$/i', $n ) ) {
			$on_disk[] = $n;
		}
	}
	$before += array_sum( array_map( function ( $n ) use ( $dir ) {
		return is_readable( $dir . $n ) ? (int) filesize( $dir . $n ) : 0;
	}, array_diff( $on_disk, izb_img_size_files( $old ) ) ) );
	$meta = wp_generate_attachment_metadata( $id, $orig );
	if ( $meta && izb_img_too_heavy( $meta, $dir ) ) {
		$GLOBALS['izb_img_q'] = max( 50, min( 95, (int) apply_filters( 'izb_heavy_quality', 72 ) ) );
		$again                = wp_generate_attachment_metadata( $id, $orig );
		unset( $GLOBALS['izb_img_q'] );
		$meta = $again ? $again : $meta;
	}
	if ( ! $meta || empty( $meta['sizes'] ) && empty( $meta['file'] ) ) {
		update_post_meta( $id, '_izb_photos', 'failed' );
		return array( $before, $before );
	}
	if ( is_array( $old ) && ! empty( $old['image_meta'] ) && empty( $meta['image_meta'] ) ) {
		$meta['image_meta'] = $old['image_meta'];
	}
	wp_update_attachment_metadata( $id, $meta );
	// what this photo uses now, and its own files (main file, original): never removed
	$keep = array_merge( izb_img_size_files( $meta ), array( wp_basename( $file ), wp_basename( $orig ) ) );
	$gone = array_diff( array_unique( array_merge( $on_disk, izb_img_size_files( $old ) ) ), $keep );
	// 1.19.4: not deleted now but a day later (izb_img_later()): a page already open in a shopper's browser, or still in
	// the page cache until the pass ends, loads its photos when they scroll into view and named the old files.
	foreach ( $gone as $n ) {
		if ( is_file( $dir . $n ) && ! izb_img_linked( $n ) ) {
			izb_img_later( $dir . $n );
		}
	}
	update_post_meta( $id, '_izb_photos', IZB_PHOTO_PASS );
	update_post_meta( $id, '_izb_webp', '1' );
	$after = izb_img_bytes( $id );
	foreach ( $gone as $n ) { // a kept (still linked) old file still takes room
		$after += is_file( $dir . $n ) ? (int) filesize( $dir . $n ) : 0;
	}
	return array( $before, $after );
}

// 1.19.4 (Dan, 2026-11-27: the Ászkalak tile showed a broken photo on the front page while its own page was fine): the
// files a photo no longer uses are kept for a day and removed then (izb_img_sweep, also on the nightly upkeep), so a
// page that was loaded or cached before the photo was made again still finds every photo it names. Before, they were
// removed at once, and a tile further down an open page (its photo loads when it scrolls into view) came up empty.
// Filter: izb_img_keep_old (seconds, DAY_IN_SECONDS).
function izb_img_later( $path ) {
	$list            = (array) get_option( 'izb_img_later', array() );
	$list[ $path ]   = time();
	update_option( 'izb_img_later', $list, false );
	if ( ! wp_next_scheduled( 'izb_img_sweep' ) ) {
		wp_schedule_single_event( time() + (int) apply_filters( 'izb_img_keep_old', DAY_IN_SECONDS ) + MINUTE_IN_SECONDS, 'izb_img_sweep' );
	}
}

function izb_img_sweep() {
	$list = (array) get_option( 'izb_img_later', array() );
	if ( ! $list ) {
		return;
	}
	$keep = (int) apply_filters( 'izb_img_keep_old', DAY_IN_SECONDS );
	$up   = wp_get_upload_dir();
	$base = trailingslashit( wp_normalize_path( $up['basedir'] ) );
	foreach ( $list as $path => $at ) {
		if ( time() - (int) $at < $keep ) {
			continue;
		}
		unset( $list[ $path ] );
		$path = wp_normalize_path( (string) $path );
		// only a file in the uploads folder that nothing names again in the meantime
		if ( 0 === strpos( $path, $base ) && is_file( $path ) && ! izb_img_linked( wp_basename( $path ) ) ) {
			wp_delete_file( $path );
		}
	}
	if ( $list ) {
		update_option( 'izb_img_later', $list, false );
		if ( ! wp_next_scheduled( 'izb_img_sweep' ) ) {
			wp_schedule_single_event( time() + HOUR_IN_SECONDS, 'izb_img_sweep' );
		}
	} else {
		delete_option( 'izb_img_later' );
	}
}
add_action( 'izb_img_sweep', 'izb_img_sweep' );

add_action( 'wp_ajax_izb_img_batch', function () {
	check_ajax_referer( 'izb_img', 'nonce' );
	if ( ! current_user_can( 'upload_files' ) || ! izb_webp_ok() ) {
		wp_send_json_error( 'WebP is not supported by this server.' );
	}
	$GLOBALS['izb_no_webp'] = ! izb_opt( 'img_webp' );
	$b = 0;
	$a = 0;
	foreach ( izb_img_todo( 5 ) as $id ) {
		list( $x, $y ) = izb_img_redo( $id );
		$b += $x;
		$a += $y;
	}
	$left = count( izb_img_todo( 500 ) );
	if ( ! $left && function_exists( 'izb_soon_purge' ) ) {
		izb_soon_purge(); // cached pages may name files that are gone
	}
	wp_send_json_success( array( 'before' => $b, 'after' => $a, 'left' => $left ) );
} );

// Settings page box.
function izb_img_box() {
	$left = count( izb_img_todo( 500 ) );
	echo '<h2 id="izb-photos">Photos</h2>';
	if ( ! izb_webp_ok() ) {
		echo '<p><b>This server cannot make WebP images</b> (ask the host to turn on WebP in PHP GD or Imagick). Uploads are still scaled down.</p>';
		return;
	}
	echo '<p>' . ( $left ? (int) $left . ' photo(s) are not at the shop\'s current standard yet (lighter WebP files, the 600px size phones use, no unused big copies).' : 'All photos are at the shop\'s current standard.' ) . ' New uploads are done by themselves.</p>';
	if ( $left ) {
		echo '<p><button type="button" class="button button-primary" id="izb-img-go">Optimise existing photos</button> <span id="izb-img-msg"></span></p>';
		echo '<script>(function(){var b=document.getElementById("izb-img-go"),m=document.getElementById("izb-img-msg"),B=0,A=0;if(!b)return;b.onclick=function(){b.disabled=true;step();};function kb(n){return Math.round(n/1024)+" KB";}function step(){var f=new FormData();f.append("action","izb_img_batch");f.append("nonce",' . wp_json_encode( wp_create_nonce( 'izb_img' ) ) . ');fetch(ajaxurl,{method:"POST",body:f,credentials:"same-origin"}).then(function(r){return r.json();}).then(function(r){if(!r.success){m.textContent=r.data||"Error";b.disabled=false;return;}B+=r.data.before;A+=r.data.after;m.textContent=r.data.left+" left · "+kb(B)+" → "+kb(A);if(r.data.left>0){step();}else{m.textContent="Done: "+kb(B)+" → "+kb(A)+" on disk. The page cache was emptied.";}}).catch(function(){m.textContent="Stopped. Press again to go on.";b.disabled=false;});}})();</script>';
	}
}

// ==========================================================================
//  No 1536px and 2048px copies
// ==========================================================================

// 1.13.0: WordPress makes a 1536px and a 2048px copy of every upload for very large screens. The shop never shows a
// photo that big (the theme and Codex stop at 1024px, the zoom uses the original), so they only filled the 1 GB disk.
// While "Lighter photos" is on they are no longer made.
add_filter( 'intermediate_image_sizes_advanced', function ( $sizes ) {
	if ( izb_opt( 'img_on' ) ) {
		unset( $sizes['1536x1536'], $sizes['2048x2048'] );
	}
	return $sizes;
} );

// ==========================================================================
//  Heavy photo warning on the product page in the dashboard
// ==========================================================================

// 1.13.0: when a product's photos are not at the current standard yet, or one is still heavy after it (a 768px file
// over 150 KB: usually a very busy or noisy picture), the product's edit page says so at the top, with the way out.
// Nothing is changed by itself. Filter: izb_heavy_photo_kb (150).
add_action( 'admin_notices', function () {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || 'product' !== $screen->id || 'post' !== $screen->base || ! izb_opt( 'img_on' ) || ! current_user_can( 'upload_files' ) ) {
		return;
	}
	$pid = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
	$product = $pid && function_exists( 'wc_get_product' ) ? wc_get_product( $pid ) : null;
	if ( ! $product ) {
		return;
	}
	$ids = array_merge( array( (int) $product->get_image_id() ), array_map( 'intval', (array) $product->get_gallery_image_ids() ) );
	if ( function_exists( 'fsz_card_image_ids' ) ) {
		$ids = array_merge( $ids, array_map( 'intval', (array) fsz_card_image_ids( $pid ) ) );
	}
	$limit = 1024 * (int) apply_filters( 'izb_heavy_photo_kb', 150 );
	$old   = 0;
	$heavy = array();
	foreach ( array_unique( array_filter( $ids ) ) as $id ) {
		if ( IZB_PHOTO_PASS !== (string) get_post_meta( $id, '_izb_photos', true ) ) {
			$old++;
			continue;
		}
		$src  = wp_get_attachment_image_src( $id, 'medium_large' );
		$file = $src ? trailingslashit( dirname( (string) get_attached_file( $id ) ) ) . wp_basename( (string) strtok( $src[0], '?' ) ) : '';
		$kb   = $file && is_readable( $file ) ? (int) filesize( $file ) : 0;
		if ( $kb > $limit ) {
			$heavy[] = get_the_title( $id ) . ' (' . round( $kb / 1024 ) . ' KB)';
		}
	}
	if ( ! $old && ! $heavy ) {
		return;
	}
	$link = admin_url( 'admin.php?page=izeltlab-bolt#izb-photos' );
	echo '<div class="notice notice-warning"><p><b>Photos:</b> ';
	if ( $old ) {
		/* translators: none, dashboard only */
		echo esc_html( $old . ' photo(s) of this product are not optimised yet. ' ) . '<a href="' . esc_url( $link ) . '">Ízeltláb Bolt → Optimise existing photos</a> ';
	}
	if ( $heavy ) {
		echo esc_html( 'Still heavy on phones: ' . implode( ', ', $heavy ) . '. A calmer background or a slightly smaller crop of the original makes it lighter.' );
	}
	echo '</p></div>';
} );

// ==========================================================================
//  Share image (JPEG 1200×630, made once per photo + frame)
// ==========================================================================

// The URL of a 1200×630 JPEG of a photo, cut around its saved frame centre (Codex / Edit photos), or ''.
function izb_share_image( $att_id, $frame = array( 50, 50, 1 ) ) {
	$att_id = (int) $att_id;
	$src    = $att_id && function_exists( 'wp_get_original_image_path' ) ? wp_get_original_image_path( $att_id ) : get_attached_file( $att_id );
	if ( ! $src || ! is_readable( $src ) ) {
		return '';
	}
	$up   = wp_upload_dir();
	$key  = substr( md5( $src . filemtime( $src ) . implode( ',', $frame ) ), 0, 10 );
	$rel  = 'izb-share/' . $att_id . '-' . $key . '.jpg';
	$file = trailingslashit( $up['basedir'] ) . $rel;
	if ( ! file_exists( $file ) ) {
		$ed = wp_get_image_editor( $src );
		if ( is_wp_error( $ed ) ) {
			return '';
		}
		$size = $ed->get_size();
		$w    = (int) $size['width'];
		$h    = (int) $size['height'];
		$zoom = max( 1, (float) $frame[2] );
		// the biggest 1200:630 window inside the photo (smaller when the frame is zoomed in), centred on the frame
		$cw = min( $w, $h * 1200 / 630 ) / $zoom;
		$ch = $cw * 630 / 1200;
		$cx = max( 0, min( $w - $cw, $w * $frame[0] / 100 - $cw / 2 ) );
		$cy = max( 0, min( $h - $ch, $h * $frame[1] / 100 - $ch / 2 ) );
		$ed->crop( (int) round( $cx ), (int) round( $cy ), (int) round( $cw ), (int) round( $ch ), 1200, 630 );
		$ed->set_quality( 84 );
		wp_mkdir_p( dirname( $file ) );
		$GLOBALS['izb_no_webp'] = true;
		$saved = $ed->save( $file, 'image/jpeg' );
		$GLOBALS['izb_no_webp'] = false;
		if ( is_wp_error( $saved ) ) {
			return '';
		}
	}
	return trailingslashit( $up['baseurl'] ) . $rel;
}

// New uploads made while WebP is on need no "optimise" later (1.13.0: they are made to the current standard at once).
add_filter( 'wp_generate_attachment_metadata', function ( $meta, $id, $context = 'create' ) {
	if ( 'create' === $context && izb_opt( 'img_on' ) && izb_opt( 'img_webp' ) && izb_webp_ok() && empty( $GLOBALS['izb_no_webp'] ) ) {
		update_post_meta( $id, '_izb_webp', '1' );
		update_post_meta( $id, '_izb_photos', IZB_PHOTO_PASS );
	}
	return $meta;
}, 10, 3 );
