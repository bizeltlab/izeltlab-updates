<?php
// ==========================================================================
//  FILE: inc/speed.php   (Ízeltláb Bolt plugin)
//  WHAT: Photos that load fast without looking different: WebP copies, right sizes, "Optimise existing
//        photos".
//  SEEN: Behind the scenes; the button on the Ízeltláb Bolt settings page.
//  SECTIONS IN THIS FILE:
//    1. The first photo of a product page loads first
//    2. Optimise existing photos (batches of 5, from the settings page)
//    3. Share image (JPEG 1200×630, made once per photo + frame)
// ==========================================================================

/**
 * 1.2.0: photos that load fast, without looking different.
 * - New uploads: anything bigger than "Largest photo side" (2000 px) is scaled down (the original is kept), and every
 *   size WordPress makes is WebP (about a third of the JPEG weight at the same look). Browsers without WebP: none of
 *   the ones in use any more.
 * - "Optimise existing photos" (settings page) makes the WebP sizes for photos uploaded before; the old files stay on
 *   disk, so nothing that links them directly breaks.
 * - The first photo of a product page (the Codex card's, the biggest thing on the screen) loads first instead of lazily;
 *   every other photo stays lazy.
 * Share images (Facebook / Instagram / Messenger) are always JPEG: seo.php uses izb_share_image() below.
 */

defined( 'ABSPATH' ) || exit;

function izb_webp_ok() {
	static $ok = null;
	if ( null === $ok ) {
		$ok = function_exists( 'wp_image_editor_supports' ) && wp_image_editor_supports( array( 'mime_type' => 'image/webp' ) );
	}
	return $ok;
}

// Bigger uploads are scaled down to this (WordPress's own default is 2560).
add_filter( 'big_image_size_threshold', function ( $px ) {
	return izb_opt( 'img_on' ) ? max( 1200, (int) izb_opt( 'img_max' ) ) : $px;
} );

// JPEG/PNG uploads → WebP sizes.
add_filter( 'image_editor_output_format', function ( $formats ) {
	if ( izb_opt( 'img_on' ) && izb_opt( 'img_webp' ) && izb_webp_ok() && empty( $GLOBALS['izb_no_webp'] ) ) {
		$formats['image/jpeg'] = 'image/webp';
		$formats['image/png']  = 'image/webp';
	}
	return $formats;
} );

add_filter( 'wp_editor_set_quality', function ( $q, $mime = '' ) {
	return izb_opt( 'img_on' ) && 'image/webp' === $mime ? max( 50, min( 95, (int) izb_opt( 'img_quality' ) ) ) : $q;
}, 10, 2 );

// ==========================================================================
//  The first photo of a product page loads first
// ==========================================================================

add_filter( 'wp_get_attachment_image_attributes', function ( $attr, $att ) {
	static $done = false;
	if ( $done || is_admin() || ! function_exists( 'is_product' ) || ! is_product() || empty( $attr['loading'] ) || 'lazy' !== $attr['loading'] ) {
		return $attr;
	}
	$pid   = get_queried_object_id();
	$first = function_exists( 'fsz_card_image_ids' ) && function_exists( 'izl_is_codex' ) && izl_is_codex( $pid ) ? fsz_card_image_ids( $pid ) : array( (int) get_post_thumbnail_id( $pid ) );
	if ( $first && (int) $att->ID === (int) reset( $first ) ) {
		$done                  = true;
		$attr['loading']       = 'eager';
		$attr['fetchpriority'] = 'high';
		$attr['decoding']      = 'async';
	}
	return $attr;
}, 30, 2 );

// ==========================================================================
//  Optimise existing photos (batches of 5, from the settings page)
// ==========================================================================

// Image attachments whose sizes are not WebP yet.
function izb_img_todo( $limit = 5 ) {
	return get_posts( array(
		'post_type'      => 'attachment',
		'post_status'    => 'inherit',
		'post_mime_type' => array( 'image/jpeg', 'image/png' ),
		'posts_per_page' => $limit,
		'fields'         => 'ids',
		'orderby'        => 'ID',
		'order'          => 'ASC',
		'meta_query'     => array( array( 'key' => '_izb_webp', 'compare' => 'NOT EXISTS' ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
	) );
}

function izb_img_bytes( $id ) {
	$meta = wp_get_attachment_metadata( $id );
	$file = get_attached_file( $id );
	if ( ! $file || ! is_array( $meta ) ) {
		return 0;
	}
	$dir   = trailingslashit( dirname( $file ) );
	$bytes = is_readable( $file ) ? filesize( $file ) : 0;
	foreach ( (array) ( $meta['sizes'] ?? array() ) as $s ) {
		$bytes += ! empty( $s['file'] ) && is_readable( $dir . $s['file'] ) ? filesize( $dir . $s['file'] ) : 0;
	}
	return $bytes;
}

// Makes the sizes again from the original photo (as WebP). Old files stay. Returns [bytes before, bytes after].
function izb_img_redo( $id ) {
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$orig = function_exists( 'wp_get_original_image_path' ) ? wp_get_original_image_path( $id ) : get_attached_file( $id );
	if ( ! $orig || ! is_readable( $orig ) ) {
		update_post_meta( $id, '_izb_webp', 'missing' );
		return array( 0, 0 );
	}
	$before = izb_img_bytes( $id );
	$old    = wp_get_attachment_metadata( $id );
	$meta   = wp_generate_attachment_metadata( $id, $orig );
	if ( ! $meta || empty( $meta['sizes'] ) && empty( $meta['file'] ) ) {
		update_post_meta( $id, '_izb_webp', 'failed' );
		return array( $before, $before );
	}
	if ( is_array( $old ) && ! empty( $old['image_meta'] ) && empty( $meta['image_meta'] ) ) {
		$meta['image_meta'] = $old['image_meta'];
	}
	wp_update_attachment_metadata( $id, $meta );
	update_post_meta( $id, '_izb_webp', '1' );
	return array( $before, izb_img_bytes( $id ) );
}

add_action( 'wp_ajax_izb_img_batch', function () {
	check_ajax_referer( 'izb_img', 'nonce' );
	if ( ! current_user_can( 'upload_files' ) || ! izb_webp_ok() ) {
		wp_send_json_error( 'WebP is not supported by this server.' );
	}
	$GLOBALS['izb_no_webp'] = ! izb_opt( 'img_webp' );
	$b = 0;
	$a = 0;
	foreach ( izb_img_todo( 5 ) as $id ) {
		list( $x, $y ) = izb_img_redo( $id );
		$b += $x;
		$a += $y;
	}
	wp_send_json_success( array( 'before' => $b, 'after' => $a, 'left' => count( izb_img_todo( 500 ) ) ) );
} );

// Settings page box.
function izb_img_box() {
	$left = count( izb_img_todo( 500 ) );
	echo '<h2>Photos</h2>';
	if ( ! izb_webp_ok() ) {
		echo '<p><b>This server cannot make WebP images</b> (ask the host to turn on WebP in PHP GD or Imagick). Uploads are still scaled down.</p>';
		return;
	}
	echo '<p>' . ( $left ? (int) $left . ' photo(s) uploaded before are not WebP yet.' : 'All photos are WebP.' ) . ' New uploads are made WebP by themselves.</p>';
	if ( $left ) {
		echo '<p><button type="button" class="button button-primary" id="izb-img-go">Optimise existing photos</button> <span id="izb-img-msg"></span></p>';
		echo '<script>(function(){var b=document.getElementById("izb-img-go"),m=document.getElementById("izb-img-msg"),B=0,A=0;if(!b)return;b.onclick=function(){b.disabled=true;step();};function kb(n){return Math.round(n/1024)+" KB";}function step(){var f=new FormData();f.append("action","izb_img_batch");f.append("nonce",' . wp_json_encode( wp_create_nonce( 'izb_img' ) ) . ');fetch(ajaxurl,{method:"POST",body:f,credentials:"same-origin"}).then(function(r){return r.json();}).then(function(r){if(!r.success){m.textContent=r.data||"Error";b.disabled=false;return;}B+=r.data.before;A+=r.data.after;m.textContent=r.data.left+" left · "+kb(B)+" → "+kb(A);if(r.data.left>0){step();}else{m.textContent="Done: "+kb(B)+" → "+kb(A)+" (old files are kept on disk)";}}).catch(function(){m.textContent="Stopped. Press again to go on.";b.disabled=false;});}})();</script>';
	}
}

// ==========================================================================
//  Share image (JPEG 1200×630, made once per photo + frame)
// ==========================================================================

// The URL of a 1200×630 JPEG of a photo, cut around its saved frame centre (Codex / Edit photos), or ''.
function izb_share_image( $att_id, $frame = array( 50, 50, 1 ) ) {
	$att_id = (int) $att_id;
	$src    = $att_id && function_exists( 'wp_get_original_image_path' ) ? wp_get_original_image_path( $att_id ) : get_attached_file( $att_id );
	if ( ! $src || ! is_readable( $src ) ) {
		return '';
	}
	$up   = wp_upload_dir();
	$key  = substr( md5( $src . filemtime( $src ) . implode( ',', $frame ) ), 0, 10 );
	$rel  = 'izb-share/' . $att_id . '-' . $key . '.jpg';
	$file = trailingslashit( $up['basedir'] ) . $rel;
	if ( ! file_exists( $file ) ) {
		$ed = wp_get_image_editor( $src );
		if ( is_wp_error( $ed ) ) {
			return '';
		}
		$size = $ed->get_size();
		$w    = (int) $size['width'];
		$h    = (int) $size['height'];
		$zoom = max( 1, (float) $frame[2] );
		// the biggest 1200:630 window inside the photo (smaller when the frame is zoomed in), centred on the frame
		$cw = min( $w, $h * 1200 / 630 ) / $zoom;
		$ch = $cw * 630 / 1200;
		$cx = max( 0, min( $w - $cw, $w * $frame[0] / 100 - $cw / 2 ) );
		$cy = max( 0, min( $h - $ch, $h * $frame[1] / 100 - $ch / 2 ) );
		$ed->crop( (int) round( $cx ), (int) round( $cy ), (int) round( $cw ), (int) round( $ch ), 1200, 630 );
		$ed->set_quality( 84 );
		wp_mkdir_p( dirname( $file ) );
		$GLOBALS['izb_no_webp'] = true;
		$saved = $ed->save( $file, 'image/jpeg' );
		$GLOBALS['izb_no_webp'] = false;
		if ( is_wp_error( $saved ) ) {
			return '';
		}
	}
	return trailingslashit( $up['baseurl'] ) . $rel;
}

// New uploads made while WebP is on need no "optimise" later.
add_filter( 'wp_generate_attachment_metadata', function ( $meta, $id, $context = 'create' ) {
	if ( 'create' === $context && izb_opt( 'img_on' ) && izb_opt( 'img_webp' ) && izb_webp_ok() && empty( $GLOBALS['izb_no_webp'] ) ) {
		update_post_meta( $id, '_izb_webp', '1' );
	}
	return $meta;
}, 10, 3 );
