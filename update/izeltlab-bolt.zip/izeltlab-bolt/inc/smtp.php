<?php
// ==========================================================================
//  FILE: inc/smtp.php   (Ízeltláb Bolt plugin)
//  WHAT: Sends the shop's mail through SMTP (Gmail app password), so order mails do not land in spam.
//  SEEN: Behind the scenes.
// ==========================================================================

/**
 * Mail through SMTP (Gmail with an App password by default), so order mails do not land in spam.
 * The From address stays the company email; with Gmail it must be the same Google account.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'phpmailer_init', function ( $m ) {
	if ( ! izb_opt( 'smtp_on' ) || ! izb_opt( 'smtp_host' ) || ! izb_opt( 'smtp_pass' ) ) {
		return;
	}
	$m->isSMTP();
	$m->Host       = (string) izb_opt( 'smtp_host' );
	$m->Port       = (int) izb_opt( 'smtp_port' ) ? (int) izb_opt( 'smtp_port' ) : 587;
	$m->SMTPAuth   = true;
	$m->SMTPSecure = 465 === (int) $m->Port ? 'ssl' : 'tls';
	$m->Username   = (string) izb_opt( 'smtp_user' );
	$m->Password   = (string) izb_opt( 'smtp_pass' );
	$m->CharSet    = 'UTF-8';
	$m->setFrom( izb_email(), (string) izb_opt( 'from_name' ), false );
} );

// WordPress's own mails (password reset etc.) come from the company too, not wordpress@yourdomain.
add_filter( 'wp_mail_from', function ( $from ) {
	return 0 === strpos( $from, 'wordpress@' ) ? izb_email() : $from;
} );
add_filter( 'wp_mail_from_name', function ( $name ) {
	return 'WordPress' === $name ? (string) izb_opt( 'from_name' ) : $name;
} );
