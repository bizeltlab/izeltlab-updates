<?php
/**
 * WooCommerce → Ízeltláb Bolt: the settings page and the two one-click buttons
 * ("Apply shop settings" = WooCommerce config as code, "Create legal page drafts").
 * Nothing changes on activation: WooCommerce settings change only when Dan presses the button, and the old values are
 * kept so "Undo" puts them back.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', function () {
	add_submenu_page( class_exists( 'WooCommerce' ) ? 'woocommerce' : 'options-general.php', 'Ízeltláb Bolt', 'Ízeltláb Bolt', 'manage_options', 'izeltlab-bolt', 'izb_settings_page' );
}, 60 );

// The fields: key => [label, type, help, section].
function izb_fields() {
	return array(
		'co_name'      => array( 'Company / sole trader name', 'text', 'As on the tax registration. Printed in the Impresszum, ÁSZF, privacy page, footer.', 'Company (legal pages, footer, emails)' ),
		'co_form'      => array( 'Business form', 'text', 'e.g. egyéni vállalkozó, Kft.', '' ),
		'co_address'   => array( 'Registered address', 'text', 'Székhely', '' ),
		'co_tax'       => array( 'Tax number', 'text', 'Adószám', '' ),
		'co_reg'       => array( 'Registration number', 'text', 'Nyilvántartási szám (e.v.) or cégjegyzékszám (Kft.)', '' ),
		'co_email'     => array( 'Company email', 'email', 'Shown to customers, Reply-To of the shop emails, receives new orders.', '' ),
		'co_phone'     => array( 'Phone', 'text', 'Required on the Impresszum by law.', '' ),
		'co_bank'      => array( 'Bank account (optional)', 'text', 'Only if you take bank transfer.', '' ),
		'host_name'    => array( 'Hosting provider name', 'text', 'Required on the Impresszum (tárhelyszolgáltató).', '' ),
		'host_address' => array( 'Hosting provider address', 'text', '', '' ),
		'host_email'   => array( 'Hosting provider email', 'text', '', '' ),
		'chamber'      => array( 'Conciliation board (békéltető testület)', 'text', 'The board of your registered seat. Default is Budapest; check the address before launch.', '' ),
		'rate_foxpost' => array( 'Foxpost price (Ft, VAT incl.)', 'number', 'Used by "Apply shop settings". Empty = the method is not made.', 'Shipping' ),
		'rate_gls'     => array( 'GLS home delivery price (Ft, VAT incl.)', 'number', 'Include the winter heat pack cost here (no note on the site).', '' ),
		'extra_closed' => array( 'Extra closed days', 'textarea', 'One date per line (2027-08-02). Nothing ships or arrives on these days, on top of the Hungarian public holidays.', '' ),
		'smtp_on'      => array( 'Send mail through SMTP', 'checkbox', 'Without it, shop mails often land in spam. See the SMTP guide.', 'Email sending (SMTP)' ),
		'smtp_host'    => array( 'SMTP host', 'text', 'Gmail: smtp.gmail.com', '' ),
		'smtp_port'    => array( 'SMTP port', 'number', '587 (TLS)', '' ),
		'smtp_user'    => array( 'SMTP user', 'text', '', '' ),
		'smtp_pass'    => array( 'SMTP password', 'password', 'Gmail: an App password (Google account → Security → 2-Step Verification → App passwords), not your normal password. Leave empty to keep the saved one.', '' ),
		'from_name'    => array( 'Sender name', 'text', '', '' ),
		'sec_limit'    => array( 'Limit login attempts', 'checkbox', '5 wrong tries = 15 minutes locked for that address.', 'Security' ),
		'sec_slug'     => array( 'Secret login address', 'text', 'e.g. "kapu" → yoursite/kapu. Empty = off. Write it down: wp-login.php and wp-admin stop working for logged-out visitors.', '' ),
		'sec_xmlrpc'   => array( 'Turn off XML-RPC', 'checkbox', 'Old remote-publishing door, mostly used by attackers.', '' ),
		'sec_headers'  => array( 'Security headers', 'checkbox', 'nosniff, frame protection, referrer policy.', '' ),
		'sec_enum'     => array( 'Hide user names', 'checkbox', 'Blocks ?author= and the public REST user list.', '' ),
		'sec_fileedit' => array( 'Turn off the theme/plugin file editor', 'checkbox', '', '' ),
		'cookie_on'    => array( 'Cookie banner', 'checkbox', 'Shown until the visitor chooses. Analytics loads only after "Elfogadom".', 'Cookies and analytics' ),
		'ga4'          => array( 'Google Analytics 4 ID', 'text', 'G-XXXXXXX. Empty = off. To get one: analytics.google.com (log in as bizeltlab@gmail.com) → Start measuring → account "Ízeltláb", property "Ízeltláb bolt", Hungary, HUF → Web → your shop address → copy the "Measurement ID" (G-…) here. Reports: Reports → Monetisation → Ecommerce purchases (views, add to cart, checkout, purchases).', '' ),
		'plausible'    => array( 'Plausible domain', 'text', 'Cookie-less alternative (paid). Empty = off.', '' ),
		'notify_on'    => array( '"Notify me" on unavailable products', 'checkbox', 'Email form under the buy box; mails everyone when the product is available again.', 'Sign-ups' ),
		'news_on'      => array( 'Newsletter sign-up in the footer', 'checkbox', 'Addresses are collected here (export CSV below), for MailerLite or similar.', '' ),
		'soldout_show' => array( 'Keep sold-out products in the shop', 'checkbox', 'They stay in their place in the grid with a "Notify me" button (WooCommerce → Restock list shows who waits).', '' ),
		'pult_on'        => array( 'Order desk', 'checkbox', 'A pill in a corner of every page, only for you (logged in): orders to pack, the newest order\'s price, the 14:00 countdown; open it for the items, address, phone, Packed / Shipped buttons, pick list and stock.', 'Order desk' ),
		'pult_corner'    => array( 'Corner', 'select', 'On phone product pages it sits under the header (the drawer owns the bottom).', '', array( 'br' => 'bottom right', 'bl' => 'bottom left', 'tr' => 'top right', 'tl' => 'top left' ) ),
		'pult_admin'     => array( 'Also in the dashboard', 'checkbox', '', '' ),
		'pult_statuses'  => array( 'Statuses to pack', 'text', 'Comma separated order statuses. processing = paid, on-hold = waiting for a bank transfer.', '' ),
		'pult_phone'     => array( 'Show phone', 'checkbox', '', '' ),
		'pult_email'     => array( 'Show email', 'checkbox', '', '' ),
		'pult_note'      => array( 'Show the customer\'s note', 'checkbox', '', '' ),
		'pult_pay'       => array( 'Show the payment method', 'checkbox', '', '' ),
		'pult_low'       => array( 'Running low at', 'number', 'Products that count stock show under Stock at this many or fewer. (Species: the "Running low" switch.) 0 = off.', '' ),
		'pult_sound'     => array( 'Beep on a new order', 'checkbox', 'While a shop page is open.', '' ),
		'pult_link'      => array( 'Phone link', 'checkbox', 'A private page with the same list, read only, no login (the link is below).', '' ),
		'pult_mail'      => array( 'Morning mail', 'checkbox', 'Orders to pack, the pick list and the stock, on shipping days (Monday to Friday, not on holidays).', '' ),
		'pult_mail_hour' => array( 'Morning mail at', 'select', 'Budapest time.', '', array_combine( range( 5, 12 ), array_map( function ( $h ) { return sprintf( '%02d:00', $h ); }, range( 5, 12 ) ) ) ),
		'pult_mail_to'   => array( 'Morning mail to', 'email', 'Empty = the company email.', '' ),
		'img_on'       => array( 'Lighter photos', 'checkbox', 'New uploads: the long side is cut to the size below (the original is kept) and WordPress makes the sizes as WebP.', 'Speed and sharing' ),
		'img_max'      => array( 'Largest photo side (px)', 'number', '2000 is sharp on every screen, also when the Codex frame zooms in.', '' ),
		'img_webp'     => array( 'WebP sizes', 'checkbox', '', '' ),
		'img_quality'  => array( 'WebP quality', 'number', '80 looks the same as the JPEG at about a third of its weight.', '' ),
		'cache_rules'  => array( 'Safe cache rules', 'checkbox', 'Tells cache plugins what never to cache and which scripts to leave alone (see "Page cache" below).', '' ),
		'share_img'    => array( 'Default share image', 'text', 'Media library ID or URL of the picture links to the front page and pages without a photo show on Facebook / Messenger (products show their own Codex photo). Empty = the first front page species.', '' ),
		'soon_on'      => array( 'Coming soon page', 'checkbox', 'Visitors who are not logged in see only the "Hamarosan nyitunk!" page below (search engines are told to come back later). You, logged in, see the real shop; to see it as a shopper, use "View as visitor" in the admin bar. Untick on launch day. Every change empties the page cache.', 'Coming soon' ),
		'soon_title'   => array( 'Title', 'text', '', '' ),
		'soon_text'    => array( 'Text', 'textarea', 'Line breaks are kept.', '' ),
		'soon_news'    => array( 'Newsletter sign-up on the page', 'checkbox', 'The same "Letters from the colony" form as in the footer; addresses land in the newsletter list below.', '' ),
		'search_on'    => array( 'Species search', 'checkbox', 'The shop search also knows the Latin, trade and Codex names, ignores accents and forgives small typos. Extra words per product: product edit screen → General → Search words.', '' ),
	);
}

add_action( 'admin_init', function () {
	register_setting( 'izb', 'izb', array( 'sanitize_callback' => 'izb_sanitize' ) );
} );

function izb_sanitize( $in ) {
	$old = (array) get_option( 'izb', array() );
	$out = array();
	foreach ( izb_fields() as $key => $f ) {
		$v = isset( $in[ $key ] ) ? $in[ $key ] : '';
		switch ( $f[1] ) {
			case 'checkbox':
				$out[ $key ] = $v ? 1 : 0;
				break;
			case 'number':
				$out[ $key ] = '' === $v ? '' : absint( $v );
				break;
			case 'select':
				$out[ $key ] = isset( $f[4][ $v ] ) ? (string) $v : (string) izb_defaults()[ $key ];
				break;
			case 'email':
				$out[ $key ] = sanitize_email( $v );
				break;
			case 'textarea':
				$out[ $key ] = sanitize_textarea_field( $v );
				break;
			case 'password':
				$out[ $key ] = '' === $v ? ( isset( $old[ $key ] ) ? $old[ $key ] : '' ) : (string) $v;
				break;
			default:
				$out[ $key ] = sanitize_text_field( $v );
		}
	}
	$out['sec_slug'] = sanitize_title( $out['sec_slug'] );
	if ( in_array( $out['sec_slug'], array( 'wp-admin', 'wp-login', 'admin', 'login', 'dashboard' ), true ) ) {
		$out['sec_slug'] = '';
	}
	return $out;
}

function izb_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$o    = izb_opt();
	$sect = '';
	echo '<div class="wrap"><h1>Ízeltláb Bolt</h1>';
	if ( isset( $_GET['izb_done'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		echo '<div class="notice notice-success"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['izb_done'] ) ) ) . '</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification
	}

	// one-click buttons
	echo '<div style="display:flex;gap:16px;flex-wrap:wrap;margin:16px 0">';
	izb_action_box( 'izb_apply', 'Apply shop settings', 'HUF without decimals, prices include 27% VAT, guest checkout, a "Magyarország" shipping zone with Foxpost / GLS (prices below) and Free shipping over the theme\'s amount (18 000 Ft), shop emails from ' . izb_email() . ', classic cart and checkout pages (so the tick boxes and the button text work). Old values are kept for Undo.', get_option( 'izb_wc_backup' ) ? 'izb_undo' : '' );
	izb_action_box( 'izb_pages', 'Create legal page drafts', 'ÁSZF, Adatkezelési tájékoztató, Elállási tájékoztató + form, Impresszum, Panaszkezelés, Szállítás, Érkezési garancia, GYIK, as DRAFTS (nothing is published). Company data comes from the fields below. A lawyer must read them before publishing. Existing pages are never overwritten.', '' );
	echo '</div>';

	echo '<form method="post" action="options.php">';
	settings_fields( 'izb' );
	echo '<table class="form-table" role="presentation">';
	foreach ( izb_fields() as $key => $f ) {
		if ( $f[3] && $f[3] !== $sect ) {
			$sect = $f[3];
			echo '</table><h2>' . esc_html( $sect ) . '</h2><table class="form-table" role="presentation">';
		}
		$name = 'izb[' . $key . ']';
		echo '<tr><th scope="row"><label for="izb-' . esc_attr( $key ) . '">' . esc_html( $f[0] ) . '</label></th><td>';
		if ( 'checkbox' === $f[1] ) {
			echo '<input type="checkbox" id="izb-' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="1"' . checked( $o[ $key ], 1, false ) . '>';
		} elseif ( 'select' === $f[1] ) {
			echo '<select id="izb-' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '">';
			foreach ( $f[4] as $val => $lab ) {
				echo '<option value="' . esc_attr( $val ) . '"' . selected( (string) $o[ $key ], (string) $val, false ) . '>' . esc_html( $lab ) . '</option>';
			}
			echo '</select>';
		} elseif ( 'textarea' === $f[1] ) {
			echo '<textarea id="izb-' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" rows="4" class="large-text code">' . esc_textarea( $o[ $key ] ) . '</textarea>';
		} else {
			$val = 'password' === $f[1] ? '' : $o[ $key ];
			$ph  = 'password' === $f[1] && $o[ $key ] ? '(saved)' : '';
			echo '<input type="' . esc_attr( $f[1] ) . '" id="izb-' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '" placeholder="' . esc_attr( $ph ) . '" class="regular-text" autocomplete="off">';
		}
		if ( $f[2] ) {
			echo '<p class="description">' . esc_html( $f[2] ) . '</p>';
		}
		echo '</td></tr>';
	}
	echo '</table>';
	submit_button();
	echo '</form>';

	// 1.2.0: the boxes of the new parts
	izb_pult_settings_box();
	izb_img_box();
	izb_ht_box();
	izb_cache_box();
	izb_backup_box();

	// sign-up lists
	echo '<h2>Sign-ups</h2><p>' . (int) izb_signups_count( 'notify' ) . ' waiting for a product (<a href="' . esc_url( admin_url( 'admin.php?page=izb-restock' ) ) . '">Restock list</a>), ' . (int) izb_signups_count( 'news' ) . ' newsletter. ';
	echo '<a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=izb_export' ), 'izb_export' ) ) . '">Export newsletter CSV</a></p>';
	if ( $o['smtp_on'] ) {
		echo '<p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=izb_testmail' ), 'izb_testmail' ) ) . '">Send a test email to ' . esc_html( izb_email() ) . '</a></p>';
	}
	echo '</div>';
}

function izb_action_box( $action, $title, $text, $undo ) {
	echo '<div style="flex:1 1 320px;max-width:560px;padding:12px 16px;background:#fff;border:1px solid #c3c4c7;border-radius:6px">';
	echo '<h2 style="margin-top:4px">' . esc_html( $title ) . '</h2><p>' . esc_html( $text ) . '</p>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline">';
	wp_nonce_field( $action );
	echo '<input type="hidden" name="action" value="' . esc_attr( $action ) . '"><button class="button button-primary">' . esc_html( $title ) . '</button></form> ';
	if ( $undo ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline">';
		wp_nonce_field( $undo );
		echo '<input type="hidden" name="action" value="' . esc_attr( $undo ) . '"><button class="button">Undo</button></form>';
	}
	echo '</div>';
}

function izb_back( $msg ) {
	wp_safe_redirect( add_query_arg( 'izb_done', rawurlencode( $msg ), admin_url( 'admin.php?page=izeltlab-bolt' ) ) );
	exit;
}

/* ------------------------------------------------------------------ Apply shop settings (WooCommerce config as code) */

// The options the button sets: option => value.
function izb_wc_options() {
	return array(
		'woocommerce_currency'                       => 'HUF',
		'woocommerce_currency_pos'                   => 'right_space',
		'woocommerce_price_thousand_sep'             => ' ',
		'woocommerce_price_decimal_sep'              => ',',
		'woocommerce_price_num_decimals'             => '0',
		'woocommerce_default_country'                => 'HU',
		'woocommerce_allowed_countries'              => 'specific',
		'woocommerce_specific_allowed_countries'     => array( 'HU' ),
		'woocommerce_ship_to_countries'              => '',
		'woocommerce_calc_taxes'                     => 'yes',
		'woocommerce_prices_include_tax'             => 'yes',
		'woocommerce_tax_based_on'                   => 'base',
		'woocommerce_tax_display_shop'               => 'incl',
		'woocommerce_tax_display_cart'               => 'incl',
		'woocommerce_tax_total_display'              => 'single',
		'woocommerce_shipping_tax_class'             => 'inherit',
		'woocommerce_enable_guest_checkout'          => 'yes',
		'woocommerce_enable_checkout_login_reminder' => 'yes',
		'woocommerce_enable_signup_and_login_from_checkout' => 'yes',
		'woocommerce_registration_generate_password' => 'yes',
		'woocommerce_enable_coupons'                 => 'no', // Dan's rule: no discounts
		'woocommerce_enable_reviews'                 => 'no',
		'woocommerce_manage_stock'                   => 'no', // only the Available switch
		'woocommerce_hide_out_of_stock_items'        => 'no', // 1.2.0: sold out stays in the shop (Notify me)
		'woocommerce_hold_stock_minutes'             => '',
		'woocommerce_ship_to_destination'            => 'billing',
		'woocommerce_cart_redirect_after_add'        => 'no',
		'woocommerce_enable_ajax_add_to_cart'        => 'yes',
		'woocommerce_email_from_name'                => izb_opt( 'from_name' ) ? izb_opt( 'from_name' ) : 'Ízeltláb',
		'woocommerce_email_from_address'             => izb_email(),
		'woocommerce_email_base_color'               => '#1F8A8A',
		'woocommerce_email_background_color'         => '#E9F1EC',
		'woocommerce_email_body_background_color'    => '#FFFFFF',
		'woocommerce_email_text_color'               => '#17302E',
		'woocommerce_email_footer_text'              => '{site_title} · ' . izb_email(),
		'woocommerce_checkout_privacy_policy_text'   => 'Személyes adataidat a rendelés teljesítéséhez és a fiókod kezeléséhez használjuk, ahogy az [privacy_policy] leírja.',
		'woocommerce_registration_privacy_policy_text' => 'Személyes adataidat a fiókod kezeléséhez használjuk, ahogy az [privacy_policy] leírja.',
		'woocommerce_erasure_request_removes_order_data' => 'no', // invoices must be kept 8 years (Hungarian accounting law)
		'woocommerce_allow_bulk_remove_personal_data' => 'no',
	);
}

add_action( 'admin_post_izb_apply', function () {
	check_admin_referer( 'izb_apply' );
	if ( ! current_user_can( 'manage_woocommerce' ) || ! class_exists( 'WooCommerce' ) ) {
		wp_die( 'WooCommerce is needed.' );
	}
	$backup = get_option( 'izb_wc_backup' );
	if ( ! $backup ) { // keep the very first values, so Undo always goes back to before the plugin
		$backup = array( 'options' => array(), 'pages' => array() );
		foreach ( izb_wc_options() as $k => $v ) {
			$backup['options'][ $k ] = get_option( $k, '__izb_none__' );
		}
	}
	foreach ( izb_wc_options() as $k => $v ) {
		update_option( $k, $v );
	}
	izb_apply_tax();
	$zone = izb_apply_zone();
	izb_apply_emails();
	$backup['pages'] = izb_apply_classic_pages( isset( $backup['pages'] ) ? $backup['pages'] : array() );
	update_option( 'izb_wc_backup', $backup, false );
	if ( class_exists( 'WC_Cache_Helper' ) ) {
		WC_Cache_Helper::get_transient_version( 'shipping', true );
	}
	izb_back( 'Shop settings applied.' . ( $zone ? ' ' . $zone : '' ) . ' Check WooCommerce → Settings once.' );
} );

add_action( 'admin_post_izb_undo', function () {
	check_admin_referer( 'izb_undo' );
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die();
	}
	$backup = (array) get_option( 'izb_wc_backup' );
	foreach ( (array) ( $backup['options'] ?? array() ) as $k => $v ) {
		'__izb_none__' === $v ? delete_option( $k ) : update_option( $k, $v );
	}
	foreach ( (array) ( $backup['pages'] ?? array() ) as $id => $content ) {
		wp_update_post( array( 'ID' => (int) $id, 'post_content' => $content ) );
	}
	delete_option( 'izb_wc_backup' );
	izb_back( 'Old WooCommerce values are back (the shipping zone and the tax rate stay; delete them by hand if needed).' );
} );

// One 27% standard rate for Hungary (only if there is no HU rate yet).
function izb_apply_tax() {
	global $wpdb;
	if ( ! class_exists( 'WC_Tax' ) ) {
		return;
	}
	$has = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}woocommerce_tax_rates WHERE tax_rate_country = 'HU' AND tax_rate_class = ''" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	if ( ! $has ) {
		WC_Tax::_insert_tax_rate( array(
			'tax_rate_country'  => 'HU',
			'tax_rate_state'    => '',
			'tax_rate'          => '27.0000',
			'tax_rate_name'     => 'ÁFA',
			'tax_rate_priority' => 1,
			'tax_rate_compound' => 0,
			'tax_rate_shipping' => 1,
			'tax_rate_order'    => 0,
			'tax_rate_class'    => '',
		) );
	}
}

// The "Magyarország" zone: Foxpost, GLS (prices from the settings) and Free shipping over the theme's amount.
// Methods already in the zone are left alone (matched by type + title), so pressing twice does not double them.
function izb_apply_zone() {
	if ( ! class_exists( 'WC_Shipping_Zones' ) ) {
		return '';
	}
	$zone = null;
	foreach ( WC_Shipping_Zones::get_zones() as $z ) {
		foreach ( $z['zone_locations'] as $loc ) {
			if ( 'country' === $loc->type && 'HU' === $loc->code ) {
				$zone = new WC_Shipping_Zone( $z['id'] );
				break 2;
			}
		}
	}
	if ( ! $zone ) {
		$zone = new WC_Shipping_Zone();
		$zone->set_zone_name( 'Magyarország' );
		$zone->add_location( 'HU', 'country' );
		$zone->save();
	}
	$have  = array();
	$fixed = array();
	$gross = array( 'Foxpost csomagautomata' => izb_opt( 'rate_foxpost' ), 'GLS házhozszállítás' => izb_opt( 'rate_gls' ) );
	foreach ( $zone->get_shipping_methods() as $m ) {
		$have[] = $m->id . '|' . $m->get_title();
		// 1.1.0: a rate that 1.0.0 saved with the VAT still in it (1 290 showed as 1 638 Ft) is set to the net cost.
		$g = isset( $gross[ $m->get_title() ] ) ? (string) $gross[ $m->get_title() ] : '';
		if ( 'flat_rate' === $m->id && '' !== $g && (float) $m->get_option( 'cost' ) === (float) $g ) {
			$opt         = 'woocommerce_flat_rate_' . $m->instance_id . '_settings';
			$set         = (array) get_option( $opt, array() );
			$set['cost'] = izb_net_cost( $g );
			update_option( $opt, $set );
			$fixed[] = $m->get_title();
		}
	}
	$free = function_exists( 'izl_free_ship' ) ? (int) izl_free_ship() : 18000;
	$want = array(
		array( 'flat_rate', 'Foxpost csomagautomata', izb_opt( 'rate_foxpost' ) ),
		array( 'flat_rate', 'GLS házhozszállítás', izb_opt( 'rate_gls' ) ),
		array( 'free_shipping', 'Ingyenes szállítás', $free ? $free : '' ),
	);
	$made = array();
	foreach ( $want as $w ) {
		if ( '' === $w[2] || in_array( $w[0] . '|' . $w[1], $have, true ) ) {
			continue;
		}
		$iid = $zone->add_shipping_method( $w[0] );
		if ( ! $iid ) {
			continue;
		}
		$settings = 'free_shipping' === $w[0]
			? array( 'title' => $w[1], 'requires' => 'min_amount', 'min_amount' => (string) $w[2], 'ignore_discounts' => 'no' )
			: array( 'title' => $w[1], 'tax_status' => 'taxable', 'cost' => izb_net_cost( $w[2] ) );
		update_option( 'woocommerce_' . $w[0] . '_' . $iid . '_settings', $settings );
		$made[] = $w[1];
	}
	$msg = $made ? 'Shipping added: ' . implode( ', ', $made ) . '.' : 'Shipping zone was already set up.';
	return $fixed ? $msg . ' VAT fixed on: ' . implode( ', ', $fixed ) . '.' : $msg;
}

// 1.1.0: WooCommerce adds the VAT on top of a flat rate's cost, so the gross price from the settings (VAT included,
// what the customer sees) is saved without it: 1 290 Ft → 1015.748 + 27% = 1 290 Ft at the checkout.
function izb_net_cost( $gross ) {
	return (string) round( (float) $gross / 1.27, 4 );
}

// Shop emails: the admin's new-order, cancelled and failed mails go to the company email.
function izb_apply_emails() {
	foreach ( array( 'new_order', 'cancelled_order', 'failed_order' ) as $id ) {
		$k = 'woocommerce_' . $id . '_settings';
		$s = (array) get_option( $k, array() );
		$s['enabled']   = 'yes';
		$s['recipient'] = izb_email();
		update_option( $k, $s );
	}
}

// Cart and checkout as the classic shortcodes (the block versions ignore the tick boxes, the button text and the
// theme's cart look). The page's old content is kept for Undo.
function izb_apply_classic_pages( $kept ) {
	foreach ( array( 'cart' => '[woocommerce_cart]', 'checkout' => '[woocommerce_checkout]' ) as $page => $code ) {
		$id = (int) wc_get_page_id( $page );
		if ( $id <= 0 ) {
			continue;
		}
		$post = get_post( $id );
		if ( ! $post || false !== strpos( $post->post_content, $code ) ) {
			continue;
		}
		if ( ! isset( $kept[ $id ] ) ) {
			$kept[ $id ] = $post->post_content;
		}
		wp_update_post( array( 'ID' => $id, 'post_content' => '<!-- wp:shortcode -->' . $code . '<!-- /wp:shortcode -->' ) );
	}
	return $kept;
}

/* ------------------------------------------------------------------ Create legal page drafts */

// slug => [title, file in legal/, option it becomes]
function izb_legal_pages() {
	return array(
		'aszf'                => array( 'Általános Szerződési Feltételek', 'aszf.html', 'woocommerce_terms_page_id' ),
		'adatkezeles'         => array( 'Adatkezelési tájékoztató', 'adatkezeles.html', 'wp_page_for_privacy_policy' ),
		'elallas'             => array( 'Elállási tájékoztató', 'elallas.html', '' ),
		'impresszum'          => array( 'Impresszum', 'impresszum.html', '' ),
		'panaszkezeles'       => array( 'Panaszkezelés', 'panasz.html', '' ),
		'szallitas'           => array( 'Szállítás', 'szallitas.html', '' ),
		'erkezesi-garancia'   => array( 'Érkezési garancia', 'garancia.html', '' ),
		'gyik'                => array( 'Gyakori kérdések', 'gyik.html', '' ),
	);
}

add_action( 'admin_post_izb_pages', function () {
	check_admin_referer( 'izb_pages' );
	if ( ! current_user_can( 'publish_pages' ) ) {
		wp_die();
	}
	$made = array();
	foreach ( izb_legal_pages() as $slug => $p ) {
		$found = get_page_by_path( $slug, OBJECT, 'page' );
		if ( ! $found ) {
			$html = (string) file_get_contents( IZB_DIR . 'legal/' . $p[1] ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$id   = wp_insert_post( array(
				'post_type'    => 'page',
				'post_status'  => 'draft',
				'post_title'   => $p[0],
				'post_name'    => $slug,
				'post_content' => '<!-- wp:html -->' . $html . '<!-- /wp:html -->',
			) );
			if ( $id && ! is_wp_error( $id ) ) {
				$made[] = $p[0];
				$found  = get_post( $id );
			}
		}
		if ( $found && $p[2] && ! (int) get_option( $p[2] ) ) {
			update_option( $p[2], $found->ID );
		}
	}
	izb_back( $made ? 'Drafts made: ' . implode( ', ', $made ) . '. Pages → Drafts. Publish them after the lawyer has read them.' : 'All legal pages already exist; nothing was changed.' );
} );

// [izb_co field="name"]: the company data in the legal pages, so they are always up to date with the settings.
add_shortcode( 'izb_co', function ( $atts ) {
	$a   = shortcode_atts( array( 'field' => 'name' ), $atts );
	$key = 'email' === $a['field'] ? 'co_email' : ( in_array( $a['field'], array( 'host_name', 'host_address', 'host_email', 'chamber' ), true ) ? $a['field'] : 'co_' . $a['field'] );
	$val = 'co_email' === $key ? izb_email() : (string) izb_opt( $key );
	if ( '' === $val ) {
		return current_user_can( 'manage_options' ) ? '<mark>[' . esc_html( $key ) . ' — fill in: WooCommerce → Ízeltláb Bolt]</mark>' : '';
	}
	return 'co_email' === $key ? '<a href="mailto:' . esc_attr( $val ) . '">' . esc_html( $val ) . '</a>' : esc_html( $val );
} );

// [izb_page slug="aszf"]: a link to another legal page (its real address, even after a slug change).
add_shortcode( 'izb_page', function ( $atts ) {
	$a = shortcode_atts( array( 'slug' => 'aszf', 'text' => '' ), $atts );
	$p = get_page_by_path( sanitize_title( $a['slug'] ), OBJECT, 'page' );
	$t = $a['text'] ? $a['text'] : ( $p ? get_the_title( $p ) : $a['slug'] );
	return $p ? '<a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( $t ) . '</a>' : esc_html( $t );
} );

// The shortcodes inside the drafts' HTML block run too.
add_filter( 'the_content', function ( $c ) {
	return false !== strpos( $c, '[izb_' ) ? do_shortcode( $c ) : $c;
}, 12 );

/* ------------------------------------------------------------------ test mail */

add_action( 'admin_post_izb_testmail', function () {
	check_admin_referer( 'izb_testmail' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die();
	}
	$ok = wp_mail( izb_email(), 'Ízeltláb próba levél', "Ha ezt olvasod, a levélküldés működik.\n\n" . home_url() );
	izb_back( $ok ? 'Test email sent. Check the inbox (and spam).' : 'Sending failed: check the SMTP host, port, user and App password.' );
} );
