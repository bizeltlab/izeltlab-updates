<?php
// ==========================================================================
//  FILE: inc/security.php   (Ízeltláb Bolt plugin)
//  WHAT: Security switches: secret login address, cleaner page head, security headers, XML-RPC off.
//  SEEN: Behind the scenes; the login address.
//  SECTIONS IN THIS FILE:
//    1. File editor off
//    2. XML-RPC off
//    3. Headers
//    4. No user names
//    5. Login attempts: 5 wrong = 15 minutes locked
//    6. Secret login address
//    7. No version tags, no dead links in the page head (since 1.7.0)
// ==========================================================================

/**
 * Security hardening, each part has its own switch in the settings:
 * login attempts limit, secret login address, XML-RPC off, security headers, no user-name leaks, no file editor.
 * 1.7.0: the headers can come from the server (inc/htaccess.php), the secret login gate cookie is signed, and the
 * page head no longer names the WordPress and WooCommerce versions.
 * 2FA: install the free "Two Factor" plugin (see the security guide); it is not rebuilt here.
 */

defined( 'ABSPATH' ) || exit;

// ==========================================================================
//  File editor off
// ==========================================================================
if ( izb_opt( 'sec_fileedit' ) && ! defined( 'DISALLOW_FILE_EDIT' ) ) {
	define( 'DISALLOW_FILE_EDIT', true );
}

// ==========================================================================
//  XML-RPC off
// ==========================================================================
if ( izb_opt( 'sec_xmlrpc' ) ) {
	add_filter( 'xmlrpc_enabled', '__return_false' );
	add_filter( 'wp_headers', function ( $h ) {
		unset( $h['X-Pingback'] );
		return $h;
	} );
	add_action( 'init', function () {
		if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
			status_header( 403 );
			exit;
		}
	}, 0 );
}

// ==========================================================================
//  Headers
// ==========================================================================
// 1.7.0: when the server itself adds them (the lines Bolt writes into .htaccess, inc/htaccess.php), PHP leaves them
// alone: the server's reach every answer, also the pages a page cache serves without starting WordPress.
if ( izb_opt( 'sec_headers' ) && ! ( function_exists( 'izb_ht_on' ) && izb_ht_on() ) ) {
	add_action( 'send_headers', function () {
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		header( 'Permissions-Policy: camera=(), microphone=(), geolocation=()' );
	} );
}

// ==========================================================================
//  No user names
// ==========================================================================
if ( izb_opt( 'sec_enum' ) ) {
	add_action( 'template_redirect', function () {
		if ( ! is_user_logged_in() && ( isset( $_GET['author'] ) || is_author() ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	} );
	add_filter( 'rest_endpoints', function ( $e ) {
		if ( ! is_user_logged_in() ) {
			unset( $e['/wp/v2/users'], $e['/wp/v2/users/(?P<id>[\d]+)'] );
		}
		return $e;
	} );
	add_filter( 'wp_sitemaps_add_provider', function ( $p, $name ) {
		return 'users' === $name ? false : $p;
	}, 10, 2 );
	// One message for a wrong user name and a wrong password.
	add_filter( 'login_errors', function () {
		return __( 'Wrong user name or password.', 'izeltlab-bolt' );
	} );
}

// ==========================================================================
//  Login attempts: 5 wrong = 15 minutes locked
// ==========================================================================
define( 'IZB_TRIES', 5 );
define( 'IZB_LOCK', 15 * MINUTE_IN_SECONDS );

function izb_ip_key() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0';
	return 'izb_fail_' . md5( $ip );
}

if ( izb_opt( 'sec_limit' ) ) {
	add_filter( 'authenticate', function ( $user ) {
		if ( (int) get_transient( izb_ip_key() ) >= IZB_TRIES ) {
			return new WP_Error( 'izb_locked', __( 'Too many wrong tries. Please wait 15 minutes.', 'izeltlab-bolt' ) );
		}
		return $user;
	}, 99 );
	add_action( 'wp_login_failed', function () {
		$k = izb_ip_key();
		set_transient( $k, (int) get_transient( $k ) + 1, IZB_LOCK );
	} );
	add_action( 'wp_login', function () {
		delete_transient( izb_ip_key() );
	} );
}

// ==========================================================================
//  Secret login address
// ==========================================================================
// yoursite/<slug> shows the login; wp-login.php and wp-admin answer 404 to logged-out visitors. Password reset,
// logout and the WooCommerce "My account" login keep working.
function izb_slug() {
	return (string) izb_opt( 'sec_slug' );
}

// 1.7.0: what the gate cookie holds: a code only this site can make from the secret address (it used to be "1",
// which anyone could set by hand without knowing the address).
function izb_gate_code() {
	return wp_hash( 'izb_gate|' . izb_slug() );
}

// 1.9.0: the gate cookie lasts a year (it used to end with the browser), and an editor gets it at every login too. So the
// coming soon page's "Belépés" link (inc/soon.php) opens the login on every phone or PC the owner has logged in on once;
// for everyone else wp-login.php still ends on the 404 page.
function izb_set_gate_cookie() {
	setcookie( 'izb_gate', izb_gate_code(), time() + YEAR_IN_SECONDS, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true );
}

if ( izb_slug() ) {
	add_action( 'init', function () {
		$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ), '/' ); // phpcs:ignore
		$home = trim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
		$rel  = trim( $home ? preg_replace( '#^' . preg_quote( $home, '#' ) . '#', '', $path ) : $path, '/' );
		if ( $rel === izb_slug() ) {
			izb_set_gate_cookie();
			wp_safe_redirect( site_url( 'wp-login.php?izb=1' ) );
			exit;
		}
	}, 1 );
	add_action( 'login_init', function () {
		$action = isset( $_REQUEST['action'] ) ? sanitize_key( $_REQUEST['action'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$gate   = isset( $_COOKIE['izb_gate'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['izb_gate'] ) ) : '';
		$ok     = ( '' !== $gate && hash_equals( izb_gate_code(), $gate ) ) || in_array( $action, array( 'logout', 'rp', 'resetpass', 'postpass', 'confirmaction', 'lostpassword', 'confirm_admin_email' ), true );
		if ( ! $ok && ! is_user_logged_in() ) {
			// wp-admin sends logged-out visitors here too, so both end on the shop's 404 page.
			wp_safe_redirect( home_url( '/nincs-ilyen-oldal/' ) );
			exit;
		}
	} );
	add_action( 'wp_login', function ( $login, $user ) {
		if ( $user instanceof WP_User && user_can( $user, 'edit_posts' ) ) {
			izb_set_gate_cookie();
		}
	}, 10, 2 );
}

// ==========================================================================
//  No version tags, no dead links in the page head (since 1.7.0)
// ==========================================================================
// The WordPress and WooCommerce version tags tell an attacker which holes to try; the editor links (RSD, Windows Live
// Writer) belong to XML-RPC, which is off (the theme leaves out the pingback link then); the shop has no comments, so no comment feed.
add_action( 'init', function () {
	remove_action( 'wp_head', 'wp_generator' );
	add_filter( 'the_generator', '__return_empty_string', 99 );
	if ( izb_opt( 'sec_xmlrpc' ) ) {
		remove_action( 'wp_head', 'rsd_link' );
		remove_action( 'wp_head', 'wlwmanifest_link' );
	}
	add_filter( 'feed_links_show_comments_feed', '__return_false' );
} );
