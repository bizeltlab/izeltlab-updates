<?php
/**
 * 1.7.0: the server lines (.htaccess) the shop needs, written by a button instead of by hand in cPanel:
 * - compression: stylesheets, scripts, pages, fonts' CSS and SVG travel packed (Brotli where the server has it, else
 *   gzip), about a quarter of their size. Before, a 127 KB stylesheet travelled as 127 KB;
 * - the security headers (when "Security headers" is ticked) from the server itself, so they are on every answer,
 *   also on pages the page cache serves without starting WordPress, plus HSTS (browsers always use https) on an
 *   https site.
 *
 * Safe by design: every line sits inside <IfModule>, so a missing server module only means that part does nothing.
 * The lines go in their own marked block ("Izeltlab Bolt"), nothing else in the file is touched, and the file as it
 * was before the first write is kept (option izb_ht_backup).
 *
 * Tried out first: the press writes the lines into a test folder (uploads/izb-ht) with a small stylesheet, and the
 * admin's own browser fetches that stylesheet. Only when the server answers it properly are the lines written into the
 * real file; a server that refuses them (error 500) only ever breaks the test folder, and the real file is not touched.
 * The browser also reports what it saw (packed or not, headers or not). After the real write the shop asks itself for
 * a page as a second check, where the host lets a site call itself: an error answer takes the block out again at once.
 * "Undo" removes the block. WooCommerce → Ízeltláb Bolt → Server lines.
 */

defined( 'ABSPATH' ) || exit;

const IZB_HT_MARK = 'Izeltlab Bolt';

function izb_ht_file() {
	if ( ! function_exists( 'get_home_path' ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
	}
	return get_home_path() . '.htaccess';
}

// Is our block in the file and switched on? (Saved, so the shop pages never read the file.)
function izb_ht_on() {
	return (bool) get_option( 'izb_ht_on' );
}

// Only Apache and LiteSpeed read .htaccess.
function izb_ht_server_ok() {
	$soft = isset( $_SERVER['SERVER_SOFTWARE'] ) ? strtolower( sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) ) : '';
	return '' === $soft || false !== strpos( $soft, 'apache' ) || false !== strpos( $soft, 'litespeed' );
}

function izb_ht_lines() {
	$types = 'text/html text/plain text/css text/xml text/javascript application/javascript application/x-javascript application/json application/ld+json application/manifest+json application/xml application/rss+xml application/atom+xml image/svg+xml font/ttf font/otf application/vnd.ms-fontobject';
	$l     = array(
		'# Written by the Izeltlab Bolt plugin (WooCommerce > Izeltlab Bolt > Server lines). "Undo" there removes it.',
		'# Compression: text files travel packed.',
		'<IfModule mod_filter.c>',
		'<IfModule mod_brotli.c>',
		'AddOutputFilterByType BROTLI_COMPRESS ' . $types,
		'</IfModule>',
		'<IfModule mod_deflate.c>',
		'AddOutputFilterByType DEFLATE ' . $types,
		'</IfModule>',
		'</IfModule>',
	);
	if ( izb_opt( 'sec_headers' ) ) {
		$l[] = '# Security headers on every answer.';
		$l[] = '<IfModule mod_headers.c>';
		$l[] = 'Header always set X-Content-Type-Options "nosniff"';
		$l[] = 'Header always set X-Frame-Options "SAMEORIGIN"';
		$l[] = 'Header always set Referrer-Policy "strict-origin-when-cross-origin"';
		$l[] = 'Header always set Permissions-Policy "camera=(), microphone=(), geolocation=()"';
		if ( 'https' === wp_parse_url( home_url(), PHP_URL_SCHEME ) ) {
			// no includeSubDomains: the host's own subdomains (cpanel., mail.) have no certificate
			$l[] = 'Header always set Strict-Transport-Security "max-age=15552000"';
		}
		$l[] = '</IfModule>';
	}
	return $l;
}

// Takes the block out of the real file, markers and all (WordPress's own helper leaves an empty block behind).
function izb_ht_strip() {
	$file = izb_ht_file();
	if ( ! is_readable( $file ) || ! is_writable( $file ) ) {
		return false;
	}
	$old = (string) file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	$new = preg_replace( '/^[ \t]*# BEGIN ' . preg_quote( IZB_HT_MARK, '/' ) . '\R.*?^[ \t]*# END ' . preg_quote( IZB_HT_MARK, '/' ) . '[ \t]*(\R|\z)/ms', '', $old );
	if ( null === $new || $new === $old ) {
		return null !== $new;
	}
	return false !== file_put_contents( $file, ltrim( $new, "\r\n" ), LOCK_EX ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
}

// The test folder: the same lines in a folder of their own, with a stylesheet to fetch. true makes it and returns the
// stylesheet's address ('' if it could not be made), false removes it.
function izb_ht_sandbox( $make ) {
	$up  = wp_upload_dir( null, false );
	$dir = trailingslashit( $up['basedir'] ) . 'izb-ht/';
	if ( ! $make ) {
		foreach ( array( '.htaccess', 't.css' ) as $f ) {
			if ( file_exists( $dir . $f ) ) {
				wp_delete_file( $dir . $f );
			}
		}
		if ( is_dir( $dir ) ) {
			@rmdir( $dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
		}
		return '';
	}
	if ( ! wp_mkdir_p( $dir ) ) {
		return '';
	}
	// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
	$ok = false !== file_put_contents( $dir . 't.css', "/* Izeltlab Bolt: server check, safe to delete */\n" . str_repeat( ".izb-check{color:#123456;margin:0 auto}\n", 60 ) );
	$ok = $ok && false !== file_put_contents( $dir . '.htaccess', implode( "\n", izb_ht_lines() ) . "\n" );
	// phpcs:enable
	return $ok ? set_url_scheme( trailingslashit( $up['baseurl'] ) . 'izb-ht/t.css' ) : '';
}

// Why the real file cannot be written, or '' when it can.
function izb_ht_blocked() {
	$file = izb_ht_file();
	if ( ! izb_ht_server_ok() ) {
		return 'Not written: this server does not read .htaccess (it is not Apache or LiteSpeed). Ask the host to turn on compression.';
	}
	if ( ( file_exists( $file ) && ! is_writable( $file ) ) || ( ! file_exists( $file ) && ! is_writable( dirname( $file ) ) ) ) {
		return 'Not written: WordPress may not change the .htaccess file on this host.';
	}
	return '';
}

// The second check, after the real write: the shop asks itself for a page and a stylesheet. Returns the error code the
// server answered with (500...), or 0 when all is well or when the host does not let the site call itself.
function izb_ht_probe() {
	$args = array( 'timeout' => 10, 'redirection' => 2, 'sslverify' => false, 'headers' => array( 'Cache-Control' => 'no-cache' ) );
	foreach ( array( add_query_arg( 'izb_ht', time(), IZB_URL . 'assets/bolt.css' ), add_query_arg( 'izb_ht', time(), home_url( '/' ) ) ) as $url ) {
		$r    = wp_remote_get( $url, $args );
		$code = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
		if ( $code >= 500 && 503 !== $code ) { // 503 = the coming soon page, which is fine
			return $code;
		}
	}
	return 0;
}

/**
 * Writes the block into the real file (true), or removes it (false). Returns a sentence for the settings page.
 * $enc ('br', 'gzip' or '') and $head (headers seen?) are what the browser saw in the test folder; null when the
 * lines are written without a new test (only ever with lines that were tested before, or fewer).
 */
function izb_ht_write( $on = true, $enc = null, $head = null ) {
	if ( ! function_exists( 'insert_with_markers' ) ) {
		require_once ABSPATH . 'wp-admin/includes/misc.php';
	}
	$file = izb_ht_file();
	if ( ! $on ) {
		$gone = ! file_exists( $file ) || izb_ht_strip();
		update_option( 'izb_ht_on', 0 );
		return $gone ? 'The server lines were removed.' : 'The server lines could not be removed: WordPress may not change the .htaccess file on this host.';
	}
	$why = izb_ht_blocked();
	if ( $why ) {
		return $why;
	}
	if ( false === get_option( 'izb_ht_backup' ) ) { // the file as it was before Bolt ever touched it
		add_option( 'izb_ht_backup', file_exists( $file ) ? (string) file_get_contents( $file ) : '', '', false ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	}
	if ( ! insert_with_markers( $file, IZB_HT_MARK, izb_ht_lines() ) ) {
		return 'Not written: the .htaccess file could not be changed.';
	}
	$code = izb_ht_probe();
	if ( $code ) {
		izb_ht_strip();
		update_option( 'izb_ht_on', 0 );
		return 'Taken out again: after writing the lines, the server answered with error ' . $code . '. Nothing is changed; the shop works as before.';
	}
	$seen = (array) get_option( 'izb_ht_seen', array() );
	$enc  = null === $enc ? ( isset( $seen['enc'] ) ? (string) $seen['enc'] : '' ) : ( in_array( $enc, array( 'br', 'gzip' ), true ) ? $enc : '' );
	$head = (bool) ( null === $head ? ! empty( $seen['head'] ) : $head ) && izb_opt( 'sec_headers' );
	update_option( 'izb_ht_seen', array( 'enc' => $enc, 'head' => $head ? 1 : 0 ), false );
	update_option( 'izb_ht_on', $head ? 1 : 0 ); // off: WordPress keeps sending the headers itself
	$msg = 'Server lines written and checked. ';
	$msg .= $enc ? 'Compression works (' . ( 'br' === $enc ? 'Brotli' : 'gzip' ) . ').' : 'Compression did not start: the server lacks the module, ask the host for mod_deflate.';
	if ( izb_opt( 'sec_headers' ) ) {
		$msg .= $head ? ' Security headers come from the server.' : ' The server did not add the security headers (mod_headers is missing), so WordPress keeps sending them.';
	}
	return $msg;
}

function izb_ht_in_file() {
	$file = izb_ht_file();
	return is_readable( $file ) && false !== strpos( (string) file_get_contents( $file ), '# BEGIN ' . IZB_HT_MARK ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
}

/**
 * The button. First press: the lines go into the test folder and a small page makes the browser fetch the test
 * stylesheet. The answer decides: fine (step=go, with what the browser saw) writes the real file; refused (step=bad)
 * leaves it alone.
 */
add_action( 'admin_post_izb_ht_apply', function () {
	check_admin_referer( 'izb_ht_apply' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die();
	}
	$step = isset( $_GET['step'] ) ? sanitize_key( wp_unslash( $_GET['step'] ) ) : '';
	if ( 'go' === $step ) {
		izb_ht_sandbox( false );
		izb_back( izb_ht_write( true, isset( $_GET['enc'] ) ? sanitize_key( wp_unslash( $_GET['enc'] ) ) : '', ! empty( $_GET['head'] ) ) );
	}
	if ( 'bad' === $step ) {
		izb_ht_sandbox( false );
		$code = isset( $_GET['code'] ) ? absint( $_GET['code'] ) : 0;
		izb_back( 'Not written: the server ' . ( $code ? 'answered the test with error ' . $code : 'did not answer the test' ) . ', so the real .htaccess file was not touched. The shop works as before.' );
	}
	$why = izb_ht_blocked();
	if ( $why ) {
		izb_back( $why );
	}
	$test = izb_ht_sandbox( true );
	if ( ! $test ) {
		izb_ht_sandbox( false );
		izb_back( 'Not written: the test folder could not be made in uploads.' );
	}
	$next = wp_nonce_url( admin_url( 'admin-post.php?action=izb_ht_apply' ), 'izb_ht_apply' );
	nocache_headers();
	header( 'Content-Type: text/html; charset=utf-8' );
	echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Checking the server…</title></head>';
	echo '<body style="font:16px/1.5 system-ui,sans-serif;padding:40px;color:#1d2327"><p>Checking that the server accepts the new lines… this takes a few seconds.</p>';
	echo '<noscript><p>This check needs JavaScript. <a href="' . esc_url( admin_url( 'admin.php?page=izeltlab-bolt' ) ) . '">Back</a></p></noscript>';
	echo '<script>(function(){var next=' . wp_json_encode( html_entity_decode( $next, ENT_QUOTES ) ) . ',test=' . wp_json_encode( $test ) . ',done=false;'
		. 'function end(q){if(!done){done=true;location.replace(next+q)}}'
		. 'fetch(test+"?t="+Date.now(),{cache:"no-store",credentials:"omit"}).then(function(r){'
		. 'if(r.ok){end("&step=go&enc="+encodeURIComponent(r.headers.get("content-encoding")||"")+"&head="+(r.headers.get("x-content-type-options")?1:0))}'
		. 'else{end("&step=bad&code="+r.status)}'
		. '}).catch(function(){end("&step=bad&code=0")});'
		. 'setTimeout(function(){end("&step=bad&code=0")},20000)})();</script></body></html>';
	exit;
} );
add_action( 'admin_post_izb_ht_undo', function () {
	check_admin_referer( 'izb_ht_undo' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die();
	}
	izb_ht_sandbox( false );
	izb_back( izb_ht_write( false ) );
} );

// The "Security headers" tick changed while the block is in the file. Unticked: the header lines go (fewer lines need
// no new test). Ticked: WordPress sends the headers itself until "Write again and check" has tried the header lines out.
add_action( 'update_option_izb', function ( $old, $new ) {
	$old = wp_parse_args( (array) $old, izb_defaults() );
	$new = wp_parse_args( (array) $new, izb_defaults() );
	if ( ( ! empty( $old['sec_headers'] ) ) === ( ! empty( $new['sec_headers'] ) ) || ! izb_ht_in_file() ) {
		return;
	}
	if ( empty( $new['sec_headers'] ) ) {
		izb_ht_write( true );
	}
	update_option( 'izb_ht_on', 0 );
}, 20, 2 );

// The plugin is switched off or deleted: the block goes with it (the headers would otherwise stay without their switch).
register_deactivation_hook( IZB_DIR . 'izeltlab-bolt.php', function () {
	izb_ht_sandbox( false );
	if ( izb_ht_in_file() ) {
		izb_ht_write( false );
	}
} );

// The settings page box.
function izb_ht_box() {
	$in   = izb_ht_in_file();
	$seen = (array) get_option( 'izb_ht_seen', array() );
	echo '<h2 id="izb-server">Server lines (compression, security headers)</h2>';
	if ( ! izb_ht_server_ok() ) {
		echo '<p>This server does not read <code>.htaccess</code>, so there is nothing to write here. Ask the host to turn on compression (gzip or Brotli).</p>';
		return;
	}
	if ( $in ) {
		$enc = isset( $seen['enc'] ) ? (string) $seen['enc'] : '';
		echo '<p><span class="dashicons dashicons-yes-alt" style="color:#1d7a45"></span> <b>On.</b> ' . ( $enc ? 'Text files travel packed (' . esc_html( 'br' === $enc ? 'Brotli' : 'gzip' ) . ').' : 'The lines are in the file, but the server did not pack the test file (module missing: ask the host for mod_deflate).' ) . ( izb_ht_on() ? ' The security headers come from the server, on cached pages too.' : ( izb_opt( 'sec_headers' ) && false === strpos( implode( "\n", (array) @file( izb_ht_file() ) ), 'X-Content-Type-Options' ) ? ' The security headers are not in the file yet: press "Write again and check".' : '' ) ) . '</p>';
	} else {
		echo '<p><b>Off.</b> The server sends stylesheets, scripts and pages unpacked, about four times the size they need to travel. One press writes the lines into <code>.htaccess</code>, checks that the shop still answers, and takes them out again by itself if it does not.</p>';
	}
	echo '<p style="display:flex;gap:8px;flex-wrap:wrap">';
	echo '<a class="button' . ( $in ? '' : ' button-primary' ) . '" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=izb_ht_apply' ), 'izb_ht_apply' ) ) . '">' . ( $in ? 'Write again and check' : 'Turn on compression and server headers' ) . '</a>';
	if ( $in ) {
		echo '<a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=izb_ht_undo' ), 'izb_ht_undo' ) ) . '">Undo (remove the lines)</a>';
	}
	echo '</p><details><summary>The lines' . ( false !== get_option( 'izb_ht_backup' ) ? ' and the file as it was before' : '' ) . '</summary>';
	echo '<textarea readonly rows="8" class="large-text code" onclick="this.select()">' . esc_textarea( implode( "\n", izb_ht_lines() ) ) . '</textarea>';
	if ( false !== get_option( 'izb_ht_backup' ) ) {
		echo '<p>The <code>.htaccess</code> file before Bolt first wrote into it (for the host\'s support, should it ever be needed):</p><textarea readonly rows="8" class="large-text code" onclick="this.select()">' . esc_textarea( (string) get_option( 'izb_ht_backup' ) ) . '</textarea>';
	}
	echo '</details>';
}

// A reminder on the dashboard until it is on (Apache / LiteSpeed only).
add_action( 'admin_notices', function () {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! current_user_can( 'manage_options' ) || ! $screen || ! in_array( $screen->id, array( 'dashboard', 'woocommerce_page_izeltlab-bolt', 'plugins' ), true ) ) {
		return;
	}
	if ( ! izb_ht_server_ok() || get_option( 'izb_ht_seen' ) || izb_ht_in_file() ) {
		return;
	}
	echo '<div class="notice notice-warning"><p><b>Ízeltláb Bolt:</b> the server sends the shop\'s files unpacked, so every page is about four times heavier than it needs to be. <a class="button button-primary" style="margin-left:6px" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=izb_ht_apply' ), 'izb_ht_apply' ) ) . '">Turn on compression</a></p></div>';
} );
