<?php
/**
 * 1.2.0: page caching that cannot break the cart. WooCommerce already keeps the cart, checkout and account pages out
 * of every page cache; this file adds the rest of the shop's own rules for the cache plugins Dan may get with a host:
 * - never cache: the order desk's phone page, a page with ?add-to-cart, a visitor with something in the cart for
 *   the cart/checkout pages (the cart count in the header updates by itself on cached pages: WooCommerce's cart
 *   fragments, loaded by the theme);
 * - never combine, delay or defer the scripts that run the buy box, the drawer and the Codex card (that is what
 *   breaks a shop most often after "optimisation");
 * - the settings page shows what is installed and what to set by hand.
 */

defined( 'ABSPATH' ) || exit;

// The scripts that must run as they are (paths are matched as parts of the URL).
function izb_cache_js_keep() {
	return array( '/themes/izeltlab/', '/plugins/codex/', '/plugins/izeltlab-bolt/', '/plugins/woocommerce/', 'jquery' );
}

function izb_cache_urls() {
	$out = array();
	foreach ( array( 'cart', 'checkout', 'myaccount' ) as $p ) {
		$id = function_exists( 'wc_get_page_id' ) ? wc_get_page_id( $p ) : 0;
		if ( $id > 0 ) {
			$out[] = (string) wp_parse_url( get_permalink( $id ), PHP_URL_PATH );
		}
	}
	return array_values( array_filter( $out ) );
}

// Pages that must never be stored (on top of WooCommerce's own).
add_action( 'template_redirect', function () {
	if ( ! izb_opt( 'cache_rules' ) ) {
		return;
	}
	if ( isset( $_GET['izb_pult'] ) || isset( $_GET['add-to-cart'] ) || ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true ); // WP Super Cache, W3 Total Cache, WP Fastest Cache, Breeze, SiteGround …
		}
		do_action( 'litespeed_control_set_nocache', 'izeltlab-bolt' ); // LiteSpeed Cache
		nocache_headers();
	}
}, 0 );

/* ------------------------------------------------------------------ WP Rocket */

add_filter( 'rocket_cache_reject_uri', function ( $uris ) {
	if ( izb_opt( 'cache_rules' ) ) {
		foreach ( izb_cache_urls() as $u ) {
			$uris[] = rtrim( $u, '/' ) . '/(.*)';
		}
	}
	return $uris;
} );
add_filter( 'rocket_cache_reject_cookies', function ( $c ) {
	if ( izb_opt( 'cache_rules' ) ) {
		$c[] = 'woocommerce_items_in_cart';
	}
	return $c;
} );
foreach ( array( 'rocket_delay_js_exclusions', 'rocket_exclude_defer_js', 'rocket_exclude_js', 'rocket_exclude_cache_busting' ) as $izb_f ) {
	add_filter( $izb_f, function ( $list ) {
		return izb_opt( 'cache_rules' ) ? array_merge( (array) $list, izb_cache_js_keep() ) : $list;
	} );
}
unset( $izb_f );

/* ------------------------------------------------------------------ LiteSpeed Cache */

foreach ( array( 'litespeed_optm_js_defer_exc', 'litespeed_optimize_js_excludes', 'litespeed_optm_gm_js_exc' ) as $izb_f ) {
	add_filter( $izb_f, function ( $list ) {
		return izb_opt( 'cache_rules' ) ? array_merge( (array) $list, izb_cache_js_keep() ) : $list;
	} );
}
unset( $izb_f );

/* ------------------------------------------------------------------ what is installed (settings page) */

function izb_cache_plugins() {
	$found = array();
	$known = array(
		'LiteSpeed Cache'    => defined( 'LSCWP_V' ),
		'WP Rocket'          => defined( 'WP_ROCKET_VERSION' ),
		'WP Super Cache'     => function_exists( 'wp_cache_phase2' ) || defined( 'WPCACHEHOME' ),
		'W3 Total Cache'     => defined( 'W3TC' ),
		'WP Fastest Cache'   => class_exists( 'WpFastestCache' ),
		'SiteGround Speed Optimizer' => defined( 'SiteGround_Optimizer\VERSION' ) || class_exists( 'SiteGround_Optimizer\Loader\Loader' ),
		'Breeze'             => defined( 'BREEZE_VERSION' ),
		'Autoptimize'        => defined( 'AUTOPTIMIZE_PLUGIN_VERSION' ),
	);
	foreach ( $known as $name => $on ) {
		if ( $on ) {
			$found[] = $name;
		}
	}
	return $found;
}

function izb_cache_box() {
	$found = izb_cache_plugins();
	echo '<h2>Page cache</h2>';
	echo '<p><b>Installed:</b> ' . ( $found ? esc_html( implode( ', ', $found ) ) : 'no cache plugin.' ) . '</p>';
	echo '<p><b>Which one:</b> if the host runs LiteSpeed (most Hungarian hosts do: Rackhost, Tárhely.Eu, DotRoll, Mediacenter), install <b>LiteSpeed Cache</b> and leave its WooCommerce settings as they are. Otherwise <b>WP Super Cache</b> (simple mode). One cache plugin only. Install it on the live site, not on LocalWP.</p>';
	echo '<details><summary>Settings to check by hand</summary><ul style="list-style:disc;margin-left:20px">';
	$urls = izb_cache_urls() ? izb_cache_urls() : array( '/kosar/', '/penztar/', '/fiokom/' );
	echo '<li>Never cache these pages: <code>' . implode( '</code>, <code>', array_map( 'esc_html', $urls ) ) . '</code> (the rules here already ask every cache plugin for that).</li>';
	echo '<li>Never cache for logged-in users (default everywhere): you see your own order desk and edit buttons.</li>';
	echo '<li>Do not use "Combine JS", "Delay JS" or "Defer JS" on the theme, Codex, Ízeltláb Bolt and WooCommerce scripts (the rules here exclude them for WP Rocket and LiteSpeed; other plugins: by hand).</li>';
	echo '<li>CSS minify and browser cache: fine to turn on. Image lazy load of the cache plugin: OFF (WordPress and this plugin already do it, and the first Codex photo must load first).</li>';
	echo '<li>After a theme / plugin update: "Purge all".</li></ul>';
	echo '<p>Browser cache for photos, fonts, CSS and JS on an Apache / LiteSpeed host without a cache plugin (add to <code>.htaccess</code>, or ask the host):</p>';
	echo '<textarea readonly rows="9" class="large-text code" onclick="this.select()">' . esc_textarea( "<IfModule mod_expires.c>\nExpiresActive On\nExpiresByType image/webp \"access plus 1 year\"\nExpiresByType image/jpeg \"access plus 1 year\"\nExpiresByType image/png \"access plus 1 year\"\nExpiresByType image/svg+xml \"access plus 1 year\"\nExpiresByType font/woff2 \"access plus 1 year\"\nExpiresByType text/css \"access plus 1 month\"\nExpiresByType application/javascript \"access plus 1 month\"\n</IfModule>" ) . '</textarea></details>';
}
