<?php
// ==========================================================================
//  FILE: inc/restock.php   (Ízeltláb Bolt plugin)
//  WHAT: Sold-out species stay in the shop; the restock list shows who waits for what.
//  SEEN: Dashboard → WooCommerce → Restock list.
//  SECTIONS IN THIS FILE:
//    1. Data
//    2. Admin page
// ==========================================================================

/**
 * 1.2.0: sold-out species stay in the shop (Dan, 2026-11-05: in their normal place in the grid) and point to "Notify me".
 * The restock list (WooCommerce → Restock list): who waits for what, CSV, a "mail them now" button, and a log of the
 * mails already sent. The sign-ups themselves are in signups.php (table wp_izb_signups, kind "notify").
 */

defined( 'ABSPATH' ) || exit;

// Sold-out products are never hidden from the shop pages, search or related products.
add_filter( 'pre_option_woocommerce_hide_out_of_stock_items', function ( $v ) {
	return izb_opt( 'soldout_show' ) ? 'no' : $v;
} );

// The shop tile of a sold-out product: its button says "Notify me when back" and leads to the form on its page.
add_filter( 'woocommerce_product_add_to_cart_text', function ( $text, $product = null ) {
	return $product instanceof WC_Product && izb_notify_offered( $product ) ? __( 'Notify me', 'izeltlab-bolt' ) : $text;
}, 20, 2 );
add_filter( 'woocommerce_product_add_to_cart_url', function ( $url, $product = null ) {
	return $product instanceof WC_Product && izb_notify_offered( $product ) ? $product->get_permalink() . '#izb-notify' : $url;
}, 20, 2 );
add_filter( 'woocommerce_product_add_to_cart_description', function ( $text, $product = null ) {
	/* translators: %s: product name */
	return $product instanceof WC_Product && izb_notify_offered( $product ) ? sprintf( __( 'Ask to be told when %s is back', 'izeltlab-bolt' ), $product->get_name() ) : $text;
}, 20, 2 );

function izb_notify_offered( $product ) {
	return izb_opt( 'notify_on' ) && ! $product->is_in_stock() && '' !== (string) $product->get_price();
}

// ==========================================================================
//  Data
// ==========================================================================

// Waiting people per product: product_id => [count, oldest date].
function izb_restock_waiting() {
	global $wpdb;
	$rows = $wpdb->get_results( 'SELECT product_id, COUNT(*) AS n, MIN(created) AS first FROM ' . izb_table() . " WHERE kind = 'notify' GROUP BY product_id ORDER BY n DESC", ARRAY_A ); // phpcs:ignore
	$out  = array();
	foreach ( (array) $rows as $r ) {
		$out[ (int) $r['product_id'] ] = array( (int) $r['n'], $r['first'] );
	}
	return $out;
}

function izb_restock_count( $product_id ) {
	global $wpdb;
	return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . izb_table() . " WHERE kind = 'notify' AND product_id = %d", $product_id ) ); // phpcs:ignore
}

// The mails already sent (newest first, last 100): [time, product id, name, how many].
function izb_restock_log( $product_id = 0, $count = 0 ) {
	$log = (array) get_option( 'izb_restock_log', array() );
	if ( $product_id && $count ) {
		array_unshift( $log, array( time(), (int) $product_id, get_the_title( $product_id ), (int) $count ) );
		update_option( 'izb_restock_log', array_slice( $log, 0, 100 ), false );
	}
	return $log;
}

// ==========================================================================
//  Admin page
// ==========================================================================

add_action( 'admin_menu', function () {
	$n     = izb_signups_count( 'notify' );
	$badge = $n ? ' <span class="awaiting-mod">' . (int) $n . '</span>' : '';
	add_submenu_page( class_exists( 'WooCommerce' ) ? 'woocommerce' : 'options-general.php', 'Restock list', 'Restock list' . $badge, 'edit_products', 'izb-restock', 'izb_restock_page' );
}, 61 );

function izb_restock_page() {
	if ( ! current_user_can( 'edit_products' ) ) {
		return;
	}
	$wait = izb_restock_waiting();
	echo '<div class="wrap"><h1>Restock list</h1>';
	if ( isset( $_GET['izb_done'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		echo '<div class="notice notice-success"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['izb_done'] ) ) ) . '</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification
	}
	echo '<p>People who pressed "Notify me" on a sold-out product. When the product is switched back to available, everyone on its line gets one mail and leaves the list. ';
	echo '<a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=izb_restock_csv' ), 'izb_restock_csv' ) ) . '">Export CSV</a></p>';
	if ( ! $wait ) {
		echo '<p><em>Nobody is waiting right now.</em></p>';
	} else {
		echo '<table class="widefat striped" style="max-width:1100px"><thead><tr><th>Product</th><th>Now</th><th>Waiting</th><th>Since</th><th>Emails</th><th></th></tr></thead><tbody>';
		foreach ( $wait as $pid => $w ) {
			$p = wc_get_product( $pid );
			if ( ! $p ) {
				continue;
			}
			$in = $p->is_in_stock();
			echo '<tr><td><b><a href="' . esc_url( get_edit_post_link( $pid ) ) . '">' . esc_html( $p->get_name() ) . '</a></b> · <a href="' . esc_url( $p->get_permalink() ) . '" target="_blank">view</a></td>';
			echo '<td>' . ( $in ? '<span style="color:#1d7a45;font-weight:600">available</span>' : '<span style="color:#b42323;font-weight:600">sold out</span>' ) . '</td>';
			echo '<td><b style="font-size:16px">' . (int) $w[0] . '</b></td><td>' . esc_html( mysql2date( 'Y.m.d.', $w[1] ) ) . '</td>';
			echo '<td><details><summary>show</summary><div style="max-height:180px;overflow:auto">';
			foreach ( izb_restock_emails( $pid ) as $r ) {
				$del = wp_nonce_url( admin_url( 'admin-post.php?action=izb_restock_del&id=' . (int) $r->id ), 'izb_restock_del' );
				echo '<div>' . esc_html( $r->email ) . ' <small>(' . esc_html( mysql2date( 'm.d.', $r->created ) ) . ')</small> <a href="' . esc_url( $del ) . '" style="color:#b42323" onclick="return confirm(\'Remove this address from the list?\')">×</a></div>';
			}
			echo '</div></details></td><td>';
			if ( $in ) {
				echo '<a class="button button-primary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=izb_restock_send&product=' . $pid ), 'izb_restock_send' ) ) . '">Mail them now</a>';
			} else {
				echo '<span class="description">mails go out by themselves when you switch it to available</span>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}
	$log = izb_restock_log();
	if ( $log ) {
		echo '<h2>Sent</h2><table class="widefat striped" style="max-width:700px"><thead><tr><th>When</th><th>Product</th><th>Mails</th></tr></thead><tbody>';
		foreach ( array_slice( $log, 0, 30 ) as $l ) {
			echo '<tr><td>' . esc_html( wp_date( 'Y.m.d. H:i', $l[0] ) ) . '</td><td>' . esc_html( $l[2] ) . '</td><td>' . (int) $l[3] . '</td></tr>';
		}
		echo '</tbody></table>';
	}
	echo '</div>';
}

function izb_restock_emails( $product_id ) {
	global $wpdb;
	return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT id, email, created FROM ' . izb_table() . " WHERE kind = 'notify' AND product_id = %d ORDER BY created", $product_id ) ); // phpcs:ignore
}

add_action( 'admin_post_izb_restock_csv', function () {
	check_admin_referer( 'izb_restock_csv' );
	if ( ! current_user_can( 'edit_products' ) ) {
		wp_die();
	}
	global $wpdb;
	$rows = $wpdb->get_results( 'SELECT product_id, email, created FROM ' . izb_table() . " WHERE kind = 'notify' ORDER BY product_id, created", ARRAY_A ); // phpcs:ignore
	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=izeltlab-varolista-' . gmdate( 'Y-m-d' ) . '.csv' );
	$out = fopen( 'php://output', 'w' ); // phpcs:ignore
	fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore -- Excel reads the accents right with the BOM
	fputcsv( $out, array( 'product', 'product_id', 'email', 'created' ), ';' );
	foreach ( $rows as $r ) {
		fputcsv( $out, izb_csv_row( array( get_the_title( $r['product_id'] ), $r['product_id'], $r['email'], $r['created'] ) ), ';' );
	}
	exit;
} );

add_action( 'admin_post_izb_restock_del', function () {
	check_admin_referer( 'izb_restock_del' );
	if ( ! current_user_can( 'edit_products' ) ) {
		wp_die();
	}
	global $wpdb;
	$wpdb->delete( izb_table(), array( 'id' => absint( $_GET['id'] ?? 0 ), 'kind' => 'notify' ) );
	wp_safe_redirect( add_query_arg( 'izb_done', rawurlencode( 'Removed.' ), admin_url( 'admin.php?page=izb-restock' ) ) );
	exit;
} );

add_action( 'admin_post_izb_restock_send', function () {
	check_admin_referer( 'izb_restock_send' );
	if ( ! current_user_can( 'edit_products' ) ) {
		wp_die();
	}
	$pid = absint( $_GET['product'] ?? 0 );
	$n   = izb_back_in_stock( $pid, 'instock' );
	wp_safe_redirect( add_query_arg( 'izb_done', rawurlencode( sprintf( '%d mail(s) sent.', (int) $n ) ), admin_url( 'admin.php?page=izb-restock' ) ) );
	exit;
} );

// The Products list: a "Waiting" column with the number of people on the restock list.
add_filter( 'manage_edit-product_columns', function ( $cols ) {
	$cols['izb_wait'] = '<span title="Restock list">Waiting</span>';
	return $cols;
}, 30 );
add_action( 'manage_product_posts_custom_column', function ( $col, $id ) {
	if ( 'izb_wait' === $col ) {
		static $wait = null;
		if ( null === $wait ) {
			$wait = izb_restock_waiting();
		}
		echo isset( $wait[ $id ] ) ? '<a href="' . esc_url( admin_url( 'admin.php?page=izb-restock' ) ) . '"><b>' . (int) $wait[ $id ][0] . '</b></a>' : '–';
	}
}, 10, 2 );
