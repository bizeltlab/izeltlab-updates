<?php
// ==========================================================================
//  FILE: inc/packing.php   (Ízeltláb Bolt plugin)
//  WHAT: The printable packing slip of an order.
//  SEEN: Dashboard → an order → Print packing slip.
// ==========================================================================

/**
 * Packing slip: a printable A5/A4 page per order (order screen → "Print packing slip", or the bulk action), with
 * the address, phone, carrier, items with a tick box each, a "live animals: this side up" stamp, and the planned
 * dispatch day. The new-order mail to the shop already goes to the company email ("Apply shop settings").
 */

defined( 'ABSPATH' ) || exit;

add_filter( 'bulk_actions-edit-shop_order', 'izb_bulk_slip' );
add_filter( 'bulk_actions-woocommerce_page_wc-orders', 'izb_bulk_slip' );
function izb_bulk_slip( $a ) {
	$a['izb_slips'] = 'Print packing slips';
	return $a;
}
add_filter( 'handle_bulk_actions-edit-shop_order', 'izb_bulk_slip_go', 10, 3 );
add_filter( 'handle_bulk_actions-woocommerce_page_wc-orders', 'izb_bulk_slip_go', 10, 3 );
function izb_bulk_slip_go( $url, $action, $ids ) {
	if ( 'izb_slips' !== $action ) {
		return $url;
	}
	return wp_nonce_url( admin_url( 'admin-post.php?action=izb_slip&order=' . implode( ',', array_map( 'absint', $ids ) ) ), 'izb_slip' );
}

add_action( 'admin_post_izb_slip', function () {
	check_admin_referer( 'izb_slip' );
	if ( ! current_user_can( 'edit_shop_orders' ) ) {
		wp_die();
	}
	$ids = array_filter( array_map( 'absint', explode( ',', sanitize_text_field( wp_unslash( $_GET['order'] ?? '' ) ) ) ) );
	$co  = izb_opt();
	header( 'Content-Type: text/html; charset=utf-8' );
	echo '<!doctype html><html lang="hu"><head><meta charset="utf-8"><title>Csomaglista</title><style>
	body{font:14px/1.45 "Courier New",monospace;color:#17302E;margin:0}
	.slip{box-sizing:border-box;width:190mm;min-height:130mm;margin:10mm auto;padding:8mm;border:2px solid #17302E;border-radius:4mm;page-break-after:always}
	.top{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px dashed #9FC3B8;padding-bottom:4mm;margin-bottom:4mm}
	h1{font-size:22px;margin:0}h2{font-size:15px;margin:0 0 2mm}
	.cols{display:flex;gap:8mm}.cols>div{flex:1}
	table{width:100%;border-collapse:collapse;margin-top:4mm}th,td{text-align:left;padding:2mm;border-bottom:1px solid #9FC3B8}
	td.box{width:8mm}td.box span{display:inline-block;width:5mm;height:5mm;border:2px solid #17302E}
	.live{display:inline-block;margin-top:3mm;padding:2mm 4mm;border:3px solid #E5484D;color:#E5484D;font-weight:700;font-size:16px;transform:rotate(-2deg)}
	.note{margin-top:4mm;padding:3mm;background:#F4D35E33;border-left:4px solid #F4D35E}
	@media print{.slip{margin:0 auto;border-width:1px}.noprint{display:none}}
	</style></head><body><p class="noprint" style="text-align:center"><button onclick="print()">Nyomtatás</button></p>';
	foreach ( $ids as $id ) {
		$o = wc_get_order( $id );
		if ( ! $o ) {
			continue;
		}
		$plan = $o->get_meta( '_izb_ship' );
		$live = is_array( $plan ) && 'live' === ( $plan['type'] ?? '' );
		echo '<div class="slip"><div class="top"><div><h1>' . esc_html( get_bloginfo( 'name' ) ) . '</h1><div>' . esc_html( $co['co_address'] ) . '</div><div>' . esc_html( izb_email() ) . ( $co['co_phone'] ? ' · ' . esc_html( $co['co_phone'] ) : '' ) . '</div></div>';
		echo '<div style="text-align:right"><h2>Rendelés #' . esc_html( $o->get_order_number() ) . '</h2><div>' . esc_html( wc_format_datetime( $o->get_date_created(), 'Y.m.d. H:i' ) ) . '</div>';
		if ( is_array( $plan ) && ! empty( $plan['out'] ) ) {
			echo '<div>Feladás: <b>' . esc_html( str_replace( '-', '.', $plan['out'] ) ) . '.</b></div>';
		}
		echo '<div>' . esc_html( $o->get_shipping_method() ) . '</div>' . ( $live ? '<div class="live">ÉLŐ ÁLLAT · EZZEL AZ OLDALÁVAL FEL</div>' : '' ) . '</div></div>';
		$ship = $o->get_formatted_shipping_address() ? $o->get_formatted_shipping_address() : $o->get_formatted_billing_address();
		echo '<div class="cols"><div><h2>Címzett</h2>' . wp_kses_post( $ship ) . '<br>' . esc_html( $o->get_billing_phone() ) . '</div><div><h2>Számlázási cím</h2>' . wp_kses_post( $o->get_formatted_billing_address() ) . '<br>' . esc_html( $o->get_billing_email() ) . '</div></div>';
		echo '<table><thead><tr><th></th><th>Termék</th><th>Db</th></tr></thead><tbody>';
		foreach ( $o->get_items() as $it ) {
			$meta = wp_strip_all_tags( wc_display_item_meta( $it, array( 'echo' => false, 'separator' => ', ', 'before' => '', 'after' => '' ) ) );
			echo '<tr><td class="box"><span></span></td><td>' . esc_html( $it->get_name() ) . ( $meta ? '<br><small>' . esc_html( $meta ) . '</small>' : '' ) . '</td><td>' . (int) $it->get_quantity() . '</td></tr>';
		}
		echo '</tbody></table>';
		if ( $o->get_customer_note() ) {
			echo '<div class="note"><b>Megjegyzés:</b> ' . esc_html( $o->get_customer_note() ) . '</div>';
		}
		echo '</div>';
	}
	echo '</body></html>';
	exit;
} );
