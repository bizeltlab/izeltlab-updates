<?php
// ==========================================================================
//  FILE: inc/seo.php   (Ízeltláb Bolt plugin)
//  WHAT: SEO basics without an SEO plugin: descriptions, share image and address, canonical tags, product
//        data for Google, sitemap.
//  SEEN: Search results and link previews (behind the scenes).
//  SECTIONS IN THIS FILE:
//    1. The data of the page (title, description, image, address)
//    2. The tags in the page head
//    3. Photo texts, product data for Google, robots, sitemap
// ==========================================================================

/**
 * SEO basics without an SEO plugin (if Yoast / Rank Math / SEOPress is active, this file steps aside):
 * meta description, Open Graph + Twitter card (share image = the product's main photo, so every share shows the
 * species), canonical is WordPress's own, missing image alt texts get the product name, no user sitemap,
 * product structured data gets the brand and the shipping country (WooCommerce prints the rest).
 */

defined( 'ABSPATH' ) || exit;

// ==========================================================================
//  The data of the page (title, description, image, address)
// ==========================================================================

function izb_seo_plugin() {
	return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || class_exists( 'AIOSEO\\Plugin\\AIOSEO' );
}

function izb_seo_text( $t, $len = 155 ) {
	$t = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( strip_shortcodes( (string) $t ) ) ) );
	return mb_strlen( $t ) > $len ? rtrim( mb_substr( $t, 0, $len - 1 ) ) . '…' : $t;
}

// [description, image url, type, image alt]
// 1.2.0: the share image is a 1200×630 JPEG cut from the photo the card shows (in its saved frame), the size Facebook,
// Messenger and Instagram links show big; the site's own share image (settings) where a page has no photo.
function izb_seo_data() {
	$desc = get_bloginfo( 'description' );
	$img  = '';
	$alt  = get_bloginfo( 'name' );
	$type = 'website';
	if ( function_exists( 'is_product' ) && is_product() ) {
		$p = wc_get_product( get_queried_object_id() );
		if ( $p ) {
			$desc = $p->get_short_description() ? $p->get_short_description() : $p->get_description();
			$img  = izb_product_share_image( $p );
			$alt  = $p->get_name();
			$type = 'product';
		}
	} elseif ( is_singular() ) {
		$post = get_queried_object();
		$desc = has_excerpt( $post ) ? get_the_excerpt( $post ) : $post->post_content;
		$img  = has_post_thumbnail( $post ) ? izb_share_image( get_post_thumbnail_id( $post ) ) : '';
		$type = is_front_page() ? 'website' : 'article';
	} elseif ( is_tax() || is_category() ) {
		$desc = term_description() ? term_description() : $desc;
		$tid  = (int) get_term_meta( get_queried_object_id(), 'thumbnail_id', true ); // a product category's own image
		$img  = $tid ? izb_share_image( $tid ) : '';
	}
	// 1.1.1: the front page is a page with no text of its own; its description is the headline text under the hero
	// (Customize → Ízeltláb front page), which says what the shop is.
	if ( is_front_page() && function_exists( 'izl_mod' ) && '' === izb_seo_text( $desc ) ) {
		$desc = izl_mod( 'izl_hero_text' );
	}
	if ( is_front_page() && ! izb_opt( 'share_img' ) && function_exists( 'izl_hero_products' ) ) {
		$hero = izl_hero_products();
		if ( $hero ) {
			$first = wc_get_product( is_object( $hero[0] ) ? $hero[0]->get_id() : $hero[0] );
			$img   = $first ? izb_product_share_image( $first ) : $img;
		}
	}
	if ( ! $img ) {
		$own = izb_opt( 'share_img' );
		$img = ctype_digit( (string) $own ) && (int) $own ? izb_share_image( (int) $own ) : esc_url_raw( (string) $own );
	}
	if ( ! $img && has_site_icon() ) {
		$img = get_site_icon_url( 512 );
	}
	return array( izb_seo_text( $desc ), $img, $type, $alt );
}

// The product's share image: the Codex card's first photo in its card frame, else the main photo in its Edit photos frame.
function izb_product_share_image( $p ) {
	$id    = 0;
	$frame = array( 50, 50, 1 );
	if ( function_exists( 'fsz_card_image_ids' ) && function_exists( 'izl_is_codex' ) && izl_is_codex( $p->get_id() ) ) {
		$ids = fsz_card_image_ids( $p->get_id() );
		$id  = $ids ? (int) $ids[0] : 0;
		if ( $id && function_exists( 'fsz_frame' ) ) {
			$frame = fsz_frame( fsz_frames( $p->get_id() ), $id );
		}
	}
	if ( ! $id ) {
		$id = (int) $p->get_image_id();
		if ( $id && function_exists( 'izl_photo_frame' ) ) {
			$frame = izl_photo_frame( $p->get_id(), $id );
		}
	}
	$url = $id ? izb_share_image( $id, $frame ) : '';
	return $url ? $url : ( $id ? (string) wp_get_attachment_image_url( $id, 'large' ) : '' );
}

// 1.7.0: the page's one true address, without whatever was typed after the "?" (tracking tags, ?wc-ajax …): the
// share address (og:url) and, where WordPress prints none itself (the front page, the shop, category and tag pages),
// the canonical link, so search engines count every variant of the address as the same page.
function izb_seo_url() {
	if ( is_front_page() ) {
		return home_url( '/' );
	}
	if ( is_singular() ) {
		return (string) get_permalink();
	}
	$url = '';
	if ( function_exists( 'is_shop' ) && is_shop() && ! is_search() ) {
		$url = (string) get_permalink( wc_get_page_id( 'shop' ) );
	} elseif ( is_tax() || is_category() || is_tag() ) {
		$link = get_term_link( get_queried_object() );
		$url  = is_wp_error( $link ) ? '' : (string) $link;
	}
	if ( '' === $url ) { // search results and the rest: the address as asked, as before
		return set_url_scheme( 'http://' . sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ?? '' ) ) . esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ?? '/' ) ) );
	}
	$page = max( 1, (int) get_query_var( 'paged' ) );
	if ( $page > 1 ) {
		global $wp_rewrite;
		$url = $wp_rewrite->using_permalinks() ? trailingslashit( $url ) . user_trailingslashit( $wp_rewrite->pagination_base . '/' . $page, 'paged' ) : add_query_arg( 'paged', $page, $url );
	}
	return $url;
}

// ==========================================================================
//  The tags in the page head
// ==========================================================================

add_action( 'wp_head', function () {
	if ( izb_seo_plugin() || is_admin() ) {
		return;
	}
	if ( ! is_singular() && ! is_search() && ( is_front_page() || ( function_exists( 'is_shop' ) && is_shop() ) || is_tax() || is_category() || is_tag() ) ) {
		echo '<link rel="canonical" href="' . esc_url( izb_seo_url() ) . '">' . "\n";
	}
}, 1 );

add_action( 'wp_head', function () {
	if ( izb_seo_plugin() || is_admin() ) {
		return;
	}
	list( $desc, $img, $type, $alt ) = izb_seo_data();
	$title = wp_get_document_title();
	$url   = izb_seo_url();
	if ( $desc ) {
		echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
	}
	echo '<meta property="og:locale" content="hu_HU">' . "\n";
	echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
	echo '<meta property="og:type" content="' . esc_attr( $type ) . '">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
	echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
	if ( $desc ) {
		echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
	}
	if ( $img ) {
		echo '<meta property="og:image" content="' . esc_url( $img ) . '">' . "\n";
		if ( false !== strpos( $img, '/izb-share/' ) ) { // 1.2.0: our own 1200×630 JPEG, so the size is known
			echo '<meta property="og:image:type" content="image/jpeg">' . "\n";
			echo '<meta property="og:image:width" content="1200">' . "\n";
			echo '<meta property="og:image:height" content="630">' . "\n";
		}
		echo '<meta property="og:image:alt" content="' . esc_attr( $alt ) . '">' . "\n";
		echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	}
	if ( 'product' === $type && ( $p = wc_get_product( get_queried_object_id() ) ) ) {
		echo '<meta property="product:price:amount" content="' . esc_attr( wc_get_price_to_display( $p ) ) . '">' . "\n";
		echo '<meta property="product:price:currency" content="' . esc_attr( get_woocommerce_currency() ) . '">' . "\n";
		echo '<meta property="product:availability" content="' . esc_attr( $p->is_in_stock() ? 'in stock' : 'out of stock' ) . '">' . "\n";
	}
}, 2 );

// ==========================================================================
//  Photo texts, product data for Google, robots, sitemap
// ==========================================================================

// Photos without alt text say what they show (the product's name), for search and screen readers.
add_filter( 'wp_get_attachment_image_attributes', function ( $attr, $att ) {
	if ( empty( $attr['alt'] ) ) {
		$parent = $att->post_parent ? get_post( $att->post_parent ) : null;
		$attr['alt'] = $parent && 'product' === $parent->post_type ? get_the_title( $parent ) : ( $att->post_title ? $att->post_title : '' );
	}
	return $attr;
}, 10, 2 );
add_filter( 'woocommerce_single_product_image_thumbnail_html', function ( $html ) {
	global $product;
	return $product ? str_replace( 'alt=""', 'alt="' . esc_attr( $product->get_name() ) . '"', $html ) : $html;
} );

// Product structured data: brand + where it ships (Google shows "Szállítás: Magyarország").
add_filter( 'woocommerce_structured_data_product', function ( $markup, $product ) {
	$markup['brand'] = array( '@type' => 'Brand', 'name' => get_bloginfo( 'name' ) );
	if ( isset( $markup['offers'][0] ) ) {
		$markup['offers'][0]['shippingDetails'] = array(
			'@type'               => 'OfferShippingDetails',
			'shippingDestination' => array( '@type' => 'DefinedRegion', 'addressCountry' => 'HU' ),
		);
		$markup['offers'][0]['hasMerchantReturnPolicy'] = array(
			'@type'                => 'MerchantReturnPolicy',
			'applicableCountry'    => 'HU',
			'returnPolicyCategory' => 'https://schema.org/MerchantReturnFiniteReturnWindow',
			'merchantReturnDays'   => 14,
		);
	}
	return $markup;
}, 10, 2 );

// The cart, checkout and account pages stay out of search (WooCommerce does cart/checkout; account too).
add_filter( 'wp_robots', function ( $r ) {
	if ( function_exists( 'is_account_page' ) && is_account_page() ) {
		$r['noindex'] = true;
	}
	return $r;
} );

// 1.2.0: the Google sitemap (WordPress's own: /wp-sitemap.xml, linked from robots.txt) leaves out the cart, checkout
// and account pages, which are no use in search results.
add_filter( 'wp_sitemaps_posts_query_args', function ( $args, $type ) {
	if ( 'page' === $type && function_exists( 'wc_get_page_id' ) ) {
		$skip                  = array_filter( array( wc_get_page_id( 'cart' ), wc_get_page_id( 'checkout' ), wc_get_page_id( 'myaccount' ) ), function ( $id ) {
			return $id > 0;
		} );
		$args['post__not_in'] = array_merge( isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array(), $skip );
	}
	return $args;
}, 10, 2 );
