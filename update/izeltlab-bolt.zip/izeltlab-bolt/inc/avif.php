<?php
// ==========================================================================
//  FILE: inc/avif.php   (Ízeltláb Bolt plugin)
//  WHAT: AVIF copies of the shop's photos, a fifth to a third lighter than the WebP files at the same look, given to
//        the browsers that can show them; every other browser keeps getting the WebP. Made by themselves (after every
//        update, every night and a minute after an upload), switched on for shoppers only once the server is checked.
//  SEEN: Behind the scenes; the "Photos" box on the Ízeltláb Bolt settings page (state and the check).
//  SECTIONS IN THIS FILE:
//    1. Can this server make AVIF?
//    2. Making a photo's AVIF copies
//    3. Which photos still need them, and when they are made
//    4. The server lines: the browser gets the AVIF copy when it can show it
//    5. The state on the settings page and the browser check
// ==========================================================================

/**
 * 1.21.0 (Dan's photo speed list, 2026-11-28, item 2: "AVIF with WebP fallback plus one-time conversion").
 *
 * How it works, without changing a single page: next to every photo file a phone or a computer actually loads (the
 * sizes from 300 to 1024 px, e.g. dc2-768x512.webp) an AVIF copy with the same name is made (dc2-768x512.avif), from
 * the same source and cut the same way. The pages keep naming the .webp files. A few server lines in the uploads
 * folder (uploads/.htaccess, its own marked block) hand out the .avif copy instead when the browser says it can show
 * AVIF (every current Chrome, Edge, Firefox, Safari 16+); any other browser, Facebook's link preview and every tool that
 * asks without saying so gets the .webp as before. So nothing in the HTML, the page cache or the scripts changes.
 *
 * Same look: quality 56 was measured on the shop's own photos to keep at least as much detail as WebP at 80 (the
 * PSNR of every tested size was equal or higher), at 15-30% fewer bytes. A copy that does not come out smaller than
 * its WebP is not kept. Only sizes up to 1024 px get one (the 1536/2048 copies are not made at all, and the very big
 * originals are only used by the zoom on computers), which keeps the 1 GB disk use small: about two thirds of the
 * WebP sizes' room again.
 *
 * Safe by design: the lines are first tried in a test folder (uploads/izb-avif) with one tiny photo; only when the
 * server hands out the AVIF there (and still the WebP to a browser that cannot show AVIF) do they go into the real
 * uploads folder, and then one real photo is checked the same way; any wrong answer takes them out again. Where the
 * host does not let the shop call itself, the admin's own browser does the check on the settings page. Removing a
 * photo removes its AVIF copies; a photo made again (Optimise) or edited gets fresh ones.
 * Filters: izb_avif_quality (56), izb_avif_max (1024), izb_avif_min (300). Setting: "AVIF copies" (Speed and sharing).
 */

defined( 'ABSPATH' ) || exit;

const IZB_AVIF_MARK = 'Izeltlab Bolt AVIF';

// ==========================================================================
//  Can this server make AVIF?
// ==========================================================================

// 'imagick', 'gd' or '' (no AVIF here). Worked out once per PHP / ImageMagick version: a tiny photo is really made.
function izb_avif_engine() {
	static $engine = null;
	if ( null !== $engine ) {
		return $engine;
	}
	$sig  = PHP_VERSION . '|' . ( class_exists( 'Imagick' ) && method_exists( 'Imagick', 'getVersion' ) ? (string) ( Imagick::getVersion()['versionString'] ?? '' ) : '' ) . '|' . ( function_exists( 'gd_info' ) ? (string) ( gd_info()['GD Version'] ?? '' ) : '' );
	$have = get_option( 'izb_avif_engine' );
	if ( is_array( $have ) && isset( $have['sig'], $have['e'] ) && $have['sig'] === $sig ) {
		return $engine = (string) $have['e'];
	}
	$engine = '';
	if ( class_exists( 'Imagick' ) ) {
		try {
			if ( Imagick::queryFormats( 'AVIF' ) ) {
				$t = new Imagick();
				$t->newImage( 16, 16, new ImagickPixel( '#6a8f5c' ) );
				$t->setImageFormat( 'avif' );
				$blob = $t->getImageBlob();
				$engine = strlen( $blob ) > 20 && false !== strpos( substr( $blob, 0, 32 ), 'ftyp' ) ? 'imagick' : '';
			}
		} catch ( Exception $e ) {
			$engine = '';
		}
	}
	if ( '' === $engine && function_exists( 'imageavif' ) && function_exists( 'gd_info' ) && ! empty( gd_info()['AVIF Support'] ) ) {
		$t = imagecreatetruecolor( 16, 16 );
		ob_start();
		$ok   = @imageavif( $t, null, 56, 6 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		$blob = (string) ob_get_clean();
		$engine = $ok && strlen( $blob ) > 20 ? 'gd' : '';
	}
	update_option( 'izb_avif_engine', array( 'sig' => $sig, 'e' => $engine ), false );
	return $engine;
}

// AVIF copies wanted and possible.
function izb_avif_on() {
	return izb_opt( 'img_on' ) && izb_opt( 'img_avif' ) && '' !== izb_avif_engine();
}

// ==========================================================================
//  Making a photo's AVIF copies
// ==========================================================================

// WordPress's own photo tools, with one more way to save: AVIF at a set quality (WordPress cannot set the AVIF
// quality on every ImageMagick, so the copy is written here; the cutting and resizing are WordPress's own).
function izb_avif_editor( $file ) {
	require_once ABSPATH . WPINC . '/class-wp-image-editor.php';
	if ( 'imagick' === izb_avif_engine() ) {
		require_once ABSPATH . WPINC . '/class-wp-image-editor-imagick.php';
		if ( ! class_exists( 'IZB_Avif_Imagick', false ) ) {
			// phpcs:disable Generic.Files.OneObjectStructurePerFile
			class IZB_Avif_Imagick extends WP_Image_Editor_Imagick {
				public function izb_avif( $dest, $q ) {
					try {
						$im = clone $this->image;
						$im->stripImage();
						$im->setCompressionQuality( $q ); // the AVIF writer reads this one …
						$im->setImageCompressionQuality( $q ); // … older ones this
						$im->setImageFormat( 'avif' );
						$blob = $im->getImageBlob();
						$im->clear();
					} catch ( Exception $e ) {
						return false;
					}
					return '' !== $blob && false !== file_put_contents( $dest, $blob ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				}
			}
		}
		$ed = new IZB_Avif_Imagick( $file );
	} else {
		require_once ABSPATH . WPINC . '/class-wp-image-editor-gd.php';
		if ( ! class_exists( 'IZB_Avif_GD', false ) ) {
			class IZB_Avif_GD extends WP_Image_Editor_GD {
				public function izb_avif( $dest, $q ) {
					return function_exists( 'imageavif' ) && @imageavif( $this->image, $dest, $q, 6 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
				}
			}
			// phpcs:enable
		}
		$ed = new IZB_Avif_GD( $file );
	}
	$ok = $ed->load();
	return is_wp_error( $ok ) ? null : $ed;
}

// The AVIF name of a .webp file name ('' for anything else).
function izb_avif_name( $webp ) {
	return preg_match( '/\.webp$/i', (string) $webp ) ? preg_replace( '/\.webp$/i', '.avif', (string) $webp ) : '';
}

/**
 * Makes the AVIF copies of one photo. Returns array( made, bytes the copies saved ), and records on the photo what it
 * made (_izb_avif = 1, _izb_avif_files, _izb_avif_for = the main file it was made from).
 */
function izb_avif_make( $id ) {
	$id   = (int) $id;
	$meta = wp_get_attachment_metadata( $id );
	$file = get_attached_file( $id );
	if ( '' === izb_avif_engine() || ! is_array( $meta ) || ! $file || ! is_readable( $file ) ) {
		update_post_meta( $id, '_izb_avif', 'skip' );
		return array( 0, 0 );
	}
	izb_avif_drop( $id ); // older copies (of an earlier version of this photo) never outlive it
	$dir   = trailingslashit( dirname( $file ) );
	$q     = max( 30, min( 90, (int) apply_filters( 'izb_avif_quality', 56 ) ) );
	$max   = (int) apply_filters( 'izb_avif_max', 1024 );
	$min   = (int) apply_filters( 'izb_avif_min', 300 );
	$crops = wp_get_registered_image_subsizes();
	$todo  = array(); // webp name => array( width, height, crop )
	foreach ( (array) ( isset( $meta['sizes'] ) ? $meta['sizes'] : array() ) as $name => $sz ) {
		$w = isset( $sz['width'] ) ? (int) $sz['width'] : 0;
		$h = isset( $sz['height'] ) ? (int) $sz['height'] : 0;
		if ( $w < $min || $w > $max || empty( $sz['file'] ) || '' === izb_avif_name( $sz['file'] ) || ! is_readable( $dir . $sz['file'] ) ) {
			continue;
		}
		$todo[ wp_basename( $sz['file'] ) ] = array( $w, $h, isset( $crops[ $name ]['crop'] ) ? $crops[ $name ]['crop'] : false );
	}
	// the main file itself, when it is small enough to be one of the files a screen picks (a small original)
	if ( ! empty( $meta['width'] ) && (int) $meta['width'] <= $max + 100 && '' !== izb_avif_name( $file ) ) {
		$todo[ wp_basename( $file ) ] = array( (int) $meta['width'], (int) $meta['height'], null );
	}
	$made  = array();
	$saved = 0;
	foreach ( $todo as $webp => $sz ) {
		$ed = izb_avif_editor( $file );
		if ( ! $ed ) {
			break;
		}
		if ( null !== $sz[2] ) {
			$r = $ed->resize( $sz[0], $sz[1], $sz[2] );
			$s = $ed->get_size();
			if ( is_wp_error( $r ) || (int) $s['width'] !== $sz[0] || (int) $s['height'] !== $sz[1] ) {
				continue; // not the same cut as the WebP: no copy, the WebP stays the only one
			}
		}
		$avif = izb_avif_name( $webp );
		if ( ! $ed->izb_avif( $dir . $avif, $q ) ) {
			continue;
		}
		clearstatcache();
		$a = is_file( $dir . $avif ) ? (int) filesize( $dir . $avif ) : 0;
		$b = (int) filesize( $dir . $webp );
		if ( $a < 1 || $a >= $b ) {
			wp_delete_file( $dir . $avif ); // not lighter: the WebP is the better file
			continue;
		}
		$made[] = $avif;
		$saved += $b - $a;
	}
	update_post_meta( $id, '_izb_avif', '1' );
	update_post_meta( $id, '_izb_avif_files', $made );
	update_post_meta( $id, '_izb_avif_for', wp_basename( $file ) );
	return array( count( $made ), $saved );
}

// Removes a photo's AVIF copies (all it made) and its record.
function izb_avif_drop( $id ) {
	$files = get_post_meta( $id, '_izb_avif_files', true );
	$file  = get_attached_file( $id );
	if ( is_array( $files ) && $file ) {
		$dir = trailingslashit( dirname( $file ) );
		foreach ( $files as $n ) {
			$n = wp_basename( (string) $n );
			if ( preg_match( '/\.avif$/i', $n ) && is_file( $dir . $n ) ) {
				wp_delete_file( $dir . $n );
			}
		}
	}
	delete_post_meta( $id, '_izb_avif' );
	delete_post_meta( $id, '_izb_avif_files' );
	delete_post_meta( $id, '_izb_avif_for' );
}

// A photo removed from the media library takes its AVIF copies with it.
add_action( 'delete_attachment', 'izb_avif_drop' );

// A photo whose main file changed (edited in the media library, or made again) gets fresh copies later.
add_filter( 'wp_update_attachment_metadata', function ( $data, $id ) {
	$for = (string) get_post_meta( $id, '_izb_avif_for', true );
	if ( '' !== $for && is_array( $data ) && ! empty( $data['file'] ) && wp_basename( (string) $data['file'] ) !== $for ) {
		izb_avif_drop( $id );
	}
	return $data;
}, 10, 2 );

// ==========================================================================
//  Which photos still need them, and when they are made
// ==========================================================================

// Photos at the shop's current WebP standard (inc/speed.php) without AVIF copies yet.
function izb_avif_todo( $limit = 5 ) {
	return get_posts( array(
		'post_type'      => 'attachment',
		'post_status'    => 'inherit',
		'post_mime_type' => array( 'image/jpeg', 'image/png', 'image/webp' ),
		'posts_per_page' => $limit,
		'fields'         => 'ids',
		'orderby'        => 'ID',
		'order'          => 'DESC', // the newest photos first: they are on the front page
		'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
			'relation' => 'AND',
			array( 'key' => '_izb_photos', 'value' => IZB_PHOTO_PASS ),
			array( 'key' => '_izb_avif', 'compare' => 'NOT EXISTS' ),
		),
	) );
}

// Makes copies for up to $secs seconds. Returns array( photos done, files made, bytes saved, photos left ).
function izb_avif_run( $secs ) {
	if ( ! izb_avif_on() ) {
		return array( 0, 0, 0, 0 );
	}
	$end = microtime( true ) + $secs;
	$n   = 0;
	$f   = 0;
	$s   = 0;
	while ( microtime( true ) < $end ) {
		$ids = izb_avif_todo( 2 );
		if ( ! $ids ) {
			break;
		}
		foreach ( $ids as $id ) {
			list( $made, $saved ) = izb_avif_make( $id );
			$n++;
			$f += $made;
			$s += $saved;
		}
	}
	$left = count( izb_avif_todo( 500 ) );
	if ( $left && ! wp_next_scheduled( 'izb_avif_more' ) ) {
		wp_schedule_single_event( time() + MINUTE_IN_SECONDS, 'izb_avif_more' );
	}
	if ( $f ) {
		izb_avif_rules_sync(); // the first copies are there: the server lines can be tried
	}
	return array( $n, $f, $s, $left );
}

// The background batches (a minute apart) until every photo has its copies.
add_action( 'izb_avif_more', function () {
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 120 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	}
	izb_avif_run( 40 );
} );

// A new upload: its copies a minute later, in the background (the upload itself stays as quick as before).
add_filter( 'wp_generate_attachment_metadata', function ( $meta, $id, $context = 'create' ) {
	if ( 'create' === $context && izb_avif_on() && ! wp_next_scheduled( 'izb_avif_more' ) ) {
		wp_schedule_single_event( time() + MINUTE_IN_SECONDS, 'izb_avif_more' );
	}
	return $meta;
}, 20, 3 );

register_deactivation_hook( IZB_DIR . 'izeltlab-bolt.php', function () {
	wp_clear_scheduled_hook( 'izb_avif_more' );
	izb_avif_rules_write( false ); // the shop then hands out the WebP files again; the copies stay for a later return
} );

// ==========================================================================
//  The server lines: the browser gets the AVIF copy when it can show it
// ==========================================================================

function izb_avif_lines() {
	return array(
		'# Written by the Izeltlab Bolt plugin (Settings: Photos, AVIF copies). A browser that can show AVIF gets the',
		'# .avif copy of a .webp photo when there is one; every other browser gets the .webp.',
		'<IfModule mod_mime.c>',
		'AddType image/avif .avif',
		'</IfModule>',
		'<IfModule mod_rewrite.c>',
		'RewriteEngine On',
		'RewriteCond %{HTTP_ACCEPT} image/avif',
		'RewriteCond %{REQUEST_FILENAME} ^(.+)\.webp$',
		'RewriteCond %1.avif -f',
		'RewriteRule ^(.+)\.webp$ $1.avif [T=image/avif,L]',
		'</IfModule>',
		'<IfModule mod_headers.c>',
		'<FilesMatch "\.(webp|avif)$">',
		'Header append Vary Accept',
		'</FilesMatch>',
		'</IfModule>',
		'<IfModule mod_expires.c>',
		'ExpiresActive On',
		'ExpiresByType image/avif "access plus 1 year"',
		'</IfModule>',
	);
}

function izb_avif_up_dir() {
	$up = wp_upload_dir( null, false );
	return array( trailingslashit( $up['basedir'] ), trailingslashit( set_url_scheme( $up['baseurl'] ) ) );
}

// The lines into uploads/.htaccess (true) or out of it (false). Returns true when the file is as asked.
function izb_avif_rules_write( $on ) {
	list( $dir ) = izb_avif_up_dir();
	$file = $dir . '.htaccess';
	if ( ! function_exists( 'insert_with_markers' ) ) {
		require_once ABSPATH . 'wp-admin/includes/misc.php';
	}
	if ( ! $on ) {
		update_option( 'izb_avif_rules', array( 'state' => 'off', 't' => time() ), false );
		if ( ! is_readable( $file ) || false === strpos( (string) file_get_contents( $file ), '# BEGIN ' . IZB_AVIF_MARK ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
			return true;
		}
		$old = (string) file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$new = preg_replace( '/^[ \t]*# BEGIN ' . preg_quote( IZB_AVIF_MARK, '/' ) . '\R.*?^[ \t]*# END ' . preg_quote( IZB_AVIF_MARK, '/' ) . '[ \t]*(\R|\z)/ms', '', $old );
		if ( null === $new ) {
			return false;
		}
		if ( '' === trim( $new ) ) {
			wp_delete_file( $file ); // the file held nothing else (Bolt made it)
			return true;
		}
		return false !== file_put_contents( $file, ltrim( $new, "\r\n" ), LOCK_EX ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}
	return (bool) insert_with_markers( $file, IZB_AVIF_MARK, izb_avif_lines() );
}

// The test folder: the lines and one tiny photo as .webp and .avif. true: made (returns the .webp address), false: removed.
function izb_avif_sandbox( $make ) {
	list( $dir, $url ) = izb_avif_up_dir();
	$box = $dir . 'izb-avif/';
	if ( ! $make ) {
		foreach ( array( '.htaccess', 't.webp', 't.avif' ) as $f ) {
			if ( file_exists( $box . $f ) ) {
				wp_delete_file( $box . $f );
			}
		}
		if ( is_dir( $box ) ) {
			@rmdir( $box ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
		}
		return '';
	}
	if ( ! wp_mkdir_p( $box ) || '' === izb_avif_engine() ) {
		return '';
	}
	// a tiny picture, written once as WebP (by WordPress) and once as AVIF (as above)
	if ( ! file_exists( $box . 't.webp' ) ) {
		$src = $box . 't.png';
		$im  = function_exists( 'imagecreatetruecolor' ) ? imagecreatetruecolor( 24, 24 ) : null;
		if ( ! $im ) {
			return '';
		}
		imagefill( $im, 0, 0, imagecolorallocate( $im, 106, 143, 92 ) );
		imagepng( $im, $src );
		$ed = wp_get_image_editor( $src );
		$GLOBALS['izb_no_webp'] = true;
		$ok = ! is_wp_error( $ed ) && ! is_wp_error( $ed->save( $box . 't.webp', 'image/webp' ) );
		$GLOBALS['izb_no_webp'] = false;
		$av = $ok ? izb_avif_editor( $src ) : null;
		$ok = $ok && $av && $av->izb_avif( $box . 't.avif', 56 );
		wp_delete_file( $src );
		if ( ! $ok ) {
			return '';
		}
	}
	// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
	if ( false === file_put_contents( $box . '.htaccess', "# BEGIN " . IZB_AVIF_MARK . "\n" . implode( "\n", izb_avif_lines() ) . "\n# END " . IZB_AVIF_MARK . "\n" ) ) {
		return '';
	}
	return $url . 'izb-avif/t.webp';
}

// Asks the server for a .webp address as an AVIF browser and as an older one. 'ok', 'bad: …' or 'unknown' (the host
// does not let the shop call itself).
function izb_avif_probe( $url ) {
	$args = array( 'timeout' => 10, 'redirection' => 0, 'sslverify' => false );
	$a    = wp_remote_get( add_query_arg( 'izb', time(), $url ), $args + array( 'headers' => array( 'Accept' => 'image/avif,image/webp,*/*;q=0.8', 'Cache-Control' => 'no-cache' ) ) );
	if ( is_wp_error( $a ) || ! wp_remote_retrieve_response_code( $a ) ) {
		return 'unknown';
	}
	$w = wp_remote_get( add_query_arg( 'izb', time() + 1, $url ), $args + array( 'headers' => array( 'Accept' => 'image/webp,*/*;q=0.8', 'Cache-Control' => 'no-cache' ) ) );
	return izb_avif_verdict(
		(int) wp_remote_retrieve_response_code( $a ),
		(string) wp_remote_retrieve_header( $a, 'content-type' ),
		substr( (string) wp_remote_retrieve_body( $a ), 0, 32 ),
		is_wp_error( $w ) ? 0 : (int) wp_remote_retrieve_response_code( $w ),
		is_wp_error( $w ) ? '' : (string) wp_remote_retrieve_header( $w, 'content-type' )
	);
}

// The two answers judged the same way for the server's own check and the admin's browser check.
function izb_avif_verdict( $code_a, $type_a, $head_a, $code_w, $type_w ) {
	if ( 200 !== (int) $code_a || 200 !== (int) $code_w ) {
		return 'bad: the server answered ' . (int) $code_a . ' / ' . (int) $code_w;
	}
	if ( false === stripos( $type_w, 'image/webp' ) ) {
		return 'bad: a browser without AVIF got "' . sanitize_text_field( $type_w ) . '" instead of the WebP';
	}
	if ( false === stripos( $type_a, 'image/avif' ) || ( '' !== $head_a && false === strpos( $head_a, 'ftyp' ) ) ) {
		return 'bad: an AVIF browser still got "' . sanitize_text_field( $type_a ) . '" (the server ignores the lines)';
	}
	return 'ok';
}

// One real photo with an AVIF copy (its .webp address), for the last check.
function izb_avif_sample_url() {
	$ids = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_izb_avif', 'meta_value' => '1', 'orderby' => 'ID', 'order' => 'DESC' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	foreach ( $ids as $id ) {
		$files = (array) get_post_meta( $id, '_izb_avif_files', true );
		$main  = wp_get_attachment_url( $id );
		if ( $files && $main ) {
			return trailingslashit( dirname( $main ) ) . rawurlencode( preg_replace( '/\.avif$/i', '.webp', (string) reset( $files ) ) );
		}
	}
	return '';
}

/**
 * Brings the server lines to where they should be. States (option izb_avif_rules): off · wait (the host does not let
 * the shop call itself: the admin's browser checks, section 5) · on · bad (with why; tried again after a day or a
 * press of "Check again").
 */
function izb_avif_rules_sync( $force = false ) {
	$st    = (array) get_option( 'izb_avif_rules', array() );
	$state = isset( $st['state'] ) ? $st['state'] : 'off';
	if ( ! izb_avif_on() ) {
		if ( 'off' !== $state ) {
			izb_avif_rules_write( false );
		}
		return;
	}
	if ( ! $force && ( 'on' === $state || 'wait' === $state || ( 'bad' === $state && time() - (int) ( $st['t'] ?? 0 ) < DAY_IN_SECONDS ) ) ) {
		return;
	}
	if ( ! function_exists( 'izb_ht_server_ok' ) || ! izb_ht_server_ok() ) {
		update_option( 'izb_avif_rules', array( 'state' => 'bad', 'why' => 'this server does not read .htaccess (it is not Apache or LiteSpeed)', 't' => time() ), false );
		return;
	}
	if ( '' === izb_avif_sample_url() ) {
		return; // no copies yet
	}
	$test = izb_avif_sandbox( true );
	if ( '' === $test ) {
		update_option( 'izb_avif_rules', array( 'state' => 'bad', 'why' => 'the test folder could not be made in uploads', 't' => time() ), false );
		return;
	}
	$v = izb_avif_probe( $test );
	if ( 'unknown' === $v ) {
		update_option( 'izb_avif_rules', array( 'state' => 'wait', 'test' => $test, 't' => time() ), false );
		return; // the sandbox stays until the browser check (section 5)
	}
	izb_avif_sandbox( false );
	if ( 'ok' !== $v ) {
		update_option( 'izb_avif_rules', array( 'state' => 'bad', 'why' => substr( $v, 5 ), 't' => time() ), false );
		return;
	}
	izb_avif_rules_go( true );
}

// The lines go into the real uploads folder, then one real photo is checked ($probe: by the server itself). Returns
// the state written.
function izb_avif_rules_go( $probe ) {
	if ( ! izb_avif_rules_write( true ) ) {
		update_option( 'izb_avif_rules', array( 'state' => 'bad', 'why' => 'uploads/.htaccess could not be written', 't' => time() ), false );
		return 'bad';
	}
	$sample = izb_avif_sample_url();
	$v      = $probe && '' !== $sample ? izb_avif_probe( $sample ) : 'unknown';
	if ( 'ok' !== $v && 'unknown' !== $v ) {
		izb_avif_rules_write( false );
		update_option( 'izb_avif_rules', array( 'state' => 'bad', 'why' => substr( $v, 5 ) . ' (on a real photo; the lines were taken out again)', 't' => time() ), false );
		return 'bad';
	}
	update_option( 'izb_avif_rules', array( 'state' => 'on', 'sample' => $sample, 'seen' => 'ok' === $v ? 'server' : 'browser', 't' => time() ), false );
	if ( function_exists( 'izb_soon_purge' ) ) {
		izb_soon_purge(); // not needed for the pages (they are the same), but the next visit then also checks nothing old
	}
	return 'on';
}

// The setting switched: AVIF off takes the lines out at once (the browsers then get the WebP files again).
add_action( 'update_option_izb', function ( $old, $new ) {
	$old = wp_parse_args( (array) $old, izb_defaults() );
	$new = wp_parse_args( (array) $new, izb_defaults() );
	if ( ! empty( $old['img_avif'] ) && empty( $new['img_avif'] ) ) {
		izb_avif_rules_write( false );
	} elseif ( empty( $old['img_avif'] ) && ! empty( $new['img_avif'] ) ) {
		update_option( 'izb_avif_rules', array( 'state' => 'off', 't' => time() ), false );
		if ( ! wp_next_scheduled( 'izb_avif_more' ) ) {
			wp_schedule_single_event( time() + 30, 'izb_avif_more' );
		}
	}
}, 30, 2 );

// ==========================================================================
//  The state on the settings page and the browser check
// ==========================================================================

// The lines for the Photos box (inc/speed.php izb_img_box()).
function izb_avif_box() {
	if ( ! izb_opt( 'img_avif' ) ) {
		echo '<p>AVIF copies: off (setting "AVIF copies" above).</p>';
		return;
	}
	if ( '' === izb_avif_engine() ) {
		echo '<p><b>AVIF copies: this server cannot make AVIF</b> (neither PHP\'s GD nor ImageMagick has it). The shop keeps handing out the WebP files, which is fine. A host that adds AVIF to PHP turns this on by itself.</p>';
		return;
	}
	$left = count( izb_avif_todo( 500 ) );
	$st   = (array) get_option( 'izb_avif_rules', array() );
	$s    = isset( $st['state'] ) ? $st['state'] : 'off';
	$text = array(
		'off'  => 'not handed out yet (the server lines are tried once the first copies are made)',
		'wait' => 'waiting for one check by your browser (this page does it now)',
		'on'   => 'handed out to every browser that can show AVIF (checked)',
		'bad'  => 'not handed out: ' . ( isset( $st['why'] ) ? $st['why'] : '' ) . '. The shop keeps the WebP files; tried again tomorrow',
	);
	echo '<p id="izb-avif-line">AVIF copies (about a fifth lighter, same look): ' . ( $left ? (int) $left . ' photo(s) still to do, made by themselves in the background' : 'every photo has them' ) . '; ' . esc_html( $text[ $s ] ?? $s ) . '.';
	if ( 'bad' === $s ) {
		echo ' <a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=izb_avif_check' ), 'izb_avif_check' ) ) . '">Check again</a>';
	}
	echo '</p>';
	if ( 'wait' === $s && ! empty( $st['test'] ) ) {
		izb_avif_browser_check( (string) $st['test'], 'sandbox' );
	} elseif ( 'on' === $s && ! empty( $st['sample'] ) && 'browser' === ( $st['seen'] ?? '' ) ) {
		izb_avif_browser_check( (string) $st['sample'], 'real' );
	}
}

// The admin's browser asks for the test (or a real) photo twice, as an AVIF browser and as an older one, and tells the
// shop what it got (the host does not let the shop ask itself).
function izb_avif_browser_check( $url, $what ) {
	$post = wp_json_encode( array( 'u' => admin_url( 'admin-ajax.php' ), 'n' => wp_create_nonce( 'izb_avif_seen' ), 'w' => $what ) );
	echo '<script>(function(){var c=' . $post . ',u=' . wp_json_encode( $url ) . ',l=document.getElementById("izb-avif-line");'
		. 'function get(a,i){return fetch(u+(u.indexOf("?")<0?"?":"&")+"izb="+Date.now()+i,{cache:"no-store",credentials:"omit",headers:{Accept:a}}).then(function(r){return r.arrayBuffer().then(function(b){var h=String.fromCharCode.apply(null,new Uint8Array(b.slice(0,32)));return{c:r.status,t:r.headers.get("content-type")||"",h:h}})})}'
		. 'Promise.all([get("image/avif,image/webp,*/*;q=0.8",1),get("image/webp,*/*;q=0.8",2)]).then(function(r){var f=new FormData();f.append("action","izb_avif_seen");f.append("nonce",c.n);f.append("what",c.w);f.append("ca",r[0].c);f.append("ta",r[0].t);f.append("ha",r[0].h.replace(/[^\\x20-\\x7e]/g,"."));f.append("cw",r[1].c);f.append("tw",r[1].t);return fetch(c.u,{method:"POST",body:f,credentials:"same-origin"}).then(function(x){return x.json()}).then(function(x){if(l&&x&&x.data){l.textContent=x.data}})}).catch(function(){})})();</script>';
}

add_action( 'wp_ajax_izb_avif_seen', function () {
	check_ajax_referer( 'izb_avif_seen', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error();
	}
	// phpcs:disable WordPress.Security.NonceVerification.Missing -- checked above
	$v    = izb_avif_verdict( absint( $_POST['ca'] ?? 0 ), sanitize_text_field( wp_unslash( $_POST['ta'] ?? '' ) ), sanitize_text_field( wp_unslash( $_POST['ha'] ?? '' ) ), absint( $_POST['cw'] ?? 0 ), sanitize_text_field( wp_unslash( $_POST['tw'] ?? '' ) ) );
	$what = sanitize_key( wp_unslash( $_POST['what'] ?? '' ) );
	// phpcs:enable
	if ( 'sandbox' === $what ) {
		izb_avif_sandbox( false );
		if ( 'ok' !== $v ) {
			update_option( 'izb_avif_rules', array( 'state' => 'bad', 'why' => substr( $v, 5 ), 't' => time() ), false );
			wp_send_json_success( 'AVIF copies: not handed out (' . substr( $v, 5 ) . '). The shop keeps the WebP files.' );
		}
		izb_avif_rules_go( false );
		wp_send_json_success( 'AVIF copies: the test passed and the lines are on. Reload this page once for the last check on a real photo.' );
	}
	if ( 'ok' !== $v ) {
		izb_avif_rules_write( false );
		update_option( 'izb_avif_rules', array( 'state' => 'bad', 'why' => substr( $v, 5 ) . ' (on a real photo; the lines were taken out again)', 't' => time() ), false );
		wp_send_json_success( 'AVIF copies: taken out again (' . substr( $v, 5 ) . '). The shop keeps the WebP files.' );
	}
	$st         = (array) get_option( 'izb_avif_rules', array() );
	$st['seen'] = 'both';
	update_option( 'izb_avif_rules', $st, false );
	wp_send_json_success( 'AVIF copies: on and checked on a real photo.' );
} );

// "Check again" after a failed check.
add_action( 'admin_post_izb_avif_check', function () {
	check_admin_referer( 'izb_avif_check' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die();
	}
	update_option( 'izb_avif_rules', array( 'state' => 'off', 't' => time() ), false );
	izb_avif_rules_sync( true );
	wp_safe_redirect( admin_url( 'admin.php?page=izeltlab-bolt#izb-photos' ) );
	exit;
} );
