<?php
/**
 * Closed days: Dan's own extra days (settings) join the Hungarian public holidays that the Ízeltláb theme counts in
 * its "Sets off" / "With you" dates (theme 2.1.0, filter izl_closed_days). Without the theme this file does nothing.
 */

defined( 'ABSPATH' ) || exit;

add_filter( 'izl_closed_days', function ( $days ) {
	foreach ( preg_split( '/[\s,;]+/', (string) izb_opt( 'extra_closed' ) ) as $d ) {
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) ) {
			$days[] = $d;
		}
	}
	return array_values( array_unique( $days ) );
} );
