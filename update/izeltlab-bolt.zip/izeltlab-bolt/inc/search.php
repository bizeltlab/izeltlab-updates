<?php
/**
 * 1.2.0: a shop search that knows the species. Every product gets a small search index (post meta _izb_search):
 * its name, the Codex name, Latin name and trade name, its categories, tags, SKU and its own "Search words" (old names,
 * nicknames: product edit screen → General). Accents and capitals do not matter ("gombaszka" finds "gömbászka"),
 * words match from their start ("porcel" finds Porcellio), an initial works ("p scaber"), and a small typo is
 * forgiven ("porcelio"): the results then say what was searched instead.
 */

defined( 'ABSPATH' ) || exit;

define( 'IZB_SEARCH_V', 3 ); // raise to rebuild every index

// "Gömbászka, Porcellio!" → "gombaszka porcellio"
function izb_norm( $s ) {
	$s = remove_accents( wp_strip_all_tags( html_entity_decode( (string) $s, ENT_QUOTES, 'UTF-8' ) ) );
	$s = function_exists( 'mb_strtolower' ) ? mb_strtolower( $s, 'UTF-8' ) : strtolower( $s );
	$s = preg_replace( '/[^a-z0-9]+/', ' ', $s );
	return trim( preg_replace( '/\s+/', ' ', $s ) );
}

// 1.4.0: the index has two parts, " names ~ the rest ": the names (shop name, Codex name, Latin, trade name, search
// words, card number) rank first; the rest is everything the Codex card says (fun fact, description, abilities, the
// detail tiles), the badges and the level in plain words (Hungarian and English), and the groups with their everyday
// names ("ászka", "pill bug"), so a shopper finds a species by whatever they remember about it.
function izb_search_text( $id ) {
	$m     = function ( $k ) use ( $id ) {
		return (string) get_post_meta( $id, $k, true );
	};
	$names = array( get_the_title( $id ), $m( '_sku' ), $m( '_izb_alias' ), $m( '_fsz_name' ), $m( '_fsz_latin' ), $m( '_fsz_trade' ) );
	if ( function_exists( 'fsz_codex_number' ) && ( '' !== $m( '_fsz_name' ) || '' !== $m( '_fsz_latin' ) ) ) {
		$num     = ltrim( (string) fsz_codex_number( $id ), '#' );
		$names[] = $num . ' ' . ltrim( $num, '0' );
	}
	$rest = array( $m( '_fsz_tags' ), $m( '_fsz_fun' ), $m( '_fsz_story' ), $m( '_fsz_ability' ), $m( '_fsz_weak' ) );
	foreach ( array( 'humidity', 'substrate', 'protein', 'offspring' ) as $k ) {
		$rest[] = $m( '_fsz_stat_' . $k );
	}
	foreach ( izb_search_trait_words( $id ) as $w ) {
		$rest[] = $w;
	}
	$rest[] = izb_search_level_words( (int) $m( '_fsz_difficulty' ) );
	foreach ( array( 'product_cat', 'product_tag' ) as $tax ) {
		$terms = get_the_terms( $id, $tax );
		foreach ( is_array( $terms ) ? $terms : array() as $t ) {
			$rest[] = $t->name . ' ' . izb_search_group_words( $t->slug . ' ' . $t->name );
			foreach ( get_ancestors( $t->term_id, $tax, 'taxonomy' ) as $a ) {
				$at = get_term( $a, $tax );
				$rest[] = $at && ! is_wp_error( $at ) ? $at->name . ' ' . izb_search_group_words( $at->slug . ' ' . $at->name ) : '';
			}
		}
	}
	$names = array_unique( explode( ' ', izb_norm( implode( ' ', array_filter( array_map( 'strval', $names ) ) ) ) ) );
	$rest  = array_diff( array_unique( explode( ' ', izb_norm( implode( ' ', array_filter( array_map( 'strval', $rest ) ) ) ) ) ), $names );
	return ' ' . implode( ' ', $names ) . ' ~ ' . implode( ' ', $rest ) . ' ';
}

// The badges in words: the card's own label (in the shop's language) and the words people use for it.
function izb_search_trait_words( $id ) {
	$raw  = (string) get_post_meta( $id, '_fsz_traits', true );
	$keys = function_exists( 'fsz_trait_keys' ) ? (array) fsz_trait_keys( $id ) : array_filter( array_map( 'trim', explode( ',', $raw ) ) );
	$more = array(
		'cleanup' => 'takarítóbrigád takarító bioaktív tisztogató cleanup crew cleaner bioactive',
		'ball'    => 'golyóvá gurul golyó gömb összegömbölyödik rolls into a ball roller',
		'feeder'  => 'etetőállat etető eleség feeder food',
	);
	$out = array();
	foreach ( $keys as $k ) {
		if ( function_exists( 'fsz_traits' ) && isset( fsz_traits()[ $k ]['label'] ) ) {
			$out[] = fsz_traits()[ $k ]['label'];
		}
		$out[] = isset( $more[ $k ] ) ? $more[ $k ] : $k;
	}
	return $out;
}

// The difficulty in words: 1-2 beginner, 3-4 intermediate, 5 expert (the card's levels).
function izb_search_level_words( $diff ) {
	if ( $diff < 1 ) {
		return '';
	}
	$level = $diff <= 2 ? 1 : ( $diff <= 4 ? 2 : 3 );
	$words = array(
		1 => 'kezdő kezdőknek könnyű egyszerű beginner beginners easy',
		2 => 'haladó közepes intermediate',
		3 => 'profi nehéz expert advanced',
	);
	$own = '';
	if ( function_exists( 'fsz_levels' ) && isset( fsz_levels()[ $level ]['word'] ) ) {
		$own = fsz_levels()[ $level ]['word'];
	}
	return $own . ' ' . $words[ $level ];
}

// Everyday names of the groups, found by the group's slug or name.
function izb_search_group_words( $what ) {
	$what   = ' ' . izb_norm( $what ) . ' ';
	$groups = array(
		'isopod|isopoda|aszka|aszkak|porcellio|armadillidium|cubaris' => 'ászka ászkák isopod isopods pill bug pillbug woodlouse woodlice rolly polly roly poly sowbug',
		'roach|roaches|blattodea|csotany|svabbogar'                   => 'csótány csótányok svábbogár roach roaches cockroach',
		'springtail|springtails|collembola|ugrovillas'               => 'ugróvillás ugróvillások springtail springtails collembola',
		'millipede|millipedes|diplopoda|ezerlabu'                    => 'ezerlábú ezerlábúak millipede millipedes',
	);
	$out = array();
	foreach ( $groups as $keys => $words ) {
		foreach ( explode( '|', $keys ) as $k ) {
			if ( false !== strpos( $what, ' ' . $k . ' ' ) ) {
				$out[] = $words;
				break;
			}
		}
	}
	return implode( ' ', $out );
}

function izb_search_index( $id ) {
	update_post_meta( $id, '_izb_search', izb_search_text( $id ) );
}

// Anything that changes what a product is called makes its index go stale; it is rebuilt at the next search.
function izb_search_stale( $id ) {
	if ( 'product' === get_post_type( $id ) ) {
		delete_post_meta( $id, '_izb_search' );
	}
}
add_action( 'save_post_product', 'izb_search_stale', 99 );
add_action( 'set_object_terms', 'izb_search_stale' );
foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $izb_hook ) {
	add_action( $izb_hook, function ( $mid, $pid, $key ) {
		if ( in_array( $key, array( '_fsz_name', '_fsz_latin', '_fsz_trade', '_fsz_tags', '_izb_alias', '_sku', '_fsz_fun', '_fsz_story', '_fsz_ability', '_fsz_weak', '_fsz_traits', '_fsz_difficulty' ), true ) || 0 === strpos( (string) $key, '_fsz_stat_' ) ) {
			izb_search_stale( $pid );
		}
	}, 10, 3 );
}
unset( $izb_hook );
add_action( 'edited_product_cat', function ( $term_id ) {
	foreach ( get_objects_in_term( $term_id, 'product_cat' ) as $pid ) {
		delete_post_meta( $pid, '_izb_search' );
	}
} );

// Indexes the products that have no index yet (a whole shop the first time: a few hundred products take a moment).
function izb_search_fill() {
	if ( (int) get_option( 'izb_search_v' ) !== IZB_SEARCH_V ) {
		delete_post_meta_by_key( '_izb_search' );
		update_option( 'izb_search_v', IZB_SEARCH_V );
	}
	$ids = get_posts( array(
		'post_type'      => 'product',
		'post_status'    => array( 'publish', 'private' ),
		'posts_per_page' => 300,
		'fields'         => 'ids',
		'meta_query'     => array( array( 'key' => '_izb_search', 'compare' => 'NOT EXISTS' ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
		'no_found_rows'  => true,
		'suppress_filters' => true,
	) );
	foreach ( $ids as $id ) {
		izb_search_index( $id );
	}
}

// Products matching every word (from the start of a word), best first: [id => score].
function izb_search_ids( $words ) {
	global $wpdb;
	if ( ! $words ) {
		return array();
	}
	$where = array();
	foreach ( $words as $w ) {
		$where[] = $wpdb->prepare( 'm.meta_value LIKE %s', '% ' . $wpdb->esc_like( $w ) . '%' );
	}
	$rows = $wpdb->get_results( "SELECT m.post_id, m.meta_value, p.post_title FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = '_izb_search' AND p.post_type = 'product' AND p.post_status = 'publish' AND " . implode( ' AND ', $where ) . ' LIMIT 500' ); // phpcs:ignore
	$out  = array();
	foreach ( $rows as $r ) {
		// 1.4.0: a hit in the names (shop name, Codex name, Latin, trade name, card number) counts most
		$cut   = strpos( $r->meta_value, ' ~ ' );
		$title = false !== $cut ? substr( $r->meta_value, 0, $cut + 1 ) : ' ' . izb_norm( $r->post_title ) . ' ';
		$score = 0;
		foreach ( $words as $w ) {
			$score += false !== strpos( $title, ' ' . $w . ' ' ) ? 6 : ( false !== strpos( $title, ' ' . $w ) ? 4 : ( false !== strpos( $r->meta_value, ' ' . $w . ' ' ) ? 2 : 1 ) );
		}
		// sold out comes after what can be bought now
		if ( 'outofstock' === get_post_meta( (int) $r->post_id, '_stock_status', true ) ) {
			$score -= 100;
		}
		$out[ (int) $r->post_id ] = $score;
	}
	arsort( $out );
	return $out;
}

// A typo: each word that finds nothing is swapped for the closest word of the indexes (1 letter off per 4 letters).
function izb_search_fix( $words ) {
	global $wpdb;
	$all = $wpdb->get_col( "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_izb_search' LIMIT 2000" ); // phpcs:ignore
	$voc = array();
	foreach ( $all as $line ) {
		foreach ( explode( ' ', trim( $line ) ) as $w ) {
			if ( strlen( $w ) >= 3 && '~' !== $w ) {
				$voc[ $w ] = true;
			}
		}
	}
	$fixed = array();
	$moved = false;
	foreach ( $words as $w ) {
		if ( isset( $voc[ $w ] ) || strlen( $w ) < 4 ) {
			$fixed[] = $w;
			continue;
		}
		$best = '';
		$bd   = max( 1, intdiv( strlen( $w ), 4 ) ) + 1;
		foreach ( array_keys( $voc ) as $v ) {
			// a typed word may also be the start of a longer one ("porcelio" ~ "porcellio")
			$d = min( levenshtein( $w, $v ), strlen( $v ) > strlen( $w ) ? levenshtein( $w, substr( $v, 0, strlen( $w ) ) ) : 99 );
			if ( $d < $bd ) {
				$bd   = $d;
				$best = $v;
			}
		}
		$fixed[] = $best ? $best : $w;
		$moved   = $moved || ( $best && $best !== $w );
	}
	return $moved ? $fixed : array();
}

// The search of the main query (shop search, and the site search for products).
$GLOBALS['izb_search_fix'] = null;
add_filter( 'posts_search', function ( $search, $q ) {
	global $wpdb;
	if ( ! izb_opt( 'search_on' ) || is_admin() || ! $q->is_main_query() || ! $q->is_search() ) {
		return $search;
	}
	$pt = (array) $q->get( 'post_type' );
	$only = array( 'product' ) === array_values( array_filter( $pt ) );
	if ( ! $only && $pt && ! in_array( 'any', $pt, true ) && ! in_array( 'product', $pt, true ) ) {
		return $search;
	}
	$words = array_values( array_unique( array_filter( explode( ' ', izb_norm( $q->get( 's' ) ) ) ) ) );
	if ( ! $words ) {
		return $search;
	}
	izb_search_fill();
	$ids = izb_search_ids( $words );
	if ( ! $ids ) {
		$fix = izb_search_fix( $words );
		if ( $fix ) {
			$ids = izb_search_ids( $fix );
			if ( $ids ) {
				$GLOBALS['izb_search_fix'] = implode( ' ', $fix );
			}
		}
	}
	if ( ! $ids ) {
		return $only ? ' AND 0 = 1 ' : $search;
	}
	$GLOBALS['izb_search_rank'] = array_keys( $ids );
	$in = implode( ',', array_map( 'intval', array_keys( $ids ) ) );
	if ( $only ) {
		return " AND {$wpdb->posts}.ID IN ($in) ";
	}
	$inner = preg_replace( '/^\s*AND\s*/i', '', (string) $search );
	return $inner ? " AND ( ( $inner ) OR {$wpdb->posts}.ID IN ($in) ) " : " AND {$wpdb->posts}.ID IN ($in) ";
}, 20, 2 );

// Best matches first (unless the visitor picked another sort order).
add_filter( 'posts_search_orderby', function ( $orderby, $q ) {
	global $wpdb;
	if ( ! empty( $GLOBALS['izb_search_rank'] ) && $q->is_main_query() && $q->is_search() ) {
		$by = isset( $_GET['orderby'] ) ? sanitize_key( wp_unslash( $_GET['orderby'] ) ) : 'relevance'; // phpcs:ignore WordPress.Security.NonceVerification
		if ( 'relevance' === $by ) {
			return 'FIELD(' . $wpdb->posts . '.ID,' . implode( ',', array_map( 'intval', $GLOBALS['izb_search_rank'] ) ) . ')';
		}
	}
	return $orderby;
}, 20, 2 );

// "Did you mean": shown above the results when a typo was forgiven.
add_action( 'woocommerce_before_shop_loop', 'izb_search_fix_note', 5 );
add_action( 'woocommerce_no_products_found', 'izb_search_fix_note', 5 );
function izb_search_fix_note() {
	if ( empty( $GLOBALS['izb_search_fix'] ) || ! is_search() ) {
		return;
	}
	/* translators: 1: what was typed, 2: what was searched instead */
	echo '<p class="izb-didyou">' . wp_kses( sprintf( __( 'No exact match for “%1$s”, so here is %2$s.', 'izeltlab-bolt' ), esc_html( get_search_query() ), '<b>' . esc_html( $GLOBALS['izb_search_fix'] ) . '</b>' ), array( 'b' => array() ) ) . '</p>';
	$GLOBALS['izb_search_fix'] = null;
}

// The 404 page: products that sound like the address (the theme calls this hook).
add_action( 'izl_404_suggest', function () {
	if ( ! izb_opt( 'search_on' ) ) {
		return;
	}
	$path  = (string) wp_parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH );
	$words = array_values( array_filter( explode( ' ', izb_norm( str_replace( array( '-', '_', '/' ), ' ', urldecode( $path ) ) ) ), function ( $w ) {
		return strlen( $w ) >= 3 && ! in_array( $w, array( 'termek', 'product', 'shop', 'bolt', 'aszkak', 'html', 'php' ), true );
	} ) );
	if ( ! $words ) {
		return;
	}
	izb_search_fill();
	$ids = array();
	foreach ( $words as $w ) { // any word of the address
		$ids += izb_search_ids( array( $w ) );
		if ( ! $ids && ( $f = izb_search_fix( array( $w ) ) ) ) {
			$ids += izb_search_ids( $f );
		}
	}
	$ids = array_slice( array_keys( $ids ), 0, 3 );
	if ( ! $ids ) {
		return;
	}
	echo '<p class="izb-404-maybe">' . esc_html__( 'Maybe you are looking for:', 'izeltlab-bolt' ) . ' ';
	$links = array();
	foreach ( $ids as $id ) {
		$links[] = '<a href="' . esc_url( get_permalink( $id ) ) . '">' . esc_html( get_the_title( $id ) ) . '</a>';
	}
	echo wp_kses( implode( ', ', $links ), array( 'a' => array( 'href' => array() ) ) ) . '</p>';
} );

// The "Search words" field (product edit screen → General): other names the species is known by.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( array(
		'id'          => '_izb_alias',
		'label'       => 'Search words',
		'description' => 'Other names people may search for: old Latin names, nicknames, misspellings. Not shown anywhere.',
		'desc_tip'    => true,
	) );
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	if ( isset( $_POST['_izb_alias'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- WooCommerce checks the product form
		$product->update_meta_data( '_izb_alias', sanitize_text_field( wp_unslash( $_POST['_izb_alias'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
	}
} );
