<?php
/**
 * Analytics only after "Accept" on the cookie banner (bolt.js loads it). GA4 or Plausible, whichever has an ID.
 * Conversion events: view_item (product page), add_to_cart, begin_checkout, purchase (thank-you page, once).
 * 1.2.0: + view_search_results (what people search for: species you may want to stock), sign_up (notify / newsletter),
 * free_shipping_reached (the cart passed the free-shipping amount), view_cart; Google consent mode v2 set to the
 * visitor's choice (analytics yes, ads no).
 */

defined( 'ABSPATH' ) || exit;

function izb_analytics_cfg() {
	static $cfg = null;
	if ( null !== $cfg ) {
		return $cfg;
	}
	$ga = preg_match( '/^G-[A-Z0-9]+$/', (string) izb_opt( 'ga4' ) ) ? (string) izb_opt( 'ga4' ) : '';
	$pl = sanitize_text_field( (string) izb_opt( 'plausible' ) );
	if ( ( ! $ga && ! $pl ) || is_admin() || current_user_can( 'edit_products' ) ) { // the shop's own visits are not counted
		return $cfg = array();
	}
	$cfg = array( 'ga4' => $ga, 'plausible' => $pl, 'cur' => function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'HUF', 'events' => array() );
	return $cfg;
}

// The page's events, printed for bolt.js (sent only after consent).
add_action( 'wp_footer', function () {
	$cfg = izb_analytics_cfg();
	if ( ! $cfg || ! function_exists( 'is_product' ) ) {
		return;
	}
	$ev = array();
	if ( is_product() && ( $p = wc_get_product( get_queried_object_id() ) ) ) {
		$ev[] = array( 'view_item', array( 'value' => (float) wc_get_price_to_display( $p ), 'items' => array( izb_item( $p ) ) ) );
	}
	if ( is_checkout() && ! is_order_received_page() && WC()->cart ) {
		$items = array();
		foreach ( WC()->cart->get_cart() as $it ) {
			$items[] = izb_item( $it['data'], $it['quantity'] );
		}
		$ev[] = array( 'begin_checkout', array( 'value' => (float) WC()->cart->get_total( 'edit' ), 'items' => $items ) );
	}
	if ( is_search() ) {
		$ev[] = array( 'view_search_results', array( 'search_term' => get_search_query( false ) ) );
	}
	if ( is_cart() && WC()->cart && ! WC()->cart->is_empty() ) {
		$ev[] = array( 'view_cart', array( 'value' => (float) WC()->cart->get_total( 'edit' ) ) );
	}
	if ( is_order_received_page() ) {
		$order = wc_get_order( absint( get_query_var( 'order-received' ) ) );
		if ( $order && ! $order->get_meta( '_izb_tracked' ) ) {
			$items = array();
			foreach ( $order->get_items() as $it ) {
				if ( $it->get_product() ) {
					$items[] = izb_item( $it->get_product(), $it->get_quantity() );
				}
			}
			$ev[] = array( 'purchase', array( 'transaction_id' => (string) $order->get_order_number(), 'value' => (float) $order->get_total(), 'shipping' => (float) $order->get_shipping_total(), 'items' => $items ) );
			$order->update_meta_data( '_izb_tracked', 1 );
			$order->save();
		}
	}
	echo '<script>window.izbEvents=' . wp_json_encode( $ev ) . ';</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}, 5 );

function izb_item( $p, $qty = 1 ) {
	return array( 'item_id' => (string) ( $p->get_sku() ? $p->get_sku() : $p->get_id() ), 'item_name' => $p->get_name(), 'price' => (float) wc_get_price_to_display( $p ), 'quantity' => (int) $qty );
}
