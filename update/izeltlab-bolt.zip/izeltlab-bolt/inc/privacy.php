<?php
// ==========================================================================
//  FILE: inc/privacy.php   (Ízeltláb Bolt plugin)
//  WHAT: GDPR tools: sign-up emails are part of WordPress's personal data export and erase.
//  SEEN: Dashboard → Tools → Export / Erase personal data.
// ==========================================================================

/**
 * GDPR tools: the sign-up emails (signups.php) go into WordPress's own personal-data export and erase
 * (Tools → Export / Erase Personal Data), and a short text is offered for the privacy page (Settings → Privacy).
 * Order data is NOT erased on request (WooCommerce option set by "Apply shop settings"): invoices must be kept
 * 8 years by Hungarian accounting law; the privacy draft says so.
 */

defined( 'ABSPATH' ) || exit;

add_filter( 'wp_privacy_personal_data_exporters', function ( $ex ) {
	$ex['izeltlab-bolt'] = array(
		'exporter_friendly_name' => 'Ízeltláb sign-ups',
		'callback'               => function ( $email ) {
			$data = array();
			foreach ( izb_signups_for( $email ) as $row ) {
				$data[] = array(
					'group_id'    => 'izb-signups',
					'group_label' => 'Ízeltláb feliratkozások',
					'item_id'     => 'izb-' . $row->id,
					'data'        => array(
						array( 'name' => 'Típus', 'value' => 'news' === $row->kind ? 'Hírlevél' : 'Értesítés: ' . get_the_title( $row->product_id ) ),
						array( 'name' => 'Feliratkozás ideje', 'value' => $row->created ),
					),
				);
			}
			return array( 'data' => $data, 'done' => true );
		},
	);
	return $ex;
} );

add_filter( 'wp_privacy_personal_data_erasers', function ( $er ) {
	$er['izeltlab-bolt'] = array(
		'eraser_friendly_name' => 'Ízeltláb sign-ups',
		'callback'             => function ( $email ) {
			$n = izb_signups_delete( $email );
			return array( 'items_removed' => $n > 0, 'items_retained' => false, 'messages' => array(), 'done' => true );
		},
	);
	return $er;
} );

add_action( 'admin_init', function () {
	if ( function_exists( 'wp_add_privacy_policy_content' ) ) {
		wp_add_privacy_policy_content( 'Ízeltláb Bolt', '<p>Feliratkozások (hírlevél, „Szólj, ha van”): az e-mail cím és a feliratkozás ideje, a leiratkozásig. Sütik: izb_consent (a sütiválasztás, 6 hónap). Statisztika csak hozzájárulás után.</p>' );
	}
} );
