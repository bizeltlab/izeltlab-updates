<?php
// ==========================================================================
//  FILE: inc/consent.php   (Ízeltláb Bolt plugin)
//  WHAT: The cookie banner.
//  SEEN: The bottom of every page until the visitor answers.
//  SECTIONS IN THIS FILE:
//    1. Order sources only after "Accept" (since 1.7.0)
// ==========================================================================

/**
 * Cookie banner (own-built, no third party). The shop itself only needs its working cookies (cart, login, the choice
 * itself), so "Only the needed ones" is always offered as one click, equal to "Accept". Analytics (analytics.php)
 * loads only after "Accept". The choice is kept 6 months in the cookie izb_consent (needed|all); the footer link
 * "Cookie settings" (any element with data-izb-cookies) opens the banner again.
 */

defined( 'ABSPATH' ) || exit;

function izb_consent() {
	$c = isset( $_COOKIE['izb_consent'] ) ? sanitize_key( wp_unslash( $_COOKIE['izb_consent'] ) ) : '';
	return in_array( $c, array( 'needed', 'all' ), true ) ? $c : '';
}

add_action( 'wp_footer', function () {
	if ( ! izb_opt( 'cookie_on' ) || is_admin() ) {
		return;
	}
	$url  = get_privacy_policy_url();
	$more = $url ? ' <a href="' . esc_url( $url ) . '">' . esc_html__( 'More about it', 'izeltlab-bolt' ) . '</a>' : '';
	$has  = izb_analytics_cfg() ? 1 : 0;
	echo '<div class="izb-cookies" role="dialog" aria-live="polite" aria-label="' . esc_attr__( 'Cookies', 'izeltlab-bolt' ) . '" hidden data-stats="' . (int) $has . '">';
	echo '<p class="izb-cookies-title">' . esc_html__( 'A crumb of cookies?', 'izeltlab-bolt' ) . '</p>';
	echo '<p class="izb-cookies-text">' . esc_html( $has
		? __( 'The cart and the login need a few cookies to work. With your leave we also count, without names, which pages are visited, so we can make the shop better.', 'izeltlab-bolt' )
		: __( 'The cart and the login need a few cookies to work. We use nothing else.', 'izeltlab-bolt' ) ) . $more . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '<div class="izb-cookies-btns">';
	if ( $has ) {
		echo '<button type="button" class="button is-light izb-ck-needed">' . esc_html__( 'Only the needed ones', 'izeltlab-bolt' ) . '</button>';
		echo '<button type="button" class="button izb-ck-all">' . esc_html__( 'Accept', 'izeltlab-bolt' ) . '</button>';
	} else {
		echo '<button type="button" class="button izb-ck-needed">' . esc_html__( 'Got it', 'izeltlab-bolt' ) . '</button>';
	}
	echo '</div></div>';
}, 50 );

// [izb_cookie_link]: the "Cookie settings" link anywhere (the theme's footer prints one too).
add_shortcode( 'izb_cookie_link', function () {
	return '<a href="#" data-izb-cookies>' . esc_html__( 'Cookie settings', 'izeltlab-bolt' ) . '</a>';
} );

// ==========================================================================
//  Order sources only after "Accept" (since 1.7.0)
// ==========================================================================
// WooCommerce's "order attribution" (where an order came from: a search, an ad, a link) stores what it sees in
// cookies from the first page view. Those are not needed for the shop to work, so under the cookie rules they wait for
// the visitor's yes, like the statistics. Decided in the browser from the banner's cookie (the page itself may come
// from the page cache, the same for everyone); assets/bolt.js switches it on the moment "Accept" is pressed and off
// again (cookies removed) on "Only the needed ones".
add_action( 'wp_enqueue_scripts', function () {
	if ( izb_opt( 'cookie_on' ) && wp_script_is( 'wc-order-attribution', 'enqueued' ) ) {
		wp_add_inline_script( 'wc-order-attribution', 'if(window.wc_order_attribution&&wc_order_attribution.params){wc_order_attribution.params.allowTracking=/(?:^|;\\s*)izb_consent=all(?:;|$)/.test(document.cookie);}', 'before' );
	}
}, 99 );
