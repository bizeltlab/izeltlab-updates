<?php
// ==========================================================================
//  FILE: inc/checkout.php   (Ízeltláb Bolt plugin)
//  WHAT: Checkout the Hungarian way: the order button text, the required consent boxes, the legal lines.
//  SEEN: The checkout page.
// ==========================================================================

/**
 * Checkout the Hungarian way (45/2014. Korm. rendelet + GDPR): the order button says that ordering means paying,
 * the ÁSZF box (WooCommerce's own, once the ÁSZF page is set) and a separate privacy box must be ticked, the phone is
 * asked (the carriers text it), and the order review says when the parcel sets off.
 */

defined( 'ABSPATH' ) || exit;

// "Megrendelés – fizetési kötelezettséggel jár" (the law wants these words, or ones as clear, on the last button).
add_filter( 'woocommerce_order_button_text', function () {
	return __( 'Place order – with obligation to pay', 'izeltlab-bolt' );
}, 20 );

// WooCommerce's terms box text, pointing at the ÁSZF and the withdrawal page.
add_filter( 'woocommerce_get_terms_and_conditions_checkbox_text', function () {
	$terms = (int) wc_terms_and_conditions_page_id();
	$back  = get_page_by_path( 'elallas', OBJECT, 'page' );
	$link  = function ( $url, $text ) {
		return $url ? '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $text ) . '</a>' : esc_html( $text );
	};
	/* translators: 1: link to the terms (ÁSZF), 2: link to the withdrawal page */
	return sprintf( __( 'I have read and accept the %1$s and the %2$s.', 'izeltlab-bolt' ), $link( $terms ? get_permalink( $terms ) : '', __( 'terms', 'izeltlab-bolt' ) ), $link( $back ? get_permalink( $back ) : '', __( 'withdrawal information', 'izeltlab-bolt' ) ) );
} );

// The separate privacy box (consent to process the order data cannot hide inside the ÁSZF box).
add_action( 'woocommerce_checkout_after_terms_and_conditions', function () {
	$url = get_privacy_policy_url();
	$txt = $url
		? sprintf( /* translators: %s: link to the privacy page */ __( 'I have read the %s.', 'izeltlab-bolt' ), '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html__( 'privacy notice', 'izeltlab-bolt' ) . '</a>' )
		: esc_html__( 'I have read the privacy notice.', 'izeltlab-bolt' );
	echo '<p class="form-row validate-required izb-privacy-row"><label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">';
	echo '<input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="izb_privacy" id="izb_privacy" value="1"> ';
	echo '<span>' . wp_kses_post( $txt ) . '</span>&nbsp;<abbr class="required" title="' . esc_attr__( 'required', 'izeltlab-bolt' ) . '">*</abbr></label></p>';
} );

add_action( 'woocommerce_checkout_process', function () {
	if ( empty( $_POST['izb_privacy'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		wc_add_notice( __( 'Please tick that you have read the privacy notice.', 'izeltlab-bolt' ), 'error' );
	}
} );

// Keep the proof of the ticks with the order (date + what was accepted).
add_action( 'woocommerce_checkout_create_order', function ( $order ) {
	if ( ! empty( $_POST['izb_privacy'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$order->update_meta_data( '_izb_privacy_ok', current_time( 'mysql' ) );
	}
	if ( ! empty( $_POST['terms'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$order->update_meta_data( '_izb_terms_ok', current_time( 'mysql' ) );
	}
} );

// Fields: phone required (Foxpost/GLS text the code), company optional and below the name, no second address line.
add_filter( 'woocommerce_billing_fields', function ( $f ) {
	if ( isset( $f['billing_phone'] ) ) {
		$f['billing_phone']['required'] = true;
		$f['billing_phone']['description'] = __( 'The carrier texts you on this number.', 'izeltlab-bolt' );
	}
	if ( isset( $f['billing_company'] ) ) {
		$f['billing_company']['label'] = __( 'Company name (only for a company invoice)', 'izeltlab-bolt' );
	}
	unset( $f['billing_address_2'] );
	return $f;
}, 20 );
add_filter( 'woocommerce_shipping_fields', function ( $f ) {
	unset( $f['shipping_address_2'] );
	return $f;
}, 20 );

// The order review: when the parcel sets off (the theme's shipping rule; the strictest item decides: live animals).
function izb_cart_ship_type() {
	if ( ! function_exists( 'izl_ship_type' ) || ! WC()->cart ) {
		return '';
	}
	$type = 'normal';
	foreach ( WC()->cart->get_cart() as $item ) {
		if ( 'live' === izl_ship_type( $item['product_id'] ) ) {
			$type = 'live';
		}
	}
	return $type;
}

function izb_ship_line_html() {
	$type = izb_cart_ship_type();
	if ( ! $type || ! function_exists( 'izl_ship_plan' ) ) {
		return '';
	}
	list( $out, $arrive, $wait ) = izl_ship_plan( $type );
	$w    = izl_ship_words();
	$when = 0 === $wait ? $w['today'] : ( 1 === $wait ? $w['tomorrow'] : $w['on'][ (int) $out->format( 'N' ) ] );
	$html = '<p class="izb-ship-when"><span>' . esc_html__( 'Sets off', 'izeltlab-bolt' ) . ':</span> <b>' . esc_html( $when ) . '</b> · <span>' . esc_html__( 'Expected', 'izeltlab-bolt' ) . ':</span> <b>' . esc_html( izl_arrive_words( $arrive ) ) . '</b></p>';
	if ( 'live' === $type ) {
		$html .= '<p class="izb-ship-note">' . esc_html__( 'Live animals set off Monday to Wednesday only, so they never spend a weekend in a depot.', 'izeltlab-bolt' ) . '</p>';
	}
	return $html;
}

add_action( 'woocommerce_review_order_before_payment', function () {
	echo izb_ship_line_html(); // phpcs:ignore WordPress.Security.EscapeOutput
} );
add_action( 'woocommerce_after_cart_totals', function () {
	// 1.2.0: the Ízeltláb theme shows its own "Útra kelnek → Nálad lesznek" box on the cart page instead
	if ( apply_filters( 'izb_cart_ship_line', true ) ) {
		echo izb_ship_line_html(); // phpcs:ignore WordPress.Security.EscapeOutput
	}
}, 5 );

// The same plan is kept on the order, for the emails and the packing slip.
add_action( 'woocommerce_checkout_create_order', function ( $order ) {
	$type = izb_cart_ship_type();
	if ( $type && function_exists( 'izl_ship_plan' ) ) {
		list( $out, $arrive ) = izl_ship_plan( $type );
		$order->update_meta_data( '_izb_ship', array( 'type' => $type, 'out' => $out->format( 'Y-m-d' ), 'arrive' => $arrive->format( 'Y-m-d' ) ) );
	}
}, 20 );
