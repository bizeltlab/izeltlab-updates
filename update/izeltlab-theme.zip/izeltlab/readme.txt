=== Ízeltláb ===
Version: 2.11.0

Release copy: only the files the shop needs. The full notes, the translation sources (.po) and the build tools are in
izeltlab-theme-source.zip of the same version, and every version's changes are in the patch notes.

Update: Settings → Ízeltláb updates → Update all. Or by hand: Appearance → Themes → Add New → Upload Theme → izeltlab-theme.zip → "Replace active with uploaded".
Settings and product data are stored on the site, not in the theme, so they stay.
