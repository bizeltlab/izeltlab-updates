=== Ízeltláb ===
Version: 3.0.0

Release copy: only the files the shop needs. Where is what: ARCHITECTURE.md in this folder. The full notes, the
translation sources (.po) and the build tools are in the source zip of the same release, and every version's changes
are in the patch notes.

Update: Settings → Ízeltláb updates → Update all. Or by hand: Appearance → Themes → Add New → Upload Theme → izeltlab-theme.zip → "Replace active with uploaded".
Settings and product data are stored on the site, not in the theme, so they stay.
