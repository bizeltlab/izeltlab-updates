=== Ízeltláb ===
Version: 2.4.0
Requires: Storefront (parent theme), WooCommerce. Works best with the Codex plugin.

The "Retro Handheld" look of the Codex card for the whole shop: teal header, mint background,
Codex-shaped product tiles, yellow press-down buttons, IBM Plex Sans / Mono fonts (bundled, no Google request).

* Header: logo, menu (Ászkák, Kiegészítők, Kezdőknek), search / account / cart icons with a live count.
  Your own menu: Appearance → Menus → "Main menu (Ízeltláb header)".
* Shop and categories: 4 tiles a row, no sidebar, difficulty pills (needs the Codex difficulty filter on).
* Kiegészítők: product category (slug "kiegeszitok") made on theme activation if missing.
* Front page: Appearance → Customize → Ízeltláb kezdőlap (texts and the species on the card).
  Shown when Settings → Reading → "Your homepage displays" is "Your latest posts" or any static page.
* Product page: the Codex card on the left; on the right the buy box. No name on Codex products (the card shows it;
  it stays in the page as a hidden heading for search engines): the sales line instead (Product data → General →
  Sales line, or Edit on the page), then for packs "How many do you want to start with?" + a pack tip, the pack buttons
  (variations), then the buy ticket: price with the VAT note, the stock stamp (In stock / Only N left / Available to
  order / Currently unavailable), "Sets off" and "With you" (Budapest time: before 14:00 on a shipping day it leaves
  the same day; live animals Mon–Wed, the rest Mon–Fri; holidays skipped; expected 1 working day later; rule in
  inc/shop-core.php izl_ship_plan(), refreshed on the page by product.js shipping() so a cached page stays right),
  a torn line, quantity − / + and the cart button. Then trust points (one taken
  from the Codex difficulty), the short description and up to 3 questions. Supplies keep their name, and get the
  sales line and the buy ticket.
  Texts: Appearance → Customize → Ízeltláb termékoldal (empty a field to hide that point).
* Buy box editor (Edit buy box, on the product page, for whoever can edit the product): price of 1 product, the base
  pack (Codex species: from the group, the top category on the card: Isopoda 10 pcs, other groups 1, changeable per
  product or for the whole group), the packs on offer (1×, 2×, 5× the base pack, as variations of "Csomag" priced
  at the base price × the multiple) and Available (every pack in stock / out of stock, no counting). Supplies: price
  and Available. Saved into WooCommerce. The whole buy box has the width of the cart panel.
* 2.1.0 launch pages (inc/launch.php, assets/launch.css, 404.php): cart (free-shipping bar, item cards on a phone,
  no coupon box), empty cart, mini cart under the header cart icon (desktop hover / keyboard), checkout in two columns,
  thank-you page ("what happens now": confirmation, sets off, with you), footer (about line, company email, the legal
  and help pages once they exist, cookie settings, newsletter slot), 404, no search results, My account tabs, the
  WordPress login screen. Hungarian public holidays (Easter-based ones too) are skipped in the ship and arrival
  dates, PHP and product.js alike; live animals also wait when the next day is a holiday. More closed days:
  filter izl_closed_days (the Ízeltláb Bolt plugin's "Extra closed days" field).
* Translation: languages/hu_HU.po / .mo.
* Fonts: IBM Plex, SIL Open Font License (assets/fonts/LICENSE-plex.txt).
* Screen size (PC, 1024px wide and up): the whole theme scales with the screen. 1920×1080 is the drawn size (16px root),
  2560×1440 about 133%, 4K about 200%, short laptop screens down to 70%; text never goes under 13px. On the product page
  the card (Codex 1.37+) and the buy box fit the first screen with the "Related products" title under them. Trust points show their icon and title (the sentence is the hover text). Admins get one toolbar row above
  the card: Edit card, Edit, Edit buy box, hidden name. The scale: style.css 1.5.0 block (html font-size); the room
  under the card: --fsz-fit-bottom.
* Questions (Customizer → Ízeltláb termékoldal): up to 6 (IZL_FAQ_COUNT in functions.php).
* Species pages (1.6.0): under the cart button "Goes well with" (Tedd mellé): 3 supplies with price and a "+" that
  adds them to the cart without leaving the page. They come from the product's Cross-sells (Product data → Linked
  products), else from Kiegészítők; only simple products in stock (IZL_SETUP_COUNT). Under the card and the buy box:
  the trust points as one line (icon + title, the sentence on hover), then "Common questions" (all, in two columns),
  then "Similar species" as small tiles, 6 in a row.
* Shipping (1.7.0): Edit buy box → Shipping: "Live animal" (ships Monday to Wednesday; default for species) or
  "Normal product" (Monday to Friday; default for everything else). Ordered before 14:00 (Budapest) on a shipping day:
  ships the same day, else on the next one (IZL_SHIP_CUTOFF, IZL_SHIP_DAYS). The ticket shows "Feladás: ma / holnap /
  hétfőn" and "Várható szállítás" 1 working day later (Foxpost and GLS deliver the next working day). Public holidays
  are not counted. Free shipping line: Customizer → Ízeltláb termékoldal → Free shipping over (0 = no line); set the same
  amount in WooCommerce → Shipping → Free shipping.
* Supply pages (1.7.0): the description under the buy box (no tabs), categories and tags as pills under the photo, the
  sales line set in from the name with a teal bar. No reviews anywhere (the theme keeps WooCommerce reviews off).
* The small-tile row under every product page (1.7.0): its title per product (Edit buy box, or Edit next to the title;
  empty = "Hasonló fajok" for species, "Ezek is kellhetnek" for the rest). It shows the product's Upsells first, then
  products from the same category or tag, 6 in a row.
* Front page (1.7.1): the back cards' hover effect is White aura, Shine or Lift, with a strength from 0 to 100, set in
  the "Edit cards" panel (theme mods izl_card_fx, izl_card_fx_strength). The cards behind the panel show it while you
  choose. The effect is a layer inside the card (carousel.js adds .izl-fx), never a filter on the card, which would
  flatten its 3D sides. "Minden termék" is a small button to the shop page. The "Ászkák" button has a rolled-up isopod
  that unrolls on hover (izl_bug_icon(); the open isopod with no animation for "reduce motion").
* Front page (1.7.2): the card in front links to its product page: a click anywhere on it opens the page (Enter for the
  keyboard, Ctrl/middle click = new tab), except "Többet" and "Vissza". A photo click no longer changes the photo; a
  drag still swipes. Back cards still come to the front on a click (assets/hero-link.js, data-href in front-page.php).
* Front page (1.7.3): a 4th hover effect, Lift + Shine (the card comes forward and a white streak sweeps across).
  White aura now glows mostly outside the card and softly just inside its edge (no hard white line), a bit stronger.
  A pointed-at back card stays a background card: still dimmed and a little blurred, only less (style.css 1.7.1 block).
* Front page (1.7.4): Lift + Shine is replaced by Float + Aura: the card floats up (the Lift movement, no rim) with
  the White aura glow from behind it. A site that had Lift + Shine saved gets Float + Aura.
* Front page (1.7.5): one hover effect left: a pointed-at back card floats up (Edit cards → Float height; theme mod
  izl_card_fx_strength), dimmed and a little blurred, only less. White aura, Shine, Lift's rim and Float + Aura are
  gone, with their layers. Speed: the cards' idle drift stops while they are scrolled out of view; in Firefox the back
  cards do not drift at all (Chromium unchanged). The "Ászkák" button's isopod sits after the text, seen from above,
  facing right, and walks while the button is pointed at.
* Ászkák button (1.7.6): the isopod is a rolled-up ball; pointed at, it unrolls and walks in place, and rolls up
  again after. On phones (no mouse) it stays open and still.
* Front page (1.7.7, Firefox engine only: Firefox, LibreWolf): against lag and flashing white boxes, the back cards are
  dimmed but not blurred, their 3D sides get one flat shade, and they do not drift (carousel.js GECKO, html.izl-gecko).
  Chromium browsers are unchanged.
* Firefox engine (1.7.8): html.izl-gecko is set in the head on every page. Codex cards: side slices shaded by colour
  instead of 24 filters, no slice transitions while the mouse tilts. Front page turns: dimming in quarter steps, drift
  paused for the turn, positions read before the cards move. Chromium browsers are unchanged.
* Front page (1.7.9): the cards' 3D side is as thin as on the product page. The mirrored resting turn made Codex's fake
  resting side twice as thick; the theme mirrors that side too (style.css, 2 - --fsz-kx). Angle and motion unchanged.
* Front page (1.7.10): the fake resting side stays at its resting size (--izl-kx/--izl-ky, from the Codex turn, lean
  and tilt settings in functions.php), so only the real 3D turn moves the side and it stays in step with the front.
* Breadcrumb (1.7.11): a dark strip glued under the header (mono capitals, bold › separators, last step yellow, one
  line that scrolls sideways on phones). Product pages leave the product out (the card shows its name), so the
  genus is the last, linked step (woocommerce/global/breadcrumb.php); the search-engine data still lists it.
* Product page (1.7.12): thinner breadcrumb strip; "Tedd mellé!"; shipping lines bigger (15px at 1080p, 13px floor on
  short screens and phones); free shipping as a centred mint badge; bigger Tedd mellé names and + buttons.
* Product page (1.7.13): the Codex tags as chips above the sales line, each a link to the shop filtered to that tag
  (Codex 1.38 saves them as WooCommerce product tags too).
* Difficulty (1.7.14): the Codex levels everywhere instead of stars. Shop pills: Összes · Kezdő (max 2) · Kezdő + Haladó
  (max 4), each with a dot in its level colour; product tiles show the level word in its colour (green, yellow, red);
  the difficulty trust point says "Kezdő a Codex alapján" instead of "Nehézség 2/5". Words come from Codex 1.47+.
* New products from the shop (1.7.15, admins only; 1.7.16 without templates): "Új termék" on every category page
  starts an empty draft in that category and its parent groups, opened with the card editor (species) or the buy box
  editor (everything else); on a genus page the Latin name starts with the genus. On the shop page, pick the category
  first. A draft shows a bar with Publish and Delete (to the trash), plus a name field when it has no Codex card; a
  species is named "Latin – „Nickname”" from its card on Publish. Shoppers never see drafts. Templates made with 1.7.15
  are plain drafts now ("Sablon: …"): delete them under Products if you made any.
* Added to cart (1.7.17): after Kosárba the page comes back with a green rubber stamp (a cart with a big check, uneven
  ink) pressed onto the right edge of the buy ticket; it lands with a little thump, holds 5 s and fades out in 3 s,
  and the Codex card's screen flashes once (Codex 1.54+). Smaller and inside the screen on phones. product.js stamp(),
  style.css "1.7.17 added to cart stamp".
* Running low (1.7.17, Codex species): a switch in the buy box editor under Available; on, the yellow light on the
  Codex card blinks while the product is in stock. Same setting as the Codex quick edit (meta _fsz_low).
* Buy ticket (1.7.18): the price is one big number with "Ft" stacked over a small note ("10 db · 27% áfával", the pack
  follows the chosen chip; supplies show only the VAT note). "Nálad lesznek … kedden, nov. 3." comes first, big and
  green ("Nálad lesz" for supplies), "Útra kelnek … ma" under it ("Útra kel"). From 11:00 until 14:00 on a shipping
  day a yellow row says "Ha 14:00-ig megrendeled, még ma feladjuk!" (rechecked every minute, so cached pages are right;
  hidden when sold out). The stock word is a bigger, tilted rubber stamp with a double frame in uneven ink.
* Kosárba vele! (1.7.18): bigger button and − 1 + (species: no − 1 +, the button takes the row). Kosárba adds without a
  reload (WooCommerce's AJAX add to cart): the stamp lands (now lower, so it misses the arrival date), the card
  flashes, the header cart bumps with its new count. Errors, or "Redirect to the cart page after successful addition"
  on, send the form the old way. "Tedd mellé" +: the photo flies to the header cart (or the top right corner).
* Free shipping progress (1.7.18): after any add, under the button: "Már csak 15 500 Ft, és ingyenes a szállítás!"
  with a thin yellow bar, then "Megvan! Ingyenes a szállítás!" in green. The amount is shop-wide: Edit buy box →
  Free shipping over (shop managers), or Customize → Ízeltláb product page. Saving it also sets the minimum order
  amount of WooCommerce's Free shipping in every shipping zone.
* Phone product page (1.7.20, needs Codex 1.56): 42px top bar (cart count never clips), bigger invisible tap areas on
  the breadcrumb (down and sideways) and the logo; card 14% smaller and centred between the bars, its screen kept clear of
  the drawer with the free-shipping line (Codex --fsz-fit-scale / --fsz-fit-center / --fsz-fit-low); leaf litter on every
  phone; pack buttons 41px and the buy row on their 3-column grid (price 28px, Kosárba vele! under 20 db + 50 db); Tedd
  mellé peeks blurred under the closed buy row at its open-drawer place (--izl-pt), no flash on press, the blur follows the
  drawer and fades while pulling, hidden on small phones; the drawer ends at Szállítás.
* Drawer gestures (1.7.20): a clear up-drag anywhere opens it (follows the finger), a down-drag anywhere in the open drawer
  at the top of its list closes it, a tap on the handle toggles, a tap on the open drawer's name / free-shipping area
  closes; no other taps open it; all off while the photo pop-out is open. product.js phone().
* Photo pop-out (1.7.20): starts from the card's exact crop (Codex per-photo position + zoom), frame in the photo's shape,
  so nothing jumps; drag to move when zoomed, and move while pinching.
* Hidden-scroll test (1.7.20): the phone product page scrolls ~100px under the pinned card and drawer so one swipe tucks the
  browser bar away. Off: add_filter( 'izl_phone_hidden_scroll', '__return_false' ).
* Phone product page (1.7.19, screens under 768px, needs Codex 1.55): slim 44px top bar with the breadcrumb under it
  (no "Kezdőlap"), sage background, the Codex card fixed on top and sized to fit, and a bottom buy drawer. Closed: price,
  pack chips, Kosárba vele!, free-shipping line ("Kedden nálad!" once added). Pull or tap the handle to open: arrival line,
  Tedd mellé, Szállítás box (dispatch day, arrival date, walking isopod on the road), stock, tabs. Density adjusts to the
  screen height. A hop + glow every 5 s after the card wakes up, until the first pull. product.js phone(), style.css "phone".
* Photo pop-out (1.7.19, phones): tap the card photo: big photo with dots, pinch or wheel zoom, swipe to switch; the card
  keeps the photo you ended on. product.js photoPop().
* Big phones (1.7.19): with spare room the card moves down to the middle and a leaf-litter (avar) backdrop shows behind it,
  beige fading to sage. assets/avar.svg, body.izl-roomy.
* Logo (1.7.19): "ízeltláb" in Space Mono Bold with the 8-segment line; new favicon and home-screen icon (rolled-up
  isopod), only used when no Site Icon is set. functions.php storefront_site_title_or_logo(), assets/icons/.
* Tedd mellé (1.7.19): rows with a group colour strip and group name (Kiegészítő for supplies); admins see dashed "Üres hely"
  slots up to 3, shoppers never. functions.php izl_setup_items().
* Free shipping reached (1.7.19): green tick, glow and a few crumbs once; the line hides after 5 s. product.js celebrate().

2.0.6 (with Codex 1.63.0): a window dragged across the phone width (either way) reloads into the other layout once
the size settles (0.3 s); a refresh always starts with the drawer closed (history.scrollRestoration manual); after a
mouse wheel the drawer glides on to open or closed instead of resting half open; admins rename the product (the hidden
name) with Edit in the admin strip (izl_product_text key _izl_name, the web address stays); WordPress's own Edit link
is a pill; on computers the added-to-cart stamp lands on the right end of Kosárba vele!, out over the ticket edge.

2.0.7 (with Codex 1.64.0): the buy ticket comes ready from the server (izl_buy_head() on woocommerce_before_add_to_cart_button:
price with the start pack's big number, stock stamp, shipping lines; pack buttons next to the hidden dropdown; − + around
the quantity), product.js only wires them (builds them itself where the server did not). Kosárba vele! and Tedd mellé +
answer at once (stamp, cart count guess, free-shipping line) and the adds go in the background one by one; no card
flash. Leaf litter in two depths (assets/avar-far.svg, avar-near.svg): phones move them with the drawer (scroll-driven),
computers get a patch behind the card (.izl-litter, product.js litter()) with scroll drift and a small mouse shift.

2.1.1 (with Ízeltláb Bolt 1.1.0): no change in the look. The shop's rules moved to inc/shop-core.php (ship dates and
holidays, free-shipping amount, packs and the Edit buy box save, Edit photos save, whole forints, reviews off, the
Kiegészítők category). The Ízeltláb Bolt plugin ships the same file and its copy runs when the plugin is on, so the
rules survive a theme change; without the plugin the theme's copy runs. Edit the two copies together.
functions.php is in page order (map at the top). Fixed: checkout billing box no longer starts lower than the order box.

2.1.2 (with Codex 1.65.0 and Ízeltláb Bolt 1.1.1, deep check 2026-11-05): no change in the look. Front page carousel
reads where the cards are before it moves them (it laid the page out again on every frame of a turn). Storefront's
Google font request is dropped (the font was not used anywhere). With Codex on, IBM Plex Mono comes from Codex's copy
of the same files, so it downloads once. The logo is no longer an H1 on the front page (the hero title is the page's one
H1). Fixed: a product page shown as WooCommerce's "Coming soon" page (or before its product loop ran) died with a fatal
error in Storefront's sticky add-to-cart bar; that bar is now left out only then. The buy button's added_to_cart event
carries the product id (for the analytics). Removed: the fallback for Codex before 1.35.

2.4.0 (with Codex 1.66.0 and Bolt 1.3.0): layouts that follow the window. Phones turned sideways (screen under 500px
tall, under 1024px wide) get the computer layout laid out 1024px wide and fitted to the screen (functions.php izl-vp
script); the product page switches between phone and computer layout on every size change, turn and back-button return
(not while typing). header.php (Storefront's, viewport-fit=cover): no empty strips at the sides of a sideways iPhone;
text keeps clear of the notch. Phone drawer on wider windows: contents centred. Front page on phones (Dan's pick A):
slim product-page header (no menu row), title fitted to one line, kicker and paragraph hidden, cards at the product
page's size fitted to the first screen (assets/home-phone.js), buttons under the cards, back cards further back and
kept inside the screen, swipe left/right turns the carousel (carousel.js). Updates from GitHub: inc/updater.php
(Settings → Ízeltláb updates; same file in Codex and Bolt).

2.3.0 (theme only, with Bolt 1.2.0 and Codex 1.65.0): smooth product page opening on PHONES ONLY (inc/swift.php):
prerender on finger touch of a shop tile (dropped when the finger moves), back/forward cache kept usable (instant
back at the same scroll spot, cart count refreshed), tile photo glides into the product photo (Chrome/Edge, Safari
18.2+; Firefox loads normally). PC, Firefox and reduced motion: nothing runs. Off: filter izl_phone_swift.

2.2.0 (with Ízeltláb Bolt 1.2.0 and Codex 1.65.0, QoL package): sold-out tiles stay in the grid with a "Sold out"
stamp and grey photo; on a sold-out product the buy button says "Szóljatok, ha lesz!" and takes you to the sign-up form
(inside the drawer's Szállítás part on phones). Cart and mini cart: the buy box's free-shipping bar; cart totals: the
phone buy box's "Útra kel / Nálad lesz" box (PC and phone). 404 page: Bolt's suggestions. No other change in the look.
