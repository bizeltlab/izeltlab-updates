// ==========================================================================
//  FILE: assets/product-edit.js   (Ízeltláb theme)
//  WHAT: EDITORS ONLY. The "Termék adatok" window (3.23.0): stock, group, texts, price, packs, shipping in one
//        floating window with one Save.
//  SEEN: Product pages, only for logged-in editors.
//  SECTIONS IN THIS FILE:
//    1. Saving: one helper with clear error messages
//    2. The "Termék adatok" window (3.23.0)
//    3. The toolbar row above the card (phone)
//    4. Computer: the editor tools float over the page
// ==========================================================================

/**
 * Product page, EDITORS ONLY: whoever can edit the product edits the sales line and the pack tip in place, and the
 * price, packs and availability in the buy box editor (saved into WooCommerce, then the page reloads). Shoppers never
 * get this file. assets/product.js calls window.izlProductEdit() once the buy box is ready.
 */
( function ( $ ) {
	'use strict';

	var cfg = window.izlProduct || {};

	/* saving (admin): one request helper that always ends with a clear message, never a silent failure */

	// ==========================================================================
	//  Saving: one helper with clear error messages
	// ==========================================================================

	// Sent the same way as the Codex quick edit (fetch + form data, same-origin cookies), which works on every set-up so far.
	function request( data, nonce ) {
		var done = $.Deferred(), body = new window.FormData();
		data._ajax_nonce = nonce || cfg.edit.nonce;
		Object.keys( data ).forEach( function ( k ) {
			if ( Array.isArray( data[ k ] ) ) {
				data[ k ].forEach( function ( v ) {
					body.append( k + '[]', v );
				} );
			} else {
				body.append( k, data[ k ] );
			}
		} );
		function answer( status, text ) {
			var json = null, at = text.indexOf( '{"success"' );
			if ( at > -1 ) {
				try {
					json = JSON.parse( text.slice( at ) ); // anything a plugin printed before the answer is skipped
				} catch ( e ) {
					json = null;
				}
			}
			if ( json && json.success ) {
				done.resolve( json.data || {} );
			} else if ( json && json.data ) {
				done.reject( String( json.data ) );
			} else if ( '0' === text.trim() ) {
				done.reject( 'Not saved: this address does not see you logged in. Log in again here, then reload the page.' );
			} else if ( '-1' === text.trim() ) {
				done.reject( 'The security check ran out. Reload the page and try again.' );
			} else {
				done.reject( 'Not saved (error ' + status + ( text ? ': ' + text.replace( /<[^>]+>/g, ' ' ).replace( /\s+/g, ' ' ).trim().slice( 0, 140 ) : '' ) + '). Send me this text.' );
			}
		}
		window.fetch( cfg.edit.ajax, { method: 'POST', credentials: 'same-origin', body: body } )
			.then( function ( r ) {
				return r.text().then( function ( t ) {
					answer( r.status, t );
				} );
			} )
			.catch( function ( e ) {
				done.reject( 'Not saved: the site did not answer (' + ( e && e.message ? e.message : 'network' ) + '). Check that you are logged in on this address, then reload.' );
			} );
		return done.promise();
	}

	function showError( after, msg ) {
		var p = after.parentNode.querySelector( '.izl-edit-error' );
		if ( ! p ) {
			p = document.createElement( 'p' );
			p.className = 'izl-edit-error';
			p.setAttribute( 'role', 'alert' );
			after.after( p );
		}
		p.textContent = msg;
	}

	// ==========================================================================
	//  The "Termék adatok" window (3.23.0)
	// ==========================================================================

	/* 3.23.0 (Dan, 2026-11-25): one small window instead of the row of pills over the buy box (Edit buy box, Stock − / +,
	   Group, Hidden name, + Sales line, the Edit buttons on the page). It floats over the page like Bolt's Rendelés-pult:
	   drag it by its header, resize it from any edge or corner, a double-click on the header puts it back; the place,
	   the size and whether it is open are kept on this device. Phones (600px and narrower) show it full screen.
	   Everything is saved with one Save (only what changed), then the page reloads. Closing with unsaved changes asks
	   first. A click on the sales line, the pack tip or the row title on the page opens the window on that field. */

	function esc( t ) {
		return String( t == null ? '' : t ).replace( /&/g, '&amp;' ).replace( /"/g, '&quot;' ).replace( /</g, '&lt;' );
	}

	var BOX = 'izl_pd_box', OPEN = 'izl_pd_open';
	function store( k, v ) {
		try {
			if ( null === v ) {
				localStorage.removeItem( k );
			} else {
				localStorage.setItem( k, JSON.stringify( v ) );
			}
		} catch ( e ) {}
	}
	function stored( k ) {
		try {
			return JSON.parse( localStorage.getItem( k ) || 'null' );
		} catch ( e ) {
			return null;
		}
	}
	function small() {
		return window.matchMedia( '(max-width:600px)' ).matches;
	}

	/* 3.24.0 (Dan, 2026-11-25): top to bottom from what changes most to what is set once: Stock, Price and packs, Texts,
	   Group, Set and forget. No explanation lines under the fields: a short hint on hover (title) where a field is not
	   obvious. The yellow warnings stay (they show only when something needs a look). The "Kevés van" number and the
	   running-low switch are gone: 5 base packs, automatic (inc/shop-core.php izl_low_at()). */
	function fields( d ) {
		var unit = d.packs ? 'pcs' : 'items', g = d.groups || { list: [], now: 0 };
		function sec( title, body, cls ) {
			return '<section class="izl-pd-sec' + ( cls ? ' ' + cls : '' ) + '"><h3>' + title + '</h3>' + body + '</section>';
		}
		function row( legend, body, hint, id ) {
			return '<fieldset class="izl-bb-row"' + ( id ? ' id="' + id + '"' : '' ) + ( hint ? ' title="' + esc( hint ) + '"' : '' ) + '><legend>' + legend + '</legend>' + body + '</fieldset>';
		}
		function text( id, label, value, ph, hint, max ) {
			return row( '<label for="' + id + '">' + label + '</label>', '<input type="text" id="' + id + '" class="izl-bb-text" maxlength="' + ( max || 160 ) + '" placeholder="' + esc( ph ) + '" value="' + esc( value ) + '">', hint );
		}
		var stock = row( 'On hand', '<div class="izl-pd-stock"><button type="button" class="izl-pd-step" data-add="-1" aria-label="One less">−</button>' +
				'<input type="number" id="izl-bb-stock" min="0" step="1" inputmode="numeric" placeholder="none" value="' + ( null === d.stock ? '' : d.stock ) + '" aria-label="On hand">' +
				'<button type="button" class="izl-pd-step" data-add="1" aria-label="One more">+</button><span>' + unit + '</span></div>',
				( d.packs ? 'Every pack takes from this number. ' : '' ) + 'Orders take from it, cancelled ones give it back. 0 = Elfogyott. Empty = not counted. Under ' + d.lowAt + ' ' + unit + ' (5 base packs): "Utolsó N db" and the yellow light.' ) +
			row( 'Available', '<label class="izl-bb-switch"><input type="checkbox" id="izl-bb-avail"' + ( d.available ? ' checked' : '' ) + '><span></span> <b id="izl-bb-avail-text"></b></label>', 'Off = paused: nobody can buy it, whatever the stock.' );
		var price = row( d.packs ? 'Price of 1 base pack' : 'Price', '<label class="izl-bb-inline"><input type="number" id="izl-bb-price" min="0" step="1" value="' + d.price + '"> ' + d.currency + '</label>' ) +
			( d.packs ? row( 'Packs people can choose', '<div class="izl-bb-plist"></div>' +
				'<div class="izl-bb-padd"><label class="izl-bb-inline"><input type="number" id="izl-bb-newc" min="1" step="1" placeholder="e.g. 30"> pcs</label><button type="button" class="izl-bb-addp">+ Own pack</button></div>' +
				'<p class="izl-bb-warn" id="izl-bb-many" hidden>More than 4 packs: phones show them in two rows, and fewer choices sell faster.</p>' +
				( d.handMade ? '<p class="izl-bb-warn">This product has packs made by hand. Saving replaces them with these.</p>' : '' ),
				'Empty price = worked out from the base price; type one for a bulk deal. ◉ = the pack the page starts on.' ) : '' );
		var texts = text( 'izl-pd-headline', 'Sales line', d.headline, 'e.g. The easiest isopod to start with', 'One short sentence at the top of the buy box. Empty = none.' ) +
			( d.hasTip ? text( 'izl-pd-tip', 'Pack tip', d.packTip, d.tipDefault, 'The line under the pack question. Empty = the default.' ) : '' ) +
			text( 'izl-bb-row', 'Row under the page', d.rowTitle, d.rowDefault, 'The title over the small tiles under the page. Empty = "' + d.rowDefault + '".', 80 );
		var group = row( '<label for="izl-pd-group">Group and genus</label>', '<select id="izl-pd-group" class="izl-bb-text">' +
			( g.now ? '' : '<option value="0" selected>(none)</option>' ) +
			g.list.map( function ( o ) {
				return '<option value="' + o[ 0 ] + '"' + ( o[ 0 ] === g.now ? ' selected' : '' ) + '>' + esc( o[ 1 ] ) + '</option>';
			} ).join( '' ) + '</select>', 'The card colour and the header buttons follow it.' );
		var once = ( d.packs ? row( 'Base pack', '<label class="izl-bb-inline"><input type="number" id="izl-bb-base" min="1" step="1" value="' + ( d.base || d.groupBase ) + '"> pcs = 1 product</label>',
				( d.groupName ? 'Group ' + d.groupName + ': ' + d.groupBase + ' pcs. ' : '' ) + 'Change it for a rarer species.' ) : '' ) +
			row( 'Shipping', '<div class="izl-bb-ship">' +
				'<label class="izl-bb-radio"><input type="radio" name="izl-bb-ship" value="live"' + ( 'live' === d.ship ? ' checked' : '' ) + '><span><b>Live animal</b> Monday to Wednesday</span></label>' +
				'<label class="izl-bb-radio"><input type="radio" name="izl-bb-ship" value="normal"' + ( 'live' !== d.ship ? ' checked' : '' ) + '><span><b>Normal product</b> Monday to Friday</span></label></div>',
				'Ordered before 2 pm on a shipping day: ships the same day.' ) +
			( null !== d.name && undefined !== d.name ? text( 'izl-pd-name', 'Hidden name', d.name, '', 'Only search engines and screen readers get it. The web address stays.', 200 ) : '' );
		return '<div class="izl-pd-cols">' + sec( 'Stock', stock, 'is-stock' ) + sec( d.packs ? 'Price and packs' : 'Price', price ) + sec( 'Texts', texts ) +
			sec( 'Group', group ) + sec( 'Set and forget', once, 'is-once' ) + '</div>';
	}

	function panel() {
		var open = document.querySelector( '.izl-pd-open' ), json = document.getElementById( 'izl-buybox-data' );
		if ( ! open || ! json || ! cfg.edit ) {
			return;
		}
		var d = JSON.parse( json.textContent ), isOpen = false, first = null, saving = false;
		var box = document.createElement( 'section' );
		box.className = 'izl-pd';
		box.id = 'izl-pd';
		box.hidden = true;
		box.setAttribute( 'role', 'dialog' );
		box.setAttribute( 'aria-label', 'Termék adatok' );
		box.innerHTML = '<form class="izl-pd-form" novalidate><header class="izl-pd-head" title="Drag to move. Double-click: back to its place."><b>Termék adatok</b>' +
			'<button type="button" class="izl-pd-x" aria-label="Close">×</button></header>' +
			'<div class="izl-pd-body"></div>' +
			'<footer class="izl-pd-foot"><p class="izl-pd-note" aria-live="polite"></p>' +
			'<span class="izl-pd-ask" hidden>Close without saving? <button type="button" class="izl-pd-drop">Discard</button><button type="button" class="izl-pd-keep">Keep editing</button></span>' +
			'<button type="button" class="izl-pd-undo">Undo</button><button type="submit" class="izl-bb-save izl-pd-save">Save</button></footer></form>';
		document.body.appendChild( box );
		open.setAttribute( 'aria-controls', 'izl-pd' );
		var form = box.querySelector( 'form' ), body = box.querySelector( '.izl-pd-body' ), head = box.querySelector( '.izl-pd-head' );
		var $d = function ( sel ) {
			return box.querySelector( sel );
		};

		/* the packs list (as in the 3.21.0 buy box editor) */
		function row( count, price ) {
			var r = document.createElement( 'div' );
			r.className = 'izl-bb-prow';
			r.setAttribute( 'data-count', count );
			r.innerHTML = '<label class="izl-bb-start" title="The page starts on this pack"><input type="radio" name="izl-bb-start" value="' + count + '"' + ( count === d.start ? ' checked' : '' ) + '><span class="screen-reader-text">Start pack</span></label>' +
				'<b>' + count + ' pcs</b><input type="number" class="izl-bb-pprice" min="0" step="1" value="' + esc( price ) + '" aria-label="Price of ' + count + ' pcs"> <span>' + d.currency + '</span>' +
				'<button type="button" class="izl-bb-pdel" aria-label="Remove ' + count + ' pcs">×</button>';
			return r;
		}
		function rows() {
			return Array.prototype.slice.call( box.querySelectorAll( '.izl-bb-prow' ) );
		}
		function build() {
			body.innerHTML = fields( d );
			var list = $d( '.izl-bb-plist' );
			if ( list ) {
				d.list.forEach( function ( p ) {
					list.appendChild( row( p.count, p.price ) );
				} );
			}
			refresh();
			first = state();
			mark();
		}
		function state() {
			var s = {}, g = $d( '#izl-pd-group' );
			[ 'izl-bb-price', 'izl-bb-base', 'izl-bb-stock', 'izl-bb-row', 'izl-pd-name', 'izl-pd-headline', 'izl-pd-tip' ].forEach( function ( id ) {
				var el = $d( '#' + id );
				if ( el ) {
					s[ id ] = el.value;
				}
			} );
			s.avail = $d( '#izl-bb-avail' ).checked;
			s.ship = ( box.querySelector( '[name="izl-bb-ship"]:checked' ) || {} ).value || '';
			s.start = ( box.querySelector( '[name="izl-bb-start"]:checked' ) || {} ).value || 0;
			s.packs = rows().map( function ( r ) {
				return r.getAttribute( 'data-count' ) + ':' + r.querySelector( '.izl-bb-pprice' ).value;
			} ).join( ',' );
			s.group = g ? g.value : '';
			return s;
		}
		var BB = [ 'izl-bb-price', 'izl-bb-base', 'izl-bb-stock', 'izl-bb-row', 'avail', 'ship', 'start', 'packs' ];
		function changed() {
			var now = state(), out = [];
			Object.keys( now ).forEach( function ( k ) {
				if ( first && String( now[ k ] ) !== String( first[ k ] ) ) {
					out.push( k );
				}
			} );
			return out;
		}
		function mark() {
			var n = changed().length;
			box.classList.toggle( 'is-dirty', n > 0 );
			open.classList.toggle( 'is-dirty', n > 0 );
			$d( '.izl-pd-save' ).disabled = saving || ! n;
			$d( '.izl-pd-undo' ).hidden = ! n || saving;
			if ( ! saving ) {
				$d( '.izl-pd-note' ).textContent = n ? 'Unsaved changes' : 'Saved into WooCommerce.';
			}
			if ( ! n ) {
				$d( '.izl-pd-ask' ).hidden = true;
			}
		}
		function refresh() {
			var price = parseFloat( ( $d( '#izl-bb-price' ) || {} ).value ) || 0, base = $d( '#izl-bb-base' ) ? ( parseInt( $d( '#izl-bb-base' ).value, 10 ) || 1 ) : 1;
			var left = '' === $d( '#izl-bb-stock' ).value ? null : parseInt( $d( '#izl-bb-stock' ).value, 10 ) || 0;
			rows().forEach( function ( r ) {
				var n = parseInt( r.getAttribute( 'data-count' ), 10 ), pb = r.querySelector( '.izl-bb-pprice' );
				pb.placeholder = price ? Math.round( price * n / base ) : '';
				r.classList.toggle( 'is-short', null !== left && n > left );
				r.title = null !== left && n > left ? 'Not enough in stock: greyed out for customers' : '';
			} );
			if ( $d( '#izl-bb-many' ) ) {
				$d( '#izl-bb-many' ).hidden = rows().length <= 4;
				$d( '.izl-bb-addp' ).disabled = rows().length >= d.max;
			}
			$d( '#izl-bb-avail-text' ).textContent = $d( '#izl-bb-avail' ).checked ? ( null !== left && left <= 0 ? 'Yes, once there is stock (now "Elfogyott")' : 'Yes, people can buy it' ) : 'No: paused, "Currently unavailable"';
			$d( '.izl-pd-stock' ).classList.toggle( 'is-out', null !== left && left <= 0 );
		}
		build();
		form.addEventListener( 'input', function () {
			refresh();
			mark();
		} );
		form.addEventListener( 'change', mark );
		body.addEventListener( 'click', function ( e ) {
			var step = e.target.closest( '.izl-pd-step' ), del = e.target.closest( '.izl-bb-pdel' ), add = e.target.closest( '.izl-bb-addp' );
			if ( step ) {
				var st = $d( '#izl-bb-stock' );
				st.value = Math.max( 0, ( parseInt( st.value, 10 ) || 0 ) + parseInt( step.getAttribute( 'data-add' ), 10 ) );
			} else if ( del && rows().length > 1 ) {
				del.closest( '.izl-bb-prow' ).remove();
				if ( ! box.querySelector( '[name="izl-bb-start"]:checked' ) ) {
					rows()[ 0 ].querySelector( 'input[type=radio]' ).checked = true;
				}
			} else if ( add ) {
				var nb = $d( '#izl-bb-newc' ), n = parseInt( nb.value, 10 ), list = $d( '.izl-bb-plist' );
				if ( ! n || n < 1 || rows().length >= d.max ) {
					nb.focus();
					return;
				}
				var same = list.querySelector( '[data-count="' + n + '"]' );
				if ( ! same ) {
					var at = rows().filter( function ( r ) {
						return parseInt( r.getAttribute( 'data-count' ), 10 ) > n;
					} )[ 0 ];
					same = row( n, '' );
					list.insertBefore( same, at || null );
				}
				nb.value = '';
				same.querySelector( '.izl-bb-pprice' ).focus();
			} else {
				return;
			}
			refresh();
			mark();
		} );
		body.addEventListener( 'keydown', function ( e ) {
			if ( 'Enter' === e.key && e.target.id === 'izl-bb-newc' ) {
				e.preventDefault();
				$d( '.izl-bb-addp' ).click();
			}
		} );

		/* open / close; closing with unsaved changes asks first */
		function show( focus ) {
			if ( ! isOpen ) {
				isOpen = true;
				box.hidden = false;
				open.setAttribute( 'aria-expanded', 'true' );
				open.classList.add( 'is-on' );
				place( stored( BOX ) );
				store( OPEN, 1 );
			}
			var el = focus && $d( focus );
			if ( el ) {
				var sec = el.closest( '.izl-pd-sec' );
				el.focus( { preventScroll: true } );
				if ( sec ) {
					body.scrollTop = Math.max( 0, sec.offsetTop - body.offsetTop - 8 );
					sec.classList.remove( 'is-flash' );
					void sec.offsetWidth;
					sec.classList.add( 'is-flash' );
				}
			}
		}
		function hide( force ) {
			if ( ! force && changed().length ) {
				$d( '.izl-pd-ask' ).hidden = false;
				$d( '.izl-pd-keep' ).focus();
				return;
			}
			isOpen = false;
			box.hidden = true;
			open.setAttribute( 'aria-expanded', 'false' );
			open.classList.remove( 'is-on' );
			store( OPEN, null );
		}
		open.addEventListener( 'click', function () {
			if ( isOpen ) {
				hide();
			} else {
				show();
			}
		} );
		$d( '.izl-pd-x' ).addEventListener( 'click', function () {
			hide();
		} );
		$d( '.izl-pd-keep' ).addEventListener( 'click', function () {
			$d( '.izl-pd-ask' ).hidden = true;
		} );
		$d( '.izl-pd-drop' ).addEventListener( 'click', function () {
			build();
			hide( true );
		} );
		$d( '.izl-pd-undo' ).addEventListener( 'click', build );
		box.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key ) {
				hide();
			}
		} );
		window.addEventListener( 'beforeunload', function ( e ) {
			if ( ! saving && changed().length ) {
				e.preventDefault();
				e.returnValue = '';
			}
		} );

		/* the texts on the page open the window on their field */
		var to = { _izl_headline: '#izl-pd-headline', _izl_pack_tip: '#izl-pd-tip', _izl_row_title: '#izl-bb-row' };
		document.addEventListener( 'click', function ( e ) {
			var t = e.target.closest && e.target.closest( '[data-izl-edit]' );
			if ( t && to[ t.getAttribute( 'data-izl-edit' ) ] && ! box.contains( t ) ) {
				e.preventDefault();
				show( to[ t.getAttribute( 'data-izl-edit' ) ] );
			}
		} );
		window.izlProductData = show; // e.g. izlProductData( '#izl-bb-stock' )

		/* one Save: only what changed, one after the other, then the page reloads */
		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			var ch = changed(), s = state(), jobs = [];
			if ( ! ch.length || saving ) {
				return;
			}
			if ( ch.some( function ( k ) {
				return BB.indexOf( k ) > -1;
			} ) ) {
				jobs.push( function () {
					return request( $.extend( {
						action: 'izl_buybox_save',
						id: d.id,
						price: s[ 'izl-bb-price' ],
						base: d.packs ? s[ 'izl-bb-base' ] : 0,
						packs: rows().map( function ( r ) {
							return r.getAttribute( 'data-count' ) + ':' + r.querySelector( '.izl-bb-pprice' ).value;
						} ),
						start: s.start,
						available: s.avail ? 1 : 0,
						ship: s.ship
					}, ch.indexOf( 'izl-bb-row' ) > -1 ? { rowTitle: s[ 'izl-bb-row' ] } : {}, ch.indexOf( 'izl-bb-stock' ) > -1 ? { stock: s[ 'izl-bb-stock' ] } : {} ) );
				} );
			}
			if ( ch.indexOf( 'group' ) > -1 && '0' !== s.group ) {
				jobs.push( function () {
					return request( { action: 'izl_product_group', id: d.id, term: s.group }, d.groupNonce );
				} );
			}
			[ [ 'izl-pd-name', '_izl_name' ], [ 'izl-pd-headline', '_izl_headline' ], [ 'izl-pd-tip', '_izl_pack_tip' ] ].forEach( function ( t ) {
				if ( ch.indexOf( t[ 0 ] ) > -1 ) {
					jobs.push( function () {
						return request( { action: 'izl_product_text', id: d.id, key: t[ 1 ], text: s[ t[ 0 ] ] } );
					} );
				}
			} );
			saving = true;
			mark();
			$d( '.izl-pd-note' ).textContent = 'Saving…';
			var err = box.querySelector( '.izl-edit-error' );
			if ( err ) {
				err.remove();
			}
			var p = $.Deferred().resolve().promise();
			jobs.forEach( function ( j ) {
				p = p.then( j );
			} );
			p.done( function () {
				$d( '.izl-pd-note' ).textContent = 'Saved. Reloading…';
				window.location.reload();
			} ).fail( function ( msg ) {
				saving = false;
				mark();
				showError( $d( '.izl-pd-foot' ), msg );
			} );
		} );

		/* moving and resizing (as Bolt's Rendelés-pult) */
		function place( b ) {
			var st = box.style;
			if ( ! b || small() ) {
				box.classList.remove( 'is-free' );
				st.left = st.top = st.width = st.height = '';
				var hd = document.querySelector( '#masthead, .site-header' ), hb = hd ? hd.getBoundingClientRect().bottom : 0;
				if ( ! small() && hb > 0 && hb < window.innerHeight * 0.4 ) {
					st.top = Math.round( hb + 12 ) + 'px'; // its own corner: under the shop's header, not over the basket
					st.height = Math.round( Math.max( 220, Math.min( 704, window.innerHeight - hb - 28 ) ) ) + 'px';
				}
				return;
			}
			var vw = document.documentElement.clientWidth, vh = window.innerHeight, bar = document.getElementById( 'wpadminbar' );
			var top = ( bar ? Math.max( 0, bar.getBoundingClientRect().bottom ) : 0 ) + 8; // never under the WordPress bar
			var w = Math.round( Math.min( Math.max( b.w, 300 ), vw - 16 ) ), h = Math.round( Math.min( Math.max( b.h, 220 ), vh - top - 8 ) );
			var x = Math.round( Math.min( Math.max( b.x, 8 ), vw - w - 8 ) ), y = Math.round( Math.min( Math.max( b.y, top ), vh - h - 8 ) );
			box.classList.add( 'is-free' );
			st.left = x + 'px';
			st.top = y + 'px';
			st.width = w + 'px';
			st.height = h + 'px';
		}
		var start = null;
		[ 'n', 'e', 's', 'w', 'ne', 'nw', 'se', 'sw' ].forEach( function ( dir ) {
			var hd = document.createElement( 'i' );
			hd.className = 'izl-pd-rz is-' + dir;
			hd.setAttribute( 'data-d', dir );
			hd.setAttribute( 'aria-hidden', 'true' );
			box.appendChild( hd );
		} );
		function down( e, dir ) {
			if ( small() || ( e.button && 0 !== e.button ) ) {
				return;
			}
			var r = box.getBoundingClientRect();
			start = { x: e.clientX, y: e.clientY, dir: dir, b: { x: r.left, y: r.top, w: r.width, h: r.height } };
			box.classList.add( 'is-moving' );
			e.target.setPointerCapture( e.pointerId );
			e.preventDefault();
		}
		box.addEventListener( 'pointerdown', function ( e ) {
			var dd = e.target.getAttribute && e.target.getAttribute( 'data-d' );
			if ( dd ) {
				down( e, dd );
			} else if ( e.target.closest( '.izl-pd-head' ) && ! e.target.closest( 'button' ) ) {
				down( e, 'move' );
			}
		} );
		box.addEventListener( 'pointermove', function ( e ) {
			if ( ! start ) {
				return;
			}
			var dx = e.clientX - start.x, dy = e.clientY - start.y, b = start.b, n = { x: b.x, y: b.y, w: b.w, h: b.h }, dd = start.dir;
			if ( 'move' === dd ) {
				n.x += dx;
				n.y += dy;
			} else {
				if ( dd.indexOf( 'e' ) > -1 ) {
					n.w = Math.max( 300, b.w + dx );
				}
				if ( dd.indexOf( 'w' ) > -1 ) {
					n.w = Math.max( 300, b.w - dx );
					n.x = b.x + b.w - n.w;
				}
				if ( dd.indexOf( 's' ) > -1 ) {
					n.h = Math.max( 220, b.h + dy );
				}
				if ( dd.indexOf( 'n' ) > -1 ) {
					n.h = Math.max( 220, b.h - dy );
					n.y = b.y + b.h - n.h;
				}
			}
			place( n );
		} );
		function up() {
			if ( ! start ) {
				return;
			}
			start = null;
			box.classList.remove( 'is-moving' );
			var r = box.getBoundingClientRect();
			store( BOX, { x: r.left, y: r.top, w: r.width, h: r.height } );
		}
		box.addEventListener( 'pointerup', up );
		box.addEventListener( 'pointercancel', up );
		head.addEventListener( 'dblclick', function ( e ) {
			if ( ! e.target.closest( 'button' ) ) {
				store( BOX, null );
				place( null );
			}
		} );
		window.addEventListener( 'resize', function () {
			if ( isOpen ) {
				place( stored( BOX ) );
			}
		} );
		if ( stored( OPEN ) ) {
			show(); // it was open before the reload (a Save, or the next product)
		}
	}

	/* the title over the small-tile row: a click opens the window on it */
	function rowTitle() {
		var h = document.querySelector( '.related.products:not(.izl-alts) > h2' );
		if ( h ) {
			h.setAttribute( 'data-izl-edit', '_izl_row_title' );
			h.title = 'Click: change it in Termék adatok';
		}
	}

	/* admins: one toolbar row above the card and the buy box ("Edit card", "Edit buy box", the hidden name), so the
	   buy box itself is as tall for an admin as for a customer and the page fits the screen the same way.
	   3.8.0: only on a phone now (where the editor tools are in the drawer); on a computer the tools float over the
	   page (floating() below), so the page is laid out exactly as a customer sees it. */

	// ==========================================================================
	//  The toolbar row above the card (phone)
	// ==========================================================================

	function toolbar() {
		var strip = document.querySelector( '.summary .izl-admin-strip' ), wrap = document.querySelector( 'div.product > .fsz-wrap' );
		if ( ! strip || ! wrap ) {
			return;
		}
		var bar = wrap.parentNode.querySelector( ':scope > .fsz-editbar' );
		if ( bar ) {
			strip.insertBefore( bar, strip.firstChild );
		}
		var link = document.querySelector( '.summary > .edit-link' ); // WordPress's own "Edit" (the product in the dashboard)
		if ( link ) {
			strip.appendChild( link );
		}
		wrap.parentNode.insertBefore( strip, wrap );
		strip.classList.add( 'is-toolbar' );
		// The admin bar and this toolbar push the card down; give that room back, so the card has the customer's size.
		var adminbar = document.getElementById( 'wpadminbar' ), cs = window.getComputedStyle( strip );
		var extra = strip.offsetHeight + parseFloat( cs.marginTop ) + parseFloat( cs.marginBottom ) + ( adminbar ? adminbar.offsetHeight : 0 );
		extra -= parseFloat( window.getComputedStyle( document.documentElement ).fontSize ); // customers have 1rem of space there instead
		wrap.style.setProperty( '--izl-admin-extra', Math.round( extra ) + 'px' );
		if ( window.fszFit ) {
			window.fszFit();
		}
	}

	// ==========================================================================
	//  3.8.0: computer: the editor tools float over the page
	// ==========================================================================

	/* Nothing an editor sees takes room on the page (Dan, 2026-11-14): "Edit card" floats on the card's top left corner
	   (3.23.0, yellow), "Termék adatok" just above the buy box, "Edit photos" on the photo. WordPress's own Edit link is
	   in the admin bar at the top, as "WooEdit" (inc/edit-buy-box.php). The look: style.css sections 45 and 63. */
	function holder( el ) {
		if ( el && 'static' === window.getComputedStyle( el ).position ) {
			el.style.position = 'relative';
		}
	}
	function floating() {
		var strip = document.querySelector( '.summary .izl-admin-strip' ), sum = strip && strip.closest( '.summary' );
		if ( ! strip || ! sum ) {
			return;
		}
		document.body.classList.add( 'izl-tools-float' );
		strip.classList.add( 'is-float' );
		holder( sum );
		var wrap = document.querySelector( 'div.product > .fsz-wrap' ), bar = document.querySelector( 'div.product > .fsz-editbar' );
		if ( wrap && bar ) {
			holder( wrap );
			bar.classList.add( 'is-float' );
			wrap.appendChild( bar );
		}
		var photos = strip.querySelector( '.izl-photos-open' ), gal = document.querySelector( 'div.product .woocommerce-product-gallery' );
		if ( photos && gal ) {
			holder( gal );
			var f = document.createElement( 'div' );
			f.className = 'izl-admin-float';
			f.appendChild( photos );
			gal.appendChild( f );
		}
		if ( wrap ) {
			// the admin bar still pushes the card down: give that room back, so the card has the customer's size
			var adminbar = document.getElementById( 'wpadminbar' );
			wrap.style.setProperty( '--izl-admin-extra', ( adminbar ? adminbar.offsetHeight : 0 ) + 'px' );
			if ( window.fszFit ) {
				window.fszFit();
			}
		}
	}

	window.izlProductEdit = function () {
		rowTitle();
		panel(); // 3.23.0: the "Termék adatok" window
		if ( window.matchMedia && window.matchMedia( '(max-width: 1023px)' ).matches ) {
			toolbar();
		} else {
			floating();
		}
	};
}( jQuery ) );
