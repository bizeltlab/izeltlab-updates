// ==========================================================================
//  FILE: assets/product-edit.js   (Ízeltláb theme)
//  WHAT: EDITORS ONLY. Edit the sales line and pack tip in place, and the buy box editor (price, packs,
//        availability).
//  SEEN: Product pages, only for logged-in editors.
//  SECTIONS IN THIS FILE:
//    1. Saving: one helper with clear error messages
//    2. Editing a text in place (sales line, pack tip, row title)
//    3. The buy box editor dialog
//    4. The toolbar row above the card
// ==========================================================================

/**
 * Product page, EDITORS ONLY: whoever can edit the product edits the sales line and the pack tip in place, and the
 * price, packs and availability in the buy box editor (saved into WooCommerce, then the page reloads). Shoppers never
 * get this file. assets/product.js calls window.izlProductEdit() once the buy box is ready.
 */
( function ( $ ) {
	'use strict';

	var cfg = window.izlProduct || {};

	/* saving (admin): one request helper that always ends with a clear message, never a silent failure */

	// ==========================================================================
	//  Saving: one helper with clear error messages
	// ==========================================================================

	// Sent the same way as the Codex quick edit (fetch + form data, same-origin cookies), which works on every set-up so far.
	function request( data ) {
		var done = $.Deferred(), body = new window.FormData();
		data._ajax_nonce = cfg.edit.nonce;
		Object.keys( data ).forEach( function ( k ) {
			if ( Array.isArray( data[ k ] ) ) {
				data[ k ].forEach( function ( v ) {
					body.append( k + '[]', v );
				} );
			} else {
				body.append( k, data[ k ] );
			}
		} );
		function answer( status, text ) {
			var json = null, at = text.indexOf( '{"success"' );
			if ( at > -1 ) {
				try {
					json = JSON.parse( text.slice( at ) ); // anything a plugin printed before the answer is skipped
				} catch ( e ) {
					json = null;
				}
			}
			if ( json && json.success ) {
				done.resolve( json.data || {} );
			} else if ( json && json.data ) {
				done.reject( String( json.data ) );
			} else if ( '0' === text.trim() ) {
				done.reject( 'Not saved: this address does not see you logged in. Log in again here, then reload the page.' );
			} else if ( '-1' === text.trim() ) {
				done.reject( 'The security check ran out. Reload the page and try again.' );
			} else {
				done.reject( 'Not saved (error ' + status + ( text ? ': ' + text.replace( /<[^>]+>/g, ' ' ).replace( /\s+/g, ' ' ).trim().slice( 0, 140 ) : '' ) + '). Send me this text.' );
			}
		}
		window.fetch( cfg.edit.ajax, { method: 'POST', credentials: 'same-origin', body: body } )
			.then( function ( r ) {
				return r.text().then( function ( t ) {
					answer( r.status, t );
				} );
			} )
			.catch( function ( e ) {
				done.reject( 'Not saved: the site did not answer (' + ( e && e.message ? e.message : 'network' ) + '). Check that you are logged in on this address, then reload.' );
			} );
		return done.promise();
	}

	function showError( after, msg ) {
		var p = after.parentNode.querySelector( '.izl-edit-error' );
		if ( ! p ) {
			p = document.createElement( 'p' );
			p.className = 'izl-edit-error';
			p.setAttribute( 'role', 'alert' );
			after.after( p );
		}
		p.textContent = msg;
	}

	/* sales line and pack tip: Edit → a text box with Save / Cancel, saved without a reload */

	// ==========================================================================
	//  Editing a text in place (sales line, pack tip, row title)
	// ==========================================================================

	function editable( box ) {
		var text = box.querySelector( '.izl-edit-text' ), btn = box.querySelector( '.izl-edit-btn' );
		text.addEventListener( 'click', function () {
			if ( box.classList.contains( 'is-empty' ) ) {
				btn.click();
			}
		} );
		btn.addEventListener( 'click', function ( e ) {
			e.preventDefault();
			var input = document.createElement( 'input' ), save = document.createElement( 'button' ), cancel = document.createElement( 'button' );
			input.type = 'text';
			input.className = 'izl-edit-input';
			input.placeholder = box.getAttribute( 'data-izl-sample' ) || '';
			input.value = box.classList.contains( 'is-empty' ) ? '' : text.textContent;
			input.setAttribute( 'aria-label', { _izl_headline: 'Sales line', _izl_pack_tip: 'Pack tip', _izl_row_title: 'Row title', _izl_name: 'Product name' }[ box.getAttribute( 'data-izl-edit' ) ] || 'Text' );
			save.type = cancel.type = 'button';
			save.className = 'izl-edit-save';
			save.textContent = 'Save';
			cancel.className = 'izl-edit-cancel';
			cancel.textContent = 'Cancel';
			var wrap = document.createElement( 'span' );
			wrap.className = 'izl-edit-form';
			wrap.append( input, save, cancel );
			text.hidden = btn.hidden = true;
			box.appendChild( wrap );
			input.focus();
			function close() {
				wrap.remove();
				if ( box.querySelector( '.izl-edit-error' ) ) {
					box.querySelector( '.izl-edit-error' ).remove();
				}
				text.hidden = btn.hidden = false;
			}
			function send() {
				save.disabled = true;
				request( { action: 'izl_product_text', id: cfg.edit.id, key: box.getAttribute( 'data-izl-edit' ), text: input.value } )
					.done( function ( r ) {
						text.textContent = r.text || box.getAttribute( 'data-izl-sample' ) || '';
						box.classList.toggle( 'is-empty', ! r.text );
						if ( box.izlAdd ) {
							box.izlAdd.hidden = ! r.text ? false : true; // 3.8.0: the "+ Sales line" pill goes once there is one
						}
						if ( '_izl_name' === box.getAttribute( 'data-izl-edit' ) ) {
							document.querySelectorAll( '.product_title' ).forEach( function ( t ) {
								t.textContent = r.text; // 2.0.6: the page's hidden title follows the new name
							} );
						}
						close();
					} )
					.fail( function ( msg ) {
						save.disabled = false;
						showError( wrap, msg );
					} );
			}
			save.addEventListener( 'click', send );
			cancel.addEventListener( 'click', close );
			input.addEventListener( 'keydown', function ( ev ) {
				if ( 'Enter' === ev.key ) {
					ev.preventDefault();
					send();
				} else if ( 'Escape' === ev.key ) {
					close();
				}
			} );
		} );
	}

	/* the title over the small-tile row: Edit next to it, like the sales line (the default comes back when emptied) */

	function rowTitle() {
		var h = document.querySelector( '.related.products:not(.izl-alts) > h2' ), json = document.getElementById( 'izl-buybox-data' );
		if ( ! h || ! json ) {
			return;
		}
		var span = document.createElement( 'span' ), btn = document.createElement( 'button' );
		span.className = 'izl-edit-text';
		span.textContent = h.textContent.trim();
		btn.type = 'button';
		btn.className = 'izl-edit-btn';
		btn.textContent = 'Edit';
		h.textContent = '';
		h.append( span, btn );
		h.setAttribute( 'data-izl-edit', '_izl_row_title' );
		h.setAttribute( 'data-izl-sample', JSON.parse( json.textContent ).rowDefault || '' );
		editable( h );
	}

	/* buy box editor (English, like the other admin tools) */

	// ==========================================================================
	//  The buy box editor dialog
	// ==========================================================================

	function esc( t ) {
		return String( t == null ? '' : t ).replace( /&/g, '&amp;' ).replace( /"/g, '&quot;' ).replace( /</g, '&lt;' );
	}

	function money( n, cur ) {
		return Math.round( n ).toString().replace( /\B(?=(\d{3})+(?!\d))/g, ' ' ) + ' ' + cur;
	}

	/* 3.21.0 (Dan, 2026-11-24): two columns on a computer (price and packs | stock and shipping), any pack size with its
	   own price if wanted, the pack the page starts on, the stock and the "Kevés van" limit. The free-shipping amount
	   (Customizer only) and the "default for the whole group" switch are gone. */
	function buybox() {
		var open = document.querySelector( '.izl-buybox-open' ), json = document.getElementById( 'izl-buybox-data' );
		if ( ! open || ! json || ! cfg.edit ) {
			return;
		}
		var d = JSON.parse( json.textContent );
		var dlg = document.createElement( 'dialog' );
		dlg.className = 'izl-buybox';
		var unit = d.packs ? 'pcs' : 'items';
		var packs = d.packs ? '<fieldset class="izl-bb-row"><legend>Base pack</legend>' +
			'<label class="izl-bb-inline"><input type="number" id="izl-bb-base" min="1" step="1" value="' + ( d.base || d.groupBase ) + '"> pcs = 1 product</label>' +
			'<p class="izl-bb-help">' + ( d.groupName ? 'Group ' + esc( d.groupName ) + ': ' + d.groupBase + ' pcs. ' : '' ) + 'Change it here for a rarer species.</p>' +
			'</fieldset><fieldset class="izl-bb-row"><legend>Packs people can choose</legend><div class="izl-bb-plist"></div>' +
			'<div class="izl-bb-padd"><label class="izl-bb-inline"><input type="number" id="izl-bb-newc" min="1" step="1" placeholder="e.g. 30"> pcs</label><button type="button" class="izl-bb-addp">+ Own pack</button></div>' +
			'<p class="izl-bb-help">Empty price = worked out from the base price. Type a price for a bulk deal. ◉ = the pack the page starts on.</p>' +
			'<p class="izl-bb-warn" id="izl-bb-many" hidden>More than 4 packs: phones show them in two rows, and fewer choices sell faster.</p>' +
			( d.handMade ? '<p class="izl-bb-warn">This product has packs made by hand. Saving replaces them with these.</p>' : '' ) +
			'</fieldset>' : '';
		dlg.innerHTML = '<form method="dialog" class="izl-bb-form"><h2>Buy box</h2><div class="izl-bb-cols">' +
			'<div class="izl-bb-col"><h3>Price' + ( d.packs ? ' and packs' : '' ) + '</h3>' +
			'<fieldset class="izl-bb-row"><legend>' + ( d.packs ? 'Price of 1 product (the base pack)' : 'Price' ) + '</legend>' +
			'<label class="izl-bb-inline"><input type="number" id="izl-bb-price" min="0" step="1" value="' + d.price + '"> ' + d.currency + '</label></fieldset>' +
			packs + '</div>' +
			'<div class="izl-bb-col"><h3>Stock and shipping</h3>' +
			'<fieldset class="izl-bb-row"><legend>Stock</legend>' +
			'<label class="izl-bb-inline"><input type="number" id="izl-bb-stock" min="0" step="1" placeholder="none" value="' + ( null === d.stock ? '' : d.stock ) + '"> ' + unit + ' on hand</label>' +
			'<p class="izl-bb-help">' + ( d.packs ? 'Every pack takes from this one number (a 20 pcs pack takes 20). ' : '' ) + 'Orders take from it, cancelled ones give it back. Empty = not counted (only the switch below).</p></fieldset>' +
			'<fieldset class="izl-bb-row"><legend>Kevés van (running low)</legend>' +
			'<label class="izl-bb-inline">below <input type="number" id="izl-bb-lowat" min="0" step="1" placeholder="off" value="' + ( d.lowAt || '' ) + '"> ' + unit + '</label>' +
			'<p class="izl-bb-help">Under this number the stamp says "Utolsó N db"' + ( d.packs ? ' and the yellow light on the card blinks by itself' : '' ) + '. Empty = set by hand.</p></fieldset>' +
			'<fieldset class="izl-bb-row"><legend>Available</legend><label class="izl-bb-switch"><input type="checkbox" id="izl-bb-avail"' + ( d.available ? ' checked' : '' ) + '><span></span> <b id="izl-bb-avail-text"></b></label></fieldset>' +
			( d.packs ? '<fieldset class="izl-bb-row" id="izl-bb-lowrow"><legend>Running low light</legend><label class="izl-bb-switch"><input type="checkbox" id="izl-bb-low"' + ( d.low ? ' checked' : '' ) + '><span></span> <b id="izl-bb-low-text"></b></label></fieldset>' : '' ) +
			'<fieldset class="izl-bb-row"><legend>Shipping</legend><div class="izl-bb-ship">' +
			'<label class="izl-bb-radio"><input type="radio" name="izl-bb-ship" value="live"' + ( 'live' === d.ship ? ' checked' : '' ) + '><span><b>Live animal</b> Ships Monday to Wednesday</span></label>' +
			'<label class="izl-bb-radio"><input type="radio" name="izl-bb-ship" value="normal"' + ( 'live' !== d.ship ? ' checked' : '' ) + '><span><b>Normal product</b> Ships Monday to Friday</span></label></div>' +
			'<p class="izl-bb-help">Ordered before 2 pm on a shipping day: ships the same day, else on the next one.</p></fieldset>' +
			'<fieldset class="izl-bb-row"><legend>Title of the product row under the page</legend>' +
			'<input type="text" id="izl-bb-row" class="izl-bb-text" maxlength="80" placeholder="' + esc( d.rowDefault ) + '" value="' + esc( d.rowTitle ) + '">' +
			'<p class="izl-bb-help">Empty = "' + esc( d.rowDefault ) + '".</p></fieldset></div></div>' +
			'<div class="izl-bb-actions"><p class="izl-bb-note">Saved into WooCommerce.</p><button type="button" class="izl-bb-cancel">Cancel</button><button type="submit" class="izl-bb-save">Save</button></div></form>';
		document.body.appendChild( dlg );
		var $d = function ( sel ) {
			return dlg.querySelector( sel );
		};
		var list = $d( '.izl-bb-plist' ), start = d.start;
		function row( count, price ) {
			var r = document.createElement( 'div' );
			r.className = 'izl-bb-prow';
			r.setAttribute( 'data-count', count );
			r.innerHTML = '<label class="izl-bb-start" title="The page starts on this pack"><input type="radio" name="izl-bb-start" value="' + count + '"' + ( count === start ? ' checked' : '' ) + '><span class="screen-reader-text">Start pack</span></label>' +
				'<b>' + count + ' pcs</b><input type="number" class="izl-bb-pprice" min="0" step="1" value="' + esc( price ) + '" aria-label="Price of ' + count + ' pcs"> <span>' + d.currency + '</span>' +
				'<button type="button" class="izl-bb-pdel" aria-label="Remove ' + count + ' pcs">×</button>';
			return r;
		}
		function rows() {
			return Array.prototype.slice.call( dlg.querySelectorAll( '.izl-bb-prow' ) );
		}
		if ( list ) {
			d.list.forEach( function ( p ) {
				list.appendChild( row( p.count, p.price ) );
			} );
			list.addEventListener( 'click', function ( e ) {
				var del = e.target.closest( '.izl-bb-pdel' );
				if ( del && rows().length > 1 ) {
					del.closest( '.izl-bb-prow' ).remove();
					if ( ! dlg.querySelector( '[name="izl-bb-start"]:checked' ) ) {
						rows()[ 0 ].querySelector( 'input[type=radio]' ).checked = true;
					}
					refresh();
				}
			} );
			$d( '.izl-bb-addp' ).addEventListener( 'click', function () {
				var box = $d( '#izl-bb-newc' ), n = parseInt( box.value, 10 );
				if ( ! n || n < 1 || rows().length >= d.max ) {
					box.focus();
					return;
				}
				var same = list.querySelector( '[data-count="' + n + '"]' );
				if ( ! same ) {
					var at = rows().filter( function ( r ) {
						return parseInt( r.getAttribute( 'data-count' ), 10 ) > n;
					} )[ 0 ];
					same = row( n, '' );
					list.insertBefore( same, at || null );
				}
				box.value = '';
				same.querySelector( '.izl-bb-pprice' ).focus();
				refresh();
			} );
			$d( '#izl-bb-newc' ).addEventListener( 'keydown', function ( e ) {
				if ( 'Enter' === e.key ) {
					e.preventDefault();
					$d( '.izl-bb-addp' ).click();
				}
			} );
		}
		function refresh() {
			var price = parseFloat( $d( '#izl-bb-price' ).value ) || 0, base = d.packs ? ( parseInt( $d( '#izl-bb-base' ).value, 10 ) || 1 ) : 1;
			var left = '' === $d( '#izl-bb-stock' ).value ? null : parseInt( $d( '#izl-bb-stock' ).value, 10 ) || 0;
			rows().forEach( function ( r ) {
				var n = parseInt( r.getAttribute( 'data-count' ), 10 ), box = r.querySelector( '.izl-bb-pprice' );
				box.placeholder = price ? Math.round( price * n / base ) : '';
				r.classList.toggle( 'is-short', null !== left && n > left );
				r.title = null !== left && n > left ? 'Not enough in stock: greyed out for customers' : '';
			} );
			if ( $d( '#izl-bb-many' ) ) {
				$d( '#izl-bb-many' ).hidden = rows().length <= 4;
				$d( '.izl-bb-addp' ).disabled = rows().length >= d.max;
			}
			$d( '#izl-bb-avail-text' ).textContent = $d( '#izl-bb-avail' ).checked ? ( null !== left && left <= 0 ? 'Yes, once there is stock' : 'Yes, people can buy it' ) : 'No: paused, "Currently unavailable"';
			var auto = ( parseInt( $d( '#izl-bb-lowat' ).value, 10 ) || 0 ) > 0;
			if ( $d( '#izl-bb-low' ) ) {
				$d( '#izl-bb-low' ).disabled = auto;
				$d( '#izl-bb-lowrow' ).classList.toggle( 'is-auto', auto );
				$d( '#izl-bb-low-text' ).textContent = auto ? 'Automatic: by the "Kevés van" number' : ( $d( '#izl-bb-low' ).checked ? 'Yes: the yellow light on the card blinks (while it is available)' : 'No' );
			}
		}
		dlg.addEventListener( 'input', refresh );
		refresh();
		open.addEventListener( 'click', function () {
			dlg.showModal();
		} );
		$d( '.izl-bb-cancel' ).addEventListener( 'click', function () {
			dlg.close();
		} );
		$d( 'form' ).addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			var save = $d( '.izl-bb-save' ), packList = [];
			rows().forEach( function ( r ) {
				packList.push( r.getAttribute( 'data-count' ) + ':' + r.querySelector( '.izl-bb-pprice' ).value );
			} );
			save.disabled = true;
			save.textContent = 'Saving…';
			var row = $d( '#izl-bb-row' ); // sent only when changed here (Edit on the row title may have changed it since)
			var st = $d( '#izl-bb-stock' ); // the same: only when changed (an order or the stock line may have changed it)
			request( $.extend( {
				action: 'izl_buybox_save',
				id: d.id,
				price: $d( '#izl-bb-price' ).value,
				base: d.packs ? $d( '#izl-bb-base' ).value : 0,
				packs: packList,
				start: ( dlg.querySelector( '[name="izl-bb-start"]:checked' ) || {} ).value || 0,
				available: $d( '#izl-bb-avail' ).checked ? 1 : 0,
				lowAt: $d( '#izl-bb-lowat' ).value || 0,
				ship: ( dlg.querySelector( '[name="izl-bb-ship"]:checked' ) || {} ).value || ''
			}, row.value !== row.defaultValue ? { rowTitle: row.value } : {}, st.value !== st.defaultValue ? { stock: st.value } : {},
				$d( '#izl-bb-low' ) && ! $d( '#izl-bb-low' ).disabled ? { low: $d( '#izl-bb-low' ).checked ? 1 : 0 } : {} ) ).done( function () {
				window.location.reload();
			} ).fail( function ( msg ) {
				save.disabled = false;
				save.textContent = 'Save';
				showError( $d( '.izl-bb-actions' ), msg );
			} );
		} );
	}

	/* 3.21.0: the stock line next to "Edit buy box": − / + change it by one, a typed number is saved when you leave the
	   box or press Enter. Saved at once (no reload); the page's pack buttons follow on the next load. */
	function stockEdit() {
		var box = document.querySelector( '.izl-stock-edit' );
		if ( ! box || ! cfg.edit ) {
			return;
		}
		var num = box.querySelector( '.izl-se-num' ), state = box.querySelector( '.izl-se-state' ), busy = false;
		function send( data ) {
			if ( busy ) {
				return;
			}
			busy = true;
			box.classList.add( 'is-busy' );
			state.textContent = '';
			var body = new window.FormData();
			body.append( 'action', 'izl_stock_set' );
			body.append( 'id', box.getAttribute( 'data-id' ) );
			body.append( '_ajax_nonce', box.getAttribute( 'data-nonce' ) );
			Object.keys( data ).forEach( function ( k ) {
				body.append( k, data[ k ] );
			} );
			window.fetch( cfg.edit.ajax, { method: 'POST', body: body, credentials: 'same-origin' } ).then( function ( r ) {
				return r.json();
			} ).then( function ( j ) {
				if ( ! j || ! j.success ) {
					throw new Error( j && j.data ? j.data : 'Not saved' );
				}
				num.value = null === j.data.left ? '' : j.data.left;
				num.defaultValue = num.value;
				state.textContent = '✓';
				box.classList.toggle( 'is-low', !! j.data.low );
			} ).catch( function ( e ) {
				num.value = num.defaultValue;
				state.textContent = String( e.message || e );
			} ).then( function () {
				busy = false;
				box.classList.remove( 'is-busy' );
			} );
		}
		box.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( '.izl-se-btn' );
			if ( b ) {
				send( { add: b.getAttribute( 'data-add' ) } );
			}
		} );
		num.addEventListener( 'change', function () {
			send( { set: num.value } );
		} );
		num.addEventListener( 'keydown', function ( e ) {
			if ( 'Enter' === e.key ) {
				e.preventDefault();
				num.blur();
			}
		} );
	}

	/* 3.22.0: the group / genus picker next to the stock: saved at once, then the page reloads (the card's colour,
	   the header's lit button and the lists follow the new group). */
	function groupEdit() {
		var box = document.querySelector( '.izl-group-edit' );
		if ( ! box || ! cfg.edit ) {
			return;
		}
		var sel = box.querySelector( 'select' ), state = box.querySelector( '.izl-se-state' ), was = sel.value;
		sel.addEventListener( 'change', function () {
			var body = new window.FormData();
			body.append( 'action', 'izl_product_group' );
			body.append( 'id', box.getAttribute( 'data-id' ) );
			body.append( 'term', sel.value );
			body.append( '_ajax_nonce', box.getAttribute( 'data-nonce' ) );
			sel.disabled = true;
			state.textContent = '…';
			window.fetch( cfg.edit.ajax, { method: 'POST', body: body, credentials: 'same-origin' } ).then( function ( r ) {
				return r.json();
			} ).then( function ( j ) {
				if ( ! j || ! j.success ) {
					throw new Error( j && j.data ? j.data : 'Not saved' );
				}
				state.textContent = '✓';
				window.location.reload();
			} ).catch( function ( e ) {
				sel.value = was;
				sel.disabled = false;
				state.textContent = String( e.message || e );
			} );
		} );
	}

	/* admins: one toolbar row above the card and the buy box ("Edit card", "Edit buy box", the hidden name), so the
	   buy box itself is as tall for an admin as for a customer and the page fits the screen the same way.
	   3.8.0: only on a phone now (where the editor tools are in the drawer); on a computer the tools float over the
	   page (floating() below), so the page is laid out exactly as a customer sees it. */

	// ==========================================================================
	//  The toolbar row above the card (phone)
	// ==========================================================================

	function toolbar() {
		var strip = document.querySelector( '.summary .izl-admin-strip' ), wrap = document.querySelector( 'div.product > .fsz-wrap' );
		if ( ! strip || ! wrap ) {
			return;
		}
		var bar = wrap.parentNode.querySelector( ':scope > .fsz-editbar' );
		if ( bar ) {
			strip.insertBefore( bar, strip.firstChild );
		}
		var link = document.querySelector( '.summary > .edit-link' ); // WordPress's own "Edit" (the product in the dashboard)
		if ( link ) {
			strip.insertBefore( link, strip.querySelector( '.izl-admin-name' ) );
		}
		wrap.parentNode.insertBefore( strip, wrap );
		strip.classList.add( 'is-toolbar' );
		// The admin bar and this toolbar push the card down; give that room back, so the card has the customer's size.
		var adminbar = document.getElementById( 'wpadminbar' ), cs = window.getComputedStyle( strip );
		var extra = strip.offsetHeight + parseFloat( cs.marginTop ) + parseFloat( cs.marginBottom ) + ( adminbar ? adminbar.offsetHeight : 0 );
		extra -= parseFloat( window.getComputedStyle( document.documentElement ).fontSize ); // customers have 1rem of space there instead
		wrap.style.setProperty( '--izl-admin-extra', Math.round( extra ) + 'px' );
		if ( window.fszFit ) {
			window.fszFit();
		}
	}

	// ==========================================================================
	//  3.8.0: computer: the editor tools float over the page
	// ==========================================================================

	/* Nothing an editor sees takes room on the page (Dan, 2026-11-14): "Edit card" floats on the card's top edge,
	   "Edit buy box" and the hidden name just above the buy box, "Edit photos" on the photo, the small "Edit" buttons
	   at the end of their line. A text a customer would not see (an empty sales line or pack tip) is left out of the
	   page, with a "+ Sales line" pill among the floating tools that opens it. WordPress's own Edit link is in the
	   admin bar at the top, as "WooEdit" (inc/edit-buy-box.php). The look: style.css section 45. */
	function holder( el ) {
		if ( el && 'static' === window.getComputedStyle( el ).position ) {
			el.style.position = 'relative';
		}
	}
	function floating() {
		var strip = document.querySelector( '.summary .izl-admin-strip' ), sum = strip && strip.closest( '.summary' );
		if ( ! strip || ! sum ) {
			return;
		}
		document.body.classList.add( 'izl-tools-float' );
		strip.classList.add( 'is-float' );
		holder( sum );
		var wrap = document.querySelector( 'div.product > .fsz-wrap' ), bar = document.querySelector( 'div.product > .fsz-editbar' );
		if ( wrap && bar ) {
			holder( wrap );
			bar.classList.add( 'is-float' );
			wrap.appendChild( bar );
		}
		var names = { _izl_headline: 'Sales line', _izl_pack_tip: 'Pack tip' };
		sum.querySelectorAll( '[data-izl-edit]' ).forEach( function ( box ) {
			var btn = box.querySelector( '.izl-edit-btn' ), key = box.getAttribute( 'data-izl-edit' );
			if ( ! btn || ! names[ key ] || box.closest( '.izl-admin-strip' ) ) {
				return;
			}
			var add = document.createElement( 'button' );
			add.type = 'button';
			add.className = 'izl-add-text';
			add.textContent = '+ ' + names[ key ];
			add.hidden = ! box.classList.contains( 'is-empty' );
			add.addEventListener( 'click', function () {
				btn.click();
			} );
			strip.appendChild( add );
			box.izlAdd = add;
		} );
		var photos = strip.querySelector( '.izl-photos-open' ), gal = document.querySelector( 'div.product .woocommerce-product-gallery' );
		if ( photos && gal ) {
			holder( gal );
			var f = document.createElement( 'div' );
			f.className = 'izl-admin-float';
			f.appendChild( photos );
			gal.appendChild( f );
		}
		if ( wrap ) {
			// the admin bar still pushes the card down: give that room back, so the card has the customer's size
			var adminbar = document.getElementById( 'wpadminbar' );
			wrap.style.setProperty( '--izl-admin-extra', ( adminbar ? adminbar.offsetHeight : 0 ) + 'px' );
			if ( window.fszFit ) {
				window.fszFit();
			}
		}
	}

	window.izlProductEdit = function () {
		document.querySelectorAll( '.summary [data-izl-edit]' ).forEach( editable );
		buybox();
		stockEdit();
		groupEdit(); // 3.22.0
		rowTitle();
		if ( window.matchMedia && window.matchMedia( '(max-width: 1023px)' ).matches ) {
			toolbar();
		} else {
			floating();
		}
	};
}( jQuery ) );
