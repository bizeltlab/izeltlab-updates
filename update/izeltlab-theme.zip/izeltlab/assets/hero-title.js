// ==========================================================================
//  FILE: assets/hero-title.js   (Ízeltláb theme)
//  WHAT: The front page title on a phone: one line, its letters made smaller until it fits.
//  SEEN: The front page on phones (printed in the page right under the title, inc/styles.php).
// ==========================================================================

/**
 * 3.15.0 (Dan, 2026-11-19): the title ("ászkák minden terráriumba") showed big for a moment while the page loaded, then
 * jumped to its fitted size. It was fitted by home-phone.js, which runs only after the three Codex cards under it are
 * in the page; a slow phone could draw the title before that. Now this small script sits right under the title, so it
 * is fitted before it is ever drawn. home-phone.js calls the same window.izlHeroTitle() again later (fonts in, phone
 * turned).
 *
 * Same result as before, fewer measurements: the letters get the largest whole-pixel size (counting down from the
 * stylesheet's size, never under 20px) at which the title fits on one line; a longer title that does not fit even then
 * wraps onto two lines. Before, it tried every size from the top one by one (up to 16 page measurements); now it
 * guesses the size from one measurement and checks the sizes next to it (usually 2-3 measurements).
 */
( function () {
	'use strict';

	var PHONE = window.matchMedia ? window.matchMedia( '(max-width: 1023px)' ) : null;
	var TITLE_MIN = 20; // px

	window.izlHeroTitle = function () {
		var h = document.querySelector( '.izl-hero h1' );
		if ( ! h ) {
			return;
		}
		h.style.fontSize = '';
		h.classList.remove( 'is-wrap' );
		if ( ! PHONE || ! PHONE.matches ) {
			return;
		}
		var top = parseFloat( window.getComputedStyle( h ).fontSize ) || 36;
		var cw = h.clientWidth, sw = h.scrollWidth;
		if ( sw <= cw + 1 || top <= TITLE_MIN ) {
			if ( sw > cw + 1 ) {
				h.classList.add( 'is-wrap' );
			}
			return;
		}
		var over = function ( fs ) {
			h.style.fontSize = fs + 'px';
			return h.scrollWidth > h.clientWidth + 1;
		};
		// the guess: the width shrinks with the letters' size; start a pixel or two above it, on the same whole steps
		// down from the top size as before
		var fs = top - Math.max( 1, Math.floor( top * ( 1 - cw / sw ) ) - 1 );
		if ( fs < TITLE_MIN ) {
			fs = top - Math.ceil( top - TITLE_MIN );
		}
		if ( over( fs ) ) {
			while ( fs > TITLE_MIN && over( fs - 1 ) ) {
				fs -= 1;
			}
			if ( fs > TITLE_MIN ) {
				fs -= 1; // over( fs - 1 ) was false: that size fits
			}
		} else {
			while ( fs + 1 < top && ! over( fs + 1 ) ) {
				fs += 1;
			}
		}
		h.style.fontSize = fs + 'px';
		if ( h.scrollWidth > h.clientWidth + 1 ) {
			h.classList.add( 'is-wrap' );
		}
	};
	window.izlHeroTitle();
}() );
