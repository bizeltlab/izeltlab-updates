/* 2.6.0: the header search (inc/finder.php). The search button opens the panel under the top bar; typing shows the
   matching species and supplies right away (izl/v1/find), with a "+" that puts the start pack in the cart. Enter opens
   the full results page, Esc or a tap outside closes, the arrow keys move through the results. */
( function () {
	var C = window.izlFind;
	var sp = document.getElementById( 'izl-sp' );
	if ( ! C || ! sp ) {
		return;
	}
	var hdr = sp.parentNode;
	var q = sp.querySelector( '#izl-sp-q' );
	var form = sp.querySelector( '.izl-sp-form' );
	var list = sp.querySelector( '.izl-sp-list' );
	var chips = sp.querySelector( '.izl-sp-chips' );
	var status = sp.querySelector( '.izl-sp-status' );
	var btns = document.querySelectorAll( '.izl-search-btn' );
	var cache = {};
	var dim = null, timer = 0, ctl = null, last = null, isOpen = false;

	function fmt( s, v ) {
		return String( s ).replace( /%(d|s)/, v );
	}
	// "Pöpi" → "popi", one letter for one letter (so a match can be marked in the original text)
	function fold( ch ) {
		return ch.normalize ? ch.normalize( 'NFD' ).charAt( 0 ).toLowerCase() : ch.toLowerCase();
	}
	function words( s ) {
		var out = [];
		String( s ).split( '' ).map( fold ).join( '' ).split( /[^a-z0-9]+/ ).forEach( function ( w ) {
			if ( w && out.indexOf( w ) < 0 ) {
				out.push( w );
			}
		} );
		return out;
	}
	// The text with the searched words marked where a word starts with them.
	function marked( text, ws ) {
		var frag = document.createDocumentFragment();
		var n = text.split( '' ).map( fold ).join( '' );
		var on = new Array( text.length );
		ws.forEach( function ( w ) {
			var i = n.indexOf( w );
			while ( i > -1 ) {
				if ( 0 === i || ! /[a-z0-9]/.test( n.charAt( i - 1 ) ) ) {
					for ( var k = i; k < i + w.length; k++ ) {
						on[ k ] = true;
					}
				}
				i = n.indexOf( w, i + 1 );
			}
		} );
		var buf = '', state = false;
		function flush() {
			if ( ! buf ) {
				return;
			}
			if ( state ) {
				var m = document.createElement( 'mark' );
				m.textContent = buf;
				frag.appendChild( m );
			} else {
				frag.appendChild( document.createTextNode( buf ) );
			}
			buf = '';
		}
		for ( var j = 0; j < text.length; j++ ) {
			if ( !! on[ j ] !== state ) {
				flush();
				state = !! on[ j ];
			}
			buf += text.charAt( j );
		}
		flush();
		return frag;
	}
	function el( tag, cls, text ) {
		var e = document.createElement( tag );
		if ( cls ) {
			e.className = cls;
		}
		if ( null != text ) {
			e.textContent = text;
		}
		return e;
	}

	function fit() {
		if ( ! list.firstChild ) {
			return;
		}
		var top = list.getBoundingClientRect().top;
		list.style.maxHeight = Math.max( 160, ( window.visualViewport ? window.visualViewport.height : window.innerHeight ) - top - 14 ) + 'px';
	}

	function render( d, v ) {
		list.textContent = '';
		var items = d && d.items ? d.items : [];
		var ws = words( d && d.fix ? d.fix : v );
		chips.hidden = !! items.length;
		if ( ! items.length ) {
			if ( v ) {
				list.appendChild( el( 'p', 'izl-sp-none', fmt( C.t.none, v ) ) );
			}
			status.textContent = v ? fmt( C.t.count, 0 ) : '';
			return;
		}
		if ( d.fix ) {
			list.appendChild( el( 'p', 'izl-sp-fix', fmt( C.t.fix, d.fix ) ) );
		}
		var group = null;
		items.forEach( function ( it ) {
			if ( it.sp !== group ) {
				group = it.sp;
				list.appendChild( el( 'p', 'izl-sp-h', it.sp ? C.t.species : C.t.supplies ) );
			}
			var row = el( 'div', 'izl-sr' + ( it.out ? ' is-out' : '' ) );
			var a = el( 'a', 'izl-sr-a' );
			a.href = it.url;
			var ph = el( 'span', 'izl-sr-ph' );
			if ( it.img ) {
				var img = el( 'img' );
				img.src = it.img;
				img.alt = '';
				img.loading = 'lazy';
				img.decoding = 'async';
				img.style.objectPosition = it.pos;
				if ( it.zoom > 1 ) {
					img.style.transformOrigin = it.pos;
					img.style.transform = 'scale(' + it.zoom + ')';
				}
				ph.appendChild( img );
			}
			a.appendChild( ph );
			var t = el( 'span', 'izl-sr-t' );
			var nm = el( 'span', 'izl-sr-n' );
			if ( it.num ) {
				nm.appendChild( el( 'span', 'izl-sr-num', it.num ) );
			}
			nm.appendChild( marked( it.name, ws ) );
			t.appendChild( nm );
			if ( it.latin ) {
				var la = el( 'span', 'izl-sr-l' );
				la.appendChild( marked( it.latin, ws ) );
				t.appendChild( la );
			}
			a.appendChild( t );
			var pr = el( 'span', 'izl-sr-p' );
			if ( it.out ) {
				pr.appendChild( el( 'span', 'izl-sr-out', C.t.out ) );
			} else {
				pr.appendChild( el( 'b', '', it.price ) );
				if ( it.pack ) {
					pr.appendChild( el( 'small', '', '/' + it.pack ) );
				}
			}
			a.appendChild( pr );
			row.appendChild( a );
			if ( it.add && C.cart ) {
				var b = el( 'button', 'izl-sr-add', '+' );
				b.type = 'button';
				b.setAttribute( 'data-id', it.add );
				b.setAttribute( 'data-url', it.url );
				b.setAttribute( 'aria-label', it.label );
				b.title = it.label;
				row.appendChild( b );
			}
			list.appendChild( row );
		} );
		var all = el( 'a', 'izl-sp-all izl-sr-a', fmt( C.t.all, d.more || items.length ) );
		all.href = form.action + ( form.action.indexOf( '?' ) < 0 ? '?' : '&' ) + 's=' + encodeURIComponent( v ) + '&post_type=product';
		list.appendChild( all );
		status.textContent = fmt( C.t.count, d.more || items.length );
		fit();
	}

	function find() {
		var v = q.value.replace( /\s+/g, ' ' ).trim();
		if ( v === last ) {
			return;
		}
		last = v;
		if ( ctl ) {
			ctl.abort();
			ctl = null;
		}
		sp.classList.remove( 'is-busy' );
		if ( ! v ) {
			render( null, '' );
			return;
		}
		if ( cache[ v ] ) {
			render( cache[ v ], v );
			return;
		}
		ctl = window.AbortController ? new AbortController() : null;
		sp.classList.add( 'is-busy' );
		fetch( C.api + ( C.api.indexOf( '?' ) < 0 ? '?' : '&' ) + 'q=' + encodeURIComponent( v ), { signal: ctl ? ctl.signal : undefined, credentials: 'same-origin', headers: { Accept: 'application/json' } } )
			.then( function ( r ) {
				return r.json();
			} )
			.then( function ( d ) {
				cache[ v ] = d;
				if ( v === last ) {
					sp.classList.remove( 'is-busy' );
					render( d, v );
				}
			} )
			.catch( function () {
				if ( v === last ) {
					sp.classList.remove( 'is-busy' );
				}
			} );
	}

	function setBtns( on ) {
		for ( var i = 0; i < btns.length; i++ ) {
			btns[ i ].setAttribute( 'aria-expanded', on ? 'true' : 'false' );
			btns[ i ].classList.toggle( 'is-on', on );
		}
	}
	function open() {
		if ( isOpen ) {
			return;
		}
		isOpen = true;
		if ( ! dim ) {
			dim = el( 'div', 'izl-sp-dim' );
			dim.addEventListener( 'click', function () {
				close( false );
			} );
			document.body.appendChild( dim );
		}
		hdr.classList.add( 'is-finding' );
		sp.classList.add( 'is-open' );
		dim.classList.add( 'is-on' );
		setBtns( true );
		q.focus( { preventScroll: true } ); // in the tap itself, so a phone opens its keyboard
		if ( q.value ) {
			q.select();
		}
		last = null;
		find();
	}
	function close( back ) {
		if ( ! isOpen ) {
			return;
		}
		isOpen = false;
		sp.classList.remove( 'is-open' );
		hdr.classList.remove( 'is-finding' );
		if ( dim ) {
			dim.classList.remove( 'is-on' );
		}
		setBtns( false );
		if ( document.activeElement && sp.contains( document.activeElement ) ) {
			if ( back && btns[ 0 ] ) {
				btns[ 0 ].focus( { preventScroll: true } );
			} else {
				document.activeElement.blur();
			}
		}
		if ( '#izl-sp' === location.hash && history.replaceState ) {
			history.replaceState( null, '', location.pathname + location.search );
		}
	}

	for ( var i = 0; i < btns.length; i++ ) {
		btns[ i ].addEventListener( 'click', function ( e ) {
			e.preventDefault();
			if ( isOpen ) {
				close( true );
			} else {
				open();
			}
		} );
	}
	sp.querySelector( '.izl-sp-x' ).addEventListener( 'click', function ( e ) {
		e.preventDefault();
		close( true );
	} );
	// opened without JavaScript's help (the #izl-sp link before this file ran)
	if ( '#izl-sp' === location.hash ) {
		open();
	}
	q.addEventListener( 'input', function () {
		clearTimeout( timer );
		timer = setTimeout( find, cache[ q.value.replace( /\s+/g, ' ' ).trim() ] ? 0 : 140 );
	} );
	form.addEventListener( 'submit', function ( e ) {
		if ( ! q.value.trim() ) {
			e.preventDefault(); // nothing typed: stay
		}
	} );

	// Keys: Esc closes; arrows move from the field through the results and back.
	function links() {
		return Array.prototype.slice.call( list.querySelectorAll( '.izl-sr-a' ) );
	}
	sp.addEventListener( 'keydown', function ( e ) {
		if ( 'Escape' === e.key ) {
			e.preventDefault();
			close( true );
			return;
		}
		if ( 'ArrowDown' !== e.key && 'ArrowUp' !== e.key ) {
			return;
		}
		var ls = links();
		if ( ! ls.length ) {
			return;
		}
		var at = ls.indexOf( document.activeElement );
		if ( document.activeElement === q ) {
			at = 'ArrowDown' === e.key ? 0 : ls.length - 1;
		} else if ( at > -1 || ( document.activeElement && document.activeElement.classList.contains( 'izl-sr-add' ) ) ) {
			if ( at < 0 ) {
				at = ls.indexOf( document.activeElement.previousSibling );
			}
			at += 'ArrowDown' === e.key ? 1 : -1;
		} else {
			return;
		}
		e.preventDefault();
		if ( at < 0 || at >= ls.length ) {
			q.focus();
			return;
		}
		ls[ at ].focus();
		ls[ at ].scrollIntoView( { block: 'nearest' } );
	} );
	document.addEventListener( 'keydown', function ( e ) {
		if ( isOpen && 'Escape' === e.key ) {
			close( true );
		}
	} );
	window.addEventListener( 'resize', fit );
	if ( window.visualViewport ) {
		window.visualViewport.addEventListener( 'resize', fit );
	}
	// Coming back with the back button (the page kept in memory): closed, as it was left.
	window.addEventListener( 'pageshow', function ( e ) {
		if ( e.persisted ) {
			close( false );
		}
	} );

	// "+": the start pack (or the product) into the cart, as the list's "Kosárba" buttons do.
	list.addEventListener( 'click', function ( e ) {
		var b = e.target.closest ? e.target.closest( '.izl-sr-add' ) : null;
		if ( ! b || b.classList.contains( 'is-busy' ) ) {
			return;
		}
		e.preventDefault();
		b.classList.add( 'is-busy' );
		var body = new URLSearchParams();
		body.append( 'product_id', b.getAttribute( 'data-id' ) );
		body.append( 'quantity', '1' );
		fetch( C.cart, { method: 'POST', body: body, credentials: 'same-origin' } )
			.then( function ( r ) {
				return r.json();
			} )
			.then( function ( d ) {
				b.classList.remove( 'is-busy' );
				if ( ! d || d.error || ! d.fragments ) {
					b.title = C.t.fail;
					window.location = d && d.product_url ? d.product_url : b.getAttribute( 'data-url' );
					return;
				}
				Object.keys( d.fragments ).forEach( function ( sel ) {
					var nodes;
					try {
						nodes = document.querySelectorAll( sel );
					} catch ( err ) {
						return;
					}
					Array.prototype.forEach.call( nodes, function ( n ) {
						n.outerHTML = d.fragments[ sel ];
					} );
				} );
				if ( window.jQuery ) {
					window.jQuery( document.body ).trigger( 'added_to_cart', [ d.fragments, d.cart_hash ] );
				}
				b.classList.add( 'is-added' );
				b.textContent = '✓';
				status.textContent = C.t.added;
				setTimeout( function () {
					b.classList.remove( 'is-added' );
					b.textContent = '+';
				}, 1800 );
			} )
			.catch( function () {
				b.classList.remove( 'is-busy' );
				window.location = b.getAttribute( 'data-url' );
			} );
	} );
} )();
