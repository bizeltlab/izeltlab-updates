/**
 * Ízeltláb 1.7.21: "Edit photos" on products without the Codex card (inc/photos.php).
 *
 * The product's photos in order (the first is the main photo): add from the media library or the device, move, remove,
 * and frame each one: drag the photo in the 4:3 window to choose what shows, the slider zooms in. The window shows it
 * exactly as the shop tiles and the product page will. Save sends the order and the frames, then the page reloads.
 */
( function () {
	'use strict';

	var cfg = window.izlProduct || {};
	var json = document.getElementById( 'izl-photos-data' );
	if ( ! json || ! cfg.edit ) {
		return;
	}
	var d = JSON.parse( json.textContent );
	var photos = d.photos.map( function ( p ) {
		return { id: p.id, thumb: p.thumb, big: p.big, frame: p.frame.slice() };
	} );
	var sel = photos.length ? 0 : -1;

	/* the button, next to Edit buy box */
	var open = document.createElement( 'button' );
	open.type = 'button';
	open.className = 'izl-buybox-open izl-photos-open';
	open.textContent = 'Edit photos';
	function place() {
		var bb = document.querySelector( '.izl-buybox-open:not(.izl-photos-open)' );
		if ( bb && bb.parentNode ) {
			bb.parentNode.insertBefore( open, bb.nextSibling );
			return true;
		}
		return false;
	}
	if ( ! place() ) {
		document.addEventListener( 'DOMContentLoaded', place );
	}

	var dlg = document.createElement( 'dialog' );
	dlg.className = 'izl-buybox izl-photos';
	dlg.innerHTML = '<form method="dialog" class="izl-bb-form"><h2>Photos</h2>' +
		'<p class="izl-bb-help">The first photo is the main one (shop tiles, Tedd mellé, the top of the product page). Drag a photo or use the arrows to change the order.</p>' +
		'<ul class="izl-ph-list"></ul>' +
		'<button type="button" class="izl-ph-add">+ Add photos</button>' +
		'<fieldset class="izl-bb-row izl-ph-framing"><legend>Framing of the chosen photo</legend>' +
		'<div class="izl-ph-win"><img alt="" draggable="false"></div>' +
		'<label class="izl-ph-zoom"><span>Zoom</span><input type="range" min="1" max="3" step="0.01" value="1"><output>100%</output></label>' +
		'<p class="izl-bb-help">Drag the photo to choose what shows. This window is the shape of the shop tiles; the product page shows the same cut.</p>' +
		'<button type="button" class="izl-ph-reset">Reset this photo</button></fieldset>' +
		'<p class="izl-bb-note">Saved into WooCommerce: the product edit screen shows the same photos.</p>' +
		'<div class="izl-bb-actions"><button type="button" class="izl-bb-cancel">Cancel</button><button type="submit" class="izl-bb-save">Save</button></div></form>';
	document.body.appendChild( dlg );
	var $ = function ( s ) {
		return dlg.querySelector( s );
	};
	var list = $( '.izl-ph-list' ), win = $( '.izl-ph-win' ), img = $( '.izl-ph-win img' ), zoom = $( '.izl-ph-zoom input' ), zout = $( '.izl-ph-zoom output' );

	function style( el, f ) {
		el.style.objectPosition = f[ 0 ] + '% ' + f[ 1 ] + '%';
		el.style.transformOrigin = f[ 0 ] + '% ' + f[ 1 ] + '%';
		el.style.transform = 'scale(' + f[ 2 ] + ')';
	}
	function move( from, to ) {
		if ( to < 0 || to >= photos.length || from === to ) {
			return;
		}
		var p = photos.splice( from, 1 )[ 0 ];
		photos.splice( to, 0, p );
		sel = to;
		render();
	}
	function render() {
		list.innerHTML = '';
		photos.forEach( function ( p, i ) {
			var li = document.createElement( 'li' );
			li.className = 'izl-ph-item' + ( i === sel ? ' is-sel' : '' );
			li.draggable = true;
			li.innerHTML = '<button type="button" class="izl-ph-pick" aria-label="Frame this photo"><span class="izl-ph-th"><img alt="" draggable="false"></span>' + ( 0 === i ? '<b class="izl-ph-main">Main</b>' : '' ) + '</button>' +
				'<span class="izl-ph-tools"><button type="button" class="izl-ph-l" aria-label="Move left"' + ( 0 === i ? ' disabled' : '' ) + '>◀</button>' +
				'<button type="button" class="izl-ph-x" aria-label="Remove">✕</button>' +
				'<button type="button" class="izl-ph-r" aria-label="Move right"' + ( i === photos.length - 1 ? ' disabled' : '' ) + '>▶</button></span>';
			var t = li.querySelector( '.izl-ph-th img' );
			t.src = p.big;
			style( t, p.frame );
			li.querySelector( '.izl-ph-pick' ).addEventListener( 'click', function () {
				sel = i;
				render();
			} );
			li.querySelector( '.izl-ph-l' ).addEventListener( 'click', function () {
				move( i, i - 1 );
			} );
			li.querySelector( '.izl-ph-r' ).addEventListener( 'click', function () {
				move( i, i + 1 );
			} );
			li.querySelector( '.izl-ph-x' ).addEventListener( 'click', function () {
				photos.splice( i, 1 );
				sel = Math.min( sel, photos.length - 1 );
				render();
			} );
			li.addEventListener( 'dragstart', function ( e ) {
				e.dataTransfer.setData( 'text/plain', String( i ) );
				e.dataTransfer.effectAllowed = 'move';
			} );
			li.addEventListener( 'dragover', function ( e ) {
				e.preventDefault();
				li.classList.add( 'is-over' );
			} );
			li.addEventListener( 'dragleave', function () {
				li.classList.remove( 'is-over' );
			} );
			li.addEventListener( 'drop', function ( e ) {
				e.preventDefault();
				move( parseInt( e.dataTransfer.getData( 'text/plain' ), 10 ), i );
			} );
			list.appendChild( li );
		} );
		var p = photos[ sel ];
		$( '.izl-ph-framing' ).hidden = ! p;
		if ( p ) {
			if ( img.getAttribute( 'src' ) !== p.big ) {
				img.src = p.big;
			}
			style( img, p.frame );
			zoom.value = p.frame[ 2 ];
			zout.textContent = Math.round( p.frame[ 2 ] * 100 ) + '%';
		}
	}

	/* framing: drag pans (object-position), the slider zooms (scale around the same point) */
	var drag = null;
	win.addEventListener( 'pointerdown', function ( e ) {
		if ( ! photos[ sel ] ) {
			return;
		}
		drag = { x: e.clientX, y: e.clientY, f: photos[ sel ].frame.slice() };
		win.setPointerCapture( e.pointerId );
		win.classList.add( 'is-drag' );
	} );
	win.addEventListener( 'pointermove', function ( e ) {
		if ( ! drag ) {
			return;
		}
		var p = photos[ sel ], bw = win.clientWidth, bh = win.clientHeight;
		var nw = img.naturalWidth || bw, nh = img.naturalHeight || bh;
		var c = Math.max( bw / nw, bh / nh ), z = p.frame[ 2 ]; // cover size, then the zoom
		var rx = Math.max( 1, nw * c * z - bw ), ry = Math.max( 1, nh * c * z - bh ); // how far the photo can travel
		p.frame[ 0 ] = Math.max( 0, Math.min( 100, drag.f[ 0 ] - ( e.clientX - drag.x ) / rx * 100 ) );
		p.frame[ 1 ] = Math.max( 0, Math.min( 100, drag.f[ 1 ] - ( e.clientY - drag.y ) / ry * 100 ) );
		style( img, p.frame );
	} );
	function end() {
		if ( drag ) {
			drag = null;
			win.classList.remove( 'is-drag' );
			render();
		}
	}
	win.addEventListener( 'pointerup', end );
	win.addEventListener( 'pointercancel', end );
	zoom.addEventListener( 'input', function () {
		var p = photos[ sel ];
		if ( p ) {
			p.frame[ 2 ] = parseFloat( zoom.value ) || 1;
			style( img, p.frame );
			zout.textContent = Math.round( p.frame[ 2 ] * 100 ) + '%';
		}
	} );
	zoom.addEventListener( 'change', render );
	$( '.izl-ph-reset' ).addEventListener( 'click', function () {
		if ( photos[ sel ] ) {
			photos[ sel ].frame = [ 50, 50, 1 ];
			render();
		}
	} );

	/* adding: the WordPress media window (the library, or upload from this computer / phone) */
	var frame = null;
	$( '.izl-ph-add' ).addEventListener( 'click', function () {
		if ( ! window.wp || ! window.wp.media ) {
			window.alert( 'The media library did not load. Reload the page and try again.' );
			return;
		}
		if ( ! frame ) {
			frame = window.wp.media( { title: 'Add photos', button: { text: 'Add to the product' }, multiple: 'add', library: { type: 'image' } } );
			frame.on( 'select', function () {
				frame.state().get( 'selection' ).each( function ( a ) {
					var j = a.toJSON(), s = j.sizes || {};
					if ( photos.some( function ( p ) {
						return p.id === j.id;
					} ) ) {
						return;
					}
					var big = ( s.woocommerce_single || s.large || s.full || {} ).url || j.url;
					photos.push( { id: j.id, thumb: ( s.woocommerce_thumbnail || s.medium || {} ).url || big, big: big, frame: [ 50, 50, 1 ] } );
				} );
				if ( sel < 0 && photos.length ) {
					sel = 0;
				}
				render();
			} );
			// Ours comes back when the media window closes (chosen or not).
			frame.on( 'close', function () {
				if ( ! dlg.open ) {
					dlg.showModal();
				}
			} );
		}
		dlg.close(); // a modal dialog sits above everything: the media window could not be clicked behind it
		frame.open();
	} );

	open.addEventListener( 'click', function () {
		render();
		dlg.showModal();
	} );
	$( '.izl-bb-cancel' ).addEventListener( 'click', function () {
		dlg.close();
	} );

	/* saving */
	$( 'form' ).addEventListener( 'submit', function ( e ) {
		e.preventDefault();
		var save = $( '.izl-bb-save' ), body = new window.FormData(), frames = {};
		body.append( 'action', 'izl_photos_save' );
		body.append( '_ajax_nonce', cfg.edit.nonce );
		body.append( 'id', d.id );
		photos.forEach( function ( p ) {
			body.append( 'ids[]', p.id );
			frames[ p.id ] = p.frame.map( function ( v ) {
				return Math.round( v * 1000 ) / 1000;
			} );
		} );
		body.append( 'frames', JSON.stringify( frames ) );
		save.disabled = true;
		save.textContent = 'Saving…';
		function fail( msg ) {
			save.disabled = false;
			save.textContent = 'Save';
			var box = $( '.izl-edit-error' ) || document.createElement( 'p' );
			box.className = 'izl-edit-error';
			box.textContent = msg;
			$( '.izl-bb-actions' ).before( box );
		}
		window.fetch( cfg.edit.ajax, { method: 'POST', body: body, credentials: 'same-origin' } ).then( function ( r ) {
			return r.text();
		} ).then( function ( t ) {
			var at = t.indexOf( '{"success"' ), j = null;
			try {
				j = at > -1 ? JSON.parse( t.slice( at ) ) : null;
			} catch ( err ) {}
			if ( j && j.success ) {
				window.location.reload();
			} else if ( j && j.data ) {
				fail( String( j.data ) );
			} else if ( '0' === t.trim() ) {
				fail( 'Not saved: this address does not see you logged in. Log in again here, then reload the page.' );
			} else if ( '-1' === t.trim() ) {
				fail( 'The security check ran out. Reload the page and try again.' );
			} else {
				fail( 'Not saved. The server answered: ' + t.slice( 0, 200 ) );
			}
		} ).catch( function () {
			fail( 'Not saved: no connection to the shop. Try again.' );
		} );
	} );
}() );
