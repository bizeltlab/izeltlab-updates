/**
 * Front page (1.7.2): the Codex card in front is a link to its product page. A click anywhere on it opens the page,
 * except "Többet" / "Vissza" (the detail screen inside the card). A photo drag still swipes to the next photo; a photo
 * click no longer changes it. Back cards of the carousel keep their own click (carousel.js brings them to the front).
 * Runs before carousel.js, so the card's tabindex is in place when the carousel hides the back cards from the keyboard.
 */
( function () {
	'use strict';

	var DRAG = 8; // px: a pointer that moved more than this is a swipe, not a click

	function setup( holder ) {
		var device = holder.querySelector( '.fsz-device' ), url = holder.getAttribute( 'data-href' );
		if ( ! device || ! url ) {
			return;
		}
		var name = device.querySelector( '.fsz-name' );
		device.classList.add( 'izl-card-link' );
		device.setAttribute( 'role', 'link' );
		device.setAttribute( 'tabindex', '0' );
		if ( name ) {
			device.setAttribute( 'aria-label', name.textContent.trim() );
		}

		function inFront() {
			var slot = holder.closest( '.izl-slot' );
			return ! slot || slot.classList.contains( 'is-front' );
		}
		function go( e ) {
			if ( e.ctrlKey || e.metaKey || 1 === e.button ) {
				window.open( url, '_blank', 'noopener' );
			} else {
				window.location.href = url;
			}
		}

		var start = null;
		device.addEventListener( 'pointerdown', function ( e ) {
			start = [ e.clientX, e.clientY ];
		}, true );
		// Capture phase: runs before the card's own handlers (the photo's "next photo" click never gets it).
		device.addEventListener( 'click', function ( e ) {
			if ( ! inFront() || e.target.closest( '.fsz-more, .fsz-back' ) ) {
				return; // a back card (carousel.js), or the detail screen's buttons
			}
			var moved = start && Math.abs( e.clientX - start[ 0 ] ) + Math.abs( e.clientY - start[ 1 ] ) > DRAG;
			start = null;
			e.stopPropagation();
			e.preventDefault();
			if ( ! moved ) {
				go( e );
			}
		}, true );
		device.addEventListener( 'auxclick', function ( e ) {
			if ( 1 === e.button && inFront() && ! e.target.closest( '.fsz-more, .fsz-back' ) ) {
				go( e );
			}
		} );
		device.addEventListener( 'keydown', function ( e ) {
			if ( 'Enter' === e.key && e.target === device && inFront() ) {
				go( e );
			}
		} );
	}

	function init() {
		Array.prototype.forEach.call( document.querySelectorAll( '.izl-hero-card [data-href]' ), setup );
	}
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
