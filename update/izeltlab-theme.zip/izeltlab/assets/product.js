// ==========================================================================
//  FILE: assets/product.js   (Ízeltláb theme)
//  WHAT: The product page for shoppers: quantity buttons, pack buttons, the big price, stock and shipping
//        lines, Kosárba without a reload, the phone's bottom drawer, the photo pop-out.
//  SEEN: Every product page. (Editors' tools: assets/product-edit.js.)
//  SECTIONS IN THIS FILE:
//    1. Quantity: the − and + buttons
//    2. Pack choice: the dropdown shown as buttons
//    3. The big price
//    4. Stock line and shipping days
//    5. The "added to cart" stamp
//    6. Header cart count and the free-shipping progress line
//    7. Kosárba without a page reload
//    8. Supplies ("Tedd mellé"): the photo flies to the cart
//    9. The phone product page ("Alsó fiók") (since 1.7.19)
//    10. PC: leaf litter behind the card
//    11. Phone: no pinch zoom; switching between the phone and PC layout
//    12. PHONE: the bottom drawer (the biggest part of this file)
//    13. The Szállítás box
//    14. Sold out: "Szólj, ha újra lesz!"
//    15. Photo pop-out
//    16. START: everything above is switched on here
// ==========================================================================

/**
 * Product page buy box: − / + buttons on the quantity box, the pack choice (a variation dropdown) as buttons,
 * and the buy panel: price and stock line (both following the chosen pack) on top of quantity and the cart button.
 * The editing tools (sales line, pack tip, buy box editor) are in assets/product-edit.js, loaded for editors only.
 * 1.7.18: the price as a big number with "Ft" over a small note, Kosárba without a reload (stamp, cart count, free
 * shipping progress), "Tedd mellé" photos fly to the cart, the order-by nudge.
 * 1.7.19: on phones the Codex product page is one screen: the card between the top bar and a bottom drawer that holds
 * the buy box ("Alsó fiók"); see phone() at the end.
 */
( function ( $ ) {
	'use strict';

	var cfg = window.izlProduct || {};

	/* quantity: − and + around the number box */

	// ==========================================================================
	//  Quantity: the − and + buttons
	// ==========================================================================

	function stepper( wrap ) {
		var input = wrap.querySelector( 'input.qty' );
		if ( ! input || input.type === 'hidden' || wrap.fszStep ) {
			return;
		}
		wrap.fszStep = true;
		function wire( b, dir ) {
			b.addEventListener( 'click', function () {
				var step = parseFloat( input.step ) || 1;
				var min = input.min === '' ? 1 : parseFloat( input.min );
				var max = input.max === '' ? Infinity : parseFloat( input.max );
				var v = ( parseFloat( input.value ) || 0 ) + dir * step;
				input.value = Math.max( min, Math.min( max, v ) );
				$( input ).trigger( 'change' );
			} );
		}
		function button( cls, label, text ) {
			var b = document.createElement( 'button' );
			b.type = 'button';
			b.className = 'izl-qty-btn ' + cls;
			b.setAttribute( 'aria-label', label );
			b.textContent = text;
			return b;
		}
		// 2.0.7: the server prints − and + (functions.php); made here only where it did not
		var less = wrap.querySelector( '.izl-qty-btn.is-less' ), more = wrap.querySelector( '.izl-qty-btn.is-more' );
		if ( ! less ) {
			less = button( 'is-less', cfg.less || '−', '−' );
			wrap.insertBefore( less, input );
		}
		if ( ! more ) {
			more = button( 'is-more', cfg.more || '+', '+' );
			wrap.appendChild( more );
		}
		wire( less, -1 );
		wire( more, 1 );
		wrap.classList.add( 'izl-qty' );
	}

	/* pack choice: each variation dropdown becomes a row of buttons (the dropdown stays, hidden, for WooCommerce) */

	// ==========================================================================
	//  Pack choice: the dropdown shown as buttons
	// ==========================================================================

	function chips( select ) {
		// 2.0.7: the server prints the buttons right before the dropdown (functions.php); made here only where it did not
		var row = select.previousElementSibling;
		if ( ! row || ! row.classList.contains( 'izl-chips' ) ) {
			row = document.createElement( 'div' );
			row.className = 'izl-chips';
			row.setAttribute( 'role', 'radiogroup' );
			var label = select.closest( 'tr' ) && select.closest( 'tr' ).querySelector( 'label' );
			if ( label ) {
				row.setAttribute( 'aria-label', label.textContent.trim() );
			}
			select.parentNode.insertBefore( row, select );
		}
		select.classList.add( 'izl-chips-select' );
		row.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( '.izl-chip' );
			if ( ! b || b.disabled ) {
				return;
			}
			var v = b.getAttribute( 'data-value' );
			if ( v === select.value ) {
				return;
			}
			// 2.0.7: the button changes on the press itself (WooCommerce then finds the pack
			// and the price follows in the same moment, prices())
			mark( v );
			$( select ).val( v ).trigger( 'change' );
		} );
		function mark( v ) {
			row.querySelectorAll( '.izl-chip' ).forEach( function ( b ) {
				b.setAttribute( 'aria-checked', b.getAttribute( 'data-value' ) === v ? 'true' : 'false' );
			} );
		}
		// Only what changed is touched: the buttons the server printed stay the same elements.
		function draw() {
			var opts = Array.prototype.filter.call( select.options, function ( o ) {
				return !! o.value;
			} );
			var btns = row.querySelectorAll( '.izl-chip' );
			if ( btns.length !== opts.length ) {
				row.innerHTML = '';
				opts.forEach( function () {
					var b = document.createElement( 'button' );
					b.type = 'button';
					b.className = 'izl-chip';
					b.setAttribute( 'role', 'radio' );
					row.appendChild( b );
				} );
				btns = row.querySelectorAll( '.izl-chip' );
			}
			opts.forEach( function ( o, i ) {
				var b = btns[ i ], t = o.textContent;
				if ( b.textContent !== t ) {
					b.textContent = t;
				}
				if ( b.getAttribute( 'data-value' ) !== o.value ) {
					b.setAttribute( 'data-value', o.value );
				}
				if ( b.disabled !== o.disabled ) {
					b.disabled = o.disabled;
				}
				var on = select.value === o.value ? 'true' : 'false';
				if ( b.getAttribute( 'aria-checked' ) !== on ) {
					b.setAttribute( 'aria-checked', on );
				}
			} );
		}
		$( select ).on( 'change', draw );
		$( select ).closest( 'form' ).on( 'woocommerce_update_variation_values', draw );
		draw();
		// Nothing chosen yet and only one choice to make: start on the first pack, so the button works right away.
		if ( ! select.value && select.closest( 'form' ).querySelectorAll( 'table.variations select' ).length === 1 ) {
			var first = Array.prototype.find.call( select.options, function ( o ) {
				return o.value && ! o.disabled;
			} );
			if ( first ) {
				$( select ).val( first.value ).trigger( 'change' );
			}
		}
	}

	/* 1.7.18: the price as one big number, with "Ft" stacked over a small note: the chosen pack · 27% áfával. Loud
	   enough to be clear, never louder than the cart button. A sale or a price range stays as WooCommerce prints it. */

	// ==========================================================================
	//  The big price
	// ==========================================================================

	function packName() {
		var sel = cfg.pack && document.querySelector( '.summary form.variations_form select[name="attribute_' + cfg.pack + '"]' );
		var o = sel && sel.value ? sel.options[ sel.selectedIndex ] : null;
		return o ? o.textContent.trim() : '';
	}

	function bigPrice() {
		var row = document.querySelector( '.summary .izl-price-row' ), price = row && row.querySelector( '.price' );
		if ( ! price ) {
			return;
		}
		var amounts = price.querySelectorAll( '.woocommerce-Price-amount' );
		if ( 1 !== amounts.length || price.querySelector( 'del' ) ) {
			row.classList.remove( 'is-px' );
			return;
		}
		var amount = amounts[ 0 ].cloneNode( true ), sym = amount.querySelector( '.woocommerce-Price-currencySymbol' );
		var cur = sym ? sym.textContent.trim() : '';
		if ( sym ) {
			sym.parentNode.removeChild( sym );
		}
		var px = row.querySelector( '.izl-px' );
		if ( ! px ) {
			px = document.createElement( 'span' );
			px.className = 'izl-px';
			px.innerHTML = '<span class="izl-px-num"></span><span class="izl-px-side"><span class="izl-px-cur"></span><span class="izl-px-note"></span></span>';
			row.appendChild( px );
		}
		px.querySelector( '.izl-px-num' ).textContent = amount.textContent.replace( /[\s\u00a0\u202f]+/g, ' ' ).trim().replace( / /g, '\u202f' );
		px.querySelector( '.izl-px-cur' ).textContent = cur;
		px.querySelector( '.izl-px-note' ).textContent = [ packName(), cfg.vat || '' ].filter( Boolean ).join( ' · ' );
		var per = row.querySelector( '.izl-px-per' );
		if ( ! per ) {
			per = document.createElement( 'span' );
			per.className = 'izl-px-per';
			row.appendChild( per );
		}
		per.textContent = packName() ? '/\u00a0' + packName() : ''; // 1.7.26: "2 500 Ft / 10 db" on the closed phone drawer
		row.classList.add( 'is-px' );
	}

	/* the price at the top follows the chosen pack */

	function prices( form ) {
		var row = document.querySelector( '.summary .izl-price-row' );
		if ( ! row ) {
			return;
		}
		var price = row.querySelector( '.price' );
		var note = row.querySelector( '.izl-price-note' );
		var start = { price: price ? price.innerHTML : '', note: note ? note.textContent : '' };
		$( form ).on( 'found_variation', function ( e, v ) {
			if ( price && v.price_html ) {
				price.innerHTML = $( '<div>' ).html( v.price_html ).find( '.price' ).html() || price.innerHTML;
			}
			if ( note ) {
				note.textContent = cfg.vat || '';
			}
			bigPrice();
		} );
		$( form ).on( 'reset_data', function () {
			if ( price ) {
				price.innerHTML = start.price;
			}
			if ( note ) {
				note.textContent = start.note;
			}
			bigPrice();
		} );
	}

	/* the stock line under the cart button follows the chosen pack */

	// ==========================================================================
	//  Stock line and shipping days
	// ==========================================================================

	function stock( form ) {
		var line = document.querySelector( '.summary .izl-stock' );
		if ( ! line || ! cfg.stock ) {
			return;
		}
		var label = line.querySelector( 'b' ), when = document.querySelectorAll( '.summary .izl-when' );
		var box = document.querySelector( '.summary .izl-ship-lines' );
		var start = { cls: line.className, text: label.textContent };
		function show( on ) {
			when.forEach( function ( p ) {
				p.hidden = ! on; // nothing ships or arrives when it can't be ordered
			} );
			if ( box ) {
				box.classList.toggle( 'is-sold-out', ! on ); // and no order-by nudge (style.css)
			}
		}
		function set( state, text ) {
			line.className = 'izl-stock is-' + state;
			label.textContent = text;
			show( 'out' !== state );
		}
		$( form ).on( 'found_variation', function ( e, v ) {
			var qty = parseInt( v.max_qty, 10 );
			if ( ! v.is_in_stock ) {
				set( 'out', cfg.stock.out );
			} else if ( v.backorders_allowed && /available-on-backorder/.test( v.availability_html || '' ) ) {
				set( 'back', cfg.stock.back );
			} else if ( qty > 0 && qty <= cfg.low ) {
				set( 'low', cfg.stock.low.replace( '%d', qty ) );
			} else {
				set( 'in', cfg.stock.in );
			}
		} );
		$( form ).on( 'reset_data', function () {
			line.className = start.cls;
			label.textContent = start.text;
			show( ! /is-out/.test( start.cls ) );
		} );
	}

	/* when it ships and when it is expected, from the time in Budapest (not the visitor's clock zone, not a cached page) */

	// Before 14:00 on a shipping day it leaves the same day, else on the next shipping day (live animals Monday to
	// Wednesday, everything else Monday to Friday); expected 1 working day later. Same rule as izl_ship_plan() in PHP.
	function shipping() {
		var box = document.querySelector( '.summary .izl-ship-lines' ), c = cfg.ship;
		if ( ! box || ! c || ! window.Intl ) {
			return;
		}
		try {
			var parts = {};
			new Intl.DateTimeFormat( 'en-US', { timeZone: cfg.tz, year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', hourCycle: 'h23' } )
				.formatToParts( new Date() ).forEach( function ( p ) {
					parts[ p.type ] = parseInt( p.value, 10 );
				} );
			var days = c.days[ box.getAttribute( 'data-ship' ) ] || c.days.normal;
			var dow = function ( d ) {
				return d.getUTCDay() || 7; // 1 = Monday … 7 = Sunday
			};
			// 2.1.0: public holidays and the shop's closed days (Y-m-d list from the server) are skipped too
			var closed = c.closed || [];
			var shut = function ( d ) {
				return closed.indexOf( d.toISOString().slice( 0, 10 ) ) >= 0;
			};
			var out = new Date( Date.UTC( parts.year, parts.month - 1, parts.day ) ), wait = 0;
			var live = 'live' === box.getAttribute( 'data-ship' );
			var no = function ( d ) {
				var next = new Date( d.getTime() + 864e5 );
				return days.indexOf( dow( d ) ) < 0 || shut( d ) || ( live && shut( next ) ); // live animals: no holiday in a depot
			};
			if ( no( out ) || parts.hour >= c.cutoff ) {
				do {
					out.setUTCDate( out.getUTCDate() + 1 );
					wait++;
				} while ( no( out ) );
			}
			var arrive = new Date( out.getTime() );
			do {
				arrive.setUTCDate( arrive.getUTCDate() + 1 );
			} while ( dow( arrive ) > 5 || shut( arrive ) );
			var leaves = box.querySelector( '.izl-leaves b' ), when = box.querySelector( '.izl-arrive b' ), nudge = box.querySelector( '.izl-nudge' );
			var w = c.words;
			if ( leaves ) {
				leaves.textContent = 0 === wait ? w.today : ( 1 === wait ? w.tomorrow : w.on[ dow( out ) ] );
			}
			if ( when && w.date && w.months ) {
				// "kedden, nov. 3." (the same words as the server prints)
				when.textContent = w.date.replace( '%1$s', w.on[ dow( arrive ) ] ).replace( '%2$s', w.months[ arrive.getUTCMonth() ] ).replace( '%3$d', arrive.getUTCDate() );
			}
			if ( nudge ) {
				// 1.7.18: "Ha 14:00-ig megrendeled, még ma feladjuk!" from 11:00 until the cutoff, on a shipping day only
				nudge.hidden = ! ( 0 === wait && parts.hour >= c.from && parts.hour < c.cutoff );
			}
		} catch ( e ) {} // keep what the server printed
	}

	/* 1.7.17: "added to cart": WooCommerce shows the page again after Kosárba; a green rubber stamp (a cart with a big
	   check, uneven ink) lands on the right edge of the ticket, holds 5 s and fades out in 3 s, and the Codex screen
	   flashes once. It waits until the ticket is at least half on screen. */

	var STAMP = '<svg viewBox="-20 -20 240 240" aria-hidden="true" focusable="false"><defs>' +
		'<filter id="izl-ink" x="-25%" y="-25%" width="150%" height="150%" color-interpolation-filters="sRGB">' +
		'<feTurbulence type="fractalNoise" baseFrequency="0.035" numOctaves="3" seed="11" result="low"/>' +
		'<feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" seed="18" result="hi"/>' +
		'<feTurbulence type="turbulence" baseFrequency="0.06" numOctaves="2" seed="14" result="warp"/>' +
		'<feDisplacementMap in="SourceGraphic" in2="warp" scale="3.5" xChannelSelector="R" yChannelSelector="G" result="rough"/>' +
		'<feColorMatrix in="low" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  2.2 0 0 0 -0.25" result="lowA"/>' +
		'<feColorMatrix in="hi" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  3.0 0 0 0 -0.55" result="hiA"/>' +
		'<feComposite in="lowA" in2="hiA" operator="arithmetic" k1="1" k2="0" k3="0" k4="0" result="mask"/>' +
		'<feComposite in="rough" in2="mask" operator="in"/></filter>' +
		'<mask id="izl-ink-ko" maskUnits="userSpaceOnUse" x="0" y="0" width="200" height="200"><rect width="200" height="200" fill="#fff"/>' +
		'<path d="M122 108 L144 133 L198 28" fill="none" stroke="#000" stroke-width="38" stroke-linecap="round" stroke-linejoin="round"/></mask></defs>' +
		'<g transform="rotate(-9 100 100)"><g filter="url(#izl-ink)"><g mask="url(#izl-ink-ko)">' +
		'<circle cx="100" cy="100" r="86" fill="none" stroke="#23793B" stroke-width="10"/>' +
		'<circle cx="100" cy="100" r="72" fill="none" stroke="#23793B" stroke-width="3.5"/>' +
		'<g transform="translate(2 30) scale(2.55)"><path d="M12 20h6l5 17h19l4.5-12H21" fill="none" stroke="#23793B" stroke-width="4.2" stroke-linecap="round" stroke-linejoin="round"/>' +
		'<circle cx="25.5" cy="43.5" r="2.9" fill="#23793B"/><circle cx="40" cy="43.5" r="2.9" fill="#23793B"/></g></g>' +
		'<path d="M122 108 L144 133 L198 28" fill="none" stroke="#23793B" stroke-width="22" stroke-linecap="round" stroke-linejoin="round"/></g></g></svg>';

	// ==========================================================================
	//  The "added to cart" stamp
	// ==========================================================================

	function ticketOf() {
		var form = document.querySelector( '.summary form.cart' );
		return form && ( form.querySelector( '.woocommerce-variation-add-to-cart' ) || form );
	}

	// Presses the stamp now (1.7.18: also right after a Kosárba without a reload; a second press starts it again).
	function pressStamp( ticket ) {
		var old = ticket.querySelector( '.izl-stamp' );
		if ( old ) {
			old.parentNode.removeChild( old );
		}
		var st = document.createElement( 'span' );
		st.className = 'izl-stamp';
		st.innerHTML = STAMP;
		ticket.appendChild( st );
		// 2.0.6 (computers): the stamp lands on the right end of Kosárba vele!, centred on the button's height, out over
		// the ticket's edge, instead of over the arrival dates. Phones keep their spot (style.css).
		var cartBtn = ticket.querySelector( '.single_add_to_cart_button' );
		if ( cartBtn && ! document.body.classList.contains( 'izl-phone' ) && ! ( window.matchMedia && window.matchMedia( PHONE_Q ).matches ) ) {
			var tr = ticket.getBoundingClientRect(), br = cartBtn.getBoundingClientRect();
			if ( br.height ) {
				st.style.top = Math.round( br.top - tr.top + br.height / 2 - st.offsetHeight / 2 - ticket.clientTop ) + 'px';
				st.style.bottom = 'auto';
			}
		}
		void st.offsetWidth;
		st.classList.add( 'is-on' );
		ticket.classList.remove( 'is-stamped' );
		void ticket.offsetWidth;
		ticket.classList.add( 'is-stamped' );
		// 2.0.7: no flash on the card any more (Dan): the stamp alone answers the press
		window.setTimeout( function () {
			ticket.classList.remove( 'is-stamped' );
		}, 700 );
		window.setTimeout( function () {
			if ( st.parentNode ) {
				st.parentNode.removeChild( st );
			}
		}, 8500 );
	}

	// After a reload add (the fallback): waits until the ticket is at least half on screen.
	function stamp() {
		var ticket = ticketOf();
		if ( ! cfg.added || ! ticket ) {
			return;
		}
		function go() {
			pressStamp( ticket );
			progress( null == cfg.addedSum ? null : parseFloat( cfg.addedSum ) );
		}
		if ( 'IntersectionObserver' in window ) {
			var io = new window.IntersectionObserver( function ( entries ) {
				if ( entries[ entries.length - 1 ].isIntersecting ) {
					io.disconnect();
					go();
				}
			}, { threshold: 0.5 } );
			io.observe( ticket );
		} else {
			go();
		}
	}

	/* 1.7.18: the header cart answers an add: it bumps and the new count pops in */

	// ==========================================================================
	//  Header cart count and the free-shipping progress line
	// ==========================================================================

	function bumpCart() {
		document.querySelectorAll( '.izl-cart' ).forEach( function ( a ) {
			var n = a.querySelector( '.izl-cart-count' );
			a.classList.remove( 'is-bump' );
			void a.offsetWidth;
			a.classList.add( 'is-bump' );
			if ( n ) {
				n.classList.remove( 'is-pop' );
				void n.offsetWidth;
				n.classList.add( 'is-pop' );
			}
		} );
	}

	// The cart total, from the refreshed cart count (functions.php puts it in data-total).
	function totalOf( fragments ) {
		var html = fragments && fragments[ 'span.izl-cart-count' ], m = html && /data-total="([\d.]+)"/.exec( html );
		return m ? parseFloat( m[ 1 ] ) : null;
	}

	/* 1.7.18: free shipping progress under the cart button after an add: "Már csak 15 500 Ft, és ingyenes a szállítás!"
	   over a thin yellow bar, green with "Megvan! Ingyenes a szállítás!" once the cart reaches the amount. */

	function money2( n ) {
		var m = cfg.money || {}, num = Math.round( n ).toString().replace( /\B(?=(\d{3})+(?!\d))/g, ' ' ), cur = m.cur || '';
		return { left: cur + num, left_space: cur + ' ' + num, right: num + cur }[ m.pos ] || num + ' ' + cur;
	}

	function progress( total ) {
		var limit = parseFloat( cfg.freeShip ) || 0, ticket = ticketOf();
		if ( ! limit || ! ticket || null === total || isNaN( total ) || ! cfg.prog ) {
			return;
		}
		var slot = document.querySelector( '.izl-dprog' ); // 1.7.19: the phone drawer keeps it above the packs
		var p = ( slot || ticket ).querySelector( '.izl-prog' );
		if ( ! p ) {
			p = document.createElement( 'p' );
			p.className = 'izl-prog';
			p.setAttribute( 'aria-live', 'polite' );
			p.innerHTML = '<span class="izl-prog-t"></span><span class="izl-prog-bar" aria-hidden="true"><i></i></span><span class="izl-prog-fx" aria-hidden="true"></span>';
			( slot || ticket ).appendChild( p );
		}
		var rest = limit - total, done = rest <= 0, first = done && ! p.classList.contains( 'is-done' );
		p.hidden = false;
		p.classList.toggle( 'is-done', done );
		var t = p.querySelector( '.izl-prog-t' );
		if ( done ) {
			t.innerHTML = '<span class="izl-prog-ck" aria-hidden="true">\u2713</span>';
			t.appendChild( document.createTextNode( cfg.prog.done ) );
		} else {
			t.textContent = cfg.prog.more.replace( '%s', money2( rest ) );
			p.classList.remove( 'is-gone' );
		}
		window.setTimeout( function () {
			p.querySelector( 'i' ).style.width = Math.max( 0, Math.min( 100, total / limit * 100 ) ) + '%';
		}, 30 );
		if ( first ) {
			celebrate( p );
		}
		$( document.body ).trigger( 'izl_progress', [ p, done ] );
	}

	/* 1.7.19: free shipping reached: the tick pops, the bar glows and a few crumbs fly off it, once. On a phone the line
	   then leaves the closed drawer after 5 s (it stays in the open one). */

	function celebrate( p ) {
		var still = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
		var bar = p.querySelector( '.izl-prog-bar' ), fx = p.querySelector( '.izl-prog-fx' ), ck = p.querySelector( '.izl-prog-ck' );
		window.setTimeout( function () {
			p.classList.add( 'is-gone' );
			$( document.body ).trigger( 'izl_progress', [ p, true ] );
		}, 5000 );
		if ( still || ! bar || ! fx || ! fx.animate ) {
			return;
		}
		[ bar, p ].forEach( function ( el, i ) {
			el.classList.remove( i ? 'is-bump' : 'is-glow' );
			void el.offsetWidth;
			el.classList.add( i ? 'is-bump' : 'is-glow' );
		} );
		if ( ck ) {
			ck.classList.add( 'is-go' );
		}
		window.setTimeout( function () {
			bar.classList.remove( 'is-glow' );
			p.classList.remove( 'is-bump' );
		}, 1200 );
		var f = fx.getBoundingClientRect(), b = bar.getBoundingClientRect(), cols = [ '#F4D35E', '#3fb37a', '#1F8A8A' ];
		for ( var i = 0; i < 10; i++ ) {
			var d = document.createElement( 'span' );
			d.style.background = cols[ i % 3 ];
			d.style.left = ( b.right - f.left - 8 ) + 'px';
			d.style.top = ( b.top - f.top + b.height / 2 - 2 ) + 'px';
			fx.appendChild( d );
			var a = -Math.PI * ( 0.15 + 0.7 * Math.random() ), r = 10 + Math.random() * 12, dx = Math.cos( a ) * r - 6, dy = Math.sin( a ) * r, rot = Math.random() * 360;
			( function ( d ) {
				var an = d.animate( [
					{ transform: 'translate(0,0) rotate(0deg)', opacity: 1 },
					{ transform: 'translate(' + dx + 'px,' + dy + 'px) rotate(' + ( rot / 2 ) + 'deg)', opacity: 1, offset: 0.45 },
					{ transform: 'translate(' + ( dx * 1.2 ) + 'px,' + ( dy + 10 ) + 'px) rotate(' + rot + 'deg)', opacity: 0 }
				], { duration: 850, delay: i * 15, easing: 'cubic-bezier(.2,.7,.4,1)', fill: 'both' } );
				an.onfinish = function () {
					d.remove();
				};
			} )( d );
		}
	}

	/* 1.7.18: Kosárba without a reload. The form goes to WooCommerce's own AJAX add to cart.
	   2.0.7: the answer is not waited for: the stamp lands, the cart count goes up and the free-shipping line moves on
	   the press itself, and the add is sent in the background (several presses queue up and go one by one). When an
	   answer comes and nothing else is queued, the real cart count and total replace the guess. Anything unexpected
	   (an error, a pack that needs more, no answer) sends the form the old way, so WooCommerce shows its message on the
	   reloaded page (with the stamp after the reload when it did add, see stamp()). */

	// ==========================================================================
	//  Kosárba without a page reload
	// ==========================================================================

	// The cart count and total right now (the header count carries the total in data-total, functions.php).
	function cartNow() {
		var n = document.querySelector( '.izl-cart-count' );
		return { n: n ? parseInt( n.textContent, 10 ) || 0 : 0, total: n ? parseFloat( n.getAttribute( 'data-total' ) ) || 0 : 0 };
	}
	// The guess: count and total moved on by an add, before the shop has answered.
	function cartGuess( qty, amount ) {
		var now = cartNow(), total = now.total + amount;
		document.querySelectorAll( '.izl-cart-count' ).forEach( function ( n ) {
			n.textContent = String( now.n + qty );
			n.classList.remove( 'is-empty' );
			n.setAttribute( 'data-total', String( total ) );
		} );
		return total;
	}

	function quickAdd( form ) {
		var btn = form.querySelector( '.single_add_to_cart_button' ), c = cfg.cart;
		if ( ! btn || ! c || ! c.url || c.redirect || ! window.fetch || ! window.FormData ) {
			return;
		}
		if ( ! form.querySelector( '[name="add-to-cart"]' ) && 'add-to-cart' !== btn.name ) {
			return; // not a normal cart form (an external product, a grouped one…)
		}
		var unit = parseFloat( cfg.unit ) || 0, jobs = [], sending = false, failed = false;
		$( form ).on( 'found_variation', function ( e, v ) {
			unit = parseFloat( v.display_price ) || 0; // the chosen pack's price, for the guess
		} );
		function native( fd ) {
			if ( ! form.querySelector( 'input[name="add-to-cart"]' ) && 'add-to-cart' === btn.name ) {
				var h = document.createElement( 'input' );
				h.type = 'hidden';
				h.name = 'add-to-cart';
				h.value = btn.value;
				form.appendChild( h ); // the button's own value is not sent by a script send
			}
			if ( fd ) {
				// the pack and the amount of the add that failed (the form may show another pack by now)
				[ 'variation_id', 'quantity' ].forEach( function ( k ) {
					var f = form.querySelector( '[name="' + k + '"]' );
					if ( f && null !== fd.get( k ) ) {
						f.value = fd.get( k );
					}
				} );
			}
			window.HTMLFormElement.prototype.submit.call( form );
		}
		function pump() {
			if ( sending || failed || ! jobs.length ) {
				return;
			}
			sending = true;
			var job = jobs.shift();
			var fail = function () {
				failed = true; // nothing more is sent from here: the page goes the old way
				jobs = [];
				native( job.fd );
			};
			window.fetch( c.url, { method: 'POST', credentials: 'same-origin', body: job.body } )
				.then( function ( r ) {
					return r.json();
				} )
				.then( function ( res ) {
					sending = false;
					if ( ! res || res.error || ! res.fragments ) {
						fail(); // not added: WooCommerce says why on the page
						return;
					}
					// Added. From here nothing sends this add again, whatever happens to the rest.
					try {
						synced( res, ! jobs.length, job.id );
					} catch ( err ) {}
					pump();
				}, function () {
					sending = false;
					fail(); // no answer, or not one we understand: nothing was added, so send the form the old way
				} );
		}
		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			if ( failed || btn.classList.contains( 'disabled' ) ) {
				return; // WooCommerce's own click handler says what is missing (no pack chosen…)
			}
			var fd = new window.FormData( form ), vid = parseInt( fd.get( 'variation_id' ), 10 ) || 0;
			var id = vid || parseInt( fd.get( 'add-to-cart' ) || btn.value || fd.get( 'product_id' ), 10 ) || 0;
			if ( ! id || ( form.classList.contains( 'variations_form' ) && ! vid ) ) {
				native();
				return;
			}
			var qty = Math.max( 1, parseFloat( fd.get( 'quantity' ) ) || 1 );
			var body = new window.FormData();
			body.append( 'product_id', id );
			body.append( 'quantity', qty );
			// the answer to the press, now
			var ticket = ticketOf();
			if ( ticket ) {
				pressStamp( ticket );
			}
			var total = cartGuess( qty, unit * qty );
			bumpCart();
			progress( unit ? total : null );
			jobs.push( { body: body, fd: fd, id: id } );
			pump();
		} );
	}

	// An answer from the shop: its cart parts replace the page's (the count and total only when no other add is still
	// on its way, so the guess never steps back), and other scripts hear about the add.
	function synced( res, last, id ) {
		var frags = {};
		$.each( res.fragments, function ( key, html ) {
			if ( last || 'span.izl-cart-count' !== key ) {
				frags[ key ] = html;
				$( key ).replaceWith( html );
			}
		} );
		if ( last ) {
			progress( totalOf( res.fragments ) );
		}
		// other scripts (mini cart, stats) hear it too; WooCommerce puts these parts in again, so the count goes along
		// only when it is the real one
		// 2.1.2: no button (WooCommerce would add its "View cart" link next to it), but the product id as a 5th value, so
		// the Ízeltláb Bolt add_to_cart event knows what was added
		$( document.body ).trigger( 'added_to_cart', [ frags, res.cart_hash, null, id ] );
	}

	/* 1.7.18: "Tedd mellé" +: the supply's photo flies in an arc to the header cart (to the top right corner when the
	   header is scrolled away), then the cart bumps and the progress updates. WooCommerce's own add to cart does the work. */

	// ==========================================================================
	//  Supplies ("Tedd mellé"): the photo flies to the cart
	// ==========================================================================

	function fly( img ) {
		var d = $.Deferred();
		var still = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
		if ( ! img || ! img.animate || still ) {
			return d.resolve();
		}
		var r = img.getBoundingClientRect(), cart = document.querySelector( '.izl-cart' ), c = cart && cart.getBoundingClientRect();
		var tx = window.innerWidth - 40, ty = 24;
		if ( c && c.width && c.bottom > 0 ) {
			tx = c.left + c.width / 2;
			ty = c.top + c.height / 2;
		}
		var f = img.cloneNode( false );
		f.removeAttribute( 'srcset' );
		f.removeAttribute( 'sizes' );
		f.removeAttribute( 'loading' );
		f.className = 'izl-fly';
		f.setAttribute( 'aria-hidden', 'true' );
		f.style.left = r.left + 'px';
		f.style.top = r.top + 'px';
		f.style.width = r.width + 'px';
		f.style.height = r.height + 'px';
		document.body.appendChild( f );
		var dx = tx - ( r.left + r.width / 2 ), dy = ty - ( r.top + r.height / 2 );
		var anim = f.animate( [
			{ transform: 'translate(0,0) scale(1)', opacity: 1 },
			{ transform: 'translate(' + ( dx * 0.45 ) + 'px,' + ( dy * 0.55 - 80 ) + 'px) scale(.8)', opacity: 1, offset: 0.45 },
			{ transform: 'translate(' + dx + 'px,' + dy + 'px) scale(.25)', opacity: 0.7 }
		], { duration: 750, easing: 'cubic-bezier(.45,0,.55,1)' } );
		function end() {
			if ( f.parentNode ) {
				f.parentNode.removeChild( f );
			}
			d.resolve();
		}
		anim.onfinish = end;
		window.setTimeout( end, 1200 ); // never wait longer than this
		return d;
	}

	function setupFly() {
		var flights = {}, pending = [];
		function setupButton( $b ) {
			var b = $b && $b[ 0 ];
			return b && b.classList && b.classList.contains( 'izl-setup-add' ) ? b : null;
		}
		// 2.0.7: the press is answered at once (tick on the button, the count and the free-shipping line move on, the
		// photo flies); WooCommerce sends the add in the background, one after the other.
		$( document.body ).on( 'adding_to_cart', function ( e, $b ) {
			var b = setupButton( $b ), li = b && b.closest( 'li' );
			if ( ! b ) {
				return;
			}
			b.classList.add( 'izl-ok' );
			var price = parseFloat( b.getAttribute( 'data-izl-price' ) ) || 0, total = cartGuess( 1, price );
			pending.push( price );
			var id = b.getAttribute( 'data-product_id' );
			flights[ id ] = fly( li && li.querySelector( '.izl-setup-photo img' ) );
			flights[ id ].always( function () {
				bumpCart();
				progress( price ? total : null );
			} );
		} );
		$( document.body ).on( 'added_to_cart', function ( e, fragments, hash, $b ) {
			var b = setupButton( $b );
			if ( ! b ) {
				return;
			}
			delete flights[ b.getAttribute( 'data-product_id' ) ];
			pending.shift();
			// after WooCommerce has put the shop's count in (its own handler of this event): adds still on their way are
			// counted on top, so the count never steps back
			window.setTimeout( function () {
				var more = pending.reduce( function ( a, p ) {
					return a + p;
				}, 0 );
				progress( pending.length ? cartGuess( pending.length, more ) : totalOf( fragments ) );
			}, 0 );
		} );
		$( document.body ).on( 'ajax_request_not_sent.adding_to_cart', function () {
			pending = [];
		} );
	}

	// ==========================================================================
	//  The phone product page ("Alsó fiók") (since 1.7.19)
	// ==========================================================================
	// One screen: the slim top bar, the Codex card (sized by Codex's screen fit, codex.php fsz_fit_script) and a bottom
	// drawer holding the buy box. Closed: the packs, the price and Kosárba vele!. Open (tap or drag the top of it): the
	// name, the arrival day, Tedd mellé, Szállítás and the rest of the page. style.css lays it out (phones, Codex product
	// pages); this builds the drawer from the page's own parts, so WooCommerce's form keeps working as it is.

	var PHONE_Q = '(max-width: 767px)';

	/* 2.0.7 computers: the leaf litter patch behind the card (style.css .izl-litter): two layers, far and near. They
	   drift with the page scroll in style.css; here they shift a few px against the mouse, the near leaves more, as if
	   the card stood over a real terrarium floor. Only while the patch is on screen; nothing for reduced motion. */

	// ==========================================================================
	//  PC: leaf litter behind the card
	// ==========================================================================

	function litter() {
		var wrap = document.querySelector( '.izl-codex-product div.product > .fsz-wrap.fsz-at-gallery' );
		if ( ! wrap || ! window.matchMedia || window.matchMedia( PHONE_Q ).matches || wrap.querySelector( '.izl-litter' ) ) {
			return;
		}
		var box = document.createElement( 'div' ), far = document.createElement( 'i' ), near = document.createElement( 'i' );
		box.className = 'izl-litter';
		box.setAttribute( 'aria-hidden', 'true' );
		near.className = 'is-near';
		box.appendChild( far );
		box.appendChild( near );
		wrap.insertBefore( box, wrap.firstChild );
		window.requestAnimationFrame( function () {
			box.classList.add( 'is-on' ); // fades in
		} );
		if ( window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches || window.matchMedia( '(pointer: coarse)' ).matches ) {
			return;
		}
		var seen = true, raf = 0, mx = 0, my = 0;
		if ( 'IntersectionObserver' in window ) {
			new window.IntersectionObserver( function ( en ) {
				seen = en[ en.length - 1 ].isIntersecting;
			} ).observe( box );
		}
		function draw() {
			raf = 0;
			far.style.transform = 'translate3d(' + ( -mx * 6 ).toFixed( 1 ) + 'px,' + ( -my * 5 ).toFixed( 1 ) + 'px,0)';
			near.style.transform = 'translate3d(' + ( -mx * 14 ).toFixed( 1 ) + 'px,' + ( -my * 11 ).toFixed( 1 ) + 'px,0)';
		}
		window.addEventListener( 'mousemove', function ( e ) {
			if ( ! seen ) {
				return;
			}
			mx = e.clientX / window.innerWidth - 0.5;
			my = e.clientY / window.innerHeight - 0.5;
			if ( ! raf ) {
				raf = window.requestAnimationFrame( draw );
			}
		}, { passive: true } );
	}

	/* 2.0.5: no pinch zoom on a phone's product page, upright or sideways (zoomed in, an iPhone redrew the card's many
	   layers at the zoom size and ran out of memory: "A problem repeatedly occurred"). touch-action in style.css
	   (izl-zl), the viewport tag, and Safari's own gesture events. Off with the roll-back switch (Customizer). */

	// ==========================================================================
	//  Phone: no pinch zoom; switching between the phone and PC layout
	// ==========================================================================

	function zoomLock() {
		var P = cfg.phone || {}, mm = window.matchMedia;
		if ( P.r203 || ! mm || ! document.querySelector( '.izl-codex-product .fsz-wrap.fsz-at-gallery' ) ) {
			return;
		}
		var small = Math.min( window.screen.width, window.screen.height ) < 600; // a phone, not a tablet
		// 2.5.0: called again when the layout switches without a reload (phoneSwitch): a desktop window made wide again
		// gets its zoom back
		var want = mm( PHONE_Q ).matches || ( small && mm( '(pointer: coarse)' ).matches );
		var vp = document.querySelector( 'meta[name="viewport"]' );
		if ( ! want ) {
			if ( document.body.classList.contains( 'izl-zl' ) ) {
				document.body.classList.remove( 'izl-zl' );
				if ( vp ) {
					vp.setAttribute( 'content', 'width=device-width, initial-scale=1, viewport-fit=cover' );
				}
				if ( window.izlVp ) {
					window.izlVp();
				}
			}
			return;
		}
		document.body.classList.add( 'izl-zl' );
		if ( vp ) {
			vp.setAttribute( 'content', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover' );
			if ( window.izlVp ) {
				window.izlVp(); // 2.4.0: a phone turned sideways keeps its computer-layout width (functions.php)
			}
		}
		if ( zoomLock.on ) {
			return;
		}
		zoomLock.on = true;
		[ 'gesturestart', 'gesturechange', 'gestureend' ].forEach( function ( n ) {
			document.addEventListener( n, function ( e ) {
				if ( document.body.classList.contains( 'izl-zl' ) ) {
					e.preventDefault();
				}
			}, { passive: false } );
		} );
	}

	/* 2.0.6: crossing the phone width (a phone turned sideways, or a desktop window dragged narrow or wide) needs the
	   other layout. 2.5.0: it switches in place, without reloading the page (Dan): phone() builds the drawer from the
	   page's own parts, its undo (PH.down) puts every part back where it was, so the chosen pack, the quantity and the
	   card stay as they were, and the switch takes a blink instead of a whole page load. Checked on every size change (an iPhone turned sideways did not always send the media query's
	   own change), when the phone is turned and when the browser brings the page back from its memory (back button);
	   never while someone types in a field (an on-screen keyboard changes the window's size). If anything goes wrong,
	   the page reloads as before 2.5.0. */
	var PH = null; // the phone drawer while it is built: { down: undo, open: whether it was open }
	function phoneSwitch() {
		var mq = window.matchMedia && window.matchMedia( PHONE_Q );
		if ( ! mq || ! document.querySelector( '.izl-codex-product .summary.entry-summary' ) || ! document.querySelector( '.fsz-wrap.fsz-at-gallery' ) ) {
			return;
		}
		// 2.5.1: switched at once, in the same moment the browser applies the new width (the media query's change and
		// the resize come before the page is drawn again). 2.5.0 waited 0.12 s, and in that moment the computer layout
		// showed the phone drawer's parts unstyled (Dan: a big house icon and the name).
		var check = function () {
			var a = document.activeElement;
			if ( mq.matches === !! PH || ( a && /^(INPUT|TEXTAREA|SELECT)$/.test( a.tagName ) && ! /^(radio|checkbox|button|submit)$/.test( a.type || '' ) ) ) {
				return;
			}
			try {
				if ( mq.matches ) {
					zoomLock();
					phone();
				} else {
					var was = PH;
					PH = null;
					was.down();
					zoomLock();
					litter();
					if ( window.fszFit ) {
						window.fszFit();
					}
					window.dispatchEvent( new window.Event( 'resize' ) ); // Codex and the rest measure the card again
				}
			} catch ( err ) {
				window.scrollTo( 0, 0 );
				window.location.reload();
			}
		};
		if ( mq.addEventListener ) {
			mq.addEventListener( 'change', check );
		} else if ( mq.addListener ) {
			mq.addListener( check );
		}
		window.addEventListener( 'resize', check ); // also when the media query's own change does not come
		window.addEventListener( 'orientationchange', check );
		window.addEventListener( 'pageshow', function ( e ) {
			if ( e.persisted ) {
				check();
			}
		} );
	}

	// ==========================================================================
	//  PHONE: the bottom drawer (the biggest part of this file)
	// ==========================================================================

	function phone() {
		var mq = window.matchMedia && window.matchMedia( PHONE_Q );
		var body = document.body, sum = document.querySelector( '.izl-codex-product .summary.entry-summary' );
		var wrap = document.querySelector( '.fsz-wrap.fsz-at-gallery' ), head = document.querySelector( '.site-header' );
		if ( PH || ! mq || ! mq.matches || ! sum || ! wrap || ! head ) {
			return;
		}
		/* 2.5.0: everything this build changes is noted, so down() can undo it (the live switch to the computer layout):
		   on() listeners, moves (each part's old spot), made (new parts), classes and inline properties. After down()
		   nothing of it runs any more (dead), also timers already waiting. */
		var dead = false, undo = [], made = [];
		var on = function ( t, type, fn, opt ) {
			t.addEventListener( type, fn, opt );
			undo.push( function () {
				t.removeEventListener( type, fn, opt );
			} );
		};
		var mv = function ( n, parent, before ) {
			var p0 = n.parentNode, s0 = n.nextSibling;
			undo.push( function () {
				if ( p0 ) {
					p0.insertBefore( n, s0 && s0.parentNode === p0 ? s0 : null );
				}
			} );
			parent.insertBefore( n, before || null );
		};
		var mk = function ( n ) {
			made.push( n );
			return n;
		};
		// 2.0.6: a refresh always starts with the drawer closed (the browser put the page back at its old scroll spot,
		// so a half-pulled drawer came back half open)
		var restore0 = 'scrollRestoration' in window.history ? window.history.scrollRestoration : null;
		if ( restore0 ) {
			window.history.scrollRestoration = 'manual';
		}
		window.scrollTo( 0, 0 );
		var still = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches, popOpen = false;
		var P = cfg.phone || {}, form = sum.querySelector( 'form.cart' );
		var panel = form && ( form.querySelector( '.woocommerce-variation-add-to-cart' ) || form );
		var el = function ( tag, cls, html ) {
			var e = document.createElement( tag );
			e.className = cls;
			if ( html ) {
				e.innerHTML = html;
			}
			return e;
		};

		/* the drawer: grab handle, then one scrolling column (core: always there; more: the open drawer) */
		var grab = mk( el( 'button', 'izl-grab' ) ), scroll = mk( el( 'div', 'izl-dscroll' ) ), core = el( 'div', 'izl-dcore' ), more = el( 'div', 'izl-dmore' );
		grab.type = 'button';
		grab.setAttribute( 'aria-label', P.open || '' );
		grab.setAttribute( 'aria-expanded', 'false' );
		var kids = Array.prototype.slice.call( sum.childNodes );
		scroll.appendChild( core );
		scroll.appendChild( more );
		// 1.7.21: no blurred peek under the closed buy row any more (it was a blur redrawn on every frame); the closed
		// drawer ends just under Kosárba vele!.
		sum.appendChild( grab );
		sum.appendChild( scroll );
		sum.classList.add( 'izl-drawer' );

		// The name (open drawer only): the nickname, then the Latin name with the card's temple icon and the English name.
		var nick = wrap.querySelector( '.fsz-nick' ), lat = wrap.querySelector( '.fsz-latin i' ), en = wrap.querySelector( '.fsz-en span' ), temple = wrap.querySelector( '.fsz-temple svg' );
		var name = el( 'div', 'izl-dname' );
		var h = el( 'p', 'izl-dname-h' );
		h.textContent = nick ? nick.textContent.trim() : '';
		var l = el( 'p', 'izl-dname-l' );
		if ( temple ) {
			l.appendChild( temple.cloneNode( true ) );
		}
		var lt = [ lat ? lat.textContent.trim() : '', en && en.textContent.trim() ? '„' + en.textContent.trim() + '”' : '' ].filter( Boolean ).join( ' ' );
		l.appendChild( document.createTextNode( lt ) );
		name.appendChild( h );
		if ( lt ) {
			name.appendChild( l );
		}
		name.setAttribute( 'aria-hidden', 'true' ); // the page's hidden h1 already names it
		core.appendChild( name );
		core.appendChild( el( 'div', 'izl-dprog' ) ); // free shipping progress (progress())
		var old = panel && panel.querySelector( '.izl-prog' );
		if ( old ) {
			mv( old, core.lastChild );
		}

		// The buy row: price (with the arrival day under it, open drawer only) next to Kosárba vele!.
		var row = sum.querySelector( '.izl-price-row' ), btn = form && form.querySelector( '.single_add_to_cart_button' );
		if ( form ) {
			mv( form, core );
		}
		// 1.7.21: the arrival day under the price is gone (the Szállítás box says it); arr stays off the page.
		var arr = el( 'span', 'izl-arr', '<i aria-hidden="true"></i><span></span>' );
		if ( row && panel ) {
			mv( row, panel, btn || panel.firstChild );
		}
		panel && panel.classList.add( 'izl-drow' );

		// Everything else goes to the open drawer, in this order: Tedd mellé, Szállítás, then the rest of the page.
		var setup = sum.querySelector( '.izl-setup' ), ship = sum.querySelector( '.izl-ship-lines' ), stockLine = sum.querySelector( '.izl-stock' );
		if ( setup ) {
			mv( setup, more );
		}
		var shipSec = el( 'section', 'izl-dship' ), shipH = el( 'p', 'izl-dhead' );
		shipH.textContent = P.ship || '';
		shipSec.appendChild( shipH );
		var route = routeBox( ship );
		if ( route ) {
			shipSec.appendChild( route.box );
		}
		if ( ship ) {
			mv( ship, shipSec );
		}
		if ( stockLine ) {
			mv( stockLine, shipSec );
		}
		// 2.2.0: a sold-out product's "Notify me" form sits in the Szállítás box, right under "Jelenleg nem kapható"
		// (the rest of the page stays off the phone drawer, so it was not reachable there)
		var notifyForm = sum.querySelector( '.izb-signup.is-notify' );
		if ( notifyForm ) {
			mv( notifyForm, shipSec );
		}
		more.appendChild( shipSec );
		kids.forEach( function ( k ) {
			if ( k.parentNode === sum && k !== grab && k !== scroll ) {
				mv( k, more ); // the admin strip, the short description, anything a plugin added
			}
		} );
		// 1.7.20: the drawer ends at Szállítás (the guarantee, questions and related products stay off the phone page).
		var dim = mk( el( 'div', 'izl-dim' ) );
		sum.parentNode.insertBefore( dim, sum );

		/* 2.0.0 scroll drawer: the drawer is the lower part of the page itself. An empty space a screen tall sits above it,
		   so pulling the drawer up is the page scrolling (that native scroll is what tucks Safari's bar away); the header,
		   the crumb strip, the card and the backdrop stay pinned.
		   2.0.1: the drawer keeps its open layout all the time; closed, its parts are slid up under its top edge (the
		   scroll column clips them) and the packs are faded out. The slides and fades are tied to the page scroll by the
		   browser itself (CSS scroll-driven animations, style.css 2.0.1), so they move in step with the drawer; where
		   that is missing, --izl-g (set on the drawer and the dim only, never the whole page) does the same. The browser's
		   own snapping (scroll-snap) lands a flick on open or closed in one motion.
		   2.0.3: no snapping: the drawer stays where it is let go; only a short smooth glide when it rests within a
		   finger's width of open or closed. Everything is sized for the screen with Safari's full bar (100svh), so
		   nothing moves when the bar folds in or out (the drawer, the snap spots and the card were measured again). */
		var open = false, S = 1, walking = false, touched = false;
		var B = 0; // 2.0.3: the closed spot is the page top (it cannot be pulled lower)
		var NEAR = 28; // the glide distance at rest
		// 2.0.5: the closed drawer's top edge sits up to TRIM px lower (less room above Kosárba vele!), the buy row and the
		// card stay where they were in 2.0.3 (2.0.4's LIFT moved the whole drawer under Safari's bar). measure() caps it.
		// The roll-back switch (Customizer) brings back 2.0.3's drawer: no trim (and pinch zoom, zoomLock()).
		var R203 = !! P.r203, TRIM = R203 ? 0 : Math.max( 0, parseFloat( P.trim ) || 0 );
		var vhp = mk( el( 'div', 'izl-vhp' ) ), lvp = mk( el( 'div', 'izl-vhp is-l' ) ); // 100svh and 100lvh, in px
		document.body.appendChild( vhp );
		document.body.appendChild( lvp );
		function scrH() {
			return vhp.offsetHeight || window.innerHeight; // the screen with Safari's full bar
		}
		function scrL() {
			return Math.max( lvp.offsetHeight, window.innerHeight, scrH() ); // with the bar folded
		}
		var SD = !! ( window.CSS && window.CSS.supports && window.CSS.supports( 'animation-timeline', 'scroll()' ) );
		var crumbs = document.querySelector( '.storefront-breadcrumb' );
		var space = mk( el( 'div', 'izl-space' ) );
		space.setAttribute( 'aria-hidden', 'true' );
		sum.parentNode.insertBefore( space, sum );
		var sab = mk( el( 'div', 'izl-sab' ) ); // the home-indicator strip (env(safe-area-inset-bottom))
		document.body.appendChild( sab );
		var foot = mk( el( 'div', 'izl-foot2' ) ); // 2.0.2: a mint strip on the screen bottom: Safari colours its bottom bar from it
		foot.setAttribute( 'aria-hidden', 'true' );
		document.body.appendChild( foot );
		var chipsEl = form && form.querySelector( '.izl-chips' ), prog = core.querySelector( '.izl-dprog' );
		body.classList.add( 'izl-sd' );
		if ( SD ) {
			body.classList.add( 'izl-sdt' );
		}
		function topH() {
			return Math.max( 0, Math.round( Math.max( head.getBoundingClientRect().bottom, crumbs ? crumbs.getBoundingClientRect().bottom : 0 ) ) );
		}
		function setG( g ) {
			sum.style.setProperty( '--izl-g', g );
			dim.style.setProperty( '--izl-g', g );
		}
		function btnG( g ) {
			if ( btn ) {
				btn.style.setProperty( '--g', g ); // Kosárba vele! 44 to 56px tall, 18 to 21px text (style.css)
			}
		}
		// Where the parts sit: open = their place in the layout; closed = the free-shipping line (while it shows in the
		// closed drawer) at the top, the buy row 4px under it. --izl-dt: how far the name and that line slide up when
		// closed, --izl-dr: the packs, the buy row and the rest. Returns the closed drawer's height on screen (its top
		// to the buy row's bottom, --izl-cpad of room and the home-indicator strip), with and without the line.
		var dims = { c: 0, cNo: 0, trim: 0 };
		function measure() {
			// measured without the slides (izl-measure: no transforms, no scroll-driven animations) at the closed size,
			// first in the open layout, then in 2.0.0's closed layout (izl-mclosed), so closed looks exactly as before
			// 2.8.0: measured from the layout itself (offsetTop, which never includes a slide), so the slides are no longer
			// switched off and on (izl-measure). Switching them off restarted the scroll-driven animations, and Safari drew
			// one frame of the closed drawer inside the open one: the buy row and the free-shipping line jumped up over the
			// name and the price when Kosárba was tapped (the line comes, and goes 5 s later, so the drawer is measured again).
			// izl-measure stays as the fallback if a part is not laid out inside the drawer.
			var g0 = sum.style.getPropertyValue( '--izl-g' ), b0 = btn ? btn.style.getPropertyValue( '--g' ) : '';
			setG( '0' );
			btnG( '0' );
			var row = panel || form;
			var lay = function ( n ) {
				var y = 0, m = n;
				while ( m && m !== sum ) {
					y += m.offsetTop;
					m = m.offsetParent;
				}
				return m === sum ? y + sum.clientTop : null;
			};
			var flat = null !== lay( row ) && null !== lay( grab ) && ( ! prog || null !== lay( prog ) );
			var top = 0;
			if ( ! flat ) {
				body.classList.add( 'izl-measure' );
				top = sum.getBoundingClientRect().top; // from the drawer's top edge
			}
			var off = function ( n ) {
				return n ? ( flat ? lay( n ) : n.getBoundingClientRect().top - top ) : 0;
			};
			var pTop = off( prog ), ph = prog ? prog.offsetHeight : 0, rTop = off( row );
			body.classList.add( 'izl-mclosed' );
			var phC = prog ? prog.offsetHeight : 0, pTopC = off( prog ), rTopC = off( row ), rowH = flat ? row.offsetHeight : row.getBoundingClientRect().height;
			var hb = flat ? lay( grab ) + grab.offsetHeight + 1 : 0;
			body.classList.remove( 'izl-mclosed', 'izl-measure' );
			setG( g0 || '0' );
			if ( SD ) {
				btnG( b0 || '0' );
			} else if ( btn ) {
				btn.style.removeProperty( '--g' ); // the fallback: the button follows the drawer's --g
			}
			var keep = phC > 0; // the free-shipping line shows in the closed drawer
			// 2.0.5: the trim: the closed drawer's first line (the free-shipping line or the buy row) stays 6px or more
			// under the handle (its bar ends about 1px under the 10px grab strip)
			var first = keep ? pTopC : rTopC;
			if ( ! flat ) {
				hb = grab.getBoundingClientRect().bottom - top + 1;
			}
			var trim = dims.trim = Math.round( Math.max( 0, Math.min( TRIM, first - hb - 6 ) ) );
			sum.style.setProperty( '--izl-dt', Math.round( pTop - pTopC + ( keep ? 0 : ph ) + trim ) + 'px' );
			sum.style.setProperty( '--izl-dr', Math.round( Math.max( 0, rTop - rTopC ) + trim ) + 'px' );
			var cpad = parseFloat( window.getComputedStyle( sum ).getPropertyValue( '--izl-cpad' ) ) || 10;
			dims.c = Math.round( rTopC + rowH + cpad + sab.offsetHeight );
			dims.cNo = dims.c - Math.round( phC );
		}
		function density() {
			var vh = scrH();
			body.setAttribute( 'data-izl-d', vh <= 650 ? 'xxs' : ( vh <= 690 ? 'xs' : ( vh < 770 ? 's' : 'l' ) ) );
		}
		function fit() {
			if ( dead ) {
				return;
			}
			density();
			var t = topH();
			body.style.setProperty( '--izl-top', t + 'px' );
			measure();
			wrap.style.setProperty( '--fsz-fit-top', t + 'px' );
			wrap.style.setProperty( '--fsz-fit-bottom', dims.cNo + 'px' );
			wrap.style.setProperty( '--fsz-fit-low', dims.c + 'px' ); // the card's screen stays clear of the drawer with its free-shipping line
			wrap.style.setProperty( '--fsz-fit-h', scrH() + 'px' ); // 2.0.3: the card fits the full-bar screen, so it stays put when the bar folds (Codex 1.59.0)
			if ( window.fszFit ) {
				window.fszFit();
			}
			var dev = wrap.querySelector( '.fsz-device' );
			cardTop = dev ? dev.getBoundingClientRect().top : 0; // the card is pinned: its top on screen
			layout( true );
		}
		// The space above the drawer: at the closed spot (scroll B) the buy row ends at the screen bottom; at the open
		// spot (scroll S) the drawer's top is 8px under the top bar, and the drawer reaches the screen bottom.
		function layout( measured ) {
			if ( dead ) {
				return;
			}
			if ( ! measured ) {
				measure();
			}
			var vh = scrH(), t = topH(), wasS = S, y0 = window.scrollY;
			var wasOpen = S > B + 1 && Math.abs( y0 - S ) <= 2;
			var at = space.getBoundingClientRect().top + y0, sh = Math.max( 0, Math.round( vh - dims.c + dims.trim - at + B ) );
			var oldSh = parseFloat( space.style.height ) || 0;
			// closed, at rest: the drawer slides to its new spot (Safari's bar folded in or out) instead of jumping
			space.classList.toggle( 'is-glide', !! oldSh && Math.abs( oldSh - sh ) > 2 && Math.abs( y0 - B ) <= 2 && ! touching && ! still );
			space.style.height = sh + 'px';
			dTop = at + sh; // the drawer's top in the page
			// 2.0.4: the drawer's own length follows Safari's bar in style.css (100dvh), so the page ends at the open spot
			S = Math.max( B + 1, at + sh - t - 8 );
			body.style.setProperty( '--izl-b', B + 'px' );
			body.style.setProperty( '--izl-s', S + 'px' );
			if ( wasOpen && S !== wasS ) {
				window.scrollTo( 0, S ); // open: the drawer stays where it is (no re-snap jump)
			}
			upd();
		}
		// 1.7.21 speed: the card's endless moves (float, Leírás) pause while the drawer covers it and while the page
		// scrolls (Codex .fsz-hush); the walking bug in Szállítás only walks while the drawer is open (2.0.1: not while
		// pulling). Only changes are passed on.
		// 2.0.5: also whenever the drawer covers the whole card (pulled up past the card's top, at rest too).
		var hushScroll = 0, hushWas = null, covered = false, cardTop = 0, dTop = 0;
		function hush() {
			var h = open || covered || !! hushScroll || popOpen, k = h + '|' + walking;
			if ( k === hushWas ) {
				return;
			}
			hushWas = k;
			wrap.classList.toggle( 'fsz-hush', h );
			if ( route ) {
				route.walk( walking );
			}
		}
		var raf = 0, gWas = -1, shutWas = null;
		function upd() {
			raf = 0;
			if ( dead ) {
				return;
			}
			var g = Math.max( 0, Math.min( 1, ( window.scrollY - B ) / ( S - B ) ) ), o = g > 0.97;
			g = Math.round( g * 1000 ) / 1000;
			if ( g !== gWas ) {
				// 2.0.5: the dim is a full-screen layer: not drawn at all while the drawer is closed
				if ( ! g !== ! gWas || gWas < 0 ) {
					dim.style.visibility = g ? '' : 'hidden';
				}
				gWas = g;
				if ( SD ) {
					btnG( String( g ) ); // 2.0.4: Safari skips a height in scroll-driven animations; the button grows from here
				} else {
					setG( String( g ) ); // only the drawer and the dim read it (with scroll-driven animations: nothing per frame)
				}
			}
			// 2.10.0: the drawer fully closed (nothing of it under the breadcrumb strip): the crumbs' tap areas may reach
			// a little below the strip (style.css body.izl-shut).
			if ( ( 0 === g ) !== shutWas ) {
				shutWas = 0 === g;
				body.classList.toggle( 'izl-shut', shutWas );
			}
			var cv = !! cardTop && dTop - window.scrollY <= cardTop;
			if ( cv !== covered ) {
				covered = cv;
				hush();
			}
			if ( o !== open || o !== walking ) {
				open = o;
				walking = o;
				body.classList.toggle( 'izl-open', o );
				grab.setAttribute( 'aria-expanded', o ? 'true' : 'false' );
				grab.setAttribute( 'aria-label', ( o ? P.close : P.open ) || '' );
				hush();
			}
			if ( ! touched && Math.abs( window.scrollY - B ) > 4 ) {
				touched = true; // the first pull: no more cue hops
				stopCue();
			}
		}

		/* moving it from code (the handle, the dim, Escape): a smooth glide to the open or closed spot.
		   2.0.3: no snapping; at rest (no finger, no glide, no mouse drag) a drawer within NEAR px of open or closed
		   glides the rest of the way, smoothly; anywhere else it stays where it was let go. */
		var md = null, tgt = null, anim = 0, goT = 0, setT = 0, touching = false;
		function go( t ) {
			if ( dead ) {
				return;
			}
			window.clearTimeout( goT );
			window.cancelAnimationFrame( glideR );
			glideR = 0;
			anim = Date.now();
			tgt = t;
			window.scrollTo( { top: t, behavior: still ? 'auto' : 'smooth' } );
			goT = window.setTimeout( function () {
				tgt = null;
			}, still ? 50 : 900 );
		}
		function setOpen( v ) {
			go( v ? S : B );
		}
		// the short glide at rest: drawn by hand over 0.35 s (the browser's own smooth scroll does a few px in a blink)
		var glideR = 0;
		function glide( t ) {
			var y0 = window.scrollY, d = t - y0, t0 = 0, dur = still ? 0 : 350;
			window.cancelAnimationFrame( glideR );
			tgt = t;
			var step = function ( now ) {
				if ( ! t0 ) {
					t0 = now;
				}
				var k = dur ? Math.min( 1, ( now - t0 ) / dur ) : 1;
				if ( touching || md || dead ) {
					tgt = null; // a finger took over
					glideR = 0;
					return;
				}
				tgt = t;
				window.scrollTo( 0, y0 + d * ( 1 - Math.pow( 1 - k, 3 ) ) );
				if ( k < 1 ) {
					glideR = window.requestAnimationFrame( step );
				} else {
					tgt = null;
					glideR = 0;
				}
			};
			glideR = window.requestAnimationFrame( step );
		}
		function settle() {
			window.clearTimeout( setT );
			if ( touching || md || null !== tgt || dead ) {
				return;
			}
			var v = window.scrollY;
			// 2.0.6: a mouse wheel (a narrow desktop window) moves the drawer in big steps and left it half open: after
			// a wheel it glides on to the end it was heading for
			if ( wheelDir && Date.now() - wheelT < 600 && v > B + 0.5 && v < S - 0.5 ) {
				glide( wheelDir > 0 ? S : B );
				wheelDir = 0;
				return;
			}
			wheelDir = 0;
			if ( v > B + 0.5 && v - B <= NEAR ) {
				glide( B );
			} else if ( v < S - 0.5 && S - v <= NEAR ) {
				glide( S );
			}
		}
		function settleLater() {
			window.clearTimeout( setT );
			setT = window.setTimeout( settle, 140 );
		}
		var wheelDir = 0, wheelT = 0;
		on( window, 'wheel', function ( e ) {
			if ( e.deltaY && ! e.ctrlKey ) {
				wheelDir = e.deltaY > 0 ? 1 : -1;
				wheelT = Date.now();
			}
		}, { passive: true } );
		on( document, 'touchstart', function () {
			touching = true;
			window.clearTimeout( setT );
		}, { passive: true, capture: true } );
		var tEnd = function ( e ) {
			if ( e.touches && e.touches.length ) {
				return;
			}
			touching = false;
			settleLater(); // a flick keeps scrolling: each scroll waits again
		};
		on( document, 'touchend', tEnd, { passive: true, capture: true } );
		on( document, 'touchcancel', tEnd, { passive: true, capture: true } );
		on( window, 'scroll', function () {
			if ( ! touching ) {
				settleLater();
			}
			if ( ! hushScroll ) {
				hushScroll = window.setTimeout( function () {}, 0 );
				hush();
			}
			window.clearTimeout( hushScroll );
			hushScroll = window.setTimeout( function () {
				hushScroll = 0;
				hush();
			}, 180 );
			if ( ! raf ) {
				raf = window.requestAnimationFrame( upd );
			}
			if ( null !== tgt && ! glideR && Math.abs( window.scrollY - tgt ) < 2 ) {
				tgt = null;
			}
		}, { passive: true } );

		/* Leírás text on the card: it scrolls first; once it is at its end (or has nothing to scroll), the same swipe
		   moves the page, so the drawer comes up (or goes down) without a second swipe. */
		function edge( b, d ) {
			return d < 0 ? b.scrollTop + b.clientHeight >= b.scrollHeight - 1 : b.scrollTop <= 0;
		}
		var td = null;
		on( wrap, 'touchstart', function ( e ) {
			var b = e.target.closest && e.target.closest( '.fsz-more-body' ), t = e.touches[ 0 ];
			td = b && 1 === e.touches.length ? { b: b, x: t.clientX, y: t.clientY, ly: t.clientY, mode: null, py: 0, st: 0 } : null;
		}, { passive: true } );
		on( wrap, 'touchmove', function ( e ) {
			if ( ! td || ! e.touches[ 0 ] ) {
				return;
			}
			var t = e.touches[ 0 ], dy = t.clientY - td.y, step = t.clientY - td.ly;
			td.ly = t.clientY;
			if ( null === td.mode ) {
				if ( Math.abs( dy ) < 6 ) {
					return;
				}
				if ( Math.abs( dy ) < Math.abs( t.clientX - td.x ) ) {
					td = null;
					return;
				}
				td.mode = edge( td.b, dy ) ? 'page' : 'text';
			} else if ( 'text' === td.mode && step && edge( td.b, step ) ) {
				td.mode = 'page';
			}
			if ( 'page' !== td.mode ) {
				return;
			}
			if ( ! td.st ) {
				td.st = window.scrollY + 0.001;
				td.py = t.clientY;
			}
			if ( e.cancelable ) {
				e.preventDefault();
			}
			window.scrollTo( 0, td.st - ( t.clientY - td.py ) );
		}, { passive: false } );
		function tdEnd() {
			td = null; // the drawer stays where it is (the page-wide touchend glides it when near open or closed)
		}
		on( wrap, 'touchend', tdEnd, { passive: true } );
		on( wrap, 'touchcancel', tdEnd, { passive: true } );

		/* a mouse (a narrow desktop window) drags the page the same way: anywhere but buttons, links, the photo and the
		   handle; on the Leírás text as above. The click after a drag is swallowed. */
		var dragged = false;
		on( window, 'pointerdown', function ( e ) {
			if ( 'mouse' !== e.pointerType || 0 !== e.button || popOpen || e.target.closest( 'button,a,input,select,textarea,label,[contenteditable],.izl-grab,.fsz-photo,.izl-pop' ) ) {
				return;
			}
			var b = e.target.closest( '.fsz-more-body' );
			md = { x: e.clientX, y: e.clientY, st: window.scrollY, b: b, mode: b ? null : 'page', ly: e.clientY, on: false };
			dragged = false;
		}, true );
		on( window, 'pointermove', function ( e ) {
			if ( ! md ) {
				return;
			}
			var dy = e.clientY - md.y, step = e.clientY - md.ly;
			md.ly = e.clientY;
			if ( md.b ) {
				if ( null === md.mode ) {
					if ( Math.abs( dy ) < 5 ) {
						return;
					}
					if ( Math.abs( dy ) < Math.abs( e.clientX - md.x ) ) {
						md = null;
						return;
					}
					md.mode = edge( md.b, dy ) ? 'page' : 'text';
					md.y = e.clientY;
				} else if ( 'text' === md.mode && step && edge( md.b, step ) ) {
					md.mode = 'page';
					md.y = e.clientY;
				}
				if ( 'text' === md.mode ) {
					return; // Codex scrolls the text
				}
				e.stopPropagation();
			} else if ( ! md.on && ( Math.abs( dy ) < 5 || Math.abs( dy ) < Math.abs( e.clientX - md.x ) ) ) {
				return;
			}
			if ( ! md.on ) {
				md.on = true;
				md.st = window.scrollY;
				md.y = e.clientY;
				dragged = true;
				body.classList.add( 'izl-mdrag' );
			}
			window.scrollTo( 0, md.st - ( e.clientY - md.y ) );
		}, true );
		function mend() {
			if ( ! md ) {
				return;
			}
			var was = md;
			md = null;
			body.classList.remove( 'izl-mdrag' );
			if ( was.on ) {
				var swallow = function ( ev ) {
					ev.stopPropagation();
					ev.preventDefault();
				};
				on( window, 'click', swallow, true );
				window.setTimeout( function () {
					window.removeEventListener( 'click', swallow, true );
					dragged = false;
				}, 0 );
				settle();
			}
		}
		on( window, 'pointerup', mend, true );
		on( window, 'pointercancel', mend, true );

		/* the handle: a tap (or Enter, Space) opens or closes; the dim and Escape close; so does a tap on the open
		   drawer's name or free-shipping line */
		on( grab, 'click', function () {
			setOpen( window.scrollY < ( B + S ) / 2 );
		} );
		// 2.2.0: other parts of the page can open or close the drawer (the sold-out "Tell me when back!" button)
		on( document, 'izl:drawer', function ( e ) {
			setOpen( !! e.detail );
		} );
		on( dim, 'click', function () {
			setOpen( false );
		} );
		on( document, 'keydown', function ( e ) {
			if ( 'Escape' === e.key && open && ! document.querySelector( '.izl-pop.is-on' ) ) {
				setOpen( false );
			}
		} );
		on( sum, 'click', function ( e ) {
			if ( ! open || popOpen || e.target.closest( 'a,button,input,select,label' ) ) {
				return;
			}
			if ( e.target.closest( '.izl-dname,.izl-dprog' ) ) {
				setOpen( false );
			}
		} );
		on( wrap, 'fsz:fit', function ( e ) {
			var spare = e.detail ? e.detail.spare : 0;
			body.classList.toggle( 'izl-roomy', spare > 150 ); // big phones (412x915, 430x932); 390x844 keeps plain sage // the leaf-litter backdrop shows in spare room only
		} );
		$( document.body ).on( 'izl_progress.izlph', function () {
			fit(); // the free-shipping line can come or go: the closed drawer's height changes
		} );
		$( form ).on( 'found_variation.izlph reset_data.izlph', function () {
			window.setTimeout( function () {
				layout();
			}, 0 );
		} );
		var wait = 0;
		var lastW = window.innerWidth, lastH = scrH();
		// 2.0.3: only a new width or a new full-bar height sets the drawer again; Safari's bar folding in or out changes
		// neither, so nothing moves then.
		function refit() {
			var h = scrH();
			if ( window.innerWidth === lastW && h === lastH ) {
				return;
			}
			lastW = window.innerWidth;
			lastH = h;
			window.cancelAnimationFrame( wait );
			wait = window.requestAnimationFrame( fit );
		}
		on( window, 'resize', refit );
		if ( window.visualViewport ) {
			on( window.visualViewport, 'resize', refit );
		}
		if ( document.fonts && document.fonts.ready ) {
			document.fonts.ready.then( fit );
		}

		/* the cue: once the card's wake-up has played (Leírás pulses, .is-kick), the closed drawer hops softly with a glow
		   on its handle; again every 5 s until the first pull. */
		var cueT = 0, startT = 0;
		function cue() {
			if ( dead || touched || open || popOpen || Math.abs( window.scrollY - B ) > 4 ) {
				return;
			}
			sum.classList.remove( 'is-cue' );
			void sum.offsetWidth;
			sum.classList.add( 'is-cue' );
			window.setTimeout( function () {
				sum.classList.remove( 'is-cue' );
			}, 1650 );
		}
		function startCue() {
			if ( dead || touched || still || cueT ) {
				return;
			}
			cue();
			cueT = window.setInterval( cue, 5000 );
		}
		function stopCue() {
			window.clearInterval( cueT );
			window.clearTimeout( startT );
			sum.classList.remove( 'is-cue' );
		}
		var dev = wrap.querySelector( '.fsz-device' );
		startT = window.setTimeout( startCue, 14000 );
		if ( dev && window.MutationObserver ) {
			var mo = mk.mo = new window.MutationObserver( function ( list ) {
				for ( var i = 0; i < list.length; i++ ) {
					if ( list[ i ].target.classList && list[ i ].target.classList.contains( 'is-kick' ) ) {
						mo.disconnect();
						window.clearTimeout( startT );
						startT = window.setTimeout( startCue, 1800 );
						return;
					}
				}
			} );
			mo.observe( dev, { subtree: true, attributes: true, attributeFilter: [ 'class' ] } );
		}

		/* the arrival day in the open drawer ("Kedden nálad!") follows the shipping box */
		function sync() {
			if ( dead ) {
				return;
			}
			var b = ship && ship.querySelector( '.izl-arrive b' ), t = arr.lastChild;
			var day = b ? b.textContent.split( ',' )[ 0 ].trim() : '';
			t.textContent = day && P.arrive ? P.arrive.replace( '%s', day.charAt( 0 ).toUpperCase() + day.slice( 1 ) ) : '';
			arr.hidden = ! day || !! ( ship && ship.classList.contains( 'is-sold-out' ) );
			if ( route ) {
				route.sync();
			}
		}
		sync();
		if ( ship && window.MutationObserver ) {
			var mo2 = new window.MutationObserver( sync );
			mo2.observe( ship, { subtree: true, childList: true, characterData: true, attributes: true } );
			undo.push( function () {
				mo2.disconnect();
			} );
		}

		photoPop( wrap, function ( v ) {
			popOpen = v;
			body.classList.toggle( 'izl-popon', v );
			hush();
		}, { on: on, mk: mk, undo: function ( f ) {
			undo.push( f );
		} } );
		hush();
		// 2.10.0: the price and Kosárba vele! show together. While the price's font (Plex Mono bold) is still loading the
		// buy row waits (style.css izl-pxwait; iPhones drew the button without the price), at most 1.2 s. A font already
		// loaded answers before the first paint, so nothing waits then.
		if ( document.fonts && document.fonts.load && ! document.fonts.check( '700 20px "Izeltlab Mono"', '0' ) ) {
			var pxGo = function () {
				body.classList.remove( 'izl-pxwait' );
			};
			body.classList.add( 'izl-pxwait' );
			document.fonts.load( '700 20px "Izeltlab Mono"', '0123456789 Ft' ).then( pxGo, pxGo );
			window.setTimeout( pxGo, 1200 );
			undo.push( pxGo );
		}
		body.classList.add( 'izl-phone' );
		fit();
		on( window, 'load', fit );
		window.setTimeout( fit, 600 );
		// 2.5.0: a drawer that was open when the window went wide opens again when it comes back to phone width
		if ( phone.reopen ) {
			phone.reopen = false;
			window.scrollTo( 0, S );
		}

		/* 2.5.0: the way back to the computer layout, in place: listeners off, timers dead, every part back at its old
		   spot (the form with the chosen pack and quantity is the same one, never copied), the new parts gone, the
		   classes and properties this build set taken off. */
		PH = { down: function () {
			phone.reopen = open;
			dead = true;
			window.clearTimeout( goT );
			window.clearTimeout( setT );
			window.clearTimeout( hushScroll );
			window.clearTimeout( startT );
			window.clearInterval( cueT );
			window.cancelAnimationFrame( raf );
			window.cancelAnimationFrame( glideR );
			window.cancelAnimationFrame( wait );
			if ( mk.mo ) {
				mk.mo.disconnect();
			}
			$( document.body ).off( '.izlph' );
			if ( form ) {
				$( form ).off( '.izlph' );
			}
			for ( var i = undo.length - 1; i >= 0; i-- ) {
				undo[ i ]();
			}
			made.forEach( function ( n ) {
				if ( n.parentNode ) {
					n.parentNode.removeChild( n );
				}
			} );
			body.classList.remove( 'izl-shut', 'izl-sd', 'izl-sdt', 'izl-phone', 'izl-open', 'izl-mdrag', 'izl-roomy', 'izl-popon', 'izl-measure', 'izl-mclosed' );
			body.removeAttribute( 'data-izl-d' );
			[ '--izl-top', '--izl-b', '--izl-s' ].forEach( function ( k ) {
				body.style.removeProperty( k );
			} );
			sum.classList.remove( 'izl-drawer', 'is-cue', 'is-drag' );
			[ '--izl-g', '--izl-dt', '--izl-dr' ].forEach( function ( k ) {
				sum.style.removeProperty( k );
			} );
			if ( panel ) {
				panel.classList.remove( 'izl-drow' );
			}
			if ( btn ) {
				btn.style.removeProperty( '--g' );
			}
			wrap.classList.remove( 'fsz-hush' );
			[ '--fsz-fit-top', '--fsz-fit-bottom', '--fsz-fit-low', '--fsz-fit-h', '--fsz-fit-y', '--fsz-fit-w' ].forEach( function ( k ) {
				wrap.style.removeProperty( k ); // (the last two: set by Codex's phone fit)
			} );
			wrap.removeAttribute( 'data-fsz-spare' );
			if ( restore0 ) {
				window.history.scrollRestoration = restore0;
			}
			window.scrollTo( 0, 0 );
		} };
	}

	/* the Szállítás box: ÚTRA KELNEK (the day it leaves, yellow van) and NÁLAD LESZNEK (the day it arrives, green house),
	   a little isopod walking the dotted road between them. The words come from the shipping lines (live from the clock). */

	// ==========================================================================
	//  The Szállítás box
	// ==========================================================================

	function routeBox( ship ) {
		if ( ! ship ) {
			return null;
		}
		var leaves = ship.querySelector( '.izl-leaves' ), arrive = ship.querySelector( '.izl-arrive' );
		if ( ! leaves || ! arrive ) {
			return null;
		}
		var box = document.createElement( 'div' );
		box.className = 'izl-route';
		box.innerHTML = '<div class="izl-route-h"><span></span><span></span></div><div class="izl-route-b">' +
			'<span class="izl-route-v is-out"><span class="izl-route-ic" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M3 7h11v9H3zM14 10h4l3 3v3h-7z"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/></svg></span><span class="izl-route-t"></span></span>' +
			'<svg class="izl-route-road" viewBox="0 -2 100 46" aria-hidden="true"><path id="izl-road" d="M4 33 C20 33 34 31 46 24 C60 15 55 4 44 9 C34 14 46 33 66 31 C80 29 90 24 98 20"/>' +
			'<g class="izl-route-bug"><animateMotion dur="8s" repeatCount="indefinite" rotate="auto"><mpath href="#izl-road"/></animateMotion><ellipse rx="10" ry="6" fill="#17322e"/><path d="M-3.3 -5.9q-2.2 5.9 0 11.8M1.1 -6q-2.2 6 0 12M5.5 -5.2q-1.8 5.2 0 10.4" stroke="#9cc5b8" stroke-width="1.2" fill="none"/><path d="M10 -2q5.4 -3.2 8.6 -5.4M10 2q5.4 3.2 8.6 5.4" stroke="#17322e" stroke-width="1.2" fill="none" stroke-linecap="round"/><path d="M-5.4 -5.7l-1.6 -2.7M0 -6v-3.2M5.4 -5.1l1.6 -2.7M-5.4 5.7l-1.6 2.7M0 6v3.2M5.4 5.1l1.6 2.7" stroke="#17322e" stroke-width="1.2" stroke-linecap="round"/></g></svg>' +
			'<span class="izl-route-v is-in"><span class="izl-route-t"></span><span class="izl-route-ic" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M3 11l9-7 9 7M5 10v10h14V10M10 20v-6h4v6"/></svg></span></span></div>';
		if ( window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
			var m = box.querySelector( 'animateMotion' );
			m.parentNode.removeChild( m );
			box.querySelector( '.izl-route-bug' ).setAttribute( 'transform', 'translate(46 24) rotate(-30)' );
		}
		var hs = box.querySelectorAll( '.izl-route-h span' ), ts = box.querySelectorAll( '.izl-route-t' );
		function text( p, sel ) {
			var n = p.querySelector( sel );
			return n ? n.textContent.trim() : '';
		}
		// 1.7.21: the bug walks only while someone can see it (an SVG animation lays the page out on every frame).
		var svg = box.querySelector( '.izl-route-road' );
		function walk( on ) {
			if ( svg && svg.pauseAnimations ) {
				on ? svg.unpauseAnimations() : svg.pauseAnimations();
			}
		}
		function sync() {
			hs[ 0 ].textContent = text( leaves, 'span' );
			hs[ 1 ].textContent = text( arrive, 'span' );
			ts[ 0 ].textContent = text( leaves, 'b' );
			ts[ 1 ].textContent = text( arrive, 'b' );
			box.hidden = leaves.hidden || arrive.hidden;
		}
		sync();
		return { box: box, sync: sync, walk: walk };
	}

	/* 2.2.0: a sold-out product (Dan, 2026-11-05): the greyed-out "Kosárba vele!" becomes "Szólj, ha újra lesz!", which
	   brings the "Notify me" form into view (on a phone it opens the drawer, the form is in its Szállítás box) and puts
	   the cursor in the email field. The form itself comes from the Ízeltláb Bolt plugin (#izb-notify). */

	// ==========================================================================
	//  Sold out: "Szólj, ha újra lesz!"
	// ==========================================================================

	function notifyBtn() {
		var nf = document.getElementById( 'izb-notify' ), btn = document.querySelector( '.summary .single_add_to_cart_button' );
		if ( ! nf || ! btn || ! cfg.notify ) {
			return;
		}
		var still = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
		btn.classList.add( 'izl-notify-btn' );
		btn.textContent = cfg.notify;
		// WooCommerce greys the button out again on every pack choice ("unavailable"): this one stays pressable
		var unGrey = function () {
			btn.removeAttribute( 'disabled' );
			if ( btn.classList.contains( 'disabled' ) || btn.classList.contains( 'wc-variation-is-unavailable' ) ) {
				btn.classList.remove( 'disabled', 'wc-variation-is-unavailable' );
			}
		};
		unGrey();
		if ( window.MutationObserver ) {
			new window.MutationObserver( unGrey ).observe( btn, { attributes: true, attributeFilter: [ 'class', 'disabled' ] } );
		}
		document.addEventListener( 'click', function ( e ) {
			if ( ! e.target.closest || ! e.target.closest( '.izl-notify-btn' ) ) {
				return;
			}
			e.preventDefault();
			e.stopImmediatePropagation(); // not WooCommerce's "this product is unavailable" alert, not the add to cart
			var phoneNow = document.body.classList.contains( 'izl-phone' );
			if ( phoneNow ) {
				document.dispatchEvent( new window.CustomEvent( 'izl:drawer', { detail: true } ) );
			} else {
				nf.scrollIntoView( { block: 'center', behavior: still ? 'auto' : 'smooth' } );
			}
			nf.classList.remove( 'is-hi' );
			void nf.offsetWidth;
			nf.classList.add( 'is-hi' );
			window.setTimeout( function () {
				var input = nf.querySelector( 'input[type=email]' );
				if ( input ) {
					input.focus( { preventScroll: true } );
				}
			}, phoneNow ? 900 : 450 );
		}, true );
	}

	/* photo pop-out: a tap on the card photo lifts it out over a dimmed page; pinch or the mouse wheel zooms (a drag
	   pans when zoomed), a swipe changes the photo (the card shows the same one after), a tap sends it back. */

	// ==========================================================================
	//  Photo pop-out
	// ==========================================================================

	function photoPop( wrap, onState, hook ) {
		var ph = wrap.querySelector( '.fsz-photo' );
		if ( ! ph || ! ph.querySelector( '.fsz-slides img' ) ) {
			return;
		}
		// 2.5.0: hook = phone()'s undo helpers (listen, new part, undo step), so the live switch takes the pop-out away
		var listen = hook.on, label0 = ph.getAttribute( 'aria-label' );
		var still = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches, P = cfg.phone || {};
		var pop = document.createElement( 'div' );
		pop.className = 'izl-pop';
		pop.setAttribute( 'aria-hidden', 'true' );
		pop.innerHTML = '<div class="izl-pop-bg"></div>';
		document.body.appendChild( hook.mk( pop ) );
		var on = false, last = null;
		function imgs() {
			return Array.prototype.slice.call( ph.querySelectorAll( '.fsz-slides > img' ) );
		}
		function current() {
			var list = imgs(), best = list[ 0 ], o = -1;
			list.forEach( function ( i ) {
				var v = parseFloat( window.getComputedStyle( i ).opacity );
				if ( v > o ) {
					o = v;
					best = i;
				}
			} );
			return { img: best, idx: list.indexOf( best ), n: list.length };
		}
		// Where the photo sits on the card now: its centre on screen, at its own untilted size.
		function target() {
			var r = ph.getBoundingClientRect();
			return { cx: r.left + r.width / 2, cy: r.top + r.height / 2, w: ph.offsetWidth, h: ph.offsetHeight };
		}
		function srcOf( i ) {
			return i.currentSrc || i.src;
		}
		// The popped photo starts from the card's exact crop: Codex's per-photo frame (position + zoom from the admin).
		function baseOf( im, src ) {
			var cs = window.getComputedStyle( src ), fx = cs.getPropertyValue( '--fsz-fx' ).trim() || '50%', fy = cs.getPropertyValue( '--fsz-fy' ).trim() || '50%', fz = cs.getPropertyValue( '--fsz-fz' ).trim() || '1';
			im.style.objectPosition = fx + ' ' + fy;
			im.style.transformOrigin = fx + ' ' + fy;
			im.style.transform = 'scale(' + fz + ')';
		}
		function openPop() {
			if ( on ) {
				return;
			}
			on = true;
			onState( true );
			last = document.activeElement;
			var c = current(), W = window.innerWidth, Hh = window.innerHeight;
			var w = W - 20, h = w * ( ph.offsetHeight / ph.offsetWidth || 0.75 ), x = 10, y = ( Hh - h ) / 2 - 20; // same shape as the card photo
			var fr = document.createElement( 'div' );
			fr.className = 'izl-pop-fr';
			fr.setAttribute( 'role', 'button' );
			fr.setAttribute( 'tabindex', '0' );
			fr.setAttribute( 'aria-label', P.closePic || '' );
			fr.innerHTML = '<div class="izl-pop-zw"><img alt="" draggable="false"></div>';
			var zw = fr.firstChild, im = zw.firstChild;
			im.src = srcOf( c.img );
			baseOf( im, c.img );
			fr.style.left = x + 'px';
			fr.style.top = y + 'px';
			fr.style.width = w + 'px';
			fr.style.height = h + 'px';
			var dots = document.createElement( 'div' );
			dots.className = 'izl-pop-dots';
			dots.style.top = ( y + h + 16 ) + 'px';
			for ( var i = 0; i < c.n; i++ ) {
				dots.appendChild( document.createElement( 'i' ) ).className = i === c.idx ? 'is-on' : '';
			}
			pop.appendChild( fr );
			pop.appendChild( dots );
			pop.setAttribute( 'aria-hidden', 'false' );
			var T = target();
			if ( ! still ) {
				fr.animate( [
					{ transform: 'translate(' + ( T.cx - ( x + w / 2 ) ) + 'px,' + ( T.cy - ( y + h / 2 ) ) + 'px) scale(' + ( T.w / w ) + ',' + ( T.h / h ) + ')', borderWidth: '0px', borderRadius: '6px', boxShadow: '0 0 0 rgba(0,0,0,0)' },
					{ transform: 'none', borderWidth: '6px', borderRadius: '14px', boxShadow: '0 30px 60px rgba(0,0,0,.45)' }
				], { duration: 640, easing: 'cubic-bezier(.18,1.12,.3,1)', fill: 'forwards' } );
			} else {
				fr.style.borderWidth = '6px';
				fr.style.borderRadius = '14px';
			}
			ph.querySelector( '.fsz-slides' ).style.visibility = 'hidden';
			fr.fszIdx = c.idx;
			fr.fszN = c.n;
			window.requestAnimationFrame( function () {
				pop.classList.add( 'is-on' );
			} );
			zoom( fr, im, zw, dots );
			fr.focus( { preventScroll: true } );
		}
		function closePop() {
			var fr = pop.querySelector( '.izl-pop-fr' );
			if ( ! on || ! fr ) {
				return;
			}
			var w = parseFloat( fr.style.width ), h = parseFloat( fr.style.height ), x = parseFloat( fr.style.left ), y = parseFloat( fr.style.top );
			fr.firstChild.style.transition = 'transform .2s';
			fr.firstChild.style.transform = 'none';
			pop.classList.remove( 'is-on' );
			fr.getAnimations && fr.getAnimations().forEach( function ( an ) {
				an.cancel();
			} );
			var D = still ? 1 : 480, t0 = window.performance.now();
			var ease = function ( k ) {
				return k < 0.5 ? 4 * k * k * k : 1 - Math.pow( -2 * k + 2, 3 ) / 2;
			};
			( function step( now ) {
				var k = Math.min( 1, ( now - t0 ) / D ), e = ease( k ), T = target(); // read again each frame: it lands where the floating card is
				var sx = 1 + ( T.w / w - 1 ) * e, sy = 1 + ( T.h / h - 1 ) * e, cx = ( x + w / 2 ) + ( T.cx - ( x + w / 2 ) ) * e, cy = ( y + h / 2 ) + ( T.cy - ( y + h / 2 ) ) * e;
				fr.style.transform = 'translate(' + ( cx - ( x + w / 2 ) ) + 'px,' + ( cy - ( y + h / 2 ) ) + 'px) scale(' + sx + ',' + sy + ')';
				fr.style.borderWidth = ( 6 * ( 1 - e ) ) + 'px';
				fr.style.borderRadius = ( 14 - 8 * e ) + 'px';
				fr.style.boxShadow = '0 ' + ( 30 * ( 1 - e ) ) + 'px ' + ( 60 * ( 1 - e ) ) + 'px rgba(0,0,0,' + ( 0.45 * ( 1 - e ) ) + ')';
				if ( k < 1 ) {
					window.requestAnimationFrame( step );
					return;
				}
				ph.querySelector( '.fsz-slides' ).style.visibility = '';
				var done = function () {
					Array.prototype.forEach.call( pop.querySelectorAll( '.izl-pop-fr,.izl-pop-dots' ), function ( n ) {
						n.remove();
					} );
					pop.setAttribute( 'aria-hidden', 'true' );
					on = false;
					onState( false );
					if ( last && last.focus ) {
						last.focus( { preventScroll: true } );
					}
				};
				if ( fr.animate && ! still ) {
					fr.animate( [ { opacity: 1 }, { opacity: 0 } ], { duration: 90 } ).onfinish = done;
				} else {
					done();
				}
			} )( t0 );
		}
		function zoom( fr, im, zw, dots ) {
			var s = 1, tx = 0, ty = 0, pts = {}, n = 0, start = null, moved = false, base = null;
			var apply = function () {
				zw.style.transform = 'translate(' + tx + 'px,' + ty + 'px) scale(' + s + ')'; // the wrapper; the photo keeps its card crop
			};
			var clamp = function () {
				var w = fr.clientWidth, h = fr.clientHeight;
				s = Math.max( 1, Math.min( 5, s ) );
				tx = Math.min( 0, Math.max( w - w * s, tx ) );
				ty = Math.min( 0, Math.max( h - h * s, ty ) );
			};
			function zoomAt( ns, cx, cy ) {
				var r = fr.getBoundingClientRect(), px = cx - r.left, py = cy - r.top;
				tx = px - ( px - tx ) * ns / s;
				ty = py - ( py - ty ) * ns / s;
				s = ns;
				clamp();
				apply();
			}
			var two = function () {
				var k = Object.keys( pts );
				return [ pts[ k[ 0 ] ], pts[ k[ 1 ] ] ];
			};
			fr.addEventListener( 'pointerdown', function ( e ) {
				fr.setPointerCapture( e.pointerId );
				pts[ e.pointerId ] = { x: e.clientX, y: e.clientY };
				n = Object.keys( pts ).length;
				if ( 1 === n ) {
					start = { x: e.clientX, y: e.clientY };
					moved = false;
				}
				if ( 2 === n ) {
					var ab = two();
					base = { d: Math.hypot( ab[ 0 ].x - ab[ 1 ].x, ab[ 0 ].y - ab[ 1 ].y ), s: s, mx: ( ab[ 0 ].x + ab[ 1 ].x ) / 2, my: ( ab[ 0 ].y + ab[ 1 ].y ) / 2 };
				}
			} );
			fr.addEventListener( 'pointermove', function ( e ) {
				if ( ! pts[ e.pointerId ] ) {
					return;
				}
				var prev = pts[ e.pointerId ];
				pts[ e.pointerId ] = { x: e.clientX, y: e.clientY };
				if ( start && Math.hypot( e.clientX - start.x, e.clientY - start.y ) > 8 ) {
					moved = true;
				}
				if ( 2 === n && base ) {
					var ab = two(), d = Math.hypot( ab[ 0 ].x - ab[ 1 ].x, ab[ 0 ].y - ab[ 1 ].y ), mx = ( ab[ 0 ].x + ab[ 1 ].x ) / 2, my = ( ab[ 0 ].y + ab[ 1 ].y ) / 2;
					tx += mx - base.mx; // both fingers moving together drag the photo while pinching
					ty += my - base.my;
					base.mx = mx;
					base.my = my;
					zoomAt( base.s * d / base.d, mx, my );
				} else if ( 1 === n && s > 1 ) {
					tx += e.clientX - prev.x;
					ty += e.clientY - prev.y;
					clamp();
					apply();
				}
			} );
			function swipe( dir ) {
				var list = imgs(), N = list.length;
				if ( N < 2 ) {
					return;
				}
				fr.fszIdx = ( fr.fszIdx + dir + N ) % N;
				var src = list[ fr.fszIdx ];
				im.src = srcOf( src );
				baseOf( im, src );
				s = 1;
				tx = 0;
				ty = 0;
				apply();
				if ( zw.animate && ! still ) {
					zw.animate( [ { opacity: 0.15, transform: 'translateX(' + ( dir * 34 ) + 'px)' }, { opacity: 1, transform: 'none' } ], { duration: 280, easing: 'cubic-bezier(.2,.8,.3,1)' } );
				}
				Array.prototype.forEach.call( dots.children, function ( d, i ) {
					d.className = i === fr.fszIdx ? 'is-on' : '';
				} );
				// The card turns to the same photo (Codex's own swipe), so it is there after closing.
				var mk = function ( t, x ) {
					return new window.PointerEvent( t, { clientX: x, clientY: 100, pointerId: 99, pointerType: 'touch', bubbles: true } );
				};
				ph.dispatchEvent( mk( 'pointerdown', 200 ) );
				ph.dispatchEvent( mk( 'pointerup', 200 - dir * 100 ) );
			}
			fr.fszSwipe = swipe;
			fr.addEventListener( 'pointerup', function ( e ) {
				delete pts[ e.pointerId ];
				n = Object.keys( pts ).length;
				if ( n < 2 ) {
					base = null;
				}
				if ( 0 === n ) {
					var dx = start ? e.clientX - start.x : 0, dy = start ? e.clientY - start.y : 0;
					if ( start && 1 === s && Math.abs( dx ) > 40 && Math.abs( dx ) > Math.abs( dy ) * 1.2 ) {
						swipe( dx < 0 ? 1 : -1 );
					} else if ( ! moved ) {
						closePop();
					}
					start = null;
				}
			} );
			fr.addEventListener( 'pointercancel', function ( e ) {
				delete pts[ e.pointerId ];
				n = Object.keys( pts ).length;
				moved = true;
			} );
			fr.addEventListener( 'wheel', function ( e ) {
				e.preventDefault();
				zoomAt( s * Math.exp( -e.deltaY * 0.002 ), e.clientX, e.clientY );
			}, { passive: false } );
			fr.addEventListener( 'keydown', function ( e ) {
				if ( 'Enter' === e.key || ' ' === e.key ) {
					e.preventDefault();
					closePop();
				}
			} );
		}
		pop.querySelector( '.izl-pop-bg' ).addEventListener( 'click', closePop );
		listen( document, 'keydown', function ( e ) {
			if ( ! on ) {
				return;
			}
			if ( 'Escape' === e.key ) {
				closePop();
			}
			var fr = pop.querySelector( '.izl-pop-fr' );
			if ( fr && fr.fszSwipe && ( 'ArrowLeft' === e.key || 'ArrowRight' === e.key ) ) {
				fr.fszSwipe( 'ArrowRight' === e.key ? 1 : -1 );
			}
		} );
		// A tap on the photo pops it out (before Codex's own "next photo" click); a swipe still changes the photo.
		var pd = null;
		listen( ph, 'pointerdown', function ( e ) {
			pd = e.target.closest( '.fsz-badge' ) || 99 === e.pointerId ? null : { x: e.clientX, y: e.clientY };
		}, true );
		listen( ph, 'click', function ( e ) {
			if ( e.target.closest( '.fsz-badge' ) ) {
				return;
			}
			e.stopImmediatePropagation();
			e.preventDefault();
			if ( ! pd || Math.hypot( e.clientX - pd.x, e.clientY - pd.y ) < 10 ) {
				openPop(); // a tap (or the keyboard: Enter on the photo)
			}
			pd = null;
		}, true );
		listen( ph, 'keydown', function ( e ) {
			if ( 'Enter' === e.key || ' ' === e.key ) {
				e.preventDefault();
				e.stopImmediatePropagation();
				openPop();
			}
		}, true );
		ph.setAttribute( 'aria-label', P.photo || ph.getAttribute( 'aria-label' ) || '' );
		// the undo: the card's photo back as it was (also when it is popped out right now), the old label
		hook.undo( function () {
			var sl = ph.querySelector( '.fsz-slides' );
			if ( sl ) {
				sl.style.visibility = '';
			}
			if ( null === label0 ) {
				ph.removeAttribute( 'aria-label' );
			} else {
				ph.setAttribute( 'aria-label', label0 );
			}
			on = false;
		} );
	}

	// ==========================================================================
	//  START: everything above is switched on here
	// ==========================================================================

	// After WooCommerce has set up the pack form (its own ready handler), so a chosen pack finds its price.
	$( function () {
		window.setTimeout( function () {
			document.querySelectorAll( '.summary form.cart' ).forEach( function ( form ) {
				// The buy panel is a ticket: price (left) and the stock stamp (right), shipping and arrival on dotted lines,
				// a torn line, then quantity and the cart button. With packs, it comes after the pack buttons.
				var row = document.querySelector( '.summary .izl-price-row' ), line = document.querySelector( '.summary .izl-stock' );
				var panel = form.classList.contains( 'variations_form' ) ? form.querySelector( '.woocommerce-variation-add-to-cart' ) : form;
				// 2.0.7: the server prints the ticket head in place (functions.php izl_buy_head()); built here only where it did not
				if ( panel && ! panel.querySelector( '.izl-buy-head' ) && ( row || line ) ) {
					var head = document.createElement( 'div' );
					head.className = 'izl-buy-head';
					if ( row ) {
						head.appendChild( row );
					}
					if ( line ) {
						head.appendChild( line );
					}
					var ship = document.querySelector( '.summary .izl-ship-lines' );
					if ( ship ) {
						head.appendChild( ship );
					}
					panel.insertBefore( head, panel.firstChild );
				}
				if ( panel && panel.querySelector( '.izl-buy-head' ) ) {
					form.classList.add( 'has-price' ); // (style.css 2.0.7 keys on the head itself: form:has(.izl-buy-head))
				}
				if ( form.classList.contains( 'variations_form' ) ) {
					prices( form );
					stock( form );
					form.querySelectorAll( 'table.variations select' ).forEach( chips );
				}
				form.querySelectorAll( '.quantity' ).forEach( stepper );
				quickAdd( form );
			} );
			bigPrice();
			shipping();
			window.setInterval( shipping, 60000 ); // the nudge and the days change with the clock while the page is open
			stamp();
			setupFly();
			zoomLock();
			phoneSwitch(); // 2.5.0: once; it builds or takes down the phone drawer when the width crosses 768px
			phone();
			notifyBtn();
			litter();
			// 3.0.0: the editing tools live in assets/product-edit.js, which only editors get
			if ( cfg.edit && window.izlProductEdit ) {
				window.izlProductEdit();
			}
		}, 0 );
	} );
}( jQuery ) );
