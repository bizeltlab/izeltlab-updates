/* ========================================================================== */
/*
    FILE: assets/groups-edit.js   (Ízeltláb theme)
    WHAT: ADMIN ONLY. The Groups dialog (3.21.0): the header's buttons (3.22.0: groups and single genera, each with its
          own text, address and PC / phone place, in one order shown as the header itself; a genus can show in another
          group too), and the form to add, rename, recolour, move or delete a group or subgroup (genus).
          Server side: inc/edit-groups.php. Look: assets/groups-edit.css.
    SEEN: Only by logged-in shop managers, from the "✎ Groups" / "+ New group" / "✎ Edit this group" buttons.
    SECTIONS IN THIS FILE:
      1. Data and helpers
      2. The list: the header's buttons, the groups and their genera
      3. The form: one group
      4. Opening the dialog
*/
/* ========================================================================== */
( function () {
	'use strict';

	// ==========================================================================
	//  1. Data and helpers
	// ==========================================================================

	var json = document.getElementById( 'izl-groups-data' );
	if ( ! json ) {
		return;
	}
	var d = JSON.parse( json.textContent ), dlg = null, moved = false;
	var byId = {};
	d.terms.forEach( function ( t ) {
		byId[ t.id ] = t;
	} );

	function esc( s ) {
		return String( null == s ? '' : s ).replace( /[&<>"']/g, function ( c ) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ c ];
		} );
	}
	function kidsOf( id ) {
		return d.terms.filter( function ( t ) {
			return t.parent === id;
		} );
	}
	// a group and everything under it (a group cannot go under these)
	function treeOf( id ) {
		var out = [ id ];
		kidsOf( id ).forEach( function ( k ) {
			out = out.concat( treeOf( k.id ) );
		} );
		return out;
	}
	function send( data ) {
		var body = new window.FormData();
		data._ajax_nonce = d.nonce;
		Object.keys( data ).forEach( function ( k ) {
			if ( Array.isArray( data[ k ] ) ) {
				data[ k ].forEach( function ( v ) {
					body.append( k + '[]', v );
				} );
			} else {
				body.append( k, data[ k ] );
			}
		} );
		return window.fetch( d.ajax, { method: 'POST', body: body, credentials: 'same-origin' } ).then( function ( r ) {
			return r.text();
		} ).then( function ( text ) {
			var at = text.indexOf( '{"success"' ), j = null;
			try {
				j = at > -1 ? JSON.parse( text.slice( at ) ) : null; // anything a plugin printed before the answer is skipped
			} catch ( e ) {
				j = null;
			}
			if ( j && j.success ) {
				return j.data || {};
			}
			throw new Error( j && j.data ? String( j.data ) : 'Could not save. Are you still logged in?' );
		} );
	}
	function error( where, msg ) {
		var p = where.querySelector( '.izl-gd-err' );
		if ( ! p ) {
			p = document.createElement( 'p' );
			p.className = 'izl-gd-err';
			p.setAttribute( 'role', 'alert' );
			where.insertBefore( p, where.firstChild );
		}
		p.textContent = msg;
	}
	function shell( title, body, actions ) {
		if ( ! dlg ) {
			dlg = document.createElement( 'dialog' );
			dlg.className = 'izl-gd';
			document.body.appendChild( dlg );
			dlg.addEventListener( 'click', function ( e ) {
				if ( e.target === dlg ) {
					dlg.close(); // a click on the dim backdrop
				}
			} );
		}
		dlg.innerHTML = '<form class="izl-gd-form" method="dialog"><h2>' + title + '</h2><div class="izl-gd-body">' + body + '</div><div class="izl-gd-actions">' + actions + '</div></form>';
		if ( ! dlg.open ) {
			dlg.showModal();
		}
		return dlg.querySelector( 'form' );
	}

	// ==========================================================================
	//  2. The list: the header's buttons, the groups and their genera
	// ==========================================================================

	/* 3.22.0 (Dan, 2026-11-25): the list is about the header's buttons. On top, the buttons exactly as shoppers will see
	   them, in their order (drag a chip, or its ‹ ›). Under it every group as a card with its genera: a switch per row
	   gives it a button (a single genus can have one, the group name can be switched off), ⚙ its own text, address and
	   place (PC and phone, PC only, phone only), "Also in…" shows a genus in another group too while it stays in its
	   own, ✎ edits the group or genus itself (name, where it sits = a real move, colour, intro). New groups and genera
	   are made here too. One Save for all of it. */

	var btns = ( d.buttons || [] ).map( function ( b ) {
		return Object.assign( {}, b );
	} );
	var also = {};
	Object.keys( d.also || {} ).forEach( function ( k ) {
		also[ k ] = ( d.also[ k ] || [] ).slice();
	} );
	var open = {}; // which rows have their ⚙ settings open
	// 3.23.0 (Dan, 2026-11-25): the phone menu has its own order (the Phone tab on top); empty = the header's order
	var porder = ( d.porder || [] ).slice(), view = 'pc';

	function btnOf( key ) {
		return btns.filter( function ( b ) {
			return b.key === key;
		} )[ 0 ];
	}
	function groupsOnly() {
		return btns.filter( function ( b ) {
			return 'group' === b.type;
		} );
	}
	function generaOf( key ) {
		return btns.filter( function ( b ) {
			return 'genus' === b.type && b.group === key;
		} );
	}
	function textOf( b ) {
		return '' !== String( b.label || '' ).trim() ? b.label : b.name;
	}
	// The top groups behind one header button (all isopod groups share the "Isopods" button).
	function topsOf( key ) {
		return d.terms.filter( function ( t ) {
			return ! t.parent && t.key === key;
		} );
	}
	function treeHtml( id, depth ) {
		return kidsOf( id ).map( function ( k ) {
			return '<li class="izl-gd-sub" style="--izl-gd-depth:' + depth + '"><span>' + esc( k.name ) + ' <small>' + k.count + ' pcs</small></span>' +
				'<button type="button" class="izl-gd-mini" data-edit="' + k.id + '" aria-label="Edit ' + esc( k.name ) + '">✎</button></li>' + treeHtml( k.id, depth + 1 );
		} ).join( '' );
	}
	function dirty( form ) {
		moved = true;
		var save = form.querySelector( '.izl-gd-save' ), note = form.querySelector( '.izl-gd-note' );
		save.disabled = false;
		note.textContent = 'Unsaved changes';
		note.classList.add( 'is-dirty' );
	}

	// The header as shoppers will see it: the switched-on buttons in their order.
	function previewHtml() {
		var on = btns.filter( function ( b ) {
			return b.shown;
		} );
		if ( ! on.length ) {
			return '<p class="izl-gd-pv-none">No buttons yet: switch on a group or a genus below.</p>';
		}
		return on.map( function ( b, i ) {
			var where = 'pc' === b.where ? ' <i>PC</i>' : ( 'phone' === b.where ? ' <i>phone</i>' : '' );
			return '<span class="izl-gd-chip' + ( b.empty ? ' is-empty' : '' ) + ( 'genus' === b.type ? ' is-genus' : '' ) + '" draggable="true" data-key="' + esc( b.key ) + '"' + ( b.empty ? ' title="No products yet: shoppers see it once it has one"' : '' ) + '>' +
				'<button type="button" class="izl-gd-nudge" data-left="' + esc( b.key ) + '" aria-label="Move ' + esc( textOf( b ) ) + ' left"' + ( i ? '' : ' disabled' ) + '>‹</button>' +
				'<b>' + esc( textOf( b ) ) + '</b>' + where +
				'<button type="button" class="izl-gd-nudge" data-right="' + esc( b.key ) + '" aria-label="Move ' + esc( textOf( b ) ) + ' right"' + ( i < on.length - 1 ? '' : ' disabled' ) + '>›</button></span>';
		} ).join( '' );
	}

	// One row's ⚙ settings: its own button text, address and place.
	function optsHtml( b ) {
		return '<div class="izl-gd-opts"' + ( open[ b.key ] ? '' : ' hidden' ) + '>' +
			'<label class="izl-gd-field"><span>Button text</span><input type="text" maxlength="60" data-set="label" data-key="' + esc( b.key ) + '" value="' + esc( b.label ) + '" placeholder="' + esc( b.name ) + '"><small>Empty = the usual one.</small></label>' +
			'<label class="izl-gd-field"><span>Opens</span><input type="text" data-set="link" data-key="' + esc( b.key ) + '" value="' + esc( b.link ) + '" placeholder="its own page"><small>Empty = its own page. Or any address, e.g. /termek/boci/</small></label>' +
			'<label class="izl-gd-field"><span>Shown on</span><select data-set="where" data-key="' + esc( b.key ) + '">' +
			'<option value=""' + ( b.where ? '' : ' selected' ) + '>PC and phone</option>' +
			'<option value="pc"' + ( 'pc' === b.where ? ' selected' : '' ) + '>PC only</option>' +
			'<option value="phone"' + ( 'phone' === b.where ? ' selected' : '' ) + '>Phone only (☰ menu)</option></select></label></div>';
	}

	function switchHtml( b ) {
		return '<label class="izl-gd-sw" title="A button for it in the header (PC bar and phone menu)"><input type="checkbox" data-tick="' + esc( b.key ) + '"' + ( b.shown ? ' checked' : '' ) + '><span class="izl-gd-sw-ui" aria-hidden="true"></span><span class="screen-reader-text">Button for ' + esc( textOf( b ) ) + '</span></label>';
	}

	function genusRow( g ) {
		var others = groupsOnly().filter( function ( x ) {
			return x.key !== g.group && ( also[ x.key ] || [] ).indexOf( g.term ) < 0;
		} );
		var sel = others.length ? '<select class="izl-gd-also" data-also="' + g.term + '" aria-label="Also show ' + esc( g.name ) + ' in another group"><option value="">Also in…</option>' +
			others.map( function ( x ) {
				return '<option value="' + esc( x.key ) + '">' + esc( textOf( x ) ) + '</option>';
			} ).join( '' ) + '</select>' : '';
		return '<li class="izl-gd-row is-genus' + ( g.shown ? '' : ' is-off' ) + '">' +
			'<div class="izl-gd-line">' + switchHtml( g ) +
			'<span class="izl-gd-name">' + esc( textOf( g ) ) + ( textOf( g ) !== g.name ? ' <small>(' + esc( g.name ) + ')</small>' : '' ) + ' <small>' + g.count + ' pcs</small>' +
			( g.empty ? ' <em class="izl-gd-tag">no products yet</em>' : '' ) + '</span>' +
			sel +
			'<button type="button" class="izl-gd-mini" data-opts="' + esc( g.key ) + '" aria-expanded="' + ( open[ g.key ] ? 'true' : 'false' ) + '" title="Button text, address, PC / phone">⚙</button>' +
			'<button type="button" class="izl-gd-mini" data-edit="' + g.term + '" title="Edit: name, move to another group, intro text">✎</button></div>' +
			optsHtml( g ) + '</li>';
	}

	function groupCard( gb ) {
		var gens = generaOf( gb.key ), tops = topsOf( gb.key ), top = tops[ 0 ];
		var guests = ( also[ gb.key ] || [] ).map( function ( tid ) {
			var g = btns.filter( function ( b ) {
				return 'genus' === b.type && b.term === tid;
			} )[ 0 ], t = byId[ tid ];
			var home = g ? btnOf( g.group ) : null;
			return t ? '<li class="izl-gd-row is-guest"><div class="izl-gd-line"><span class="izl-gd-plus" aria-hidden="true">+</span><span class="izl-gd-name">' + esc( t.name ) + ' <small>' + t.count + ' pcs</small> <em class="izl-gd-tag is-guest">also here, stays in ' + esc( home ? textOf( home ) : 'its group' ) + '</em></span>' +
				'<button type="button" class="izl-gd-mini" data-unalso="' + esc( gb.key ) + ':' + tid + '" aria-label="Stop showing ' + esc( t.name ) + ' here" title="Stop showing it here">×</button></div></li>' : '';
		} ).join( '' );
		var subs = tops.length > 1 ? tops.map( function ( t ) {
			return '<li class="izl-gd-sub is-top"><span>' + esc( t.name ) + ' <small>' + t.count + ' pcs</small></span><button type="button" class="izl-gd-mini" data-edit="' + t.id + '" aria-label="Edit ' + esc( t.name ) + '">✎</button></li>';
		} ).join( '' ) : '';
		var n = gens.length;
		return '<li class="izl-gd-card' + ( gb.shown ? '' : ' is-off' ) + '" data-key="' + esc( gb.key ) + '">' +
			'<div class="izl-gd-line is-head">' + switchHtml( gb ) +
			'<span class="izl-gd-name"><b>' + esc( textOf( gb ) ) + '</b>' + ( textOf( gb ) !== gb.name ? ' <small>(' + esc( gb.name ) + ')</small>' : '' ) +
			( gb.empty ? ' <em class="izl-gd-tag">no products yet: the button shows once it has one</em>' : '' ) + '</span>' +
			'<button type="button" class="izl-gd-mini" data-opts="' + esc( gb.key ) + '" aria-expanded="' + ( open[ gb.key ] ? 'true' : 'false' ) + '" title="Button text, address, PC / phone">⚙</button>' +
			( 1 === tops.length ? '<button type="button" class="izl-gd-mini" data-edit="' + top.id + '" title="Edit the group: name, colour, card type, intro text">✎</button>' : '' ) + '</div>' +
			optsHtml( gb ) +
			( subs ? '<ul class="izl-gd-tree">' + subs + '</ul>' : '' ) +
			'<details class="izl-gd-gens"' + ( n || guests ? ' open' : '' ) + '><summary>' + ( n ? n + ( 1 === n ? ' genus' : ' genera' ) : 'No genera yet' ) + '</summary>' +
			'<ul class="izl-gd-rows">' + gens.map( genusRow ).join( '' ) + guests + '</ul>' +
			( top ? '<button type="button" class="izl-gd-add" data-new="' + top.id + '">+ New genus in ' + esc( textOf( gb ) ) + '</button>' : '' ) +
			'</details></li>';
	}

	function list() {
		// groups that have no button: the default "Uncategorized" one, or one only an isopod group could join
		var shown = {};
		groupsOnly().forEach( function ( o ) {
			topsOf( o.key ).forEach( function ( t ) {
				shown[ t.id ] = 1;
			} );
		} );
		var rest = d.terms.filter( function ( t ) {
			return ! t.parent && ! shown[ t.id ];
		} ).map( function ( t ) {
			return '<li class="izl-gd-sub"><span>' + esc( t.name ) + ' <small>' + t.count + ' pcs' + ( 'default' === t.locked ? ', the default group' : '' ) + '</small></span><button type="button" class="izl-gd-mini" data-edit="' + t.id + '" aria-label="Edit ' + esc( t.name ) + '">✎</button></li>' + treeHtml( t.id, 1 );
		} ).join( '' );
		var body = dlg && dlg.open ? dlg.querySelector( '.izl-gd-body' ) : null, at = body ? body.scrollTop : 0;
		var form = shell( 'Header buttons and groups',
			'<div class="izl-gd-pv"><p class="izl-gd-pv-h"><span class="izl-gd-tabs"><button type="button" data-view="pc" aria-pressed="' + ( 'pc' === view ) + '">PC header</button><button type="button" data-view="phone" aria-pressed="' + ( 'phone' === view ) + '">Phone menu</button></span> <span>' + ( 'phone' === view ? 'use ↑ ↓ for the phone order; genera stay in their group' : 'drag a button or use ‹ › to change the order' ) + '</span></p><div class="izl-gd-pv-row' + ( 'phone' === view ? ' is-phone' : '' ) + '">' + pvHtml() + '</div></div>' +
			'<p class="izl-gd-help">Switch on what gets a button: a whole group, single genera, or both (switch the group off to show only its genera). ⚙ = the button\'s own text, address, PC / phone. "Also in…" shows a genus in another group too; it stays in its own. ✎ = the group or genus itself (name, move it, colour, intro).</p>' +
			'<ol class="izl-gd-cards">' + groupsOnly().map( groupCard ).join( '' ) + '</ol>' +
			'<button type="button" class="izl-gd-add is-big" data-new="0">+ New group</button>' +
			( rest ? '<p class="izl-gd-help">Not in the header (no button of their own):</p><ul class="izl-gd-tree is-rest">' + rest + '</ul>' : '' ),
			'<span class="izl-gd-note' + ( moved ? ' is-dirty' : '' ) + '">' + ( moved ? 'Unsaved changes' : '' ) + '</span><button type="button" class="izl-gd-cancel">Close</button><button type="submit" class="izl-gd-save"' + ( moved ? '' : ' disabled' ) + '>Save</button>' );
		if ( at ) {
			form.querySelector( '.izl-gd-body' ).scrollTop = at; // a redraw keeps the place
		}
		wireList( form );
	}

	// 3.23.0: the phone menu as shoppers see it: a group with genera is a section (its genera under it), in the phone order
	function prank( b ) {
		var i = porder.indexOf( b.key );
		return i >= 0 ? i : 1000 + btns.indexOf( b );
	}
	function phoneOn( b ) {
		return b.shown && ! b.empty && 'pc' !== b.where;
	}
	function phoneSecs() {
		var secs = [];
		groupsOnly().forEach( function ( g ) {
			var items = generaOf( g.key ).filter( phoneOn ).sort( function ( a, b ) {
				return prank( a ) - prank( b );
			} );
			if ( items.length || ( phoneOn( g ) ) ) {
				secs.push( { g: g, items: items } );
			}
		} );
		return secs.sort( function ( a, b ) {
			return prank( a.g ) - prank( b.g );
		} );
	}
	function phRow( b, i, n, cls ) {
		return '<span class="izl-gd-ph-row' + cls + '"><b>' + esc( textOf( b ) ) + '</b>' +
			'<button type="button" class="izl-gd-nudge" data-up="' + esc( b.key ) + '" aria-label="Move ' + esc( textOf( b ) ) + ' up"' + ( i ? '' : ' disabled' ) + '>↑</button>' +
			'<button type="button" class="izl-gd-nudge" data-down="' + esc( b.key ) + '" aria-label="Move ' + esc( textOf( b ) ) + ' down"' + ( i < n - 1 ? '' : ' disabled' ) + '>↓</button></span>';
	}
	function phoneHtml() {
		var secs = phoneSecs();
		if ( ! secs.length ) {
			return '<p class="izl-gd-pv-none">Nothing in the phone menu yet: switch on a group or a genus below.</p>';
		}
		return '<ol class="izl-gd-ph">' + secs.map( function ( sec, i ) {
			return '<li>' + phRow( sec.g, i, secs.length, sec.items.length ? ' is-head' : '' ) +
				( sec.items.length ? '<ol class="izl-gd-ph-sub">' + sec.items.map( function ( b, j ) {
					return '<li>' + phRow( b, j, sec.items.length, '' ) + '</li>';
				} ).join( '' ) + '</ol>' : '' ) + '</li>';
		} ).join( '' ) + '</ol>';
	}
	function pvHtml() {
		return 'phone' === view ? phoneHtml() : previewHtml();
	}
	// One place up or down among its neighbours (a group among the groups, a genus inside its group); the whole phone
	// order is written down again, so it no longer follows the header's.
	function pnudge( key, dir ) {
		var secs = phoneSecs(), b = btnOf( key ), sibs;
		if ( 'group' === b.type ) {
			sibs = secs.map( function ( x ) {
				return x.g;
			} );
		} else {
			sibs = ( secs.filter( function ( x ) {
				return x.g.key === b.group;
			} )[ 0 ] || { items: [] } ).items;
		}
		var i = sibs.indexOf( b ), j = i + dir;
		if ( i < 0 || j < 0 || j >= sibs.length ) {
			return false;
		}
		sibs[ i ] = sibs[ j ];
		sibs[ j ] = b;
		if ( 'group' === b.type ) {
			secs = sibs.map( function ( g ) {
				return secs.filter( function ( x ) {
					return x.g === g;
				} )[ 0 ];
			} );
		}
		porder = [];
		secs.forEach( function ( x ) {
			porder.push( x.g.key );
			x.items.forEach( function ( y ) {
				porder.push( y.key );
			} );
		} );
		return true;
	}

	// Moves a switched-on button one place left or right among the switched-on ones (the rest keep their places).
	function nudge( key, dir ) {
		var on = btns.filter( function ( b ) {
			return b.shown;
		} );
		var i = on.indexOf( btnOf( key ) ), j = i + dir;
		if ( i < 0 || j < 0 || j >= on.length ) {
			return false;
		}
		var a = btns.indexOf( on[ i ] ), b = btns.indexOf( on[ j ] ), x = btns[ a ];
		btns[ a ] = btns[ b ];
		btns[ b ] = x;
		return true;
	}

	function wireList( form ) {
		var row = form.querySelector( '.izl-gd-pv-row' ), drag = null;
		form.addEventListener( 'change', function ( e ) {
			var el = e.target, b;
			if ( el.hasAttribute( 'data-tick' ) ) {
				b = btnOf( el.getAttribute( 'data-tick' ) );
				b.shown = el.checked;
				dirty( form );
				list();
			} else if ( el.hasAttribute( 'data-also' ) ) {
				if ( el.value ) {
					also[ el.value ] = ( also[ el.value ] || [] ).concat( [ parseInt( el.getAttribute( 'data-also' ), 10 ) ] );
					dirty( form );
					list();
				}
			} else if ( 'where' === el.getAttribute( 'data-set' ) ) {
				btnOf( el.getAttribute( 'data-key' ) ).where = el.value;
				dirty( form );
				row.innerHTML = pvHtml();
			}
		} );
		form.addEventListener( 'input', function ( e ) {
			var el = e.target, set = el.getAttribute && el.getAttribute( 'data-set' );
			if ( 'label' === set || 'link' === set ) {
				btnOf( el.getAttribute( 'data-key' ) )[ set ] = el.value;
				dirty( form );
				if ( 'label' === set ) {
					row.innerHTML = pvHtml();
				}
			}
		} );
		form.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( 'button' );
			if ( ! b ) {
				return;
			}
			if ( b.hasAttribute( 'data-view' ) ) {
				view = b.getAttribute( 'data-view' );
				list();
				return;
			}
			if ( b.hasAttribute( 'data-up' ) || b.hasAttribute( 'data-down' ) ) {
				var pk = b.getAttribute( b.hasAttribute( 'data-up' ) ? 'data-up' : 'data-down' ), up = b.hasAttribute( 'data-up' );
				if ( pnudge( pk, up ? -1 : 1 ) ) {
					dirty( form );
					row.innerHTML = pvHtml();
					var back = row.querySelector( '[data-' + ( up ? 'up' : 'down' ) + '="' + pk + '"]' );
					if ( back && ! back.disabled ) {
						back.focus();
					}
				}
				return;
			}
			if ( b.hasAttribute( 'data-left' ) || b.hasAttribute( 'data-right' ) ) {
				var key = b.getAttribute( b.hasAttribute( 'data-left' ) ? 'data-left' : 'data-right' );
				if ( nudge( key, b.hasAttribute( 'data-left' ) ? -1 : 1 ) ) {
					dirty( form );
					row.innerHTML = pvHtml();
					var again = row.querySelector( '[data-' + ( b.hasAttribute( 'data-left' ) ? 'left' : 'right' ) + '="' + key + '"]' );
					if ( again && ! again.disabled ) {
						again.focus();
					}
				}
			} else if ( b.hasAttribute( 'data-opts' ) ) {
				var k = b.getAttribute( 'data-opts' ), box = b.closest( 'li' ).querySelector( '.izl-gd-opts' );
				open[ k ] = ! open[ k ];
				box.hidden = ! open[ k ];
				b.setAttribute( 'aria-expanded', open[ k ] ? 'true' : 'false' );
				if ( open[ k ] ) {
					box.querySelector( 'input' ).focus();
				}
			} else if ( b.hasAttribute( 'data-unalso' ) ) {
				var p = b.getAttribute( 'data-unalso' ).split( ':' ), tid = parseInt( p[ 1 ], 10 );
				also[ p[ 0 ] ] = ( also[ p[ 0 ] ] || [] ).filter( function ( x ) {
					return x !== tid;
				} );
				dirty( form );
				list();
			} else if ( b.hasAttribute( 'data-edit' ) ) {
				edit( parseInt( b.getAttribute( 'data-edit' ), 10 ), 0 );
			} else if ( b.hasAttribute( 'data-new' ) ) {
				edit( 0, parseInt( b.getAttribute( 'data-new' ), 10 ) );
			} else if ( b.classList.contains( 'izl-gd-cancel' ) ) {
				dlg.close();
			}
		} );
		// drag and drop (mouse) in the header preview: the chip under the pointer makes room
		row.addEventListener( 'dragstart', function ( e ) {
			drag = e.target.closest && e.target.closest( '.izl-gd-chip' );
			if ( drag ) {
				drag.classList.add( 'is-drag' );
				e.dataTransfer.effectAllowed = 'move';
				e.dataTransfer.setData( 'text/plain', drag.getAttribute( 'data-key' ) );
			}
		} );
		row.addEventListener( 'dragover', function ( e ) {
			var over = e.target.closest && e.target.closest( '.izl-gd-chip' );
			if ( ! drag || ! over || over === drag ) {
				return;
			}
			e.preventDefault();
			var r = over.getBoundingClientRect();
			row.insertBefore( drag, e.clientX > r.left + r.width / 2 ? over.nextSibling : over );
		} );
		row.addEventListener( 'dragend', function () {
			if ( ! drag ) {
				return;
			}
			drag = null;
			// the switched-on buttons take the new order in the places they had among all of them
			var keys = Array.prototype.map.call( row.querySelectorAll( '.izl-gd-chip' ), function ( c ) {
				return c.getAttribute( 'data-key' );
			} );
			var slots = [];
			btns.forEach( function ( b, i ) {
				if ( b.shown ) {
					slots.push( i );
				}
			} );
			var before = btns.slice();
			keys.forEach( function ( k, n ) {
				btns[ slots[ n ] ] = before.filter( function ( b ) {
					return b.key === k;
				} )[ 0 ];
			} );
			if ( btns.some( function ( b, i ) {
				return b !== before[ i ];
			} ) ) {
				dirty( form );
			}
			row.innerHTML = pvHtml();
		} );
		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			var save = form.querySelector( '.izl-gd-save' ), more = { names: {}, links: {}, where: {}, also: also, porder: porder };
			btns.forEach( function ( b ) {
				if ( '' !== String( b.label || '' ).trim() ) {
					more.names[ b.key ] = b.label;
				}
				if ( '' !== String( b.link || '' ).trim() ) {
					more.links[ b.key ] = b.link;
				}
				if ( b.where ) {
					more.where[ b.key ] = b.where;
				}
			} );
			save.disabled = true;
			save.textContent = 'Saving…';
			send( { action: 'izl_group_order', keys: btns.map( function ( b ) {
				return b.key;
			} ), shown: btns.filter( function ( b ) {
				return b.shown;
			} ).map( function ( b ) {
				return b.key;
			} ).concat( [ '-' ] ), more: JSON.stringify( more ) } ).then( function () {
				window.location.reload();
			} ).catch( function ( err ) {
				save.disabled = false;
				save.textContent = 'Save';
				error( form.querySelector( '.izl-gd-body' ), err.message );
			} );
		} );
	}

	// ==========================================================================
	//  3. The form: one group
	// ==========================================================================

	function edit( id, parent ) {
		var t = id ? byId[ id ] : { id: 0, name: '', parent: parent, count: 0, kids: 0, desc: '', color: '', kind: '', auto: '', menu: '', line: '', locked: '', key: '' };
		var no = id ? treeOf( id ) : [];
		var opts = '<option value="0">Nothing: a group of its own</option>';
		( function walk( pid, depth ) {
			d.terms.filter( function ( x ) {
				return x.parent === pid;
			} ).forEach( function ( x ) {
				if ( no.indexOf( x.id ) < 0 ) {
					opts += '<option value="' + x.id + '"' + ( x.id === t.parent ? ' selected' : '' ) + '>' + new Array( depth + 1 ).join( '— ' ) + esc( x.name ) + '</option>';
					walk( x.id, depth + 1 );
				}
			} );
		}( 0, 0 ) );
		var kinds = '<option value="">Automatic: ' + ( t.auto ? esc( d.kinds[ t.auto ] ) : 'no card' ) + ' (by the name)</option>';
		Object.keys( d.kinds ).forEach( function ( k ) {
			kinds += '<option value="' + k + '"' + ( t.kind === k ? ' selected' : '' ) + '>' + esc( d.kinds[ k ] ) + ' card</option>';
		} );
		kinds += '<option value="none"' + ( 'none' === t.kind ? ' selected' : '' ) + '>No Codex card (supplies, anything else)</option>';
		var color = t.color || d.presets[ t.kind ] || d.presets[ t.auto ] || d.device;
		var title = id ? 'Edit group: ' + esc( t.name ) : ( parent ? 'New subgroup under ' + esc( byId[ parent ] ? byId[ parent ].name : '' ) : 'New group' );
		var del = ! id ? '' : ( t.locked ? 'The shop needs this group: it cannot be deleted.' : ( t.count || t.kids ? 'Only an empty group can be deleted (' + t.count + ' products, ' + t.kids + ' subgroups here now).' : '' ) );
		var form = shell( title,
			'<div class="izl-gd-cols"><div class="izl-gd-col">' +
			'<label class="izl-gd-field"><span>Name</span><input type="text" id="izl-gd-name" maxlength="80" required value="' + esc( t.name ) + '"><small>Shown on its page and in the "New product" list.</small></label>' +
			'<label class="izl-gd-field"><span>Sits under</span><select id="izl-gd-parent">' + opts + '</select><small>Nothing = its own button in the header. Moving it takes its products and subgroups along.</small></label>' +
			'<label class="izl-gd-field"><span>Intro text at the top of its page</span><textarea id="izl-gd-desc" rows="5" placeholder="A few words for shoppers: what these animals are like, who they suit.">' + esc( t.desc ) + '</textarea><small>Empty = no intro.</small></label>' +
			'</div><div class="izl-gd-col izl-gd-top">' +
			'<label class="izl-gd-field"><span>Button text in the header</span><input type="text" id="izl-gd-menu" maxlength="60" placeholder="' + esc( ( t.key && d.names[ t.key ] ) || t.name || 'the name' ) + '" value="' + esc( t.menu ) + '"><small>Empty = the usual one.</small></label>' +
			'<label class="izl-gd-field"><span>Card type</span><select id="izl-gd-kind">' + kinds + '</select><small>Isopods, cockroaches, springtails, spiders get the Codex card. All isopod groups share the one "Isopods" button.</small></label>' +
			'<div class="izl-gd-field"><span>Card colour</span><span class="izl-gd-color"><input type="color" id="izl-gd-color" value="' + esc( color ) + '"><label><input type="checkbox" id="izl-gd-nocolor"' + ( t.color ? '' : ' checked' ) + '> the standard colour</label></span><small>The colour of every card in the group (a colour set on one card wins).</small></div>' +
			'</div></div>',
			( id ? '<button type="button" class="izl-gd-del"' + ( del ? ' disabled title="' + esc( del ) + '"' : '' ) + '>Delete</button>' : '' ) +
			'<span class="izl-gd-note">' + ( moved ? 'Saving this drops the unsaved button changes. ' : '' ) + ( id ? t.count + ( 1 === t.count ? ' product here' : ' products here' ) : '' ) + '</span><button type="button" class="izl-gd-cancel">Back</button><button type="submit" class="izl-gd-save">' + ( id ? 'Save' : 'Add' ) + '</button>' );
		var $f = function ( s ) {
			return form.querySelector( s );
		};
		function top() {
			var on = '0' === $f( '#izl-gd-parent' ).value;
			$f( '.izl-gd-top' ).hidden = ! on;
			$f( '#izl-gd-color' ).disabled = $f( '#izl-gd-nocolor' ).checked;
		}
		form.addEventListener( 'input', top );
		form.addEventListener( 'change', top );
		top();
		$f( '#izl-gd-color' ).addEventListener( 'input', function () {
			$f( '#izl-gd-nocolor' ).checked = false;
		} );
		$f( '#izl-gd-name' ).focus();
		$f( '.izl-gd-cancel' ).addEventListener( 'click', list );
		if ( $f( '.izl-gd-del' ) ) {
			$f( '.izl-gd-del' ).addEventListener( 'click', function () {
				var b = this;
				if ( b.classList.contains( 'is-sure' ) ) {
					b.disabled = true;
					send( { action: 'izl_group_delete', id: id } ).then( function ( r ) {
						if ( d.here === id ) {
							window.location.href = r.link; // its own page is gone: to the group above it (or home)
						} else {
							window.location.reload();
						}
					} ).catch( function ( err ) {
						b.disabled = false;
						error( $f( '.izl-gd-body' ), err.message );
					} );
				} else {
					b.classList.add( 'is-sure' ); // a second click deletes (no browser pop-up)
					b.textContent = 'Sure? Delete';
				}
			} );
		}
		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			var save = $f( '.izl-gd-save' ), isTop = '0' === $f( '#izl-gd-parent' ).value;
			var data = { action: 'izl_group_save', id: id, name: $f( '#izl-gd-name' ).value, parent: $f( '#izl-gd-parent' ).value, desc: $f( '#izl-gd-desc' ).value };
			if ( isTop ) {
				data.menu = $f( '#izl-gd-menu' ).value;
				data.kind = $f( '#izl-gd-kind' ).value;
				if ( ! $f( '#izl-gd-nocolor' ).checked || t.color ) {
					data.color = $f( '#izl-gd-nocolor' ).checked ? '' : $f( '#izl-gd-color' ).value;
				}
			}
			save.disabled = true;
			save.textContent = 'Saving…';
			send( data ).then( function ( r ) {
				if ( ! id && r.link ) {
					window.location.href = r.link; // a new group: open its page (add its first product there)
				} else {
					window.location.reload();
				}
			} ).catch( function ( err ) {
				save.disabled = false;
				save.textContent = id ? 'Save' : 'Add';
				error( $f( '.izl-gd-body' ), err.message );
			} );
		} );
	}

	// ==========================================================================
	//  4. Opening the dialog
	// ==========================================================================

	document.addEventListener( 'click', function ( e ) {
		var b = e.target.closest( '[data-izl-gd]' );
		if ( ! b ) {
			return;
		}
		e.preventDefault();
		var what = b.getAttribute( 'data-izl-gd' ).split( ':' ), n = parseInt( what[ 1 ], 10 ) || 0;
		if ( 'edit' === what[ 0 ] && byId[ n ] ) {
			edit( n, 0 );
		} else if ( 'new' === what[ 0 ] ) {
			edit( 0, n );
		} else {
			list();
		}
	} );
}() );
