/* ========================================================================== */
/*
    FILE: assets/groups-edit.js   (Ízeltláb theme)
    WHAT: ADMIN ONLY. The Groups dialog (3.21.0): the list of the set-up groups in the header's order (tick the ones
          that get a header button, drag or ↑ ↓ to change the order; 3.21.1), and the form to add, rename, recolour,
          move or delete a group or subgroup. New groups are made from the shop page's "+ New group" only.
          Server side: inc/edit-groups.php. Look: assets/groups-edit.css.
    SEEN: Only by logged-in shop managers, from the "✎ Groups" / "+ New group" / "✎ Edit this group" buttons.
    SECTIONS IN THIS FILE:
      1. Data and helpers
      2. The list: order and the group tree
      3. The form: one group
      4. Opening the dialog
*/
/* ========================================================================== */
( function () {
	'use strict';

	// ==========================================================================
	//  1. Data and helpers
	// ==========================================================================

	var json = document.getElementById( 'izl-groups-data' );
	if ( ! json ) {
		return;
	}
	var d = JSON.parse( json.textContent ), dlg = null, order = d.order.slice(), moved = false;
	var byId = {};
	d.terms.forEach( function ( t ) {
		byId[ t.id ] = t;
	} );

	function esc( s ) {
		return String( null == s ? '' : s ).replace( /[&<>"']/g, function ( c ) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ c ];
		} );
	}
	function kidsOf( id ) {
		return d.terms.filter( function ( t ) {
			return t.parent === id;
		} );
	}
	// a group and everything under it (a group cannot go under these)
	function treeOf( id ) {
		var out = [ id ];
		kidsOf( id ).forEach( function ( k ) {
			out = out.concat( treeOf( k.id ) );
		} );
		return out;
	}
	function send( data ) {
		var body = new window.FormData();
		data._ajax_nonce = d.nonce;
		Object.keys( data ).forEach( function ( k ) {
			if ( Array.isArray( data[ k ] ) ) {
				data[ k ].forEach( function ( v ) {
					body.append( k + '[]', v );
				} );
			} else {
				body.append( k, data[ k ] );
			}
		} );
		return window.fetch( d.ajax, { method: 'POST', body: body, credentials: 'same-origin' } ).then( function ( r ) {
			return r.text();
		} ).then( function ( text ) {
			var at = text.indexOf( '{"success"' ), j = null;
			try {
				j = at > -1 ? JSON.parse( text.slice( at ) ) : null; // anything a plugin printed before the answer is skipped
			} catch ( e ) {
				j = null;
			}
			if ( j && j.success ) {
				return j.data || {};
			}
			throw new Error( j && j.data ? String( j.data ) : 'Could not save. Are you still logged in?' );
		} );
	}
	function error( where, msg ) {
		var p = where.querySelector( '.izl-gd-err' );
		if ( ! p ) {
			p = document.createElement( 'p' );
			p.className = 'izl-gd-err';
			p.setAttribute( 'role', 'alert' );
			where.insertBefore( p, where.firstChild );
		}
		p.textContent = msg;
	}
	function shell( title, body, actions ) {
		if ( ! dlg ) {
			dlg = document.createElement( 'dialog' );
			dlg.className = 'izl-gd';
			document.body.appendChild( dlg );
			dlg.addEventListener( 'click', function ( e ) {
				if ( e.target === dlg ) {
					dlg.close(); // a click on the dim backdrop
				}
			} );
		}
		dlg.innerHTML = '<form class="izl-gd-form" method="dialog"><h2>' + title + '</h2><div class="izl-gd-body">' + body + '</div><div class="izl-gd-actions">' + actions + '</div></form>';
		if ( ! dlg.open ) {
			dlg.showModal();
		}
		return dlg.querySelector( 'form' );
	}

	// ==========================================================================
	//  2. The list: order and the group tree
	// ==========================================================================

	// The top groups behind one header button (all isopod groups share the "Isopods" button).
	function topsOf( key ) {
		return d.terms.filter( function ( t ) {
			return ! t.parent && t.key === key;
		} );
	}
	function treeHtml( id, depth ) {
		return kidsOf( id ).map( function ( k ) {
			return '<li class="izl-gd-sub" style="--izl-gd-depth:' + depth + '"><span>' + esc( k.name ) + ' <small>' + k.count + ' pcs</small></span>' +
				'<button type="button" class="izl-gd-mini" data-edit="' + k.id + '" aria-label="Edit ' + esc( k.name ) + '">✎</button></li>' + treeHtml( k.id, depth + 1 );
		} ).join( '' );
	}
	function list() {
		var rows = order.map( function ( o, i ) {
			var tops = topsOf( o.key ), inner = tops.map( function ( t ) {
				return ( tops.length > 1 ? '<li class="izl-gd-sub is-top"><span>' + esc( t.name ) + ' <small>' + t.count + ' pcs</small></span><button type="button" class="izl-gd-mini" data-edit="' + t.id + '" aria-label="Edit ' + esc( t.name ) + '">✎</button></li>' : '' ) +
					treeHtml( t.id, tops.length > 1 ? 1 : 0 );
			} ).join( '' );
			return '<li class="izl-gd-item' + ( o.shown ? '' : ' is-off' ) + '" draggable="true" data-key="' + esc( o.key ) + '">' +
				'<div class="izl-gd-head"><span class="izl-gd-grip" aria-hidden="true">⠿</span>' +
				'<label class="izl-gd-tick" title="Show a button for this group in the header"><input type="checkbox" data-tick="' + i + '"' + ( o.shown ? ' checked' : '' ) + '><b>' + esc( o.label ) + '</b></label>' +
				( o.empty ? '<em class="izl-gd-tag">no products yet: the button shows once it has one</em>' : '' ) +
				'<span class="izl-gd-move"><button type="button" class="izl-gd-mini" data-up="' + i + '" aria-label="Move ' + esc( o.label ) + ' up"' + ( i ? '' : ' disabled' ) + '>↑</button>' +
				'<button type="button" class="izl-gd-mini" data-down="' + i + '" aria-label="Move ' + esc( o.label ) + ' down"' + ( i < order.length - 1 ? '' : ' disabled' ) + '>↓</button>' +
				( 1 === tops.length ? '<button type="button" class="izl-gd-mini" data-edit="' + tops[ 0 ].id + '" aria-label="Edit ' + esc( o.label ) + '">✎</button>' : '' ) + '</span></div>' +
				( inner ? '<ul class="izl-gd-tree">' + inner + '</ul>' : '' ) + '</li>';
		} ).join( '' );
		// groups that have no button: the default "Uncategorized" one, or one only an isopod group could join
		var shown = {};
		order.forEach( function ( o ) {
			topsOf( o.key ).forEach( function ( t ) {
				shown[ t.id ] = 1;
			} );
		} );
		var rest = d.terms.filter( function ( t ) {
			return ! t.parent && ! shown[ t.id ];
		} ).map( function ( t ) {
			return '<li class="izl-gd-sub"><span>' + esc( t.name ) + ' <small>' + t.count + ' pcs' + ( 'default' === t.locked ? ', the default group' : '' ) + '</small></span><button type="button" class="izl-gd-mini" data-edit="' + t.id + '" aria-label="Edit ' + esc( t.name ) + '">✎</button></li>' + treeHtml( t.id, 1 );
		} ).join( '' );
		var form = shell( 'Groups',
			'<p class="izl-gd-help">Tick the groups that get a button in the header. Drag a group or use ↑ ↓ to set their order, then Save. ✎ edits a group: name, colour, where it sits, its intro text. New groups: "+ New group" on the shop page (Minden termék).</p>' +
			'<ol class="izl-gd-list">' + rows + '</ol>' +
			( rest ? '<p class="izl-gd-help">Not in the header (no button of their own):</p><ul class="izl-gd-tree is-rest">' + rest + '</ul>' : '' ),
			'<span class="izl-gd-note"></span><button type="button" class="izl-gd-cancel">Close</button><button type="submit" class="izl-gd-save"' + ( moved ? '' : ' disabled' ) + '>Save</button>' );
		wireList( form );
	}
	function wireList( form ) {
		var ol = form.querySelector( '.izl-gd-list' ), drag = null;
		form.addEventListener( 'change', function ( e ) {
			var t = e.target.getAttribute && e.target.getAttribute( 'data-tick' );
			if ( null !== t && undefined !== t ) {
				order[ parseInt( t, 10 ) ].shown = e.target.checked;
				e.target.closest( '.izl-gd-item' ).classList.toggle( 'is-off', ! e.target.checked );
				moved = true;
				form.querySelector( '.izl-gd-save' ).disabled = false;
			}
		} );
		form.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( 'button' );
			if ( ! b ) {
				return;
			}
			if ( b.hasAttribute( 'data-up' ) || b.hasAttribute( 'data-down' ) ) {
				var i = parseInt( b.getAttribute( b.hasAttribute( 'data-up' ) ? 'data-up' : 'data-down' ), 10 ), j = b.hasAttribute( 'data-up' ) ? i - 1 : i + 1;
				var o = order[ i ];
				order[ i ] = order[ j ];
				order[ j ] = o;
				moved = true;
				list();
				var again = dlg.querySelector( '[data-' + ( j < i ? 'up' : 'down' ) + '="' + j + '"]' );
				( again && ! again.disabled ? again : dlg.querySelector( '.izl-gd-save' ) ).focus();
			} else if ( b.hasAttribute( 'data-edit' ) ) {
				edit( parseInt( b.getAttribute( 'data-edit' ), 10 ), 0 );
			} else if ( b.hasAttribute( 'data-new' ) ) {
				edit( 0, parseInt( b.getAttribute( 'data-new' ), 10 ) );
			} else if ( b.classList.contains( 'izl-gd-cancel' ) ) {
				dlg.close();
			}
		} );
		// drag and drop (mouse): the row under the pointer makes room
		ol.addEventListener( 'dragstart', function ( e ) {
			drag = e.target.closest( '.izl-gd-item' );
			if ( drag ) {
				drag.classList.add( 'is-drag' );
				e.dataTransfer.effectAllowed = 'move';
				e.dataTransfer.setData( 'text/plain', drag.getAttribute( 'data-key' ) );
			}
		} );
		ol.addEventListener( 'dragover', function ( e ) {
			var over = e.target.closest( '.izl-gd-item' );
			if ( ! drag || ! over || over === drag ) {
				return;
			}
			e.preventDefault();
			var r = over.getBoundingClientRect();
			ol.insertBefore( drag, e.clientY > r.top + r.height / 2 ? over.nextSibling : over );
		} );
		ol.addEventListener( 'dragend', function () {
			if ( ! drag ) {
				return;
			}
			drag = null;
			var keys = Array.prototype.map.call( ol.children, function ( li ) {
				return li.getAttribute( 'data-key' );
			} );
			var next = keys.map( function ( k ) {
				return order.filter( function ( o ) {
					return o.key === k;
				} )[ 0 ];
			} );
			moved = moved || next.some( function ( o, i ) {
				return o !== order[ i ];
			} );
			order = next;
			list();
		} );
		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			var save = form.querySelector( '.izl-gd-save' );
			save.disabled = true;
			save.textContent = 'Saving…';
			send( { action: 'izl_group_order', keys: order.map( function ( o ) {
				return o.key;
			} ), shown: order.filter( function ( o ) {
				return o.shown;
			} ).map( function ( o ) {
				return o.key;
			} ).concat( [ '-' ] ) } ).then( function () {
				window.location.reload();
			} ).catch( function ( err ) {
				save.disabled = false;
				save.textContent = 'Save';
				error( form.querySelector( '.izl-gd-body' ), err.message );
			} );
		} );
	}

	// ==========================================================================
	//  3. The form: one group
	// ==========================================================================

	function edit( id, parent ) {
		var t = id ? byId[ id ] : { id: 0, name: '', parent: parent, count: 0, kids: 0, desc: '', color: '', kind: '', auto: '', menu: '', line: '', locked: '', key: '' };
		var no = id ? treeOf( id ) : [];
		var opts = '<option value="0">Nothing: a group of its own</option>';
		( function walk( pid, depth ) {
			d.terms.filter( function ( x ) {
				return x.parent === pid;
			} ).forEach( function ( x ) {
				if ( no.indexOf( x.id ) < 0 ) {
					opts += '<option value="' + x.id + '"' + ( x.id === t.parent ? ' selected' : '' ) + '>' + new Array( depth + 1 ).join( '— ' ) + esc( x.name ) + '</option>';
					walk( x.id, depth + 1 );
				}
			} );
		}( 0, 0 ) );
		var kinds = '<option value="">Automatic: ' + ( t.auto ? esc( d.kinds[ t.auto ] ) : 'no card' ) + ' (by the name)</option>';
		Object.keys( d.kinds ).forEach( function ( k ) {
			kinds += '<option value="' + k + '"' + ( t.kind === k ? ' selected' : '' ) + '>' + esc( d.kinds[ k ] ) + ' card</option>';
		} );
		kinds += '<option value="none"' + ( 'none' === t.kind ? ' selected' : '' ) + '>No Codex card (supplies, anything else)</option>';
		var color = t.color || d.presets[ t.kind ] || d.presets[ t.auto ] || d.device;
		var title = id ? 'Edit group: ' + esc( t.name ) : ( parent ? 'New subgroup under ' + esc( byId[ parent ] ? byId[ parent ].name : '' ) : 'New group' );
		var del = ! id ? '' : ( t.locked ? 'The shop needs this group: it cannot be deleted.' : ( t.count || t.kids ? 'Only an empty group can be deleted (' + t.count + ' products, ' + t.kids + ' subgroups here now).' : '' ) );
		var form = shell( title,
			'<div class="izl-gd-cols"><div class="izl-gd-col">' +
			'<label class="izl-gd-field"><span>Name</span><input type="text" id="izl-gd-name" maxlength="80" required value="' + esc( t.name ) + '"><small>Shown on its page and in the "New product" list.</small></label>' +
			'<label class="izl-gd-field"><span>Sits under</span><select id="izl-gd-parent">' + opts + '</select><small>Nothing = its own button in the header. Moving it takes its products and subgroups along.</small></label>' +
			'<label class="izl-gd-field"><span>Intro text at the top of its page</span><textarea id="izl-gd-desc" rows="5" placeholder="A few words for shoppers: what these animals are like, who they suit.">' + esc( t.desc ) + '</textarea><small>Empty = no intro.</small></label>' +
			'</div><div class="izl-gd-col izl-gd-top">' +
			'<label class="izl-gd-field"><span>Button text in the header</span><input type="text" id="izl-gd-menu" maxlength="60" placeholder="' + esc( ( t.key && d.names[ t.key ] ) || t.name || 'the name' ) + '" value="' + esc( t.menu ) + '"><small>Empty = the usual one.</small></label>' +
			'<label class="izl-gd-field"><span>Card type</span><select id="izl-gd-kind">' + kinds + '</select><small>Isopods, cockroaches, springtails, spiders get the Codex card. All isopod groups share the one "Isopods" button.</small></label>' +
			'<div class="izl-gd-field"><span>Card colour</span><span class="izl-gd-color"><input type="color" id="izl-gd-color" value="' + esc( color ) + '"><label><input type="checkbox" id="izl-gd-nocolor"' + ( t.color ? '' : ' checked' ) + '> the standard colour</label></span><small>The colour of every card in the group (a colour set on one card wins).</small></div>' +
			'</div></div>',
			( id ? '<button type="button" class="izl-gd-del"' + ( del ? ' disabled title="' + esc( del ) + '"' : '' ) + '>Delete</button>' : '' ) +
			'<span class="izl-gd-note">' + ( id ? t.count + ( 1 === t.count ? ' product here' : ' products here' ) : '' ) + '</span><button type="button" class="izl-gd-cancel">Back</button><button type="submit" class="izl-gd-save">' + ( id ? 'Save' : 'Add' ) + '</button>' );
		var $f = function ( s ) {
			return form.querySelector( s );
		};
		function top() {
			var on = '0' === $f( '#izl-gd-parent' ).value;
			$f( '.izl-gd-top' ).hidden = ! on;
			$f( '#izl-gd-color' ).disabled = $f( '#izl-gd-nocolor' ).checked;
		}
		form.addEventListener( 'input', top );
		form.addEventListener( 'change', top );
		top();
		$f( '#izl-gd-color' ).addEventListener( 'input', function () {
			$f( '#izl-gd-nocolor' ).checked = false;
		} );
		$f( '#izl-gd-name' ).focus();
		$f( '.izl-gd-cancel' ).addEventListener( 'click', list );
		if ( $f( '.izl-gd-del' ) ) {
			$f( '.izl-gd-del' ).addEventListener( 'click', function () {
				var b = this;
				if ( b.classList.contains( 'is-sure' ) ) {
					b.disabled = true;
					send( { action: 'izl_group_delete', id: id } ).then( function ( r ) {
						if ( d.here === id ) {
							window.location.href = r.link; // its own page is gone: to the group above it (or home)
						} else {
							window.location.reload();
						}
					} ).catch( function ( err ) {
						b.disabled = false;
						error( $f( '.izl-gd-body' ), err.message );
					} );
				} else {
					b.classList.add( 'is-sure' ); // a second click deletes (no browser pop-up)
					b.textContent = 'Sure? Delete';
				}
			} );
		}
		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			var save = $f( '.izl-gd-save' ), isTop = '0' === $f( '#izl-gd-parent' ).value;
			var data = { action: 'izl_group_save', id: id, name: $f( '#izl-gd-name' ).value, parent: $f( '#izl-gd-parent' ).value, desc: $f( '#izl-gd-desc' ).value };
			if ( isTop ) {
				data.menu = $f( '#izl-gd-menu' ).value;
				data.kind = $f( '#izl-gd-kind' ).value;
				if ( ! $f( '#izl-gd-nocolor' ).checked || t.color ) {
					data.color = $f( '#izl-gd-nocolor' ).checked ? '' : $f( '#izl-gd-color' ).value;
				}
			}
			save.disabled = true;
			save.textContent = 'Saving…';
			send( data ).then( function ( r ) {
				if ( ! id && r.link ) {
					window.location.href = r.link; // a new group: open its page (add its first product there)
				} else {
					window.location.reload();
				}
			} ).catch( function ( err ) {
				save.disabled = false;
				save.textContent = id ? 'Save' : 'Add';
				error( $f( '.izl-gd-body' ), err.message );
			} );
		} );
	}

	// ==========================================================================
	//  4. Opening the dialog
	// ==========================================================================

	document.addEventListener( 'click', function ( e ) {
		var b = e.target.closest( '[data-izl-gd]' );
		if ( ! b ) {
			return;
		}
		e.preventDefault();
		var what = b.getAttribute( 'data-izl-gd' ).split( ':' ), n = parseInt( what[ 1 ], 10 ) || 0;
		if ( 'edit' === what[ 0 ] && byId[ n ] ) {
			edit( n, 0 );
		} else if ( 'new' === what[ 0 ] ) {
			edit( 0, n );
		} else {
			list();
		}
	} );
}() );
