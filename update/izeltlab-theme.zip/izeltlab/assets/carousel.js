// ==========================================================================
//  FILE: assets/carousel.js   (Ízeltláb theme)
//  WHAT: The front page's card carousel: the hero cards turn, the one in front is the active one.
//  SEEN: The front page, with more than one hero card.
// ==========================================================================

/**
 * Front page Codex carousel: up to 3 cards on a ring, seen from a little in front.
 * Seen from above the cards sit on a ring: one in front, one on each side, set back, all facing the customer.
 * Every few seconds the ring turns clockwise (seen from above): the front card goes to the left,
 * the right one comes to the front and the left one travels behind to the right. The cards never pass through
 * each other and never turn or change shape, they only slide and shrink evenly, in two steps: first the front card
 * slides left and back, a little past its spot, until it is clear of the right card; then the right card comes forward
 * while the left one settles into its spot behind it. The card travelling round the back stays below both.
 */
( function () {
	'use strict';

	var INTERVAL = 7000; // ms between two turns
	var DURATION = 1300; // ms of one turn (two steps)
	var SIDE_X = 0.4; // side cards: sideways, in card widths
	var SIDE_Z = 0.62; // side cards: how far back, in card widths
	var DIM = 0.45; // brightness of the cards in the back
	// The Firefox engine (Firefox, LibreWolf, other Gecko browsers; 1.7.7): a blur on a card that holds a 3D card
	// lagged there and flashed white boxes, so the back cards are only dimmed, never blurred (style.css .izl-gecko).
	// 1.7.8: during a turn the dimming changes in a few steps, the drift pauses and positions are read before the cards
	// move (each change of a filter makes Firefox redraw the whole 3D card). functions.php sets the class in the head.
	// Chromium browsers say "like Gecko" without the slash, and support neither check, so they are unchanged.
	var GECKO = document.documentElement.classList.contains( 'izl-gecko' ) || /\bGecko\/\d/.test( navigator.userAgent ) || !! ( window.CSS && CSS.supports && CSS.supports( '-moz-orient', 'inline' ) );
	// 3.20.0 (Dan's speed list): weak phones (lite mode, html.izl-lite from inc/speed.php) get the back cards dimmed only,
	// like Firefox: a blur on a 3D card is drawn again on every frame of its float, the front page's biggest cost there.
	var LITE = document.documentElement.classList.contains( 'izl-lite' );
	var BLUR = GECKO || LITE ? 0 : 1.5; // px
	if ( GECKO ) {
		document.documentElement.classList.add( 'izl-gecko' );
	}
	var OVER = 0.3; // step 1: how far past its side spot the leaving card slides, in card widths
	var STEP_1 = 0.5; // step 1 (the front card steps aside) ends here, as a part of the turn
	var STEP_2 = 0.42; // step 2 (the next card comes forward, the leaving one settles) starts here
	// 2.4.0 phones (under 1024px since 3.11.0): the back cards sit further back (smaller), and only as far out to the sides as the
	// screen allows, so their outer edges never get cut off. A swipe left or right turns the ring that way.
	var PHONE = window.matchMedia ? window.matchMedia( '(max-width: 1023px)' ) : null;
	var PHONE_Z = 1; // phones: how far back the side cards sit, in card widths
	var EDGE = 14; // phones: px kept free between a back card and the screen edge
	var SWIPE = 40; // px: a sideways finger move this long turns the ring

	function ease( t ) {
		return t < 0.5 ? 4 * t * t * t : 1 - Math.pow( -2 * t + 2, 3 ) / 2;
	}

	function setup( box ) {
		var slots = Array.prototype.slice.call( box.querySelectorAll( '.izl-slot' ) );
		var n = slots.length;
		if ( n < 2 ) {
			return;
		}
		// Ring places, in degrees: 0 = front, 90 = right side, -90 = left side (180 = straight behind).
		var places = n === 2 ? [ 0, 90 ] : [ 0, 90, -90 ];
		var pos = slots.map( function ( s, i ) {
			return i;
		} );
		var angle = places.slice( 0, n );
		var still = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
		var busy = false, paused = false, timer = 0;

		// The ring follows the card width, so the side cards stay mostly hidden behind the front one.
		function radius() {
			var front = slots[ pos.indexOf( 0 ) ].querySelector( '.fsz-device' );
			return front ? front.offsetWidth : 380;
		}

		function place( slot, x, z, near, zi ) {
			if ( GECKO && near <= 0.999 ) {
				near = Math.round( near * 4 ) / 4; // Firefox: the dimming in quarter steps (the same filter is not redrawn)
			}
			// Every card faces the customer, at rest and while moving; the Codex resting angle and float (codex.css) stay on all of them.
			slot.style.transform = near > 0.999 ? 'none' : 'translate3d(' + x.toFixed( 1 ) + 'px,0,' + z.toFixed( 1 ) + 'px)';
			slot.style.filter = near > 0.999 ? 'none' : 'brightness(' + ( DIM + ( 1 - DIM ) * near ).toFixed( 3 ) + ') saturate(' + ( 0.55 + 0.45 * near ).toFixed( 3 ) + ')' + ( BLUR ? ' blur(' + ( BLUR * ( 1 - near ) ).toFixed( 2 ) + 'px)' : '' );
			slot.style.zIndex = String( zi );
		}

		// Where the side cards sit, in card widths: [sideways, back]. On a phone 'sideways' is worked out from the room:
		// a card set back by z looks smaller by P / (P + z) (P = the box's perspective), and so does its distance from
		// the middle, so its outer edge is at (x + w / 2) * P / (P + z), which has to stay EDGE px inside the box.
		function geo( w ) {
			if ( ! PHONE || ! PHONE.matches || ! w ) {
				return [ SIDE_X, SIDE_Z ];
			}
			var P = parseFloat( window.getComputedStyle( box ).perspective ) || 1400;
			var s = P / ( P + PHONE_Z * w ), half = box.clientWidth / 2;
			return [ Math.max( 0.12, Math.min( SIDE_X, ( ( half - EDGE ) / s - w / 2 ) / w ) ), PHONE_Z ];
		}

		function overlap( p, q ) {
			var a = p.querySelector( '.fsz-device' ).getBoundingClientRect(), b = q.querySelector( '.fsz-device' ).getBoundingClientRect();
			return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;
		}

		function pairClear( move ) {
			var out = slots[ move.role.indexOf( 'out' ) ], inc = slots[ move.role.indexOf( 'in' ) ];
			return !! ( out && inc && ! overlap( out, inc ) );
		}

		// At rest: a = ring angle per card. During a turn, move = { t: time 0..1, k: eased, role: per card 'out' | 'in' | 'back',
		// side: where the leaving card goes (-1 left, 1 right), swapped: the incoming card is already drawn on top }.
		// The order changes once the two cards no longer cover each other, at the latest when step 2 starts.
		function draw( a, w, move ) {
			// Whether the two cards cover each other, read before they move (no extra layout pass each frame). 2.1.2: in every
			// browser (Chromium read it after the move, which laid the page out again on every frame of a turn). The order
			// only changes while they do not cover each other, so one frame later shows the same.
			var clear = move && ! move.swapped ? pairClear( move ) : false;
			var g = geo( w ), SX = g[ 0 ], SZ = g[ 1 ];
			slots.forEach( function ( slot, i ) {
				var role = move ? move.role[ i ] : '';
				var rad = a[ i ] * Math.PI / 180;
				var cos = Math.cos( rad ), sin = Math.sin( rad );
				if ( 'out' === role ) {
					// Step 1: slides aside and back, past its spot, until it is clear of the next card. Step 2: settles into its spot.
					var go = ease( Math.min( 1, move.t / STEP_1 ) ), settle = ease( Math.max( 0, ( move.t - STEP_2 ) / ( 1 - STEP_2 ) ) );
					place( slot, move.side * w * ( SX * go + OVER * ( go - settle ) ), -SZ * w * go, 1 - go, move.swapped ? 200 : 300 );
				} else if ( 'in' === role ) {
					// Step 2: comes forward from its side spot to the front, in front of the card that just stepped aside.
					var q = ease( Math.max( 0, ( move.t - STEP_2 ) / ( 1 - STEP_2 ) ) );
					place( slot, -move.side * SX * w * ( 1 - q ), -SZ * w * ( 1 - q ), q, move.swapped ? 300 : 200 );
				} else {
					// At rest, and the card travelling round the back (always below the other two).
					place( slot, SX * w * sin, SZ * w * ( cos - 1 ), Math.max( 0, cos ), move ? 100 : 100 + Math.round( cos * 50 ) );
				}
			} );
			// The drawing order changes only while the two cards do not cover each other, so nothing ever pops or cuts through.
			if ( move && ! move.swapped ) {
				var out = slots[ move.role.indexOf( 'out' ) ], inc = slots[ move.role.indexOf( 'in' ) ];
				if ( out && inc && ( move.t >= STEP_2 || clear ) ) {
					move.swapped = true;
					out.style.zIndex = '200';
					inc.style.zIndex = '300';
				}
			}
		}

		function settle() {
			slots.forEach( function ( slot, i ) {
				var front = pos[ i ] === 0;
				slot.classList.toggle( 'is-front', front );
				// Not inert: an inert card cannot be clicked, and a click on a back card turns it to the front.
				// Its links and buttons only leave the keyboard order (style.css stops clicks on them).
				if ( front ) {
					slot.removeAttribute( 'aria-hidden' );
				} else {
					slot.setAttribute( 'aria-hidden', 'true' );
				}
				Array.prototype.forEach.call( slot.querySelectorAll( 'a,button,input,select,textarea,[tabindex]' ), function ( el ) {
					if ( front ) {
						if ( el.hasAttribute( 'data-izl-tab' ) ) {
							var was = el.getAttribute( 'data-izl-tab' );
							if ( was ) {
								el.setAttribute( 'tabindex', was );
							} else {
								el.removeAttribute( 'tabindex' );
							}
							el.removeAttribute( 'data-izl-tab' );
						}
					} else if ( ! el.hasAttribute( 'data-izl-tab' ) ) {
						el.setAttribute( 'data-izl-tab', el.getAttribute( 'tabindex' ) || '' );
						el.setAttribute( 'tabindex', '-1' );
					}
				} );
			} );
		}

		// dir -1 = clockwise seen from above (the right card comes to the front), +1 = the other way.
		function turn( dir ) {
			if ( busy ) {
				return;
			}
			slots.forEach( function ( sl ) {
				sl.classList.remove( 'is-wait' ); // 3.16.0: a turn shows a back card still waiting for its photo
			} );
			var from = angle.slice(), to = [], role = [];
			pos = pos.map( function ( p ) {
				return ( p + dir + n ) % n; // clockwise: one place back in the list (front → left, right → front)
			} );
			slots.forEach( function ( s, i ) {
				var target = places[ pos[ i ] ];
				var delta = ( ( ( target - from[ i ] ) % 360 ) + 360 ) % 360; // 0..359, the way round the other way
				if ( dir < 0 && delta > 0 ) {
					delta -= 360;
				}
				to[ i ] = from[ i ] + delta;
				role[ i ] = Math.abs( from[ i ] % 360 ) < 1 ? 'out' : ( 0 === pos[ i ] ? 'in' : 'back' );
			} );
			// The leaving card goes left on a clockwise turn (seen from above), right on the other.
			var side = dir < 0 ? -1 : 1;
			var r = radius(); // 2.1.2: read before settle() changes the classes, so it needs no fresh layout
			settle();
			if ( still ) {
				angle = to.map( function ( a ) {
					return ( ( a % 360 ) + 360 ) % 360;
				} );
				draw( angle, r );
				return;
			}
			busy = true;
			if ( GECKO ) {
				box.classList.add( 'is-turning' ); // Firefox: the drift pauses for the turn (style.css)
			}
			var start = performance.now();
			var move = { t: 0, k: 0, role: role, side: side, swapped: false };
			function frame( now ) {
				var t = Math.min( 1, ( now - start ) / DURATION ), k = ease( t );
				draw( from.map( function ( a, i ) {
					return a + ( to[ i ] - a ) * k;
				} ), r, t < 1 ? ( move.t = t, move.k = k, move ) : null );
				if ( t < 1 ) {
					window.requestAnimationFrame( frame );
				} else {
					angle = to.map( function ( a ) {
						return ( ( a % 360 ) + 360 ) % 360;
					} );
					busy = false;
					if ( GECKO ) {
						box.classList.remove( 'is-turning' );
					}
				}
			}
			window.requestAnimationFrame( frame );
		}

		function restart() {
			window.clearInterval( timer );
			if ( ! still ) {
				timer = window.setInterval( function () {
					if ( ! paused && ! document.hidden && ! box.classList.contains( 'is-away' ) ) {
						turn( -1 );
					}
				}, INTERVAL );
			}
		}

		// A click on a back card brings it to the front, the short way round.
		slots.forEach( function ( slot, i ) {
			// Back cards stay still under the mouse (no Codex tilt); they float up on hover (style.css), which says they can be clicked.
			slot.addEventListener( 'mousemove', function ( e ) {
				if ( pos[ i ] !== 0 ) {
					e.stopPropagation();
				}
			}, true );
			slot.addEventListener( 'click', function ( e ) {
				if ( pos[ i ] === 0 ) {
					return;
				}
				e.preventDefault();
				turn( pos[ i ] === 1 ? -1 : 1 );
				restart();
			} );
		} );
		// 2.4.0: a finger swiped sideways over the cards turns the ring the same way: to the left brings the right card
		// to the front, to the right brings the left one. Up and down still scroll the page (style.css touch-action).
		// A swipe that starts on a photo with more photos to show changes the photo instead (Codex), as before.
		var sw = null, swiped = false;
		box.addEventListener( 'pointerdown', function ( e ) {
			sw = null;
			if ( 'mouse' === e.pointerType || ( e.target.closest && e.target.closest( '.fsz-photo[role=button], .fsz-page-more' ) ) ) {
				return;
			}
			sw = [ e.clientX, e.clientY ];
		}, { passive: true } );
		box.addEventListener( 'pointermove', function ( e ) {
			if ( ! sw ) {
				return;
			}
			var dx = e.clientX - sw[ 0 ], dy = e.clientY - sw[ 1 ];
			if ( Math.abs( dy ) > Math.abs( dx ) && Math.abs( dy ) > 12 ) {
				sw = null; // scrolling the page
				return;
			}
			if ( Math.abs( dx ) >= SWIPE && Math.abs( dx ) > Math.abs( dy ) * 1.2 ) {
				sw = null;
				swiped = true;
				turn( dx < 0 ? -1 : 1 );
				restart();
			}
		}, { passive: true } );
		[ 'pointerup', 'pointercancel' ].forEach( function ( n ) {
			box.addEventListener( n, function () {
				sw = null;
			}, { passive: true } );
		} );
		// the tap that ended a swipe opens nothing (capture: before the card's own link, hero-link.js)
		box.addEventListener( 'click', function ( e ) {
			if ( swiped ) {
				swiped = false;
				e.stopPropagation();
				e.preventDefault();
			}
		}, true );
		box.addEventListener( 'pointerdown', function () {
			swiped = false;
		}, { capture: true, passive: true } );

		// No turning while someone reads or uses the front card.
		box.addEventListener( 'mouseenter', function () {
			paused = true;
		} );
		box.addEventListener( 'mouseleave', function () {
			paused = false;
		} );
		box.addEventListener( 'focusin', function () {
			paused = true;
		} );
		box.addEventListener( 'focusout', function () {
			paused = false;
		} );
		// Out of view (scrolled away): no turning, and the cards' idle drift stops (style.css .is-away), so the page
		// below scrolls without redrawing the 3D cards on every frame.
		if ( 'IntersectionObserver' in window ) {
			new IntersectionObserver( function ( entries ) {
				box.classList.toggle( 'is-away', ! entries[ 0 ].isIntersecting );
			} ).observe( box );
		}
		var redraw = function () {
			if ( ! busy ) {
				draw( angle, radius() );
			}
		};
		window.addEventListener( 'resize', redraw );
		window.addEventListener( 'izl:hero-fit', redraw ); // 2.4.0: home-phone.js resized the cards

		box.classList.add( 'is-ready' );
		settle();
		draw( angle, radius() );
		restart();
		together( box );
	}

	// 3.1.0: the cards appeared together (Dan, 2026-11-12): the whole carousel stayed invisible until every card's photo,
	// the fonts and the ring were ready. The hiding starts in a one-line script right before the carousel (front-page.php:
	// class izl-hero-wait on <html>, style.css), which also holds the safety stop (2 s). Without JavaScript nothing is
	// hidden.
	// 3.16.0 (Dan, 2026-11-19, PageSpeed "Largest Contentful Paint"): the card in front no longer waits for the two
	// behind it. It appears as soon as its own first photo is in and decoded (and the fonts, for at most 0.6 s more),
	// two frames after the ring is placed; the back cards then fade in (0.4 s, style.css section 54) each when its own
	// photo is ready. Only the front card's photo gets top priority now (front-page.php), so it arrives first. A turn or
	// a swipe shows any back card still waiting at once (it finishes its fade).
	function show() {
		document.documentElement.classList.remove( 'izl-hero-wait' );
	}
	function decoded( img, fn ) {
		var once = function () {
			if ( fn ) {
				var f = fn;
				fn = null;
				f();
			}
		};
		var dec = function () {
			if ( img.decode ) {
				img.decode().then( once, once );
			} else {
				once();
			}
		};
		if ( ! img ) {
			once();
		} else if ( img.complete ) {
			dec();
		} else {
			img.addEventListener( 'load', dec, { once: true } );
			img.addEventListener( 'error', once, { once: true } );
		}
	}
	function together( box ) {
		var slots = Array.prototype.slice.call( box.querySelectorAll( '.izl-slot' ) );
		var waiting = document.documentElement.classList.contains( 'izl-hero-wait' );
		slots.forEach( function ( slot ) {
			if ( slot.classList.contains( 'is-front' ) ) {
				return;
			}
			var img = slot.querySelector( '.fsz-slides > img:first-child' );
			if ( waiting && img && ! img.complete && ! ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) ) {
				slot.classList.add( 'is-wait' ); // invisible until its photo is in, then fades in
				decoded( img, function () {
					slot.classList.remove( 'is-wait' );
				} );
			}
		} );
		if ( ! waiting ) {
			return;
		}
		var slot = box.querySelector( '.izl-slot.is-front' );
		var front = slot && slot.querySelector( '.fsz-slides > img:first-child' );
		decoded( front, function () {
			var go = function () {
				window.requestAnimationFrame( function () {
					window.requestAnimationFrame( function () {
						// 3.17.0: before the page's last scripts are in (Codex's codex.js fits long names), only when
						// the card already looks exactly as codex.js would leave it; otherwise right after codex.js
						if ( document.readyState !== 'loading' || fitted( slot ) ) {
							show();
						} else if ( ! document.fonts || 'loaded' === document.fonts.status ) {
							// 3.20.0 (Dan's speed list): the card no longer waits for the page's last scripts. It gets
							// Codex's fitting here, the same as codex.js gives it (fitNow), and shows at once; when
							// codex.js runs later it measures the same and changes nothing.
							fitNow( slot );
							show();
						} else {
							document.addEventListener( 'DOMContentLoaded', function () {
								window.requestAnimationFrame( show );
							}, { once: true } );
						}
					} );
				} );
			};
			if ( document.fonts && document.fonts.ready && 'loaded' !== document.fonts.status ) {
				var t = window.setTimeout( go, 600 );
				document.fonts.ready.then( function () {
					window.clearTimeout( t );
					go();
				}, go );
			} else {
				go();
			}
		} );
	}

	// 3.17.0 (speed, Dan's list P1): may the front card show before codex.js has run? Only when Codex's fitting would
	// change nothing on it: the fonts are in, no name is too long for its strip (codex.js fitLists()), no English name
	// runs into the barcode, and the funny line fits its box (codex.js fitFun()). The same measurements as there.
	function fitted( slot ) {
		if ( ! slot || ( document.fonts && 'loaded' !== document.fonts.status ) ) {
			return false;
		}
		var ok = true;
		Array.prototype.forEach.call( slot.querySelectorAll( '.fsz-name' ), function ( el ) {
			var cw = el.clientWidth, sw = el.scrollWidth;
			if ( cw && ( el.classList.contains( 'fsz-nick' ) ? sw > cw + 1 : sw / cw > 1.01 ) ) {
				ok = false;
			}
		} );
		Array.prototype.forEach.call( slot.querySelectorAll( '.fsz-en' ), function ( en ) {
			var name = en.firstElementChild;
			if ( ok && name && en.clientWidth ) {
				var left = parseFloat( window.getComputedStyle( en, '::after' ).left );
				var gap = 0.8 * parseFloat( window.getComputedStyle( en ).fontSize );
				if ( ! isNaN( left ) && name.offsetLeft + name.offsetWidth + gap > left ) {
					ok = false;
				}
			}
		} );
		Array.prototype.forEach.call( slot.querySelectorAll( '.fsz-fun-text' ), function ( t ) {
			if ( t.offsetWidth && t.scrollHeight > t.clientHeight + 1 ) {
				ok = false;
			}
		} );
		return ok;
	}

	// 3.20.0: Codex's fitting of one card, the same steps and numbers as codex.js fitLists() and fitFun() (Codex 2.17.0):
	// a name too long for its strip shrinks (the nickname with --fsz-fit, at least 60%; the others with --fsz-k), the
	// barcode hides when the English name runs into it, and the fun fact steps down until it fits its two lines.
	// Change one, change both.
	function fitNow( slot ) {
		var els = Array.prototype.slice.call( slot.querySelectorAll( '.fsz-name' ) );
		var ens = Array.prototype.slice.call( slot.querySelectorAll( '.fsz-en' ) );
		els.forEach( function ( el ) {
			el.style.removeProperty( el.classList.contains( 'fsz-nick' ) ? '--fsz-fit' : '--fsz-k' );
		} );
		els.map( function ( el ) {
			return [ el.clientWidth, el.scrollWidth ];
		} ).forEach( function ( m, i ) {
			var cw = m[ 0 ], sw = m[ 1 ];
			if ( ! cw ) {
				return;
			}
			if ( els[ i ].classList.contains( 'fsz-nick' ) ) {
				if ( sw > cw + 1 ) {
					els[ i ].style.setProperty( '--fsz-fit', Math.max( 0.6, cw / sw ).toFixed( 3 ) );
				}
			} else if ( sw / cw > 1.01 ) {
				els[ i ].style.setProperty( '--fsz-k', ( 0.62 * ( sw / cw ) * 1.02 ).toFixed( 3 ) );
			}
		} );
		ens.forEach( function ( en ) {
			en.classList.remove( 'no-mark' );
		} );
		ens.map( function ( en ) {
			var name = en.firstElementChild;
			if ( ! name || ! en.clientWidth ) {
				return false;
			}
			var left = parseFloat( window.getComputedStyle( en, '::after' ).left );
			var gap = 0.8 * parseFloat( window.getComputedStyle( en ).fontSize );
			return ! isNaN( left ) && name.offsetLeft + name.offsetWidth + gap > left;
		} ).forEach( function ( off, i ) {
			if ( off ) {
				ens[ i ].classList.add( 'no-mark' );
			}
		} );
		Array.prototype.forEach.call( slot.querySelectorAll( '.fsz-fun-text' ), function ( t ) {
			var steps = [ 14.5, 14, 13.5, 13, 12.5, 12 ];
			if ( ! t.offsetWidth ) {
				return;
			}
			t.style.fontSize = '';
			for ( var i = 0; i < steps.length && t.scrollHeight > t.clientHeight + 1; i++ ) {
				t.style.fontSize = 'calc(' + steps[ i ] + '*var(--fsz-u))';
			}
		} );
	}

	function init() {
		Array.prototype.forEach.call( document.querySelectorAll( '.izl-carousel' ), setup );
	}
	// 3.17.0: this script is printed right after the cards (inc/styles.php izl_hero_scripts()), so they are all there:
	// the ring is placed at once instead of after the whole page has been read (the footer scripts held it up).
	if ( document.readyState === 'loading' && ! document.querySelector( '.izl-carousel' ) ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
