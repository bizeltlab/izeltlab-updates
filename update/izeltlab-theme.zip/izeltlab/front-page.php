<?php
/**
 * The front page: up to 3 Codex cards turning on a carousel next to the title, the newest isopods, the supplies and a few words about the breeder.
 * The texts are set under Appearance → Customize → Ízeltláb front page.
 *
 * @package izeltlab
 */

get_header();

$isopods  = izl_isopods_url();
$supplies = izl_supplies_term();
$cards    = izl_hero_products();
$hero     = $cards ? $cards[0] : 0;
$beginner = $isopods && izl_has_codex() && '1' === fsz_opt( 'filter' ) ? add_query_arg( 'max_difficulty', izl_beginner_level(), $isopods ) : '';
?>
<div class="izl-home">

	<section class="izl-hero<?php echo $hero ? '' : ' no-card'; ?>">
		<div class="izl-hero-copy">
			<p class="izl-hero-kicker"><?php echo esc_html( izl_mod( 'izl_hero_kicker' ) ); ?></p>
			<h1><?php echo esc_html( izl_mod( 'izl_hero_title' ) ); ?></h1>
			<div class="izl-hero-text"><?php echo wp_kses_post( wpautop( izl_mod( 'izl_hero_text' ) ) ); ?></div>
			<p class="izl-hero-btns">
				<?php if ( $isopods ) : ?>
					<a class="izl-btn has-bug" href="<?php echo esc_url( $isopods ); ?>"><?php esc_html_e( 'Isopods', 'izeltlab' ); ?><?php izl_bug_icon(); ?></a>
				<?php endif; ?>
				<?php if ( $beginner ) : ?>
					<a class="izl-btn is-alt" href="<?php echo esc_url( $beginner ); ?>"><?php esc_html_e( 'For beginners', 'izeltlab' ); ?></a>
				<?php elseif ( $supplies ) : ?>
					<a class="izl-btn is-alt" href="<?php echo esc_url( get_term_link( $supplies ) ); ?>"><?php esc_html_e( 'Supplies', 'izeltlab' ); ?></a>
				<?php endif; ?>
			</p>
		</div>
		<?php if ( $hero ) : ?>
			<div class="izl-hero-card">
				<?php izl_home_edit_panel(); ?>
				<?php if ( count( $cards ) > 1 ) : ?>
					<div class="izl-carousel" style="--izl-fx:<?php echo esc_attr( izl_card_fx_strength() / 100 ); ?>" role="group" aria-roledescription="carousel" aria-label="<?php esc_attr_e( 'Featured species', 'izeltlab' ); ?>">
						<?php foreach ( $cards as $i => $id ) : ?>
							<div class="izl-slot<?php echo $i ? '' : ' is-front'; ?>" data-pos="<?php echo (int) $i; ?>" data-href="<?php echo esc_url( get_permalink( $id ) ); ?>"<?php echo $i ? ' aria-hidden="true"' : ''; ?>><?php echo do_shortcode( '[codex id="' . (int) $id . '"]' ); ?></div>
						<?php endforeach; ?>
					</div>
				<?php else : ?>
					<div class="izl-hero-single" data-href="<?php echo esc_url( get_permalink( $hero ) ); ?>"><?php echo do_shortcode( '[codex id="' . (int) $hero . '"]' ); ?></div>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	</section>
	<?php
	if ( $hero ) {
		izl_hero_scripts(); // 2.5.0: right here, so the cards are placed before the page is first drawn
	}
	?>

	<?php $newest = izl_codex_product_ids( 4 ); ?>
	<?php if ( $newest ) : ?>
		<section class="izl-section">
			<div class="izl-section-head">
				<h2><?php esc_html_e( 'Newest isopods', 'izeltlab' ); ?></h2>
				<a class="izl-section-link is-btn" href="<?php echo esc_url( izl_all_products_url() ); ?>"><?php esc_html_e( 'All products', 'izeltlab' ); ?> →</a>
			</div>
			<?php izl_product_row( $newest ); ?>
		</section>
	<?php endif; ?>

	<?php $supply_ids = $supplies ? izl_category_product_ids( IZL_SUPPLIES ) : array(); ?>
	<?php if ( $supply_ids ) : ?>
		<section class="izl-section">
			<div class="izl-section-head">
				<h2><?php esc_html_e( 'Supplies', 'izeltlab' ); ?></h2>
				<a class="izl-section-link" href="<?php echo esc_url( get_term_link( $supplies ) ); ?>"><?php esc_html_e( 'All supplies', 'izeltlab' ); ?> →</a>
			</div>
			<?php izl_product_row( $supply_ids ); ?>
		</section>
	<?php endif; ?>

	<section class="izl-about">
		<h2><?php echo esc_html( izl_mod( 'izl_about_title' ) ); ?></h2>
		<div class="izl-about-text"><?php echo wp_kses_post( wpautop( izl_mod( 'izl_about_text' ) ) ); ?></div>
	</section>

</div>
<?php
get_footer();
