<?php
// ==========================================================================
//  FILE: front-page.php   (Ízeltláb theme)
//  WHAT: The front page's layout: hero text and cards, then the sections with product rows.
//         3.17.0: PC shows two tiles (Isopods, Supplies) under the text instead of the two buttons.
//         3.21.1 (Dan, 2026-11-24): back to these two only (3.21.0 showed every group here).
//  SEEN: The front page.
// ==========================================================================

/**
 * The front page: up to 3 Codex cards turning on a carousel next to the title, the newest isopods, the supplies and a few words about the breeder.
 * The texts are set under Appearance → Customize → Ízeltláb front page.
 *
 * @package izeltlab
 */

get_header();

$isopods  = izl_isopods_url();
$supplies = izl_supplies_term();
$cards    = izl_hero_products();
$hero     = $cards ? $cards[0] : 0;
// 3.1.0 gave all hero cards' first photos top priority so they arrived together. 3.16.0: only the front card's photo
// has it again (Codex's own default, fsz_high_cards 1): the front card appears as soon as its photo is in and the back
// cards fade in after (carousel.js together()), so the front photo should not share the line with the other two.
?>
<div class="izl-home">

	<section class="izl-hero<?php echo $hero ? '' : ' no-card'; ?>">
		<div class="izl-hero-copy">
			<p class="izl-hero-kicker"><?php echo esc_html( izl_mod( 'izl_hero_kicker' ) ); ?></p>
			<h1><?php echo esc_html( izl_mod( 'izl_hero_title' ) ); ?></h1>
			<?php izl_hero_title_script(); // 3.15.0: the title is fitted right here, before the page is first drawn ?>
			<div class="izl-hero-text"><?php echo wp_kses_post( wpautop( izl_mod( 'izl_hero_text' ) ) ); ?></div>
			<?php // 3.17.0 (Dan, 2026-11-19, mock F): PC shows two big tiles instead of the two buttons (style.css 3.17.0); phones keep the buttons. ?>
			<?php if ( $isopods || $supplies ) : ?>
				<div class="izl-htiles">
					<?php if ( $isopods ) : ?>
						<a class="izl-htile is-y" href="<?php echo esc_url( $isopods ); ?>"><i><svg width="34" height="22" viewBox="0 0 40 24" aria-hidden="true" focusable="false"><path d="M6 20C6 9 14 4 22 4s14 5 14 16z"/><path d="M14 6v14M20 4v16M26 4v16M31 7v13M6 14q-4-3-5-8"/></svg></i><span><b><?php esc_html_e( 'Isopods', 'izeltlab' ); ?></b><small><?php esc_html_e( 'Beginner species and rarities', 'izeltlab' ); ?></small></span></a>
					<?php endif; ?>
					<?php if ( $supplies ) : ?>
						<a class="izl-htile" href="<?php echo esc_url( get_term_link( $supplies ) ); ?>"><i><svg width="26" height="26" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 19C5 10 11 5 20 4c-1 9-6 15-15 15z"/><path d="M5 19l8-8"/></svg></i><span><b><?php esc_html_e( 'Supplies', 'izeltlab' ); ?></b><small><?php esc_html_e( 'Hideouts, leaf litter, food', 'izeltlab' ); ?></small></span></a>
					<?php endif; ?>
				</div>
			<?php endif; ?>
			<p class="izl-hero-btns">
				<?php if ( $isopods ) : ?>
					<a class="izl-btn has-bug" href="<?php echo esc_url( $isopods ); ?>"><?php esc_html_e( 'Isopods', 'izeltlab' ); ?><?php izl_bug_icon(); ?></a>
				<?php endif; ?>
				<?php if ( $supplies ) : ?>
					<?php // 3.11.0 (Dan, 2026-11-18): the second button leads to the supplies (was "Kezdőknek"). ?>
					<a class="izl-btn is-alt" href="<?php echo esc_url( get_term_link( $supplies ) ); ?>"><?php esc_html_e( 'Supplies', 'izeltlab' ); ?></a>
				<?php endif; ?>
			</p>
		</div>
		<?php if ( $hero ) : ?>
			<div class="izl-hero-card">
				<?php function_exists( 'izl_home_edit_panel' ) && izl_home_edit_panel(); ?>
				<?php if ( count( $cards ) > 1 ) : ?>
					<?php // 3.1.0: hide the cards until all are ready (carousel.js together() shows them; here the 2 s safety stop). ?>
					<script>document.documentElement.classList.add('izl-hero-wait');setTimeout(function(){document.documentElement.classList.remove('izl-hero-wait')},2000)</script>
					<div class="izl-carousel" style="--izl-fx:<?php echo esc_attr( izl_card_fx_strength() / 100 ); ?>" role="group" aria-roledescription="carousel" aria-label="<?php esc_attr_e( 'Featured species', 'izeltlab' ); ?>">
						<?php foreach ( $cards as $i => $id ) : ?>
							<div class="izl-slot<?php echo $i ? '' : ' is-front'; ?>" data-pos="<?php echo (int) $i; ?>" data-href="<?php echo esc_url( get_permalink( $id ) ); ?>"<?php echo $i ? ' aria-hidden="true"' : ''; ?>><?php echo do_shortcode( '[codex id="' . (int) $id . '"]' ); ?></div>
						<?php endforeach; ?>
					</div>
				<?php else : ?>
					<div class="izl-hero-single" data-href="<?php echo esc_url( get_permalink( $hero ) ); ?>"><?php echo do_shortcode( '[codex id="' . (int) $hero . '"]' ); ?></div>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	</section>
	<?php
	if ( $hero ) {
		izl_hero_scripts(); // 2.5.0: right here, so the cards are placed before the page is first drawn
		if ( function_exists( 'izl_first_end' ) ) {
			izl_first_end(); // 3.34.0: the first frame waits for the hero up to here (inc/speed.php section 9)
		}
	}
	?>

	<?php $newest = izl_codex_product_ids( 4 ); ?>
	<?php if ( $newest ) : ?>
		<section class="izl-section">
			<div class="izl-section-head">
				<h2><?php esc_html_e( 'Newest isopods', 'izeltlab' ); ?></h2>
				<a class="izl-section-link is-btn" href="<?php echo esc_url( izl_all_products_url() ); ?>"><?php esc_html_e( 'All products', 'izeltlab' ); ?> →</a>
			</div>
			<?php izl_product_row( $newest ); ?>
		</section>
	<?php endif; ?>

	<?php $supply_ids = $supplies ? izl_category_product_ids( IZL_SUPPLIES ) : array(); ?>
	<?php if ( $supply_ids ) : ?>
		<section class="izl-section">
			<div class="izl-section-head">
				<h2><?php esc_html_e( 'Supplies', 'izeltlab' ); ?></h2>
				<a class="izl-section-link" href="<?php echo esc_url( get_term_link( $supplies ) ); ?>"><?php esc_html_e( 'All supplies', 'izeltlab' ); ?> →</a>
			</div>
			<?php izl_product_row( $supply_ids ); ?>
		</section>
	<?php endif; ?>

	<section class="izl-about">
		<h2><?php echo esc_html( izl_mod( 'izl_about_title' ) ); ?></h2>
		<div class="izl-about-text"><?php echo wp_kses_post( wpautop( izl_mod( 'izl_about_text' ) ) ); ?></div>
	</section>

</div>
<?php
get_footer();
