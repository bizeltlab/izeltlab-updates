<?php
/**
 * Shop breadcrumb, as a strip under the header (1.7.11).
 *
 * Same as WooCommerce's own template, with two changes: on a product page the product itself is left out (the card
 * already shows its name), so its group or genus is the last step and stays a link; and the last step gets the
 * is-last class for the yellow highlight. The structured data for search engines is built from the full trail before
 * this template runs, so it still lists the product.
 *
 * @package Izeltlab
 * @version 2.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $breadcrumb ) ) {
	return;
}

$izl_product = is_product() && count( $breadcrumb ) > 1;
if ( $izl_product ) {
	array_pop( $breadcrumb );
}
$izl_last = count( $breadcrumb ) - 1;

echo $wrap_before; // phpcs:ignore WordPress.Security.EscapeOutput
echo '<span class="izl-crumb-mark" aria-hidden="true">&#9656;</span>';

foreach ( $breadcrumb as $key => $crumb ) {
	$is_last = $izl_last === $key;

	// 1.7.19: the first step (Home) and its arrow in one span, so a phone product page can leave them out (the logo goes home).
	if ( 0 === $key && ! $is_last ) {
		echo '<span class="izl-crumb-home">';
	}
	echo $before; // phpcs:ignore WordPress.Security.EscapeOutput

	if ( ! empty( $crumb[1] ) && ( ! $is_last || $izl_product ) ) {
		echo '<a href="' . esc_url( $crumb[1] ) . '"' . ( $is_last ? ' class="is-last"' : '' ) . '>' . esc_html( $crumb[0] ) . '</a>';
	} else {
		echo '<span class="is-last" aria-current="page">' . esc_html( $crumb[0] ) . '</span>';
	}

	echo $after; // phpcs:ignore WordPress.Security.EscapeOutput

	if ( ! $is_last ) {
		echo $delimiter; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	if ( 0 === $key && ! $is_last ) {
		echo '</span>';
	}
}

echo $wrap_after; // phpcs:ignore WordPress.Security.EscapeOutput
