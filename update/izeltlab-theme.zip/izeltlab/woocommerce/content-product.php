<?php
/**
 * One product tile on the shop, category, search and front page lists (built in functions.php: izl_product_tile).
 *
 * @package izeltlab
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}

izl_product_tile( $product );
