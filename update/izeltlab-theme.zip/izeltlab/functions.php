<?php
// ==========================================================================
//  FILE: functions.php   (Ízeltláb theme)
//  WHAT: The theme's starting point. It only sets the version and loads the files in inc/, one file per feature.
//        Storefront does the shop work (cart, checkout, account); this theme changes the look, the header, the
//        product tiles, the front page and the product page. With the Codex plugin on, tiles and pages show the
//        Codex number, difficulty and colour of each species.
//  WHERE IS WHAT: read ARCHITECTURE.md in this folder ("I want to change X → open file Y").
//  ORDER MATTERS: the files below are loaded top to bottom. Do not reorder them.
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'IZL_VERSION', '3.0.0' );

$izl_inc = __DIR__ . '/inc/';

// True when the visitor carries a WordPress login cookie (or the request is a dashboard one). The ADMIN ONLY files
// below are loaded only then; each of them still checks the user's real rights before it does anything.
function izl_editor_may_be_here() {
	if ( is_admin() ) {
		return true;
	}
	foreach ( array_keys( $_COOKIE ) as $name ) {
		if ( 0 === strpos( (string) $name, 'wordpress_logged_in_' ) ) {
			return true;
		}
	}
	return false;
}

// ==========================================================================
//  1. Basics every other file uses
// ==========================================================================

require_once $izl_inc . 'minified-files.php'; // which copy of a stylesheet or script shoppers get

// The shop's rules and data (ship days, holidays, packs, free shipping, whole forints, photo frames). The same file is
// in the Ízeltláb Bolt plugin; whichever loads first runs, so the shop works with or without the plugin.
if ( ! defined( 'IZL_CORE' ) ) { // the Ízeltláb Bolt plugin already loaded its copy
	require_once $izl_inc . 'shop-core.php';
}

require_once $izl_inc . 'helpers.php'; // theme setup, colours, isopod list address, Codex levels

// ==========================================================================
//  2. The whole site: look, styles, layout, top bar, titles
// ==========================================================================

require_once $izl_inc . 'look.php';        // colours stay the shop's own, phone/PC switch, logo and icons
require_once $izl_inc . 'styles.php';      // stylesheets, fonts, front page scripts
require_once $izl_inc . 'unused-files.php'; // leaves out Storefront files the shop does not use
require_once $izl_inc . 'layout.php';      // full-width pages, tiles per row
require_once $izl_inc . 'site-header.php'; // top bar: logo, menu, search / account / cart
require_once $izl_inc . 'titles.php';      // breadcrumbs, shop title, footer credit off

// ==========================================================================
//  3. Shop lists
// ==========================================================================

require_once $izl_inc . 'shop-list.php'; // difficulty pills and product tiles
if ( izl_editor_may_be_here() ) {
	require_once $izl_inc . 'edit-new-product.php'; // ADMIN ONLY: "New product" bar, draft bar
}

// ==========================================================================
//  4. Front page
// ==========================================================================

require_once $izl_inc . 'front-page.php'; // texts, hero cards, product rows, Customizer panel
if ( izl_editor_may_be_here() ) {
	require_once $izl_inc . 'edit-front-page.php'; // ADMIN ONLY: "Edit cards" panel
}

// ==========================================================================
//  5. Product page
// ==========================================================================

require_once $izl_inc . 'product-page.php';   // layout: buy box next to the card, "Tedd mellé" supplies
require_once $izl_inc . 'product-texts.php';  // sales line, tag chips, pack question
require_once $izl_inc . 'product-ticket.php'; // stock stamp, shipping lines, price row, packs, quantity
require_once $izl_inc . 'product-trust.php';  // trust points, common questions, cart button text
require_once $izl_inc . 'product-script.php'; // loads assets/product.js, Customizer panel
if ( izl_editor_may_be_here() ) {
	require_once $izl_inc . 'edit-buy-box.php'; // ADMIN ONLY: "Edit buy box" button and data
}
require_once $izl_inc . 'product-row.php';    // supply pages, the row of tiles under a product
require_once $izl_inc . 'photos.php';         // Edit photos dialog (server side) and the photo frames
require_once $izl_inc . 'product-fonts.php';  // fonts fetched early on product pages

// ==========================================================================
//  6. Other pages and tools
// ==========================================================================

require_once $izl_inc . 'launch.php'; // cart, checkout, thank-you, 404, footer, account, login, mini cart
require_once $izl_inc . 'swift.php';  // smooth product page opening on phones
require_once $izl_inc . 'finder.php'; // the header search

// Updates from the shop's GitHub repository (Settings → Ízeltláb updates), shared with Codex and Bolt.
require_once $izl_inc . 'updater.php';
IZL_Updater::add( 'theme', 'theme', basename( get_stylesheet_directory() ), 'Ízeltláb theme', IZL_VERSION );

unset( $izl_inc );
