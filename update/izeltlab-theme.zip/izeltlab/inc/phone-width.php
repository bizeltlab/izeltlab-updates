<?php
// ==========================================================================
//  FILE: inc/phone-width.php   (Ízeltláb theme)
//  WHAT: The phone layout runs up to 1023px wide (since 3.11.0): Storefront's own stylesheets get the same line, from
//        a copy made once in the uploads folder.
//  SEEN: Windows and tablets between 768 and 1023px wide (every page): they get the phone layout.
//  SWITCH OFF: add_filter( 'izl_phone_width_copies', '__return_false' );
//  SECTIONS IN THIS FILE:
//    1. Storefront's stylesheets with the 1024px line
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Storefront's stylesheets with the 1024px line
// ==========================================================================
//
// 3.11.0 (Dan, 2026-11-18): between 768 and 1023px wide the computer layout was cramped (the product page's guarantee
// column squeezed between the card and the buy box), so the phone layout now runs up to 1023px (style.css, Codex,
// the scripts: 767/768 became 1023/1024) and tablets get it too (inc/look.php). Storefront's style.css and
// woocommerce.css switch to their computer layout at 768px (floats, columns, widths); left as they are, they would
// pull the phone layout apart in that band. So the shop loads a copy of each with that line moved to 1024px. Nothing
// else in them changes; relative image addresses are made absolute, so the copy works from the uploads folder.
// The copy is made once and named after Storefront's file and this theme's version, so a Storefront or theme update
// makes a new one. If the uploads folder cannot be written, Storefront's own file loads, as before.
add_action( 'wp_enqueue_scripts', function () {
	if ( ! apply_filters( 'izl_phone_width_copies', true ) || 'storefront' !== basename( get_template_directory() ) || is_rtl() ) {
		return;
	}
	$styles = wp_styles();
	foreach ( array( 'storefront-style' => 'style.css', 'storefront-woocommerce-style' => 'assets/css/woocommerce/woocommerce.css' ) as $handle => $rel ) {
		if ( empty( $styles->registered[ $handle ] ) ) {
			continue;
		}
		$url = izl_phone_width_copy( $rel );
		if ( $url ) {
			$styles->registered[ $handle ]->src = $url;
			$styles->registered[ $handle ]->ver = null; // the file name carries the version
		}
	}
}, 190 );

// The copy's address (made now if missing), or '' when it cannot be made.
function izl_phone_width_copy( $rel ) {
	$src = get_template_directory() . '/' . $rel;
	if ( ! is_readable( $src ) ) {
		return '';
	}
	$up = wp_upload_dir( null, false );
	if ( ! empty( $up['error'] ) || empty( $up['basedir'] ) ) {
		return '';
	}
	$key  = substr( md5( $rel . '|' . filesize( $src ) . '|' . filemtime( $src ) . '|' . IZL_VERSION ), 0, 10 );
	$name = 'izeltlab-css/sf-' . sanitize_file_name( basename( $rel, '.css' ) ) . '-' . $key . '.css';
	$file = trailingslashit( $up['basedir'] ) . $name;
	if ( ! is_readable( $file ) ) {
		$css = file_get_contents( $src ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! is_string( $css ) || '' === $css ) {
			return '';
		}
		$css = preg_replace( '/min-width:\s*768px/', 'min-width:1024px', $css );
		$css = preg_replace( '/max-width:\s*767px/', 'max-width:1023px', $css );
		// relative addresses (url(../../../assets/images/…)) made absolute, from the file's own folder
		$base = trailingslashit( get_template_directory_uri() ) . ( '.' === dirname( $rel ) ? '' : dirname( $rel ) . '/' );
		$css  = preg_replace_callback( '/url\(\s*([\'"]?)(?!data:|https?:|\/)([^\'")]+)\1\s*\)/i', function ( $m ) use ( $base ) {
			return 'url(' . $m[1] . izl_phone_width_resolve( $base, $m[2] ) . $m[1] . ')';
		}, $css );
		if ( ! wp_mkdir_p( dirname( $file ) ) ) {
			return '';
		}
		$tmp = $file . '.' . wp_rand( 1000, 9999 ) . '.tmp';
		if ( false === file_put_contents( $tmp, $css ) || ! @rename( $tmp, $file ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return '';
		}
	}
	return set_url_scheme( trailingslashit( $up['baseurl'] ) . $name );
}

// "https://…/storefront/assets/css/woocommerce/" + "../../../assets/images/a.svg" -> "https://…/storefront/assets/images/a.svg"
function izl_phone_width_resolve( $base, $path ) {
	$parts = wp_parse_url( $base );
	$root  = $parts['scheme'] . '://' . $parts['host'] . ( isset( $parts['port'] ) ? ':' . $parts['port'] : '' );
	$segs  = explode( '/', trim( isset( $parts['path'] ) ? $parts['path'] : '', '/' ) );
	foreach ( explode( '/', $path ) as $seg ) {
		if ( '..' === $seg ) {
			array_pop( $segs );
		} elseif ( '.' !== $seg && '' !== $seg ) {
			$segs[] = $seg;
		}
	}
	return $root . '/' . implode( '/', $segs );
}
