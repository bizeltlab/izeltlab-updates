<?php
// ==========================================================================
//  FILE: inc/phone-width.php   (Ízeltláb theme)
//  WHAT: The phone layout runs up to 1023px wide (since 3.11.0): Storefront's own stylesheets get the same line, from
//        a copy made once in the uploads folder.
//  SEEN: Windows and tablets between 768 and 1023px wide (every page): they get the phone layout.
//  SWITCH OFF: add_filter( 'izl_phone_width_copies', '__return_false' );
//  SECTIONS IN THIS FILE:
//    1. Storefront's stylesheets with the 1024px line
//    2. The copy made smaller (since 3.13.0)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Storefront's stylesheets with the 1024px line
// ==========================================================================
//
// 3.11.0 (Dan, 2026-11-18): between 768 and 1023px wide the computer layout was cramped (the product page's guarantee
// column squeezed between the card and the buy box), so the phone layout now runs up to 1023px (style.css, Codex,
// the scripts: 767/768 became 1023/1024) and tablets get it too (inc/look.php). Storefront's style.css and
// woocommerce.css switch to their computer layout at 768px (floats, columns, widths); left as they are, they would
// pull the phone layout apart in that band. So the shop loads a copy of each with that line moved to 1024px. Nothing
// else in them changes; relative image addresses are made absolute, so the copy works from the uploads folder.
// The copy is made once and named after Storefront's file and this theme's version, so a Storefront or theme update
// makes a new one. If the uploads folder cannot be written, Storefront's own file loads, as before.
add_action( 'wp_enqueue_scripts', function () {
	if ( ! apply_filters( 'izl_phone_width_copies', true ) || 'storefront' !== basename( get_template_directory() ) || is_rtl() ) {
		return;
	}
	$styles = wp_styles();
	foreach ( array( 'storefront-style' => 'style.css', 'storefront-woocommerce-style' => 'assets/css/woocommerce/woocommerce.css' ) as $handle => $rel ) {
		if ( empty( $styles->registered[ $handle ] ) ) {
			continue;
		}
		$url = izl_phone_width_copy( $rel );
		if ( $url ) {
			$styles->registered[ $handle ]->src = $url;
			$styles->registered[ $handle ]->ver = null; // the file name carries the version
		}
	}
}, 190 );

// The copy's address (made now if missing), or '' when it cannot be made.
function izl_phone_width_copy( $rel ) {
	$src = get_template_directory() . '/' . $rel;
	if ( ! is_readable( $src ) ) {
		return '';
	}
	$up = wp_upload_dir( null, false );
	if ( ! empty( $up['error'] ) || empty( $up['basedir'] ) ) {
		return '';
	}
	$key  = substr( md5( $rel . '|' . filesize( $src ) . '|' . filemtime( $src ) . '|' . IZL_VERSION ), 0, 10 );
	$name = 'izeltlab-css/sf-' . sanitize_file_name( basename( $rel, '.css' ) ) . '-' . $key . '.css';
	$file = trailingslashit( $up['basedir'] ) . $name;
	if ( ! is_readable( $file ) ) {
		$css = file_get_contents( $src ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! is_string( $css ) || '' === $css ) {
			return '';
		}
		$css = izl_css_slim( $css ); // 3.13.0: smaller (comments, spaces and the rules of parts the shop never shows)
		$css = preg_replace( '/min-width:\s*768px/', 'min-width:1024px', $css );
		$css = preg_replace( '/max-width:\s*767px/', 'max-width:1023px', $css );
		// relative addresses (url(../../../assets/images/…)) made absolute, from the file's own folder
		$base = trailingslashit( get_template_directory_uri() ) . ( '.' === dirname( $rel ) ? '' : dirname( $rel ) . '/' );
		$css  = preg_replace_callback( '/url\(\s*([\'"]?)(?!data:|https?:|\/)([^\'")]+)\1\s*\)/i', function ( $m ) use ( $base ) {
			return 'url(' . $m[1] . izl_phone_width_resolve( $base, $m[2] ) . $m[1] . ')';
		}, $css );
		if ( ! wp_mkdir_p( dirname( $file ) ) ) {
			return '';
		}
		$tmp = $file . '.' . wp_rand( 1000, 9999 ) . '.tmp';
		if ( false === file_put_contents( $tmp, $css ) || ! @rename( $tmp, $file ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return '';
		}
	}
	return set_url_scheme( trailingslashit( $up['baseurl'] ) . $name );
}

// "https://…/storefront/assets/css/woocommerce/" + "../../../assets/images/a.svg" -> "https://…/storefront/assets/images/a.svg"
function izl_phone_width_resolve( $base, $path ) {
	$parts = wp_parse_url( $base );
	$root  = $parts['scheme'] . '://' . $parts['host'] . ( isset( $parts['port'] ) ? ':' . $parts['port'] : '' );
	$segs  = explode( '/', trim( isset( $parts['path'] ) ? $parts['path'] : '', '/' ) );
	foreach ( explode( '/', $path ) as $seg ) {
		if ( '..' === $seg ) {
			array_pop( $segs );
		} elseif ( '.' !== $seg && '' !== $seg ) {
			$segs[] = $seg;
		}
	}
	return $root . '/' . implode( '/', $segs );
}

// ==========================================================================
//  The copy made smaller (since 3.13.0)
// ==========================================================================

// 3.13.0 (Dan's PageSpeed list: "unused CSS"): the copy leaves out Storefront's comments and extra spaces, and the rules
// of Storefront parts this shop never prints (the theme takes them out: Storefront's menus and menu button, its header
// cart, its previous / next product photos, the "You're viewing" bar, its home page sections). A rule that also styles
// something else keeps that part. Every other rule stays, in the same order.
function izl_css_slim( $css ) {
	$css = preg_replace( '#/\*.*?\*/#s', '', $css );
	$css = preg_replace( '/\s+/', ' ', $css );
	$css = preg_replace( '/\s*([{};])\s*/', '$1', $css );
	$css = preg_replace( '/;}/', '}', $css );
	$dead = (array) apply_filters( 'izl_css_slim_dead', array( 'site-header-cart', 'storefront-product-pagination', 'main-navigation', 'menu-toggle', 'handheld-navigation', 'secondary-navigation', 'storefront-primary-navigation', 'storefront-product-section', 'storefront-sticky-add-to-cart' ) );
	if ( ! $dead ) {
		return trim( $css );
	}
	$re  = '/\.(' . implode( '|', array_map( 'preg_quote', $dead ) ) . ')(?![\w-])/';
	$out = izl_css_slim_block( $css, 0, $re );
	return trim( $out[0] );
}

// Walks one level of rules from $at; returns array( kept text, position after the closing brace or the end ).
function izl_css_slim_block( $css, $at, $re ) {
	$out = '';
	$len = strlen( $css );
	while ( $at < $len ) {
		if ( '}' === $css[ $at ] ) {
			return array( $out, $at + 1 );
		}
		$open = strpos( $css, '{', $at );
		$semi = strpos( $css, ';', $at );
		if ( false !== $semi && ( false === $open || $semi < $open ) ) { // @charset / @import ...;
			$out .= substr( $css, $at, $semi + 1 - $at );
			$at   = $semi + 1;
			continue;
		}
		if ( false === $open ) {
			return array( $out . substr( $css, $at ), $len );
		}
		$head = trim( substr( $css, $at, $open - $at ) );
		if ( preg_match( '/^@(media|supports|document|layer|container)\b/i', $head ) ) {
			$in = izl_css_slim_block( $css, $open + 1, $re );
			if ( '' !== $in[0] ) {
				$out .= $head . '{' . $in[0] . '}';
			}
			$at = $in[1];
			continue;
		}
		// a plain rule, @font-face or @keyframes: its body runs to the matching brace
		$depth = 0;
		for ( $i = $open; $i < $len; $i++ ) {
			if ( '{' === $css[ $i ] ) {
				$depth++;
			} elseif ( '}' === $css[ $i ] && 0 === --$depth ) {
				break;
			}
		}
		$body = substr( $css, $open, $i + 1 - $open );
		$at   = $i + 1;
		if ( '@' !== substr( $head, 0, 1 ) ) {
			$keep = array();
			foreach ( izl_css_split_selectors( $head ) as $sel ) {
				if ( ! preg_match( $re, $sel ) ) {
					$keep[] = $sel;
				}
			}
			if ( ! $keep ) {
				continue;
			}
			$head = implode( ',', $keep );
		}
		$out .= $head . $body;
	}
	return array( $out, $at );
}

// "a, b:not(.c, .d)" -> array( "a", "b:not(.c, .d)" ): commas inside brackets do not split.
function izl_css_split_selectors( $head ) {
	$parts = array();
	$depth = 0;
	$cur   = '';
	foreach ( str_split( $head ) as $ch ) {
		if ( '(' === $ch || '[' === $ch ) {
			$depth++;
		} elseif ( ')' === $ch || ']' === $ch ) {
			$depth--;
		}
		if ( ',' === $ch && 0 === $depth ) {
			$parts[] = trim( $cur );
			$cur     = '';
			continue;
		}
		$cur .= $ch;
	}
	$parts[] = trim( $cur );
	return array_filter( $parts, 'strlen' );
}

