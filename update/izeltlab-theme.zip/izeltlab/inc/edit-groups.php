<?php
// ==========================================================================
//  FILE: inc/edit-groups.php   (Ízeltláb theme)
//  WHAT: ADMIN ONLY. The Groups dialog (3.21.0, Dan 2026-11-24): add, rename, recolour, move and delete product groups
//        (categories) from the shop itself, and set the one order of the header's group buttons and the front page
//        tiles. The dialog itself is assets/groups-edit.js, its look assets/groups-edit.css.
//  SEEN: Only by logged-in shop managers: "✎ Groups" in the header's group bar (which set-up groups get a button, and
//        their order), "+ New group" / "✎ Groups" in the "New product" bar of the shop page (Minden termék), and
//        "✎ Edit this group" / "+ New subgroup" in that bar on a group page. 3.21.1 (Dan, 2026-11-24): new groups are
//        made only on the shop page, the header only picks from the groups already set up.
//  SECTIONS IN THIS FILE:
//    1. Who can, and the buttons that open the dialog
//    2. The dialog's data and files
//    3. Saving: a group, the order, deleting
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  1. Who can, and the buttons that open the dialog
// ==========================================================================

function izl_groups_can() {
	return is_user_logged_in() && current_user_can( 'manage_product_terms' );
}

// The header's group bar (PC): after the group buttons. Picks which set-up groups get a button, and their order.
function izl_groups_header_buttons() {
	if ( ! izl_groups_can() ) {
		return '';
	}
	return '<span class="izl-gd-open-wrap"><button type="button" class="izl-gd-open" data-izl-gd="list">✎ ' . esc_html__( 'Groups', 'izeltlab' ) . '</button></span>';
}

// The "New product" bar: on a group page this group and a new subgroup under it; on the shop page the dialog.
function izl_groups_bar_buttons() {
	if ( ! izl_groups_can() ) {
		return '';
	}
	if ( is_product_category() ) {
		$id = (int) get_queried_object_id();
		return '<button type="button" class="izl-gd-open" data-izl-gd="edit:' . $id . '">✎ ' . esc_html__( 'Edit this group', 'izeltlab' ) . '</button>'
			. '<button type="button" class="izl-gd-open" data-izl-gd="new:' . $id . '">+ ' . esc_html__( 'New subgroup', 'izeltlab' ) . '</button>';
	}
	// the shop page (Minden termék): the one place new groups are made (3.21.1). "✎ Groups" stays in the header only.
	return '<button type="button" class="izl-gd-open" data-izl-gd="new:0">+ ' . esc_html__( 'New group', 'izeltlab' ) . '</button>';
}

// ==========================================================================
//  2. The dialog's data and files
// ==========================================================================

// The card types a top group can have (Codex's set-up groups), as the dialog names them.
function izl_group_kinds() {
	return array(
		'isopoda'    => 'Isopods',
		'blattodea'  => 'Cockroaches',
		'collembola' => 'Springtails',
		'arachnida'  => 'Spiders',
	);
}

// The kind a top group has by its name alone (what "Automatic" means), without the one set in the dialog.
function izl_group_auto_kind( $term ) {
	remove_filter( 'fsz_group_kind', 'izl_group_kind_filter', 10 );
	$kind = function_exists( 'fsz_term_kind' ) ? fsz_term_kind( $term ) : '';
	add_filter( 'fsz_group_kind', 'izl_group_kind_filter', 10, 2 );
	return $kind;
}

// Products in a group itself (any status: drafts too), not counting its subgroups.
function izl_group_product_count( $term_id ) {
	$q = new WP_Query( array(
		'post_type'      => 'product',
		'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
		'posts_per_page' => 1,
		'fields'         => 'ids',
		'no_found_rows'  => false,
		'tax_query'      => array( array( 'taxonomy' => 'product_cat', 'terms' => (int) $term_id, 'include_children' => false ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
	) );
	return (int) $q->found_posts;
}

// The header key of a top group: "isopoda" for every isopod group (they share one button), else "id<term id>".
function izl_group_key( $term ) {
	return izl_top_key( $term ); // 3.22.0: one rule, in inc/site-header.php
}

function izl_groups_data() {
	$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'orderby' => 'name' ) );
	$terms = is_wp_error( $terms ) ? array() : $terms;
	$cfg   = izl_groups_cfg();
	$def   = (int) get_option( 'default_product_cat', 0 );
	$kids  = array();
	foreach ( $terms as $t ) {
		$kids[ (int) $t->parent ] = isset( $kids[ (int) $t->parent ] ) ? $kids[ (int) $t->parent ] + 1 : 1;
	}
	$names = array();
	foreach ( izl_cat_items( true ) as $item ) {
		$names[ $item['key'] ] = $item[0];
	}
	$list = array();
	foreach ( $terms as $t ) {
		$top  = ! $t->parent;
		$key  = $top ? izl_group_key( $t ) : '';
		$link = get_term_link( $t );
		$list[] = array(
			'id'     => (int) $t->term_id,
			'name'   => $t->name,
			'parent' => (int) $t->parent,
			'count'  => izl_group_product_count( $t->term_id ),
			'kids'   => isset( $kids[ (int) $t->term_id ] ) ? $kids[ (int) $t->term_id ] : 0,
			'link'   => is_wp_error( $link ) ? '' : $link,
			'desc'   => $t->description,
			'key'    => $key,
			'color'  => $top ? (string) sanitize_hex_color( (string) get_term_meta( $t->term_id, 'fsz_color', true ) ) : '',
			'kind'   => $top ? (string) get_term_meta( $t->term_id, 'izl_kind', true ) : '',
			'auto'   => $top ? izl_group_auto_kind( $t ) : '',
			'menu'   => $top && isset( $cfg['names'][ $key ] ) ? (string) $cfg['names'][ $key ] : '',
			'line'   => $top && isset( $cfg['lines'][ $key ] ) ? (string) $cfg['lines'][ $key ] : '',
			'locked' => (int) $t->term_id === $def ? 'default' : ( IZL_SUPPLIES === $t->slug ? 'supplies' : '' ),
		);
	}
	// every group that can have a header button (ticked or not, empty or not), in the header's order
	$order = array();
	foreach ( izl_cat_items( true ) as $item ) {
		$order[] = array( 'key' => $item['key'], 'label' => $item[0], 'empty' => (bool) $item['empty'], 'shown' => (bool) $item['shown'] );
	}
	// 3.22.0: every possible header button, groups and genera, in the header's order, with its own settings
	$buttons = array();
	foreach ( izl_header_buttons( true ) as $b ) {
		$buttons[] = array(
			'key'   => $b['key'],
			'type'  => $b['type'],
			'term'  => (int) $b['term'],
			'group' => $b['group'],
			'name'  => $b['name'], // its usual text (the group's standard word, the genus's name)
			'label' => $b['label'],
			'link'  => $b['link'],
			'where' => $b['where'],
			'empty' => (bool) $b['empty'],
			'shown' => (bool) $b['shown'],
			'count' => (int) $b['count'],
		);
	}
	return array(
		'ajax'   => admin_url( 'admin-ajax.php', 'relative' ),
		'nonce'  => wp_create_nonce( 'izl_groups' ),
		'here'   => is_product_category() ? (int) get_queried_object_id() : 0,
		'terms'  => $list,
		'order'  => $order,
		'buttons' => $buttons,
		'also'   => (object) $cfg['also'],
		'porder' => array_values( array_map( 'strval', $cfg['porder'] ) ), // 3.23.0: the phone menu's order
		'names'  => $names,
		'kinds'  => izl_group_kinds(),
		'device' => function_exists( 'fsz_opt' ) ? (string) sanitize_hex_color( fsz_opt( 'device' ) ) : '#1F8A8A',
		'presets' => function_exists( 'fsz_group_presets' ) ? fsz_group_presets() : array(),
	);
}

add_action( 'wp_enqueue_scripts', function () {
	if ( ! izl_groups_can() ) {
		return;
	}
	$uri = get_stylesheet_directory_uri() . '/';
	wp_enqueue_style( 'izeltlab-groups-edit', $uri . izl_min( 'assets/groups-edit.css' ), array(), IZL_VERSION );
	wp_enqueue_script( 'izeltlab-groups-edit', $uri . izl_min( 'assets/groups-edit.js' ), array(), IZL_VERSION, true );
}, 40 );

// The data, read by the dialog when it opens (printed once, at the page's end).
add_action( 'wp_footer', function () {
	if ( izl_groups_can() ) {
		echo '<script type="application/json" id="izl-groups-data">' . wp_json_encode( izl_groups_data() ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}, 5 );

// ==========================================================================
//  3. Saving: a group, the order, deleting
// ==========================================================================

function izl_groups_check() {
	if ( ! izl_groups_can() || ! check_ajax_referer( 'izl_groups', '_ajax_nonce', false ) ) {
		wp_send_json_error( __( 'You cannot change the groups.', 'izeltlab' ), 403 );
	}
}

// The Codex categories (Codex settings): a top group with a card type is one of them, so its species get the card.
function izl_codex_cat( $slug, $on ) {
	if ( ! function_exists( 'fsz_opt' ) || ! defined( 'FSZ_OPT' ) ) {
		return;
	}
	$opts  = fsz_opt();
	$slugs = array_values( array_filter( array_map( 'sanitize_title', explode( ',', (string) $opts['categories'] ) ) ) );
	$has   = in_array( $slug, $slugs, true );
	if ( $on === $has ) {
		return;
	}
	$slugs              = $on ? array_merge( $slugs, array( $slug ) ) : array_values( array_diff( $slugs, array( $slug ) ) );
	$opts['categories'] = implode( ', ', $slugs );
	update_option( FSZ_OPT, $opts );
}

// Every page shows the header's group buttons: the saved pages are dropped so the next visit draws them anew.
function izl_groups_changed() {
	if ( function_exists( 'wp_cache_clear_cache' ) ) { // WP Super Cache
		wp_cache_clear_cache();
	}
}

// A key renamed (a group that turns into an isopod group or back): its button text, tile line, place and tick go with it.
function izl_groups_cfg_move( $from, $to ) {
	$cfg = izl_groups_cfg();
	foreach ( array( 'names', 'lines' ) as $k ) {
		if ( isset( $cfg[ $k ][ $from ] ) ) {
			if ( '' !== $to && ! isset( $cfg[ $k ][ $to ] ) ) {
				$cfg[ $k ][ $to ] = $cfg[ $k ][ $from ];
			}
			unset( $cfg[ $k ][ $from ] );
		}
	}
	$swap         = function ( $key ) use ( $from, $to ) {
		return $key === $from ? $to : $key;
	};
	$cfg['order'] = array_values( array_unique( array_filter( array_map( $swap, $cfg['order'] ) ) ) );
	if ( is_array( $cfg['shown'] ) ) { // the header tick goes with it too (3.21.1)
		$cfg['shown'] = array_values( array_unique( array_filter( array_map( $swap, $cfg['shown'] ) ) ) );
	}
	update_option( 'izl_groups', $cfg, true );
}

add_action( 'wp_ajax_izl_group_save', function () {
	izl_groups_check();
	$in     = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification
	$id     = isset( $in['id'] ) ? absint( $in['id'] ) : 0;
	$name   = isset( $in['name'] ) ? trim( sanitize_text_field( $in['name'] ) ) : '';
	$parent = isset( $in['parent'] ) ? absint( $in['parent'] ) : 0;
	$desc   = isset( $in['desc'] ) ? wp_kses_post( trim( (string) $in['desc'] ) ) : '';
	if ( '' === $name ) {
		wp_send_json_error( __( 'The group needs a name.', 'izeltlab' ) );
	}
	$old = $id ? get_term( $id, 'product_cat' ) : null;
	if ( $id && ( ! $old || is_wp_error( $old ) ) ) {
		wp_send_json_error( __( 'This group is gone. Reload the page.', 'izeltlab' ) );
	}
	if ( $parent ) {
		$p = get_term( $parent, 'product_cat' );
		if ( ! $p || is_wp_error( $p ) || ( $id && ( $parent === $id || in_array( $id, array_map( 'intval', get_ancestors( $parent, 'product_cat', 'taxonomy' ) ), true ) ) ) ) {
			wp_send_json_error( __( 'A group cannot go under itself or its own subgroup.', 'izeltlab' ) );
		}
	}
	$was_parent = $old ? (int) $old->parent : 0;
	$old_chain  = $old ? array_map( 'intval', get_ancestors( $id, 'product_cat', 'taxonomy' ) ) : array();
	$old_top    = $old ? ( $old_chain ? get_term( (int) $old_chain[ count( $old_chain ) - 1 ], 'product_cat' ) : $old ) : null;
	$old_key    = $old && ! $was_parent ? izl_group_key( $old ) : '';
	$old_codex  = $old_top && ! is_wp_error( $old_top ) && function_exists( 'fsz_category_ids' ) && in_array( (int) $old_top->term_id, fsz_category_ids(), true );

	if ( $id ) {
		$r = wp_update_term( $id, 'product_cat', array( 'name' => $name, 'parent' => $parent, 'description' => $desc ) );
	} else {
		$r = wp_insert_term( $name, 'product_cat', array( 'parent' => $parent, 'description' => $desc ) );
	}
	if ( is_wp_error( $r ) ) {
		wp_send_json_error( $r->get_error_message() );
	}
	$id   = (int) $r['term_id'];
	$term = get_term( $id, 'product_cat' );

	// Moved: the products follow, their old upper groups off and the new ones on (a product sits in its whole chain).
	if ( $old && $was_parent !== $parent ) {
		$new_chain = array_map( 'intval', get_ancestors( $id, 'product_cat', 'taxonomy' ) );
		$tree      = array_merge( array( $id ), array_map( 'intval', (array) get_term_children( $id, 'product_cat' ) ) );
		$products  = get_posts( array(
			'post_type'      => 'product',
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'tax_query'      => array( array( 'taxonomy' => 'product_cat', 'terms' => $tree, 'include_children' => false ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
		) );
		$off = array_values( array_diff( $old_chain, $new_chain ) );
		foreach ( $products as $pid ) {
			if ( $off ) {
				wp_remove_object_terms( $pid, $off, 'product_cat' );
			}
			if ( $new_chain ) {
				wp_add_object_terms( $pid, $new_chain, 'product_cat' );
			}
			if ( function_exists( 'wc_delete_product_transients' ) ) {
				wc_delete_product_transients( $pid );
			}
		}
		if ( ! $was_parent && $old_key ) {
			// a top group went under another one: its own button and Codex entry go (the new top group covers it)
			izl_groups_cfg_move( $old_key, 'isopoda' === $old_key ? 'isopoda' : '' );
			izl_codex_cat( $term->slug, false );
			delete_term_meta( $id, 'izl_kind' ); // the group above decides now
		}
		if ( $was_parent && ! $parent && $old_top && ! is_wp_error( $old_top ) ) {
			// a subgroup became a group of its own: it keeps the card type, colour and Codex card it had under the old one
			$top_kind = function_exists( 'fsz_term_kind' ) ? fsz_term_kind( $old_top ) : '';
			if ( $top_kind && izl_group_auto_kind( $term ) !== $top_kind ) {
				update_term_meta( $id, 'izl_kind', $top_kind );
			}
			$c = (string) get_term_meta( $old_top->term_id, 'fsz_color', true );
			if ( $c && '' === (string) get_term_meta( $id, 'fsz_color', true ) ) {
				update_term_meta( $id, 'fsz_color', $c );
			}
			if ( $old_codex ) {
				izl_codex_cat( $term->slug, true );
			}
		}
	}

	// A top group's own settings: card type, colour, button text, front page line.
	if ( ! $parent ) {
		$kinds = izl_group_kinds();
		if ( isset( $in['kind'] ) ) {
			$kind = sanitize_key( $in['kind'] );
			$kind = isset( $kinds[ $kind ] ) || 'none' === $kind ? $kind : '';
			$had  = (string) get_term_meta( $id, 'izl_kind', true );
			if ( '' === $kind ) {
				delete_term_meta( $id, 'izl_kind' );
			} else {
				update_term_meta( $id, 'izl_kind', $kind );
			}
			$now = function_exists( 'fsz_term_kind' ) ? fsz_term_kind( $term ) : '';
			if ( ! $old || $had !== $kind ) {
				// a card type on = its species get the Codex card; "No Codex card" = they do not
				izl_codex_cat( $term->slug, '' !== $now && isset( $kinds[ $now ] ) );
				if ( '' !== $now && '' === (string) get_term_meta( $id, 'fsz_color', true ) && ! isset( $in['color'] ) && function_exists( 'fsz_seed_group_colors' ) ) {
					$presets = fsz_group_presets();
					if ( isset( $presets[ $now ] ) ) {
						update_term_meta( $id, 'fsz_color', $presets[ $now ] );
					}
				}
			}
		}
		if ( isset( $in['color'] ) ) {
			$c = sanitize_hex_color( (string) $in['color'] );
			if ( $c ) {
				update_term_meta( $id, 'fsz_color', $c );
			} else {
				delete_term_meta( $id, 'fsz_color' );
			}
		}
		$key = izl_group_key( $term );
		if ( $old_key && $old_key !== $key && $was_parent === $parent ) {
			izl_groups_cfg_move( $old_key, $key );
		}
		$cfg = izl_groups_cfg();
		foreach ( array( 'menu' => 'names', 'line' => 'lines' ) as $field => $k ) {
			if ( isset( $in[ $field ] ) ) {
				$v = trim( sanitize_text_field( $in[ $field ] ) );
				if ( '' === $v ) {
					unset( $cfg[ $k ][ $key ] );
				} else {
					$cfg[ $k ][ $key ] = mb_substr( $v, 0, 60 );
				}
			}
		}
		update_option( 'izl_groups', $cfg, true );
	}
	izl_groups_changed();
	$link = get_term_link( $term );
	wp_send_json_success( array( 'id' => $id, 'link' => is_wp_error( $link ) ? '' : $link ) );
} );

add_action( 'wp_ajax_izl_group_order', function () {
	izl_groups_check();
	$ok    = function ( $k ) {
		return 'isopoda' === $k || preg_match( '/^(id|g)\d+$/', $k ); // 3.22.0: g<term id> = a genus button
	};
	$keys  = isset( $_POST['keys'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['keys'] ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification
	$shown = isset( $_POST['shown'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['shown'] ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification
	$cfg   = izl_groups_cfg();
	$cfg['order'] = array_values( array_unique( array_filter( $keys, $ok ) ) );
	// 3.21.1: the groups ticked for the header (from now on a group shows only when ticked)
	$cfg['shown'] = array_values( array_unique( array_filter( $shown, $ok ) ) );
	// 3.22.0: each button's own text, address and place (PC / phone), and the genera shown in another group too
	$more = isset( $_POST['more'] ) ? json_decode( (string) wp_unslash( $_POST['more'] ), true ) : null; // phpcs:ignore WordPress.Security.NonceVerification,WordPress.Security.ValidatedSanitizedInput
	if ( is_array( $more ) ) {
		foreach ( array( 'names', 'links', 'where' ) as $k ) {
			$cfg[ $k ] = array();
			foreach ( isset( $more[ $k ] ) && is_array( $more[ $k ] ) ? $more[ $k ] : array() as $key => $v ) {
				$key = sanitize_key( $key );
				$v   = trim( (string) $v );
				if ( ! $ok( $key ) || '' === $v ) {
					continue;
				}
				if ( 'names' === $k ) {
					$cfg[ $k ][ $key ] = mb_substr( sanitize_text_field( $v ), 0, 60 );
				} elseif ( 'links' === $k ) {
					$url = esc_url_raw( $v );
					if ( '' !== $url ) {
						$cfg[ $k ][ $key ] = $url;
					}
				} elseif ( in_array( $v, array( 'pc', 'phone' ), true ) ) {
					$cfg[ $k ][ $key ] = $v;
				}
			}
		}
		$cfg['also'] = array();
		foreach ( isset( $more['also'] ) && is_array( $more['also'] ) ? $more['also'] : array() as $key => $ids ) {
			$key = sanitize_key( $key );
			if ( ! $ok( $key ) || 0 === strpos( $key, 'g' ) ) {
				continue; // only a group can hold another group's genus
			}
			$list = array();
			foreach ( (array) $ids as $id ) {
				$t = get_term( absint( $id ), 'product_cat' );
				if ( $t && ! is_wp_error( $t ) && $t->parent ) {
					$list[] = (int) $t->term_id;
				}
			}
			if ( $list ) {
				$cfg['also'][ $key ] = array_values( array_unique( $list ) );
			}
		}
		// 3.23.0: the phone menu's own order (the dialog's Phone tab); none sent = the header's order
		$cfg['porder'] = array();
		foreach ( isset( $more['porder'] ) && is_array( $more['porder'] ) ? $more['porder'] : array() as $key ) {
			$key = sanitize_key( (string) $key );
			if ( $ok( $key ) && ! in_array( $key, $cfg['porder'], true ) ) {
				$cfg['porder'][] = $key;
			}
		}
	}
	update_option( 'izl_groups', $cfg, true );
	izl_groups_changed();
	wp_send_json_success();
} );

add_action( 'wp_ajax_izl_group_delete', function () {
	izl_groups_check();
	$id   = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
	$term = $id ? get_term( $id, 'product_cat' ) : null;
	if ( ! $term || is_wp_error( $term ) ) {
		wp_send_json_error( __( 'This group is gone. Reload the page.', 'izeltlab' ) );
	}
	if ( (int) get_option( 'default_product_cat', 0 ) === $id || IZL_SUPPLIES === $term->slug ) {
		wp_send_json_error( __( 'This group cannot be deleted: the shop needs it.', 'izeltlab' ) );
	}
	if ( izl_group_product_count( $id ) || get_term_children( $id, 'product_cat' ) ) {
		wp_send_json_error( __( 'Only an empty group can be deleted: move its products and subgroups first.', 'izeltlab' ) );
	}
	$key    = $term->parent ? '' : izl_group_key( $term );
	$parent = $term->parent ? get_term( $term->parent, 'product_cat' ) : null;
	$r      = wp_delete_term( $id, 'product_cat' );
	if ( ! $r || is_wp_error( $r ) ) {
		wp_send_json_error( is_wp_error( $r ) ? $r->get_error_message() : __( 'Could not delete it.', 'izeltlab' ) );
	}
	izl_codex_cat( $term->slug, false );
	if ( $key && 'isopoda' !== $key ) {
		izl_groups_cfg_move( $key, '' );
	}
	izl_groups_changed();
	$link = $parent && ! is_wp_error( $parent ) ? get_term_link( $parent ) : home_url( '/' );
	wp_send_json_success( array( 'link' => is_wp_error( $link ) ? home_url( '/' ) : $link ) );
} );
