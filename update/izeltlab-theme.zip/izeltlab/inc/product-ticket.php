<?php
// ==========================================================================
//  FILE: inc/product-ticket.php   (Ízeltláb theme)
//  WHAT: The buy ticket: stock stamp, shipping lines, the price row, pack buttons and the quantity − / + buttons, printed ready by the server.
//  SEEN: Product pages: the white ticket with the price and Kosárba vele!.
//  SECTIONS IN THIS FILE:
//    1. Buy ticket: stock stamp, ship lines, price row
//    2. The buy ticket comes ready from the server (since 2.0.7)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Buy ticket: stock stamp, ship lines, price row
// ==========================================================================

define( 'IZL_LOW_STOCK', 3 ); // this many or fewer in stock: "Only N left"

// [state, label] for a product or a pack: in, low, back(order), out.
function izl_stock_state( $product ) {
	if ( ! $product->is_in_stock() ) {
		return array( 'out', __( 'Currently unavailable', 'izeltlab' ) );
	}
	if ( $product->is_on_backorder( 1 ) ) {
		return array( 'back', __( 'Available to order', 'izeltlab' ) );
	}
	$qty = $product->managing_stock() ? (int) $product->get_stock_quantity() : 0;
	if ( $qty > 0 && $qty <= IZL_LOW_STOCK ) {
		/* translators: %d: how many are left */
		return array( 'low', sprintf( __( 'Only %d left', 'izeltlab' ), $qty ) );
	}
	return array( 'in', __( 'In stock', 'izeltlab' ) );
}

// The stock stamp on the buy ticket, next to the price (follows the chosen pack, see product.js).
function izl_stock_line() {
	global $product;
	if ( ! $product instanceof WC_Product || '' === (string) $product->get_price() ) {
		return;
	}
	$s = izl_stock_state( $product );
	$in_form = izl_head_in_form( $product );
	if ( ! empty( $GLOBALS['izl_head_now'] ) ) {
		echo '<p class="izl-stock is-' . esc_attr( $s[0] ) . '" aria-live="polite"><i aria-hidden="true"></i><b>' . esc_html( $s[1] ) . '</b></p>';
		return; // 2.0.7: inside the buy ticket (the ink filter below is printed with the summary)
	}
	// 1.7.18: uneven ink for the stamp's frame (style.css .izl-stock::before); the letters stay crisp.
	echo '<svg class="izl-defs" width="0" height="0" aria-hidden="true" focusable="false"><filter id="izl-stock-ink" x="-10%" y="-20%" width="120%" height="140%" color-interpolation-filters="sRGB">'
		. '<feTurbulence type="fractalNoise" baseFrequency="0.05" numOctaves="3" seed="4" result="low"/>'
		. '<feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="9" result="hi"/>'
		. '<feTurbulence type="turbulence" baseFrequency="0.08" numOctaves="2" seed="2" result="warp"/>'
		. '<feDisplacementMap in="SourceGraphic" in2="warp" scale="2" xChannelSelector="R" yChannelSelector="G" result="rough"/>'
		. '<feColorMatrix in="low" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  1.6 0 0 0 0.05" result="lowA"/>'
		. '<feColorMatrix in="hi" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  2.2 0 0 0 -0.2" result="hiA"/>'
		. '<feComposite in="lowA" in2="hiA" operator="arithmetic" k1="1" k2="0" k3="0" k4="0" result="mask"/>'
		. '<feComposite in="rough" in2="mask" operator="in"/></filter></svg>';
	if ( $in_form ) {
		return;
	}
	echo '<p class="izl-stock is-' . esc_attr( $s[0] ) . '" aria-live="polite"><i aria-hidden="true"></i><b>' . esc_html( $s[1] ) . '</b></p>';
}

// The ship lines (1.7.0). The rule itself (izl_ship_plan(), holidays) is in inc/shop-core.php.
// The labels of the two ship lines: plural for live animals ("they"), singular for the rest.
function izl_ship_labels( $type ) {
	return 'live' === $type
		? array( 'arrive' => _x( 'With you', 'live animals', 'izeltlab' ), 'leaves' => _x( 'Sets off', 'live animals', 'izeltlab' ) )
		: array( 'arrive' => _x( 'With you', 'product', 'izeltlab' ), 'leaves' => _x( 'Sets off', 'product', 'izeltlab' ) );
}

function izl_nudge_text() {
	/* translators: %s: the cutoff time, e.g. 14:00 */
	return sprintf( __( 'If you order by %s, we ship it today!', 'izeltlab' ), sprintf( '%02d:00', IZL_SHIP_CUTOFF ) );
}

// On the buy ticket (1.7.18): "With you on Tuesday, Nov 3" first (big, green), then "Sets off today", the order-by
// nudge (11:00 until 14:00 on shipping days) and the free shipping amount. product.js works the same out again in the
// visitor's browser (Budapest time), so a cached page still shows the right days; what is printed here is for the
// moment before the script runs.
function izl_ship_lines() {
	global $product;
	if ( ! $product instanceof WC_Product || '' === (string) $product->get_price() || ! $product->is_in_stock() ) {
		return; // nothing to ship while it can't be ordered (no buy panel then either)
	}
	if ( izl_head_in_form( $product ) ) {
		return; // 2.0.7: printed inside the buy ticket instead
	}
	$type   = izl_ship_type( $product->get_id() );
	$plan   = izl_ship_plan( $type );
	$words  = izl_ship_words();
	$labels = izl_ship_labels( $type );
	$when   = 0 === $plan[2] ? $words['today'] : ( 1 === $plan[2] ? $words['tomorrow'] : $words['on'][ (int) $plan[0]->format( 'N' ) ] );
	echo '<div class="izl-ship-lines" data-ship="' . esc_attr( $type ) . '">';
	echo '<p class="izl-when izl-arrive"><span>' . esc_html( $labels['arrive'] ) . '</span><i aria-hidden="true"></i><b>' . esc_html( izl_arrive_words( $plan[1] ) ) . '</b></p>';
	echo '<p class="izl-when izl-leaves"><span>' . esc_html( $labels['leaves'] ) . '</span><i aria-hidden="true"></i><b>' . esc_html( $when ) . '</b></p>';
	echo '<p class="izl-nudge"' . ( izl_nudge_now( $type ) ? '' : ' hidden' ) . '><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg><span>' . esc_html( izl_nudge_text() ) . '</span></p>';
	$free = izl_free_ship();
	if ( $free > 0 ) {
		/* translators: %s: order amount, e.g. 18 000 Ft */
		echo '<p class="izl-free-ship">' . izl_trust_icon( 'truck' ) . wp_kses_post( sprintf( __( 'Free shipping over %s', 'izeltlab' ), wc_price( $free ) ) ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</div>';
}

// The stock line says it already, so no second "5 in stock" in the buy panel.
function izl_hide_wc_stock( $html, $product ) {
	return is_product() && get_queried_object_id() === $product->get_id() ? '' : $html;
}

add_action( 'wp_ajax_izl_product_text', function () {
	if ( ! check_ajax_referer( 'izl_product_text', false, false ) ) {
		wp_send_json_error( 'The security check ran out. Reload the page and try again.', 403 );
	}
	$id  = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
	$key = isset( $_POST['key'] ) ? sanitize_key( wp_unslash( $_POST['key'] ) ) : '';
	// 2.0.6: the product's own name (the hidden name in the admin strip); the web address stays as it is
	if ( '_izl_name' === $key && $id && current_user_can( 'edit_post', $id ) ) {
		$text    = isset( $_POST['text'] ) ? sanitize_text_field( wp_unslash( $_POST['text'] ) ) : '';
		$product = wc_get_product( $id );
		if ( ! $product || '' === $text ) {
			wp_send_json_error( '' === $text ? 'The name cannot be empty.' : 'Product not found.' );
		}
		$product->set_name( $text );
		$product->delete_meta_data( '_izl_auto_title' ); // named by hand: Publish keeps it
		$product->save();
		wp_send_json_success( array( 'text' => $product->get_name() ) );
	}
	if ( ! $id || ! current_user_can( 'edit_post', $id ) || ! isset( izl_product_texts()[ $key ] ) ) {
		wp_send_json_error( 'Not allowed.', 403 );
	}
	$text = isset( $_POST['text'] ) ? sanitize_text_field( wp_unslash( $_POST['text'] ) ) : '';
	update_post_meta( $id, $key, $text );
	if ( '' === $text && '_izl_pack_tip' === $key ) {
		$text = trim( (string) izl_pmod( 'izl_pack_tip' ) ); // back to the default tip
	} elseif ( '' === $text && '_izl_row_title' === $key ) {
		$text = izl_row_default( $id, true ); // back to the default title
	}
	wp_send_json_success( array( 'text' => $text ) );
} );

function izl_price_row() {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	// No price: WooCommerce shows no cart button either. Visitors see nothing here; whoever can edit the product sees why.
	if ( '' === (string) $product->get_price() ) {
		if ( current_user_can( 'edit_post', $product->get_id() ) ) {
			echo '<p class="izl-admin-hint">' . esc_html( $product->is_type( 'variable' ) ? 'No price yet, so there is no cart button. Give the packs a price: Edit product → Product data → Variations.' : 'No price yet, so there is no cart button. Add one: Edit product → Product data → General → Regular price.' ) . '</p>';
		}
		return;
	}
	if ( izl_head_in_form( $product ) ) {
		return; // 2.0.7: printed inside the buy ticket instead (izl_buy_head())
	}
	$note = array_filter( array( trim( (string) izl_pmod( 'izl_vat_note' ) ) ) );
	// 2.0.7: the chosen pack's price and the big number are printed here (product.js bigPrice() did it after load,
	// so a slow page showed WooCommerce's range "2 500 Ft – 12 500 Ft" first)
	$shown = $product->is_type( 'variable' ) ? izl_start_variation( $product ) : null;
	$html  = $shown ? $shown->get_price_html() : $product->get_price_html();
	$px    = izl_px_html( $shown ? $shown : $product, $html, $shown ? izl_start_pack_name( $product ) : '' );
	echo '<div class="izl-price-row' . ( $px ? ' is-px' : '' ) . '">';
	echo '<p class="' . esc_attr( apply_filters( 'woocommerce_product_price_class', 'price' ) ) . '">' . $html . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
	if ( $note ) {
		echo '<span class="izl-price-note">' . esc_html( implode( ' · ', $note ) ) . '</span>';
	}
	echo $px; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '</div>';
}

// ==========================================================================
//  The buy ticket comes ready from the server (since 2.0.7)
// ==========================================================================
// 
// Before 2.0.7 product.js built the ticket after the page loaded: it moved the price, the stock stamp and the shipping
// lines into the cart panel, turned the pack dropdown into buttons, made the big price and added − + to the quantity.
// On a slow connection people saw WooCommerce's plain box, then a half-built one, then the ticket. Now the server
// prints all of it in place; product.js finds the parts already there and only wires them up (and still builds them
// itself on any page this does not cover, e.g. a sold-out variable product).

// True when the price, stock stamp and shipping lines go inside the cart form (the form is on the page and has the
// panel), so the summary does not print them above it. Only for the page's own product, simple or with packs.
function izl_head_in_form( $product ) {
	if ( ! $product instanceof WC_Product || ! empty( $GLOBALS['izl_head_now'] ) || ! function_exists( 'is_product' ) || ! is_product() ) {
		return false;
	}
	static $memo = array();
	$id = (int) $product->get_id();
	if ( isset( $memo[ $id ] ) ) {
		return $memo[ $id ];
	}
	$ok = false;
	if ( $id === (int) get_queried_object_id() && '' !== (string) $product->get_price() && $product->is_purchasable() && $product->is_in_stock() ) {
		if ( $product->is_type( 'simple' ) ) {
			$ok = true;
		} elseif ( $product->is_type( 'variable' ) ) {
			foreach ( $product->get_visible_children() as $cid ) {
				$v = wc_get_product( $cid );
				if ( $v && $v->variation_is_visible() ) {
					$ok = true;
					break;
				}
			}
		}
	}
	return $memo[ $id ] = $ok;
}

add_action( 'woocommerce_before_add_to_cart_button', 'izl_buy_head', 1 );
function izl_buy_head() {
	global $product;
	static $done = false;
	if ( $done || ! izl_head_in_form( $product ) ) {
		return;
	}
	$done = true;
	$GLOBALS['izl_head_now'] = true;
	echo '<div class="izl-buy-head">';
	izl_price_row();
	izl_stock_line();
	izl_ship_lines();
	echo '</div>';
	$GLOBALS['izl_head_now'] = false;
}

// The pack the page starts on: the product's default, else (one choice to make) the first pack that can be bought,
// the same one product.js chips() used to pick after load. The pack dropdown starts on it too (filter below).
function izl_start_attrs( $product ) {
	if ( ! $product instanceof WC_Product_Variable ) {
		return array();
	}
	static $memo = array();
	$id = $product->get_id();
	if ( isset( $memo[ $id ] ) ) {
		return $memo[ $id ];
	}
	$attrs = $product->get_variation_attributes();
	$out   = array();
	foreach ( $attrs as $name => $options ) {
		$key = 'attribute_' . sanitize_title( $name );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$req = isset( $_REQUEST[ $key ] ) ? wc_clean( wp_unslash( $_REQUEST[ $key ] ) ) : null;
		$val = null !== $req ? $req : $product->get_variation_default_attribute( $name );
		if ( '' === (string) $val && 1 === count( $attrs ) ) {
			foreach ( $product->get_visible_children() as $cid ) {
				$v = wc_get_product( $cid );
				if ( $v && $v->variation_is_visible() && $v->is_purchasable() && $v->is_in_stock() ) {
					$va  = $v->get_variation_attributes();
					$val = isset( $va[ $key ] ) ? (string) $va[ $key ] : '';
					if ( '' !== $val ) {
						break;
					}
				}
			}
			// the first option in the dropdown's order when that variation covers "any"
			if ( '' === (string) $val && $options ) {
				$val = (string) reset( $options );
			}
		}
		if ( '' === (string) $val ) {
			return $memo[ $id ] = array(); // more than one choice left open: no start pack
		}
		$out[ $key ] = (string) $val;
	}
	return $memo[ $id ] = $out;
}

function izl_start_variation( $product ) {
	$attrs = izl_start_attrs( $product );
	if ( ! $attrs ) {
		return null;
	}
	$vid = WC_Data_Store::load( 'product' )->find_matching_product_variation( $product, $attrs );
	$v   = $vid ? wc_get_product( $vid ) : null;
	return $v && $v->variation_is_visible() && '' !== (string) $v->get_price() ? $v : null;
}

// The start pack's name as the pack buttons show it ("10 db"); only for the pack attribute.
function izl_start_pack_name( $product ) {
	$key   = 'attribute_' . sanitize_title( IZL_PACK_ATTR );
	$attrs = izl_start_attrs( $product );
	if ( ! isset( $attrs[ $key ] ) ) {
		return '';
	}
	$val = $attrs[ $key ];
	foreach ( $product->get_variation_attributes() as $name => $options ) {
		if ( 'attribute_' . sanitize_title( $name ) !== $key ) {
			continue;
		}
		if ( taxonomy_exists( $name ) ) {
			$term = get_term_by( 'slug', $val, $name );
			return $term ? (string) apply_filters( 'woocommerce_variation_option_name', $term->name, $term, $name, $product ) : '';
		}
		foreach ( $options as $o ) {
			if ( sanitize_title( $o ) === sanitize_title( $val ) || $o === $val ) {
				return (string) apply_filters( 'woocommerce_variation_option_name', $o, null, $name, $product );
			}
		}
	}
	return '';
}

// The big price (same markup product.js bigPrice() makes): one amount, not on sale. '' = WooCommerce's own price stays.
function izl_px_html( $p, $html, $pack ) {
	if ( 1 !== substr_count( $html, 'woocommerce-Price-amount' ) || false !== strpos( $html, '<del' ) ) {
		return '';
	}
	$num = number_format( (float) wc_get_price_to_display( $p ), wc_get_price_decimals(), wc_get_price_decimal_separator(), wc_get_price_thousand_separator() );
	$num = trim( preg_replace( '/[\s\x{00a0}\x{202f}]+/u', "\u{202f}", html_entity_decode( $num, ENT_QUOTES, 'UTF-8' ) ) );
	$cur = trim( html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' ) );
	$note = implode( ' · ', array_filter( array( $pack, trim( (string) izl_pmod( 'izl_vat_note' ) ) ) ) );
	return '<span class="izl-px"><span class="izl-px-num">' . esc_html( $num ) . '</span><span class="izl-px-side"><span class="izl-px-cur">' . esc_html( $cur ) . '</span><span class="izl-px-note">' . esc_html( $note ) . '</span></span></span>'
		. '<span class="izl-px-per">' . ( '' !== $pack ? esc_html( "/\u{00a0}" . $pack ) : '' ) . '</span>';
}

// The pack dropdown starts on the start pack, and the pack buttons are printed next to it (product.js chips() takes
// them over). The dropdown stays, hidden, for WooCommerce.
add_filter( 'woocommerce_dropdown_variation_attribute_options_args', function ( $args ) {
	if ( empty( $args['selected'] ) && ! empty( $args['product'] ) && izl_head_in_form( $args['product'] ) ) {
		$attrs = izl_start_attrs( $args['product'] );
		$key   = 'attribute_' . sanitize_title( $args['attribute'] );
		if ( isset( $attrs[ $key ] ) ) {
			$args['selected'] = $attrs[ $key ];
		}
	}
	return $args;
}, 20 );

add_filter( 'woocommerce_dropdown_variation_attribute_options_html', function ( $html, $args ) {
	if ( empty( $args['product'] ) || ! izl_head_in_form( $args['product'] ) || false !== strpos( $html, 'izl-chips-select' ) ) {
		return $html;
	}
	if ( ! preg_match_all( '/<option\s+value="([^"]*)"([^>]*)>(.*?)<\/option>/s', $html, $m, PREG_SET_ORDER ) ) {
		return $html;
	}
	$sel   = isset( $args['selected'] ) ? (string) $args['selected'] : '';
	$label = wc_attribute_label( $args['attribute'], $args['product'] );
	$row   = '<div class="izl-chips" role="radiogroup" aria-label="' . esc_attr( $label ) . '">';
	foreach ( $m as $o ) {
		if ( '' === $o[1] ) {
			continue;
		}
		$val  = html_entity_decode( $o[1], ENT_QUOTES, 'UTF-8' );
		$on   = '' !== $sel && ( $val === $sel || sanitize_title( $val ) === sanitize_title( $sel ) );
		$row .= '<button type="button" class="izl-chip" role="radio" data-value="' . esc_attr( $val ) . '" aria-checked="' . ( $on ? 'true' : 'false' ) . '">' . esc_html( wp_strip_all_tags( html_entity_decode( $o[3], ENT_QUOTES, 'UTF-8' ) ) ) . '</button>';
	}
	$row .= '</div>';
	$html = preg_replace( '/<select\s+([^>]*?)class="([^"]*)"/', '<select $1class="$2 izl-chips-select"', $html, 1, $n );
	if ( ! $n ) {
		$html = preg_replace( '/<select\s/', '<select class="izl-chips-select" ', $html, 1 );
	}
	return $row . $html;
}, 20, 2 );

// − and + around the quantity box (product.js stepper() made them after load); only in the page's own cart form.
add_action( 'woocommerce_before_add_to_cart_quantity', function () {
	global $product;
	$GLOBALS['izl_qty_here'] = izl_head_in_form( $product );
} );
add_action( 'woocommerce_after_add_to_cart_quantity', function () {
	$GLOBALS['izl_qty_here'] = false;
} );
add_filter( 'woocommerce_quantity_input_type', function ( $type ) {
	$GLOBALS['izl_qty_type'] = $type;
	return $type;
}, PHP_INT_MAX );
add_action( 'woocommerce_before_quantity_input_field', function () {
	if ( ! empty( $GLOBALS['izl_qty_here'] ) && 'number' === ( $GLOBALS['izl_qty_type'] ?? '' ) ) {
		echo '<button type="button" class="izl-qty-btn is-less" aria-label="' . esc_attr__( 'Decrease quantity', 'izeltlab' ) . '">−</button>';
	}
} );
add_action( 'woocommerce_after_quantity_input_field', function () {
	if ( ! empty( $GLOBALS['izl_qty_here'] ) && 'number' === ( $GLOBALS['izl_qty_type'] ?? '' ) ) {
		echo '<button type="button" class="izl-qty-btn is-more" aria-label="' . esc_attr__( 'Increase quantity', 'izeltlab' ) . '">+</button>';
	}
} );
