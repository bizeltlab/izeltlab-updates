<?php
// ==========================================================================
//  FILE: inc/product-row.php   (Ízeltláb theme)
//  WHAT: Supply product pages and the product row under a product (title, which products, the description, the tag pills).
//  SEEN: Product pages of supplies; the row of tiles under every product.
//  SECTIONS IN THIS FILE:
//    1. Product row, supply pages (reviews off: inc/shop-core.php) (since 1.7.0)
//    2. Sold out: what can be bought instead (since 3.20.0)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Product row, supply pages (reviews off: inc/shop-core.php) (since 1.7.0)
// ==========================================================================

// The row's title when the product has none of its own: species "Relatives" ("A rokonság", 3.25.0), or "Our other
// little critters" ("Szomszédok", 3.28.0; was "Többi kis lakónk") when its genus has no other species and the row shows its group instead;
// everything else "You might also need". $shop: in the shop's language even when saved from an English dashboard.
function izl_row_default( $product_id, $shop = false ) {
	if ( izl_is_codex( $product_id ) ) {
		$text = 'group' === izl_kin( $product_id )['by'] ? 'Our other little critters' : 'Relatives';
	} else {
		$text = 'You might also need';
	}
	return $shop ? izl_shop_text( $text ) : translate( $text, 'izeltlab' ); // phpcs:ignore WordPress.WP.I18n
}

// The title over the small-tile row: the product's own (Termék adatok, or a click on the title itself), else the
// default. 3.25.0: an own title that is just the old default ("Hasonló fajok") counts as none, so it follows the new one.
function izl_row_title() {
	$own = trim( (string) get_post_meta( get_the_ID(), '_izl_row_title', true ) );
	return '' !== $own && ! in_array( $own, array( 'Hasonló fajok', 'Similar species' ), true ) ? $own : izl_row_default( get_the_ID() );
}

// 3.25.0 (Dan, 2026-11-25): who a species' row shows: only species of its own genus (Boci → only Porcellio). When the
// genus has no other species (or the species has no genus), the species of its group instead, so the row is never
// empty. Returns array( 'ids' => [...], 'by' => 'genus'|'group' ). Worked out once per product and page view.
function izl_kin( $product_id ) {
	static $memo = array();
	$product_id = (int) $product_id;
	if ( isset( $memo[ $product_id ] ) ) {
		return $memo[ $product_id ];
	}
	$group = izl_group_term( $product_id );
	$genus = function_exists( 'izl_genus_term' ) ? izl_genus_term( $product_id, $group ) : null;
	$find  = function ( $slugs ) use ( $product_id ) {
		if ( ! $slugs ) {
			return array();
		}
		$ids = wc_get_products( array(
			'status'     => 'publish',
			'visibility' => 'catalog',
			'limit'      => 60,
			'exclude'    => array( $product_id ),
			'category'   => $slugs,
			'return'     => 'ids',
		) );
		return array_values( array_filter( array_map( 'absint', $ids ), 'izl_is_codex' ) );
	};
	$ids = $find( $genus ? array( $genus->slug ) : array() );
	$by  = 'genus';
	if ( ! $ids ) {
		// 3.28.0 (Dan, 2026-11-25, "Szomszédok"): the group fill-up takes only the same kind of animal: an isopod gets
		// other isopods from every isopod group (izl_isopod_terms()), never roaches or supplies.
		$slugs = $group ? array( $group->slug ) : array();
		if ( $group && function_exists( 'izl_top_key' ) && 'isopoda' === izl_top_key( $group ) ) {
			$slugs = array_values( array_unique( array_merge( $slugs, wp_list_pluck( izl_isopod_terms(), 'slug' ) ) ) );
		}
		$ids = array_values( array_filter( $find( $slugs ), function ( $id ) use ( $group ) {
			return izl_kin_same( $id, $group );
		} ) );
		$by  = 'group';
	}
	$memo[ $product_id ] = array( 'ids' => $ids, 'by' => $by );
	return $memo[ $product_id ];
}

// 3.28.0: whether a product is the same kind of animal as a group (the same header key: every isopod group is "isopoda").
function izl_kin_same( $id, $group ) {
	$t = izl_group_term( $id );
	if ( ! $t || ! $group ) {
		return false;
	}
	return function_exists( 'izl_top_key' ) ? izl_top_key( $t ) === izl_top_key( $group ) : (int) $t->term_id === (int) $group->term_id;
}

// What the row shows: the product's Upsells (Product data → Linked products → Upsells) first, the rest filled up with
// WooCommerce's own related products (same category or tag), so the row is never half empty. 3.25.0: under a species
// the rest is its genus (izl_kin()), not WooCommerce's pick.
// 3.23.0 (Dan, 2026-11-25): what can be bought comes first, sold-out ones last (they only fill up the row). The rest
// is still mixed on every visit (WooCommerce's own shuffle and order are turned off below, so this order stays).
add_filter( 'woocommerce_related_products', function ( $related, $product_id, $args ) {
	$product = wc_get_product( $product_id );
	$ups     = $product ? array_map( 'absint', $product->get_upsell_ids() ) : array();
	// 3.28.0 (Dan, 2026-11-25): under a species the row only holds species of the same kind (isopods under an isopod),
	// hand-picked Upsells included: a supply or another kind of animal picked there stays out.
	if ( izl_is_codex( $product_id ) ) {
		$grp = izl_group_term( $product_id );
		$ups = array_values( array_filter( $ups, function ( $id ) use ( $grp ) {
			return izl_is_codex( $id ) && izl_kin_same( $id, $grp );
		} ) );
	}
	// 3.25.0: a species' row = its own genus only (or its group when the genus has no one else): izl_kin().
	$rest    = izl_is_codex( $product_id ) ? izl_kin( $product_id )['ids'] : array_map( 'absint', (array) $related );
	shuffle( $rest );
	$limit = isset( $args['limit'] ) && $args['limit'] > 0 ? (int) $args['limit'] : 6;
	$ids   = array_values( array_diff( array_unique( array_merge( $ups, $rest ) ), array( (int) $product_id ) ) );
	$in    = array();
	$out   = array();
	foreach ( $ids as $id ) {
		if ( 'outofstock' === get_post_meta( $id, '_stock_status', true ) ) {
			$out[] = $id;
		} else {
			$in[] = $id;
		}
	}
	return array_slice( array_merge( $in, $out ), 0, $limit );
}, 10, 3 );
add_filter( 'woocommerce_product_related_posts_shuffle', '__return_false' );

// Supplies: the description under the buy box, as wide as the buy box, with the product's details (weight, size,
// attributes) under it if it has any.
function izl_description() {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$text  = trim( (string) $product->get_description() );
	$attrs = $product->has_attributes() || $product->has_weight() || $product->has_dimensions();
	if ( '' === $text && ! $attrs ) {
		return;
	}
	echo '<section class="izl-desc"><h2>' . esc_html__( 'Description', 'izeltlab' ) . '</h2>';
	if ( '' !== $text ) {
		echo '<div class="izl-desc-text">' . apply_filters( 'the_content', $text ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- post content
	}
	if ( $attrs ) {
		wc_display_product_attributes( $product );
	}
	echo '</section>';
}

// Supplies: categories and tags as small clickable pills under the photo (instead of "Categories: … Tags: …").
function izl_term_pills() {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$skip  = (int) get_option( 'default_product_cat' ); // "Uncategorized"
	$pills = array();
	foreach ( array( 'product_cat' => '', 'product_tag' => '#' ) as $tax => $mark ) {
		$terms = get_the_terms( $product->get_id(), $tax );
		if ( ! $terms || is_wp_error( $terms ) ) {
			continue;
		}
		foreach ( $terms as $t ) {
			if ( 'product_cat' === $tax && (int) $t->term_id === $skip ) {
				continue;
			}
			$link = get_term_link( $t );
			if ( ! is_wp_error( $link ) ) {
				$pills[] = '<a class="izl-term is-' . ( $mark ? 'tag' : 'cat' ) . '" href="' . esc_url( $link ) . '" rel="tag">' . esc_html( $mark . $t->name ) . '</a>';
			}
		}
	}
	if ( $pills ) {
		echo '<nav class="izl-terms" aria-label="' . esc_attr__( 'Categories and tags', 'izeltlab' ) . '">' . implode( '', $pills ) . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

// ==========================================================================
//  2. Sold out: what can be bought instead (since 3.20.0)
// ==========================================================================

// Dan (2026-11-22): a shopper who lands on a sold-out species still finds something to buy. Right under the card and
// the buy box (above the trust line), "Addig is, ők kaphatók:" with up to 3 species of the same group that are in stock,
// best sellers first, as the same small tiles as the row at the bottom of the page. Nothing when none are in stock.
// Change the number with the filter izl_sold_alternatives_max (0 turns the row off).
function izl_sold_alternative_ids( $product_id ) {
	$max   = (int) apply_filters( 'izl_sold_alternatives_max', 3 );
	$group = izl_group_term( $product_id );
	if ( $max < 1 || ! $group ) {
		return array();
	}
	$args = array(
		'status'       => 'publish',
		'limit'        => $max,
		'stock_status' => 'instock',
		'visibility'   => 'catalog',
		'exclude'      => array( (int) $product_id ),
		'category'     => array( $group->slug ),
		'return'       => 'ids',
	);
	$ids = wc_get_products( $args + array( 'meta_key' => 'total_sales', 'orderby' => 'meta_value_num', 'order' => 'DESC' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	if ( count( $ids ) < $max ) {
		$more = wc_get_products( array_merge( $args, array( 'exclude' => array_merge( array( (int) $product_id ), $ids ), 'limit' => $max - count( $ids ), 'orderby' => 'date', 'order' => 'DESC' ) ) );
		$ids  = array_merge( $ids, $more );
	}
	// 3.30.0: a species gets species, a supply gets supplies (Dan, 2026-11-26: sold-out supplies too)
	$codex = izl_is_codex( $product_id );
	return array_values( array_filter( array_map( 'absint', $ids ), function ( $id ) use ( $codex ) {
		return $codex === izl_is_codex( $id );
	} ) );
}

function izl_sold_alternatives() {
	global $product;
	if ( ! $product instanceof WC_Product || $product->is_in_stock() ) {
		return;
	}
	$ids = izl_sold_alternative_ids( $product->get_id() );
	if ( ! $ids ) {
		return;
	}
	$keep = $product;
	$title = izl_is_codex( $product->get_id() ) ? __( 'Meanwhile, these are in stock:', 'izeltlab' ) : __( 'Meanwhile, these are available:', 'izeltlab' ); // 3.30.0: "Addig is, ezek kaphatók:"
	echo '<section class="related products izl-alts"><h2>' . esc_html( $title ) . '</h2>';
	wc_set_loop_prop( 'name', 'izl-alts' );
	wc_set_loop_prop( 'columns', count( $ids ) );
	woocommerce_product_loop_start();
	foreach ( $ids as $id ) {
		$GLOBALS['post'] = get_post( $id ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride
		setup_postdata( $GLOBALS['post'] );
		wc_get_template_part( 'content', 'product' );
	}
	woocommerce_product_loop_end();
	wp_reset_postdata();
	$GLOBALS['product'] = $keep; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
	echo '</section>';
}
add_action( 'wp', function () {
	if ( function_exists( 'is_product' ) && is_product() ) {
		add_action( 'woocommerce_after_single_product_summary', 'izl_sold_alternatives', 4 );
	}
} );

// 3.29.0 (Dan, 2026-11-26): where "Többiekhez!" (a sold-out species on a phone) and "Vissza a többiekhez!" (the basket
// already holds all that is left) lead: the product's group page, the same address as the group's header button (all
// isopod groups: the "Isopods" page; a group's own address from the Groups dialog wins). Empty when there is no group.
function izl_group_link( $product_id ) {
	return izl_group_button( $product_id )['url'];
}
// 3.30.0: the group's header button as array( 'label', 'url' ) (its own text and address from the Groups dialog,
// else the group's name and page); empty strings when the product has no group.
function izl_group_button( $product_id ) {
	$out   = array( 'label' => '', 'url' => '' );
	$group = izl_group_term( $product_id );
	if ( ! $group ) {
		return $out;
	}
	if ( function_exists( 'izl_header_buttons' ) && function_exists( 'izl_top_key' ) ) {
		$key = izl_top_key( $group );
		foreach ( izl_header_buttons( true ) as $b ) {
			if ( 'group' === $b['type'] && $key === $b['key'] && '' !== trim( (string) $b[1] ) ) {
				return array( 'label' => (string) $b[0], 'url' => (string) $b[1] );
			}
		}
	}
	$link = get_term_link( $group );
	return array( 'label' => $group->name, 'url' => is_wp_error( $link ) ? '' : (string) $link );
}

// 3.30.0 (Dan, 2026-11-26): a supply's photos as a framed card, in the place of WooCommerce's gallery. The class
// names are the Codex card's (fsz-wrap fsz-at-gallery, fsz-photo, fsz-slides), so the phone drawer and the photo
// pop-out (assets/product.js) work on it as they do on a species' card; the theme draws it (style.css section 71).
// The photos lie on top of each other and the one with .is-on shows (a swipe or a dot changes it, product.js
// supplyCard()). Computers get small framed squares under the card for more photos. fsz-nick (hidden) gives the
// phone drawer its name line.
function izl_supply_card() {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$ids = array_values( array_unique( array_filter( array_map( 'absint', array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) ) ) ) );
	$btn = izl_group_button( $product->get_id() );
	$h   = '<div class="fsz-wrap fsz-at-gallery izl-sc' . ( count( $ids ) > 1 ? ' has-more' : '' ) . '"><div class="izl-sc-card">';
	if ( '' !== $btn['label'] ) {
		$h .= '<a class="izl-sc-label" href="' . esc_url( $btn['url'] ) . '">' . esc_html( $btn['label'] ) . '</a>';
	}
	if ( $product->is_on_sale() ) {
		$h .= '<span class="izl-sc-sale">' . esc_html__( 'Sale!', 'woocommerce' ) . '</span>';
	}
	// 3.31.0 (Dan, 2026-11-26): the photo window has two sides. The front: the photos, their dots on its bottom edge.
	// The back: the long description (the attributes under it), turned to with "Leírás" like a page; the frame and the
	// tab stay. The text is in the page from the start (search engines read it), shoppers see it after the tap, and
	// whoever can edit the product types into it there (assets/product-edit.js supplyText()).
	$back = izl_supply_back( $product );
	$h   .= '<div class="izl-sc-stage"><div class="izl-sc-turn">';
	$h   .= '<div class="fsz-photo izl-sc-photo" role="button" tabindex="0" aria-label="' . esc_attr__( 'Photo', 'izeltlab' ) . '"><div class="fsz-slides">';
	if ( $ids ) {
		foreach ( $ids as $i => $id ) {
			$h .= wp_get_attachment_image( $id, 'woocommerce_single', false, array(
				'class'         => 0 === $i ? 'is-on' : '',
				'loading'       => 0 === $i ? 'eager' : 'lazy',
				'fetchpriority' => 0 === $i ? 'high' : 'auto',
				'decoding'      => 'async',
				'sizes'         => '(max-width: 1023px) 92vw, 34rem',
				'alt'           => 0 === $i ? $product->get_name() : '',
			) );
		}
	} else {
		$h .= wc_placeholder_img( 'woocommerce_single', array( 'class' => 'is-on' ) );
	}
	$h .= '</div>';
	if ( count( $ids ) > 1 ) {
		$h .= '<span class="izl-sc-dots" aria-hidden="true">' . str_repeat( '<i></i>', count( $ids ) ) . '</span>';
	}
	$h .= '</div>';
	if ( '' !== $back ) {
		$h .= $back;
	}
	$h .= '</div></div>';
	// the card's foot: the name (phone) and the Leírás / Fotók button
	$h .= '<div class="izl-sc-cap"><b aria-hidden="true">' . esc_html( $product->get_name() ) . '</b>';
	if ( '' !== $back ) {
		$h .= '<button type="button" class="izl-sc-flip" aria-controls="izl-sc-back" aria-expanded="false"><span class="izl-sc-flip-t" data-back="' . esc_attr__( 'Photos', 'izeltlab' ) . '">' . esc_html__( 'Description', 'izeltlab' ) . '</span><i aria-hidden="true"></i></button>';
	}
	$h .= '</div></div>';
	if ( count( $ids ) > 1 ) {
		$h .= '<div class="izl-sc-thumbs">';
		foreach ( $ids as $i => $id ) {
			/* translators: %d: the photo's number */
			$h .= '<button type="button" class="izl-sc-thumb' . ( 0 === $i ? ' is-on' : '' ) . '" data-i="' . (int) $i . '" aria-label="' . esc_attr( sprintf( __( 'Photo %d', 'izeltlab' ), $i + 1 ) ) . '">' . wp_get_attachment_image( $id, 'woocommerce_gallery_thumbnail', false, array( 'alt' => '', 'loading' => 'lazy' ) ) . '</button>';
		}
		$h .= '</div>';
	}
	$h .= '<span class="fsz-nick" hidden>' . esc_html( $product->get_name() ) . '</span></div>';
	echo $h; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts
}
// 3.31.0: the back of the supply card: the long description (else the short one) and the attributes (weight…).
// Empty for shoppers when there is nothing to say (then no Leírás button); editors always get it, to write into.
function izl_supply_back( $product ) {
	$text  = trim( (string) $product->get_description() );
	$short = '' === $text ? trim( (string) $product->get_short_description() ) : '';
	$edit  = current_user_can( 'edit_post', $product->get_id() );
	ob_start();
	if ( $product->has_attributes() || $product->has_weight() || $product->has_dimensions() ) {
		wc_display_product_attributes( $product );
	}
	$attrs = trim( (string) ob_get_clean() );
	if ( '' === $text && '' === $short && '' === $attrs && ! $edit ) {
		return '';
	}
	$body = '' !== $text ? apply_filters( 'the_content', $text ) : ( '' !== $short ? apply_filters( 'woocommerce_short_description', $short ) : '' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals -- core filters
	$h    = '<div class="izl-sc-back" id="izl-sc-back" aria-hidden="true" tabindex="-1"><div class="izl-sc-text"';
	if ( $edit ) {
		$h .= ' data-izl-desc="' . ( '' !== $text ? '1' : '0' ) . '" data-empty="' . esc_attr__( 'Write the description here…', 'izeltlab' ) . '" data-save="' . esc_attr__( 'Save', 'izeltlab' ) . '" data-saved="' . esc_attr__( 'Saved', 'izeltlab' ) . '"';
	}
	$h .= '>' . ( '' !== $text || ! $edit ? $body : '' ) . '</div>';
	if ( '' !== $attrs ) {
		$h .= '<div class="izl-sc-attrs">' . $attrs . '</div>';
	}
	return $h . '</div>';
}

// 3.30.0 (Dan, 2026-11-26): a sold-out supply gets the species' sold-out buy row too. WooCommerce prints no cart form
// for a simple product that is out of stock, so this prints one with only the button: assets/product.js notifyBtn()
// makes it "Szóljatok, ha lesz!" (computer: to the e-mail form) or "Többiekhez!" (phone: the group page), and the phone
// drawer has its buy row (price + button). Nothing is ever sent with it.
function izl_supply_gone_button() {
	global $product;
	if ( ! $product instanceof WC_Product || $product->is_in_stock() || ! $product->is_type( 'simple' ) || '' === (string) $product->get_price() ) {
		return;
	}
	echo '<form class="cart izl-gone-form" onsubmit="return false"><button type="button" class="single_add_to_cart_button button alt">' . esc_html__( 'Tell me when back!', 'izeltlab' ) . '</button></form>';
}
// It rides in the buy box (hidden), so a card swipe brings the next species' own address and state with it
// (assets/product.js groupLink()). data-gone="1": the product cannot be ordered (sold out or paused).
add_action( 'woocommerce_single_product_summary', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	echo '<span class="izl-grp-link" hidden data-href="' . esc_url( izl_group_link( $product->get_id() ) ) . '" data-gone="' . ( $product->is_in_stock() ? '0' : '1' ) . '"></span>';
}, 1 );

