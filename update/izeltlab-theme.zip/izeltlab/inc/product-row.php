<?php
// ==========================================================================
//  FILE: inc/product-row.php   (Ízeltláb theme)
//  WHAT: Supply product pages and the product row under a product (title, which products, the description, the tag pills).
//  SEEN: Product pages of supplies; the row of tiles under every product.
//  SECTIONS IN THIS FILE:
//    1. Product row, supply pages (reviews off: inc/shop-core.php) (since 1.7.0)
//    2. Sold out: what can be bought instead (since 3.20.0)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Product row, supply pages (reviews off: inc/shop-core.php) (since 1.7.0)
// ==========================================================================

// The row's title when the product has none of its own: species "Similar species", everything else "You might also need".
// $shop: in the shop's language even when saved from an English dashboard.
function izl_row_default( $product_id, $shop = false ) {
	if ( $shop ) {
		return izl_shop_text( izl_is_codex( $product_id ) ? 'Similar species' : 'You might also need' );
	}
	return izl_is_codex( $product_id ) ? __( 'Similar species', 'izeltlab' ) : __( 'You might also need', 'izeltlab' );
}

// The title over the small-tile row: the product's own (Edit buy box, or Edit on the title itself), else the default.
function izl_row_title() {
	$own = trim( (string) get_post_meta( get_the_ID(), '_izl_row_title', true ) );
	return '' !== $own ? $own : izl_row_default( get_the_ID() );
}

// What the row shows: the product's Upsells (Product data → Linked products → Upsells) first, the rest filled up with
// WooCommerce's own related products (same category or tag), so the row is never half empty.
// 3.23.0 (Dan, 2026-11-25): what can be bought comes first, sold-out ones last (they only fill up the row). The rest
// is still mixed on every visit (WooCommerce's own shuffle and order are turned off below, so this order stays).
add_filter( 'woocommerce_related_products', function ( $related, $product_id, $args ) {
	$product = wc_get_product( $product_id );
	$ups     = $product ? array_map( 'absint', $product->get_upsell_ids() ) : array();
	$rest    = array_map( 'absint', (array) $related );
	shuffle( $rest );
	$limit = isset( $args['limit'] ) && $args['limit'] > 0 ? (int) $args['limit'] : 6;
	$ids   = array_values( array_diff( array_unique( array_merge( $ups, $rest ) ), array( (int) $product_id ) ) );
	$in    = array();
	$out   = array();
	foreach ( $ids as $id ) {
		if ( 'outofstock' === get_post_meta( $id, '_stock_status', true ) ) {
			$out[] = $id;
		} else {
			$in[] = $id;
		}
	}
	return array_slice( array_merge( $in, $out ), 0, $limit );
}, 10, 3 );
add_filter( 'woocommerce_product_related_posts_shuffle', '__return_false' );

// Supplies: the description under the buy box, as wide as the buy box, with the product's details (weight, size,
// attributes) under it if it has any.
function izl_description() {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$text  = trim( (string) $product->get_description() );
	$attrs = $product->has_attributes() || $product->has_weight() || $product->has_dimensions();
	if ( '' === $text && ! $attrs ) {
		return;
	}
	echo '<section class="izl-desc"><h2>' . esc_html__( 'Description', 'izeltlab' ) . '</h2>';
	if ( '' !== $text ) {
		echo '<div class="izl-desc-text">' . apply_filters( 'the_content', $text ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- post content
	}
	if ( $attrs ) {
		wc_display_product_attributes( $product );
	}
	echo '</section>';
}

// Supplies: categories and tags as small clickable pills under the photo (instead of "Categories: … Tags: …").
function izl_term_pills() {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$skip  = (int) get_option( 'default_product_cat' ); // "Uncategorized"
	$pills = array();
	foreach ( array( 'product_cat' => '', 'product_tag' => '#' ) as $tax => $mark ) {
		$terms = get_the_terms( $product->get_id(), $tax );
		if ( ! $terms || is_wp_error( $terms ) ) {
			continue;
		}
		foreach ( $terms as $t ) {
			if ( 'product_cat' === $tax && (int) $t->term_id === $skip ) {
				continue;
			}
			$link = get_term_link( $t );
			if ( ! is_wp_error( $link ) ) {
				$pills[] = '<a class="izl-term is-' . ( $mark ? 'tag' : 'cat' ) . '" href="' . esc_url( $link ) . '" rel="tag">' . esc_html( $mark . $t->name ) . '</a>';
			}
		}
	}
	if ( $pills ) {
		echo '<nav class="izl-terms" aria-label="' . esc_attr__( 'Categories and tags', 'izeltlab' ) . '">' . implode( '', $pills ) . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

// ==========================================================================
//  2. Sold out: what can be bought instead (since 3.20.0)
// ==========================================================================

// Dan (2026-11-22): a shopper who lands on a sold-out species still finds something to buy. Right under the card and
// the buy box (above the trust line), "Addig is, ők kaphatók:" with up to 3 species of the same group that are in stock,
// best sellers first, as the same small tiles as the row at the bottom of the page. Nothing when none are in stock.
// Change the number with the filter izl_sold_alternatives_max (0 turns the row off).
function izl_sold_alternative_ids( $product_id ) {
	$max   = (int) apply_filters( 'izl_sold_alternatives_max', 3 );
	$group = izl_group_term( $product_id );
	if ( $max < 1 || ! $group ) {
		return array();
	}
	$args = array(
		'status'       => 'publish',
		'limit'        => $max,
		'stock_status' => 'instock',
		'visibility'   => 'catalog',
		'exclude'      => array( (int) $product_id ),
		'category'     => array( $group->slug ),
		'return'       => 'ids',
	);
	$ids = wc_get_products( $args + array( 'meta_key' => 'total_sales', 'orderby' => 'meta_value_num', 'order' => 'DESC' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	if ( count( $ids ) < $max ) {
		$more = wc_get_products( array_merge( $args, array( 'exclude' => array_merge( array( (int) $product_id ), $ids ), 'limit' => $max - count( $ids ), 'orderby' => 'date', 'order' => 'DESC' ) ) );
		$ids  = array_merge( $ids, $more );
	}
	return array_values( array_filter( array_map( 'absint', $ids ), 'izl_is_codex' ) );
}

function izl_sold_alternatives() {
	global $product;
	if ( ! $product instanceof WC_Product || $product->is_in_stock() || ! izl_is_codex( $product->get_id() ) ) {
		return;
	}
	$ids = izl_sold_alternative_ids( $product->get_id() );
	if ( ! $ids ) {
		return;
	}
	$keep = $product;
	echo '<section class="related products izl-alts"><h2>' . esc_html__( 'Meanwhile, these are in stock:', 'izeltlab' ) . '</h2>';
	wc_set_loop_prop( 'name', 'izl-alts' );
	wc_set_loop_prop( 'columns', count( $ids ) );
	woocommerce_product_loop_start();
	foreach ( $ids as $id ) {
		$GLOBALS['post'] = get_post( $id ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride
		setup_postdata( $GLOBALS['post'] );
		wc_get_template_part( 'content', 'product' );
	}
	woocommerce_product_loop_end();
	wp_reset_postdata();
	$GLOBALS['product'] = $keep; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
	echo '</section>';
}
add_action( 'wp', function () {
	if ( function_exists( 'is_product' ) && is_product() ) {
		add_action( 'woocommerce_after_single_product_summary', 'izl_sold_alternatives', 4 );
	}
} );

