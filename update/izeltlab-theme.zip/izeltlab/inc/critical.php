<?php
// ==========================================================================
//  FILE: inc/critical.php   (Ízeltláb theme)
//  WHAT: 3.19.0: the first screen is drawn at once. Before, the browser drew nothing (not even the light teal
//        background) until five stylesheets had arrived (Storefront's styles, its icons and shop styles, the theme's and
//        Codex's: about 1.4 s on a phone's first visit, measured on the live shop). On the front page, product pages and
//        shop lists (categories and product search too) the rules that draw the first screen are now written into the
//        page (assets/critical/<kind>.json, made by build/critical.js on the test shop), so the background, header and
//        hero words appear as soon as the page arrives; the hero cards follow together (carousel.js, as before); the full
//        stylesheets load alongside without holding the page up. The written rules are copies of the stylesheets' own
//        rules, in their order and in each stylesheet's place, so nothing looks different once everything has loaded.
//        They are used only while every one of those stylesheets is exactly the file they were made from (a
//        fingerprint of its text); after an update that changes one (Storefront, WooCommerce, Codex, this theme) pages
//        load the old way until the next build. Logged-in users always get the old way; without JavaScript the full
//        stylesheets load as before.
//  SEEN: Behind the scenes: the front page, product pages and shop lists for shoppers (not logged in).
//  SWITCH OFF: add_filter( 'izl_critical_css', '__return_false' );
//  SECTIONS IN THIS FILE:
//    1. Which pages get the written rules
//    2. The written rules, while every stylesheet is unchanged
//    3. The rules in the page, the stylesheets alongside
//    4. window.izlCss: a promise for scripts that measure the page (resolved once every full stylesheet is in)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  1. Which pages get the written rules
// ==========================================================================

// The page's kind ('front', 'product', 'list') when the written rules can be used, else ''.
function izl_critical_kind() {
	static $kind = null;
	if ( null !== $kind ) {
		return $kind;
	}
	$kind = '';
	if ( is_admin() || is_user_logged_in() || is_customize_preview() || is_feed() || ! apply_filters( 'izl_critical_css', true ) ) {
		return $kind;
	}
	$wc = function_exists( 'is_product' );
	if ( is_front_page() ) {
		$kind = 'front';
	} elseif ( $wc && is_product() ) {
		$kind = 'product';
	} elseif ( $wc && ( is_shop() || is_product_taxonomy() || ( is_search() && 'product' === get_query_var( 'post_type' ) ) ) ) {
		$kind = 'list';
	}
	return $kind;
}

// ==========================================================================
//  2. The written rules, while every stylesheet is unchanged
// ==========================================================================

// The written rules for this page: handle => css, or an empty list when any stylesheet changed since the build.
function izl_critical_sheets() {
	static $sheets = null;
	if ( null !== $sheets ) {
		return $sheets;
	}
	$sheets = array();
	$kind   = izl_critical_kind();
	$file   = $kind ? get_stylesheet_directory() . '/assets/critical/' . $kind . '.json' : '';
	if ( ! $file || ! is_readable( $file ) ) {
		return $sheets;
	}
	$data = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	if ( empty( $data['sheets'] ) || ! is_array( $data['sheets'] ) ) {
		return $sheets;
	}
	$styles = wp_styles();
	$out    = array();
	foreach ( $data['sheets'] as $handle => $sheet ) {
		// A stylesheet this page does not use (not registered) needs no check; the others must be the same files.
		$reg = isset( $styles->registered[ $handle ] ) ? $styles->registered[ $handle ] : null;
		if ( ! $reg ) {
			continue;
		}
		if ( ! $reg->src || empty( $sheet['fp'] ) || ! isset( $sheet['css'] ) ) {
			return $sheets;
		}
		$href = $styles->_css_href( $reg->src, $reg->ver, $handle );
		$path = izl_local_file( (string) $href );
		$text = $path ? (string) file_get_contents( $path ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( '' === $text || md5( preg_replace( '#https?://[^/\s\'")]+#', '', $text ) ) !== $sheet['fp'] ) {
			return $sheets; // something changed since the build: the old way for the whole page
		}
		$out[ $handle ] = (string) $sheet['css'];
	}
	$sub = (string) wp_parse_url( home_url(), PHP_URL_PATH );
	$sub = untrailingslashit( $sub );
	foreach ( $out as $handle => $css ) {
		if ( '' !== $sub ) {
			$css = str_replace( 'url("/', 'url("' . $sub . '/', $css );
		}
		$out[ $handle ] = $css;
	}
	$sheets = $out;
	return $sheets;
}

// The file of a stylesheet of this site from its address, or null.
function izl_local_file( $href ) {
	$url = preg_replace( '/[?#].*$/', '', $href );
	if ( 0 === strpos( $url, '//' ) ) {
		$url = ( is_ssl() ? 'https:' : 'http:' ) . $url;
	}
	$path = (string) wp_parse_url( $url, PHP_URL_PATH );
	$root = untrailingslashit( (string) wp_parse_url( content_url(), PHP_URL_PATH ) );
	if ( '' === $path || 0 !== strpos( $path, $root . '/' ) || false !== strpos( $path, '..' ) || ! preg_match( '/\.css$/', $path ) ) {
		return null;
	}
	$file = WP_CONTENT_DIR . substr( $path, strlen( $root ) );
	return is_readable( $file ) ? $file : null;
}

// ==========================================================================
//  3. The rules in the page, the stylesheets alongside
// ==========================================================================

// Each stylesheet with written rules: its rules in its place, then the file fetched at once without holding the page
// up (preload, then used as a stylesheet when it arrives; <noscript> keeps it for browsers without JavaScript).
add_filter( 'style_loader_tag', function ( $tag, $handle, $href, $media = 'all' ) {
	if ( is_admin() || ( $media && 'all' !== $media ) || false !== strpos( $tag, 'onload=' ) ) {
		return $tag;
	}
	$sheets = izl_critical_sheets();
	if ( ! isset( $sheets[ $handle ] ) ) {
		return $tag;
	}
	$late = preg_replace( '/\srel=([\'"])stylesheet\1/', ' rel="preload" as="style" data-izl-crit onload="this.onload=null;this.rel=\'stylesheet\';this.setAttribute(\'data-izl-ok\',\'\');window.izlCssOne&&izlCssOne()" onerror="this.onerror=null;this.removeAttribute(\'data-izl-crit\');window.izlCssOne&&izlCssOne()"', $tag, 1, $n );
	if ( ! $n ) {
		return $tag;
	}
	return "<style id='" . esc_attr( $handle ) . "-crit'>" . $sheets[ $handle ] . "</style>\n" . $late . '<noscript>' . trim( $tag ) . "</noscript>\n";
}, 30, 4 );

// ==========================================================================
//  4. window.izlCss: a promise for scripts that measure the page
// ==========================================================================

// A script that measures the page once at its start (the phone product drawer, the card's fit: assets/product.js)
// waits for window.izlCss, so it measures with every rule there, as it always did. It resolves once every full
// stylesheet with written rules has arrived (or failed), after the page's HTML is read; at the latest after 6 s; and at
// once on a page without written rules.
add_action( 'wp_head', function () {
	if ( ! izl_critical_sheets() ) {
		return;
	}
	echo "<script>window.izlCss=new Promise(function(r){function c(){if('loading'===document.readyState){return}var l=document.querySelectorAll('link[data-izl-crit]'),i;for(i=0;i<l.length;i++){if(!l[i].hasAttribute('data-izl-ok')){return}}(function w(){for(i=0;i<l.length;i++){if(!l[i].sheet&&l[i].hasAttribute('data-izl-crit')){return setTimeout(w,30)}}r()})()}window.izlCssOne=c;document.addEventListener('DOMContentLoaded',c);setTimeout(r,6000)})</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}, 2 );
