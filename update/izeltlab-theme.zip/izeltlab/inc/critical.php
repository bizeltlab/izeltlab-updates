<?php
// ==========================================================================
//  FILE: inc/critical.php   (Ízeltláb theme)
//  WHAT: 3.19.0: the first screen is drawn at once. Before, the browser drew nothing (not even the light teal
//        background) until five stylesheets had arrived (Storefront's styles, its icons and shop styles, the theme's and
//        Codex's: about 1.4 s on a phone's first visit, measured on the live shop). On the front page, product pages and
//        shop lists (categories and product search too) the rules that draw the first screen are now written into the
//        page (assets/critical/<kind>.json, made by build/critical.js on the test shop), so the background, header and
//        hero words appear as soon as the page arrives; the hero cards follow together (carousel.js, as before); the full
//        stylesheets load alongside without holding the page up. The written rules are copies of the stylesheets' own
//        rules, in their order and in each stylesheet's place, so nothing looks different once everything has loaded.
//        They are used only while every one of those stylesheets is exactly the file they were made from (a
//        fingerprint of its text); after an update that changes one (Storefront, WooCommerce, Codex, this theme) pages
//        load the old way until the next build. Logged-in users always get the old way; without JavaScript the full
//        stylesheets load as before.
//        3.34.0 (Dan, 2026-11-28): product pages had lost this on the live shop. WooCommerce 11.3.1 changed its photo
//        viewer's stylesheet (PhotoSwipe), which a species page does not even print, and one changed file sent the whole
//        page back to the old way. Now only the stylesheets the page really prints are checked, and a changed one only
//        loses its own written rules (it loads the old way, in its place); the others keep theirs. Which page kinds have
//        a changed stylesheet is shown in Settings → Ízeltláb updates (section 5), so it never goes unnoticed again.
//  SEEN: Behind the scenes: the front page, product pages and shop lists for shoppers (not logged in).
//  SWITCH OFF: add_filter( 'izl_critical_css', '__return_false' );
//  SECTIONS IN THIS FILE:
//    1. Which pages get the written rules
//    2. The written rules, while every stylesheet is unchanged
//    3. The rules in the page, the stylesheets alongside
//    4. window.izlCss: a promise for scripts that measure the page (resolved once every full stylesheet is in)
//    5. A warning in the updates box when a stylesheet changed since the build (since 3.34.0)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  1. Which pages get the written rules
// ==========================================================================

// The page's kind ('front', 'product', 'list') when the written rules can be used, else ''.
function izl_critical_kind() {
	static $kind = null;
	if ( null !== $kind ) {
		return $kind;
	}
	$kind = '';
	if ( is_admin() || is_user_logged_in() || is_customize_preview() || is_feed() || ! apply_filters( 'izl_critical_css', true ) ) {
		return $kind;
	}
	$wc = function_exists( 'is_product' );
	if ( is_front_page() ) {
		$kind = 'front';
	} elseif ( $wc && is_product() ) {
		$kind = 'product';
	} elseif ( $wc && ( is_shop() || is_product_taxonomy() || ( is_search() && 'product' === get_query_var( 'post_type' ) ) ) ) {
		$kind = 'list';
	}
	return $kind;
}

// ==========================================================================
//  2. The written rules, while every stylesheet is unchanged
// ==========================================================================

// The written rules for this page: handle => css. 3.34.0: a stylesheet that changed since the build is left out (it
// loads the old way); before, one changed file emptied the whole list.
function izl_critical_sheets() {
	static $sheets = null;
	if ( null !== $sheets ) {
		return $sheets;
	}
	$sheets = array();
	$kind   = izl_critical_kind();
	$file   = $kind ? get_stylesheet_directory() . '/assets/critical/' . $kind . '.json' : '';
	if ( ! $file || ! is_readable( $file ) ) {
		return $sheets;
	}
	$data = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	if ( empty( $data['sheets'] ) || ! is_array( $data['sheets'] ) ) {
		return $sheets;
	}
	$styles  = wp_styles();
	$printed = izl_printed_styles();
	$out     = array();
	$changed = array();
	foreach ( $data['sheets'] as $handle => $sheet ) {
		// 3.34.0: a stylesheet this page does not print needs no check (before, a registered one counted too: WooCommerce's
		// photo viewer styles are registered on every product page, printed on none of the species pages)
		$reg = isset( $styles->registered[ $handle ] ) ? $styles->registered[ $handle ] : null;
		if ( ! $reg || ! isset( $printed[ $handle ] ) ) {
			continue;
		}
		if ( ! $reg->src || empty( $sheet['fp'] ) || ! isset( $sheet['css'] ) ) {
			$changed[ $handle ] = $handle;
			continue;
		}
		$href = $styles->_css_href( $reg->src, $reg->ver, $handle );
		$path = izl_local_file( (string) $href );
		$text = $path ? (string) file_get_contents( $path ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( '' === $text || md5( preg_replace( '#https?://[^/\s\'")]+#', '', $text ) ) !== $sheet['fp'] ) {
			// 3.34.0: changed since the build (a Storefront or WooCommerce update): only this file loads the old way, in
			// its place, so the page still looks the same; the other files keep their written rules
			$changed[ $handle ] = $path ? wp_basename( $path ) : $handle;
			continue;
		}
		$out[ $handle ] = (string) $sheet['css'];
	}
	// a stylesheet that holds the page up and is not in the build's list at all (a plugin added one): reported too
	foreach ( $printed as $handle => $on ) {
		if ( isset( $data['sheets'][ $handle ] ) || ! izl_blocking_style( $handle ) ) {
			continue;
		}
		$changed[ $handle ] = $handle . ' (new)';
	}
	izl_critical_note( $kind, $changed, array_keys( $out ) );
	$sub = (string) wp_parse_url( home_url(), PHP_URL_PATH );
	$sub = untrailingslashit( $sub );
	foreach ( $out as $handle => $css ) {
		if ( '' !== $sub ) {
			$css = str_replace( 'url("/', 'url("' . $sub . '/', $css );
		}
		$out[ $handle ] = $css;
	}
	$sheets = $out;
	return $sheets;
}

// 3.34.0: the stylesheets this page prints: the queue and everything it needs (handle => true). Asked in the page head
// after the stylesheets were queued (wp_enqueue_scripts) and before they are printed. Codex takes its own out of the
// queue a moment later to print them last (Codex inc/assets.php); they are still printed, so they count.
function izl_printed_styles() {
	$styles = wp_styles();
	$seen   = array();
	$walk   = function ( $handle ) use ( &$walk, &$seen, $styles ) {
		if ( isset( $seen[ $handle ] ) || empty( $styles->registered[ $handle ] ) ) {
			return;
		}
		$seen[ $handle ] = true;
		foreach ( (array) $styles->registered[ $handle ]->deps as $dep ) {
			$walk( $dep );
		}
	};
	foreach ( (array) $styles->queue as $handle ) {
		$walk( $handle );
	}
	return $seen;
}

// 3.34.0: does this stylesheet hold up the first paint? A file for all screens that is not loaded late
// (inc/speed.php izl_late_styles) or written into the page (izl_inline_styles).
function izl_blocking_style( $handle ) {
	$reg = isset( wp_styles()->registered[ $handle ] ) ? wp_styles()->registered[ $handle ] : null;
	if ( ! $reg || ! is_string( $reg->src ) || '' === $reg->src || ! preg_match( '/\.css(\?|$)/', $reg->src ) ) {
		return false;
	}
	$media = $reg->args ? (string) $reg->args : 'all';
	if ( 'all' !== $media || in_array( $handle, izl_late_styles(), true ) || in_array( $handle, izl_inline_styles(), true ) ) {
		return false;
	}
	return ! in_array( $handle, (array) apply_filters( 'izl_critical_ignore', array() ), true );
}

// 3.34.0: remembers which stylesheets of a page kind changed since the build (option izl_crit_off, shown in the updates
// box, section 5). Written only when something changes (at most once a day for a file that stays changed), so pages do
// not write to the database. A file seen unchanged again is taken off; the list starts empty with every theme version.
function izl_critical_note( $kind, $bad, $good ) {
	$all = get_option( 'izl_crit_off' );
	$was = $all;
	$all = is_array( $all ) && isset( $all['v'] ) && IZL_VERSION === $all['v'] ? $all : array( 'v' => IZL_VERSION );
	$now = time();
	foreach ( $good as $handle ) {
		unset( $all[ $kind ][ $handle ] );
	}
	foreach ( $bad as $handle => $file ) {
		if ( empty( $all[ $kind ][ $handle ]['t'] ) || $now - (int) $all[ $kind ][ $handle ]['t'] > DAY_IN_SECONDS ) {
			$all[ $kind ][ $handle ] = array(
				'f' => (string) $file,
				't' => $now,
			);
		}
	}
	if ( empty( $all[ $kind ] ) ) {
		unset( $all[ $kind ] );
	}
	if ( $all !== $was ) {
		update_option( 'izl_crit_off', $all, true );
	}
}

// The file of a stylesheet of this site from its address, or null.
function izl_local_file( $href ) {
	$url = preg_replace( '/[?#].*$/', '', $href );
	if ( 0 === strpos( $url, '//' ) ) {
		$url = ( is_ssl() ? 'https:' : 'http:' ) . $url;
	}
	$path = (string) wp_parse_url( $url, PHP_URL_PATH );
	$root = untrailingslashit( (string) wp_parse_url( content_url(), PHP_URL_PATH ) );
	if ( '' === $path || 0 !== strpos( $path, $root . '/' ) || false !== strpos( $path, '..' ) || ! preg_match( '/\.css$/', $path ) ) {
		return null;
	}
	$file = WP_CONTENT_DIR . substr( $path, strlen( $root ) );
	return is_readable( $file ) ? $file : null;
}

// ==========================================================================
//  3. The rules in the page, the stylesheets alongside
// ==========================================================================

// Each stylesheet with written rules: its rules in its place, then the file fetched at once without holding the page
// up (preload, then used as a stylesheet when it arrives; <noscript> keeps it for browsers without JavaScript).
add_filter( 'style_loader_tag', function ( $tag, $handle, $href, $media = 'all' ) {
	if ( is_admin() || ( $media && 'all' !== $media ) || false !== strpos( $tag, 'onload=' ) ) {
		return $tag;
	}
	$sheets = izl_critical_sheets();
	if ( ! isset( $sheets[ $handle ] ) ) {
		return $tag;
	}
	$late = preg_replace( '/\srel=([\'"])stylesheet\1/', ' rel="preload" as="style" data-izl-crit onload="this.onload=null;this.rel=\'stylesheet\';this.setAttribute(\'data-izl-ok\',\'\');window.izlCssOne&&izlCssOne()" onerror="this.onerror=null;this.removeAttribute(\'data-izl-crit\');window.izlCssOne&&izlCssOne()"', $tag, 1, $n );
	if ( ! $n ) {
		return $tag;
	}
	return "<style id='" . esc_attr( $handle ) . "-crit'>" . $sheets[ $handle ] . "</style>\n" . $late . '<noscript>' . trim( $tag ) . "</noscript>\n";
}, 30, 4 );

// ==========================================================================
//  4. window.izlCss: a promise for scripts that measure the page
// ==========================================================================

// A script that measures the page once at its start (the phone product drawer, the card's fit: assets/product.js)
// waits for window.izlCss, so it measures with every rule there, as it always did. It resolves once every full
// stylesheet with written rules has arrived (or failed), after the page's HTML is read; at the latest after 6 s; and at
// once on a page without written rules.
add_action( 'wp_head', function () {
	if ( ! izl_critical_sheets() ) {
		return;
	}
	echo "<script>window.izlCss=new Promise(function(r){function c(){if('loading'===document.readyState){return}var l=document.querySelectorAll('link[data-izl-crit]'),i;for(i=0;i<l.length;i++){if(!l[i].hasAttribute('data-izl-ok')){return}}(function w(){for(i=0;i<l.length;i++){if(!l[i].sheet&&l[i].hasAttribute('data-izl-crit')){return setTimeout(w,30)}}r()})()}window.izlCssOne=c;document.addEventListener('DOMContentLoaded',c);setTimeout(r,6000)})</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}, 2 );

// ==========================================================================
//  5. A warning in the updates box when a stylesheet changed since the build (since 3.34.0)
// ==========================================================================

// Dan (2026-11-28): the product pages had lost their fast first screen and nobody could see it. Settings → Ízeltláb
// updates now says so, under the buttons, while a page kind has a stylesheet that changed since the theme was built (seen
// on a shopper's page in the last 7 days). Nothing breaks meanwhile: that one file just holds the page up as before.
// The warning lines (also read by Bolt's health checks, the Optimise button and the nightly upkeep).
function izl_critical_off_lines() {
	$all = get_option( 'izl_crit_off' );
	if ( ! is_array( $all ) || ! isset( $all['v'] ) || IZL_VERSION !== $all['v'] ) {
		return array();
	}
	$kinds = array(
		'front'   => 'the front page',
		'product' => 'product pages',
		'list'    => 'shop lists',
	);
	$lines = array();
	foreach ( $kinds as $kind => $name ) {
		$files = array();
		foreach ( isset( $all[ $kind ] ) ? (array) $all[ $kind ] : array() as $rec ) {
			if ( ! empty( $rec['t'] ) && time() - (int) $rec['t'] < WEEK_IN_SECONDS ) {
				$files[] = (string) $rec['f'];
			}
		}
		if ( $files ) {
			$lines[] = sprintf( 'Fast first screen: on %1$s, %2$s changed since the theme was built (a Storefront, WooCommerce or plugin update). Those pages still look right, they only show a little later. The next theme build brings it back.', $name, implode( ', ', array_unique( $files ) ) );
		}
	}
	return $lines;
}
add_action( 'izl_updates_box_after', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$lines = izl_critical_off_lines();
	if ( ! $lines ) {
		return;
	}
	echo '<ul style="margin:12px 0 0;padding-left:18px;list-style:disc">';
	foreach ( $lines as $line ) {
		echo '<li style="color:#b32d2e;margin:2px 0">' . esc_html( $line ) . '</li>';
	}
	echo '</ul>';
}, 5 );
