<?php
// ==========================================================================
//  FILE: inc/swift.php   (Ízeltláb theme)
//  WHAT: Phones only: product pages open smoothly from a list (the next page is fetched early and slides
//        in).
//  SEEN: Phones, when a tile is tapped. PC (since 3.20.0): when the mouse rests on a tile.
// ==========================================================================

/**
 * 2.3.0: smooth product page opening, PHONES ONLY (under 1024px since 3.11.0, the same line as body.izl-phone).
 *
 * 1. Prerender on touch: a finger on a shop tile's link starts building that product page in the background
 *    (speculation rules, Chrome/Edge). The rule is dropped as soon as the finger moves (a scroll, not a tap),
 *    which cancels the prerender, so scrolling the list costs nothing. Nothing is prerendered on view.
 * 2. Instant back: nothing here blocks the browser's back/forward cache (no unload handlers, no no-store on
 *    shop/category/product pages for visitors), so swiping back shows the list at the same scroll spot at once.
 *    Restored from that cache, the cart fragments are refreshed (a product may have been added meanwhile).
 * 3. Photo glide: tile photo → product photo (cross-document View Transition: Chrome/Edge 126+, Safari 18.2+).
 *    Only for a tap on a shop tile; every other navigation stays exactly as before (the transition is skipped).
 *
 * 3.3.0: a move made by the Codex card swipe (html[data-fsz-swipe], Codex inc/card-swipe.php) is left to Codex: its
 *    card slide plays, the photo glide stays out of it.
 *
 * On PC (1024px and wider since 3.11.0), in Firefox and with reduced motion the inline script stops on its first line:
 * no rules, no listeners, no transitions. Turn the whole thing off: add_filter( 'izl_phone_swift', '__return_false' ).
 *
 * @package izeltlab
 */

defined( 'ABSPATH' ) || exit;

// The product photo's end marker: a hidden empty span right after the photo (Codex card or gallery), so the
// browser can wait for the photo's markup before showing a gliding page (rel=expect). No look, no layout.
add_action( 'woocommerce_before_single_product_summary', function () {
	if ( apply_filters( 'izl_phone_swift', true ) ) {
		echo '<span id="izl-vt-mark" hidden></span>';
	}
}, 99 );

add_action( 'wp_head', function () {
	if ( is_admin() || is_customize_preview() || ! apply_filters( 'izl_phone_swift', true ) ) {
		return;
	}
	$product = function_exists( 'is_product' ) && is_product() ? 1 : 0;
	?>
<script id="izl-swift">(function(){var w=window,d=document,m=w.matchMedia;if(!m||!m('(max-width: 1023px)').matches)return;
var P=<?php echo (int) $product; ?>,rule=null,sx=0,sy=0,tap=null,tapT=0,named=[];
function link(t){var a=t&&t.closest?t.closest('.izl-tile a[href]'):null;if(!a||a.origin!==location.origin||/add_to_cart|ajax_add/.test(a.className)||/[?&]add-to-cart=/.test(a.href))return null;return a}
function drop(){if(rule){rule.remove();rule=null}}
function unname(){while(named.length)named.pop().style.viewTransitionName=''}
function name(el){el.style.viewTransitionName='izl-photo';named.push(el)}
/* 1. prerender on touch, cancelled when the finger moves */
if(w.HTMLScriptElement&&HTMLScriptElement.supports&&HTMLScriptElement.supports('speculationrules')){
var o={passive:true,capture:true};
d.addEventListener('touchstart',function(e){var a=link(e.target);drop();if(!a||e.touches.length>1)return;sx=e.touches[0].clientX;sy=e.touches[0].clientY;rule=d.createElement('script');rule.type='speculationrules';rule.textContent=JSON.stringify({prerender:[{source:'list',urls:[a.href],eagerness:'immediate'}]});d.head.appendChild(rule)},o);
d.addEventListener('touchmove',function(e){if(rule&&(Math.abs(e.touches[0].clientX-sx)>10||Math.abs(e.touches[0].clientY-sy)>10))drop()},o);
d.addEventListener('touchcancel',drop,o);}
/* 2. back from the cache: fresh cart, no stale rule or names */
w.addEventListener('pageshow',function(e){if(!e.persisted)return;drop();unname();if(w.jQuery&&w.wc_cart_fragments_params)w.jQuery(d.body).trigger('wc_fragment_refresh')});
/* 3. photo glide (only where both page events exist, never with reduced motion) */
if(!('onpageswap' in w)||!('onpagereveal' in w)||m('(prefers-reduced-motion: reduce)').matches)return;
var s=d.createElement('style');s.textContent='@view-transition{navigation:auto}::view-transition-group(izl-photo){animation-duration:.34s;animation-timing-function:cubic-bezier(.2,.8,.2,1)}::view-transition-old(izl-photo),::view-transition-new(izl-photo){width:100%;height:100%;object-fit:cover}::view-transition-old(root),::view-transition-new(root){animation-duration:.22s}';d.head.appendChild(s);
if(P){var x=d.createElement('link');x.rel='expect';x.href='#izl-vt-mark';x.setAttribute('blocking','render');d.head.appendChild(x)}
d.addEventListener('click',function(e){var a=link(e.target);tap=a;tapT=a?Date.now():0},true);
function key(u){try{var x=new URL(u,location.href);return x.pathname+x.search}catch(_){return ''}}
w.addEventListener('pageswap',function(e){var vt=e.viewTransition;if(!vt||d.documentElement.hasAttribute('data-fsz-swipe'))return;var A=e.activation,ok=tap&&Date.now()-tapT<4000&&(!A||(A.navigationType==='push'&&A.entry&&key(A.entry.url)===key(tap.href)));var t=ok&&tap.closest('.izl-tile'),ph=t&&t.querySelector('.izl-tile-photo');if(!ph||!ph.querySelector('img')){vt.skipTransition();return}name(ph);tap=null});
w.addEventListener('pagereveal',function(e){drop();unname();var vt=e.viewTransition;if(!vt||d.documentElement.hasAttribute('data-fsz-swipe'))return;var p=P&&(d.querySelector('.fsz-wrap.fsz-at-gallery .fsz-photo')||d.querySelector('.woocommerce-product-gallery__image'));if(!p){vt.skipTransition();return}name(p);vt.finished.then(unname,unname)});
})();</script>
	<?php
}, 1 );

/**
 * 3.20.0 (Dan, 2026-11-22): PC, the product page is ready before the click. When the mouse rests on a shop tile (or a
 * tile in a row under a product) for a moment, Chrome and Edge start building that product page in the background, so
 * the click opens it at once. Only for visitors on a screen with a mouse, 1024px and wider; not with data saving on.
 * The browser keeps at most two such pages and drops them when the mouse moves on. Analytics count a page only once it
 * is really opened. Turn it off: add_filter( 'izl_pc_hover_prerender', '__return_false' ).
 */
add_action( 'wp_head', function () {
	if ( is_admin() || is_customize_preview() || is_user_logged_in() || ! apply_filters( 'izl_pc_hover_prerender', true ) ) {
		return;
	}
	$rules = array(
		'prerender' => array(
			array(
				'where'     => array(
					'and' => array(
						array( 'selector_matches' => '.izl-tile a[href], li.product a.woocommerce-LoopProduct-link[href]' ),
						array( 'not' => array( 'selector_matches' => '.add_to_cart_button, .ajax_add_to_cart, .izl-tile-notify, a[href*="add-to-cart="]' ) ),
						array( 'href_matches' => '/*' ),
					),
				),
				'eagerness' => 'moderate',
			),
		),
	);
	echo "<script id=\"izl-hover\">(function(){var w=window,n=navigator,c=n.connection||{};if(!w.matchMedia||!w.matchMedia('(min-width: 1024px) and (hover: hover) and (pointer: fine)').matches||c.saveData||!w.HTMLScriptElement||!HTMLScriptElement.supports||!HTMLScriptElement.supports('speculationrules'))return;var s=document.createElement('script');s.type='speculationrules';s.textContent=" . wp_json_encode( wp_json_encode( $rules ) ) . ";document.head.appendChild(s)})();</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}, 2 );

