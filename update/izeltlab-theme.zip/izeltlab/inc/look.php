<?php
// ==========================================================================
//  FILE: inc/look.php   (Ízeltláb theme)
//  WHAT: The site-wide look that is set in the page head: the shop keeps its own colours (no dark mode), the phone/PC layout switch, the logo and the browser icons.
//  SEEN: Every page: logo, browser tab icon, colours.
//  SECTIONS IN THIS FILE:
//    1. Colours stay the shop's own
//    2. Which layout fits the window (since 2.4.0)
//    3. Logo and icons (since 1.7.19)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Colours stay the shop's own
// ==========================================================================

// Dark Reader (and browsers that darken pages, like LibreWolf with it built in) would recolour the shop: dark mint
// background, brown buttons. The lock tag tells Dark Reader to leave the site alone, and color-scheme keeps form
// controls light, so every visitor sees the same teal, mint and yellow.
add_action( 'wp_head', function () {
	echo '<meta name="darkreader-lock">' . "\n" . '<meta name="color-scheme" content="light only">' . "\n";
}, 1 );

// The Firefox engine (Firefox, LibreWolf, other Gecko browsers; 1.7.8): html.izl-gecko, set before the page is drawn,
// so style.css can give the 3D Codex cards a lighter way to draw there (Firefox lagged on them). Chromium browsers say
// "like Gecko" without the slash and support neither check, so they never get the class and nothing changes for them.
add_action( 'wp_head', function () {
	echo "<script>if(/\\bGecko\\/\\d/.test(navigator.userAgent)||(window.CSS&&CSS.supports&&CSS.supports('-moz-orient','inline'))){document.documentElement.classList.add('izl-gecko')}</script>\n";
}, 2 );

// ==========================================================================
//  Which layout fits the window (since 2.4.0)
// ==========================================================================
// 
// Upright phones (under 768px wide) get the phone layout; everything else gets the computer layout. A phone turned
// sideways is only 360-430px tall, too short for the phone layout's card and drawer, and 667-956px wide, where the
// computer layout is cramped (the product page's guarantee column ran under the card). So for a phone on its side
// (screen under 500px tall, under 1024px wide) this script tells the browser to lay every page out 1024px wide and
// fit it to the screen: the full computer layout, slightly zoomed out, the same on every page (theme and Codex).
// Turned upright again, the normal width comes back. It reads the SCREEN's size and turn, not the window's, so an
// on-screen keyboard (which makes the window shorter) never switches it. Runs in the head, before anything is drawn;
// window.izlVp() re-applies it (product.js calls it after it changes the tag).
add_action( 'wp_head', function () {
	echo "<script id=\"izl-vp\">(function(w){var m=document.querySelector('meta[name=viewport]');if(!m||!w.screen)return;function squeezed(){var s=w.screen,lo=Math.min(s.width,s.height),hi=Math.max(s.width,s.height),o=s.orientation&&s.orientation.type,side=o?o.indexOf('landscape')===0:Math.abs(+w.orientation||0)===90;return side&&hi<1024&&lo<500}w.izlVp=function(){var c=m.getAttribute('content')||'',s=squeezed(),k=Math.max(w.screen.width,w.screen.height)/1024,p=c.split(',').map(function(x){return x.trim()}).filter(function(x){return x&&!/^(width|initial-scale|viewport-fit)=/.test(x)});if(s){p=p.filter(function(x){return!/^(maximum-scale|user-scalable)=/.test(x)})}p.unshift(s?'width=1024, initial-scale='+k.toFixed(3):'width=device-width, initial-scale=1');p.push('viewport-fit=cover');var n=p.join(', ');if(n!==c){m.setAttribute('content',n)}};w.izlVp();w.addEventListener('orientationchange',function(){setTimeout(w.izlVp,60)});w.addEventListener('resize',w.izlVp)})(window)</script>\n";
}, 1 );

// ==========================================================================
//  Logo and icons (since 1.7.19)
// ==========================================================================

// The wordmark: "ízeltláb" in Space Mono Bold, white, with the 8-segment line under the letters (one segment under each
// letter, the two end ones shorter). A logo set in the Customizer still wins. Storefront lets a child theme replace this.
function storefront_site_title_or_logo( $echo = true ) {
	if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
		$logo = get_custom_logo();
		$html = is_home() ? '<h1 class="logo">' . $logo . '</h1>' : $logo;
	} else {
		$tag  = is_home() && ! is_front_page() ? 'h1' : 'div'; // 2.1.2: the front page's one H1 is the hero title
		$html = '<' . $tag . ' class="beta site-title izl-logo"><a href="' . esc_url( home_url( '/' ) ) . '" rel="home"><span class="screen-reader-text">' . esc_html( get_bloginfo( 'name' ) ) . '</span><span class="izl-logo-t" aria-hidden="true">ízeltláb</span><span class="izl-logo-seg" aria-hidden="true">' . str_repeat( '<b></b>', 8 ) . '</span></a></' . $tag . '>';
	}
	if ( ! $echo ) {
		return $html;
	}
	echo $html; // phpcs:ignore WordPress.Security.EscapeOutput
}

// The tab icon and the home-screen icon: "Három vastag sáv", the rolled-up isopod on a teal tile. A Site Icon set under
// Appearance → Customize → Site Identity still wins.
add_action( 'wp_head', function () {
	if ( function_exists( 'has_site_icon' ) && has_site_icon() ) {
		return;
	}
	$u = get_stylesheet_directory_uri() . '/assets/icons/';
	echo '<link rel="icon" href="' . esc_url( $u . 'favicon.svg' ) . '" type="image/svg+xml">' . "\n";
	echo '<link rel="icon" href="' . esc_url( $u . 'favicon-32.png' ) . '" sizes="32x32" type="image/png">' . "\n";
	echo '<link rel="apple-touch-icon" href="' . esc_url( $u . 'apple-touch-icon.png' ) . '">' . "\n";
	echo '<link rel="manifest" href="' . esc_url( $u . 'site.webmanifest' ) . '">' . "\n";
	// 2.0.0: no theme colour on product pages, so Safari keeps its own whiteish bars there (1.7.27 made them mint).
	if ( ! ( function_exists( 'is_product' ) && is_product() ) ) {
		echo '<meta name="theme-color" content="#1F8A8A">' . "\n";
	}
}, 3 );
