<?php
// ==========================================================================
//  FILE: inc/look.php   (Ízeltláb theme)
//  WHAT: The site-wide look that is set in the page head: the shop keeps its own colours (no dark mode), the phone/PC layout switch, the logo and the browser icons.
//  SEEN: Every page: logo, browser tab icon, colours.
//  SECTIONS IN THIS FILE:
//    1. Colours stay the shop's own
//    2. Which layout fits the window (since 2.4.0)
//    3. Logo and icons (since 1.7.19)
//    4. The phone's status bar colour (since 3.5.0)
//    5. A shop photo that does not load (since 3.33.0)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Colours stay the shop's own
// ==========================================================================

// Dark Reader (and browsers that darken pages, like LibreWolf with it built in) would recolour the shop: dark mint
// background, brown buttons. The lock tag tells Dark Reader to leave the site alone, and color-scheme keeps form
// controls light, so every visitor sees the same teal, mint and yellow.
add_action( 'wp_head', function () {
	echo '<meta name="darkreader-lock">' . "\n" . '<meta name="color-scheme" content="light only">' . "\n";
	// 3.34.0 (Dan, 2026-11-28): on a computer, Chromium drew the first frame without the scroll bar, then found the page
	// was long and moved everything about 8px left. The room for the bar is now kept from the very first frame, on every
	// page (it was only on product pages, Codex 2.x). Phones and Macs with hidden scroll bars keep no room, nothing changes.
	// It is the first thing in the page head (header.php, right under the viewport line): printed here, a computer's
	// first frame sized the text to the full window and only later to the window without the bar (0.8% smaller).
}, 1 );

// The Firefox engine (Firefox, LibreWolf, other Gecko browsers; 1.7.8): html.izl-gecko, set before the page is drawn,
// so style.css can give the 3D Codex cards a lighter way to draw there (Firefox lagged on them). Chromium browsers say
// "like Gecko" without the slash and support neither check, so they never get the class and nothing changes for them.
add_action( 'wp_head', function () {
	echo "<script>if(/\\bGecko\\/\\d/.test(navigator.userAgent)||(window.CSS&&CSS.supports&&CSS.supports('-moz-orient','inline'))){document.documentElement.classList.add('izl-gecko')}</script>\n";
}, 2 );

// ==========================================================================
//  Which layout fits the window (since 2.4.0)
// ==========================================================================
// 
// Upright phones (under 768px wide) get the phone layout; everything else gets the computer layout. A phone turned
// sideways is only 360-430px tall, too short for the phone layout's card and drawer, and 667-956px wide, where the
// computer layout is cramped (the product page's guarantee column ran under the card). So for a phone on its side
// (screen under 500px tall, under 1024px wide) this script tells the browser to lay every page out 1024px wide and
// fit it to the screen: the full computer layout, slightly zoomed out, the same on every page (theme and Codex).
// Turned upright again, the normal width comes back. It reads the SCREEN's size and turn, not the window's, so an
// on-screen keyboard (which makes the window shorter) never switches it. Runs in the head, before anything is drawn;
// window.izlVp() re-applies it (product.js calls it after it changes the tag).
// 3.30.0 (Dan, 2026-11-26): no pinch zoom on ANY page of a phone held upright (shop, groups, basket, checkout, search,
// front page, legal pages), not only on the product page: the tag gets maximum-scale=1, user-scalable=no, <html> gets
// izl-zl (style.css section 71: touch-action pan only) and Safari's pinch gestures are stopped. A phone is a touch
// screen whose short side is under 600px; tablets and computers keep their zoom, and so does a phone on its side
// (the zoomed-out computer layout above).
// 3.11.0 (Dan, 2026-11-18): the phone layout now runs up to 1023px wide (it was 767px), because the computer layout was
// cramped between 768 and 1023px. A touch tablet (no mouse, its short side 600px or more) that is 1024px or wider in
// its current turn (an iPad on its side, a big iPad) is laid out 1000px wide and fitted to the screen, so tablets
// always get the phone layout too. A phone on its side still gets the computer layout (1024px wide, see above).
// 3.14.0 (PageSpeed, 2026-11-19): Google's PageSpeed (and Chrome's Lighthouse) pretend to be an upright phone but report
// "landscape" with the screen still upright (412 x 823, turned 0 degrees), so the test got the zoomed-out computer page
// and measured the wrong layout. "On its side" now also needs the screen to agree: wider than tall (Android) or turned
// 90 degrees (iPhone, whose screen size never swaps). Real phones and tablets behave exactly as before.
add_action( 'wp_head', function () {
	echo "<script id=\"izl-vp\">(function(w){var m=document.querySelector('meta[name=viewport]');if(!m||!w.screen)return;function fit(){var s=w.screen,lo=Math.min(s.width,s.height),hi=Math.max(s.width,s.height),o=s.orientation&&s.orientation.type,side=o?o.indexOf('landscape')===0&&(s.width>s.height||(+s.orientation.angle||0)%180!==0):Math.abs(+w.orientation||0)===90,now=side?hi:lo,touch=!!(w.matchMedia&&w.matchMedia('(hover:none) and (pointer:coarse)').matches);if(side&&hi<1024&&lo<500)return[1024,hi/1024];if(touch&&lo>=600&&now>=1024)return[1000,now/1000];return null}var d=document.documentElement;function ph(){var s=w.screen;return Math.min(s.width,s.height)<600&&!!(w.matchMedia&&w.matchMedia('(pointer:coarse)').matches)}['gesturestart','gesturechange','gestureend'].forEach(function(n){document.addEventListener(n,function(e){if(d.classList.contains('izl-zl'))e.preventDefault()},{passive:false})});w.izlVp=function(){var c=m.getAttribute('content')||'',f=fit(),p=c.split(',').map(function(x){return x.trim()}).filter(function(x){return x&&!/^(width|initial-scale|viewport-fit)=/.test(x)});var lk=!f&&ph();d.classList.toggle('izl-zl',lk);if(f){p=p.filter(function(x){return!/^(maximum-scale|user-scalable)=/.test(x)})}else if(lk){p=p.filter(function(x){return!/^(maximum-scale|user-scalable)=/.test(x)});p.push('maximum-scale=1','user-scalable=no')}p.unshift(f?'width='+f[0]+', initial-scale='+f[1].toFixed(3):'width=device-width, initial-scale=1');p.push('viewport-fit=cover');var n=p.join(', ');if(n!==c){m.setAttribute('content',n)}};w.izlVp();w.addEventListener('orientationchange',function(){setTimeout(w.izlVp,60)});w.addEventListener('resize',w.izlVp)})(window)</script>\n";
}, 1 );

// ==========================================================================
//  Logo and icons (since 1.7.19)
// ==========================================================================

// The wordmark: "ízeltláb" in Space Mono Bold, white, with the 8-segment line under the letters (one segment under each
// letter, the two end ones shorter). A logo set in the Customizer still wins. Storefront lets a child theme replace this.
function storefront_site_title_or_logo( $echo = true ) {
	if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
		$logo = get_custom_logo();
		$html = is_home() ? '<h1 class="logo">' . $logo . '</h1>' : $logo;
	} else {
		$tag  = is_home() && ! is_front_page() ? 'h1' : 'div'; // 2.1.2: the front page's one H1 is the hero title
		$html = '<' . $tag . ' class="beta site-title izl-logo"><a href="' . esc_url( home_url( '/' ) ) . '" rel="home"><span class="screen-reader-text">' . esc_html( get_bloginfo( 'name' ) ) . '</span><span class="izl-logo-t" aria-hidden="true">ízeltláb</span><span class="izl-logo-seg" aria-hidden="true">' . str_repeat( '<b></b>', 8 ) . '</span></a></' . $tag . '>';
	}
	if ( ! $echo ) {
		return $html;
	}
	echo $html; // phpcs:ignore WordPress.Security.EscapeOutput
}

// The tab icon and the home-screen icon: "Három vastag sáv", the rolled-up isopod on a teal tile. A Site Icon set under
// Appearance → Customize → Site Identity still wins.
add_action( 'wp_head', function () {
	if ( function_exists( 'has_site_icon' ) && has_site_icon() ) {
		return;
	}
	$u = get_stylesheet_directory_uri() . '/assets/icons/';
	echo '<link rel="icon" href="' . esc_url( $u . 'favicon.svg' ) . '" type="image/svg+xml">' . "\n";
	echo '<link rel="icon" href="' . esc_url( $u . 'favicon-32.png' ) . '" sizes="32x32" type="image/png">' . "\n";
	echo '<link rel="apple-touch-icon" href="' . esc_url( $u . 'apple-touch-icon.png' ) . '">' . "\n";
	echo '<link rel="manifest" href="' . esc_url( $u . 'site.webmanifest' ) . '">' . "\n";
	// 2.0.0: no theme colour on product pages, so Safari keeps its own whiteish bars there (1.7.27 made them mint).
	if ( ! ( function_exists( 'is_product' ) && is_product() ) ) {
		echo '<meta name="theme-color" content="' . esc_attr( izl_menu_color() ) . '">' . "\n"; // 3.15.0: the darker menu colour (was #1F8A8A)
	}
}, 3 );

// ==========================================================================
//  The phone's status bar colour (since 3.5.0)
// ==========================================================================

// Safari 26 colours the phone's status bar from a bar pinned to the top of the screen. On the product page the fixed
// top bar does it; on the other pages (the front page first) 2.6.0's thin teal line drawn by style.css (body::after)
// did not count for Safari, so the status bar stayed pale there. 3.5.0: a real element instead, the same teal line,
// only on touch screens (style.css 3.5.0 .izl-sbar). Nothing changes on a computer.
add_action( 'wp_body_open', function () {
	echo '<div class="izl-sbar" aria-hidden="true"></div>' . "\n";
}, 1 );

// 3.34.0: with the room for the scroll bar kept (section 1), Chromium sizes the computer layout's text (style.css: the
// root size follows the window width) to the window without the bar, but only from its first restyle after the page
// has been laid out once; until then the first frame used the full window and the text shrank 0.8% a moment later
// (Dan's rule: no jumps). Here, at the top of the body, the page is laid out once (still nearly empty, so it is quick)
// and restyled, so the first frame already has the final size. Only with a mouse and a scroll bar that takes room.
add_action( 'wp_body_open', function () {
	echo "<script id=\"izl-sg\">(function(h){if(window.matchMedia&&matchMedia('(pointer:fine)').matches&&innerWidth-h.clientWidth>0){h.style.setProperty('--izl-sg','1')}})(document.documentElement)</script>\n";
}, 0 );

// ==========================================================================
//  5. A shop photo that does not load (since 3.33.0)
// ==========================================================================

// Dan (2026-11-27): the Ászkalak tile on the front page showed the browser's broken-photo sign (a "?" on the dark tile)
// while its own page was fine; one of the photo's size files was gone for a moment (Bolt 1.19.4 now keeps those a day).
// If a photo from the uploads folder still fails, it tries once more with the photo's full-size file (the same picture,
// the size files are made from it); if that fails too, it hides itself, so the tile shows its plain colour instead of
// the "?" sign. Listens from the page head, so photos that fail before the scripts load are caught too.
add_action( 'wp_head', function () {
	echo "<script id=\"izl-imgfb\">document.addEventListener('error',function(e){var i=e.target,s;if(!i||i.tagName!=='IMG')return;s=i.currentSrc||i.src||'';if(s.indexOf('/wp-content/uploads/')<0)return;if(!i.getAttribute('data-izl-fb')){var f=s.replace(/-\\d+x\\d+(\\.[a-z0-9]+)(\\?.*)?$/i,'$1');i.setAttribute('data-izl-fb','1');if(f!==s){i.removeAttribute('srcset');i.removeAttribute('sizes');i.src=f;return}}i.setAttribute('data-izl-fb','2');i.style.visibility='hidden'},true)</script>\n";
}, 2 );

