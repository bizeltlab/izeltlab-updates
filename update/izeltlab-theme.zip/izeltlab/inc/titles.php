<?php
// ==========================================================================
//  FILE: inc/titles.php   (Ízeltláb theme)
//  WHAT: Small text changes: no Storefront credit in the footer, the breadcrumb trail, the shop page title.
//  SEEN: Breadcrumbs and titles on shop pages; the footer.
//  SECTIONS IN THIS FILE:
//    1. Footer
//    2. Page titles
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Footer
// ==========================================================================

// No "Built with WooCommerce" line under the shop: only the copyright stays.
add_filter( 'storefront_credit_link', '__return_false' );

// ==========================================================================
//  Page titles
// ==========================================================================

// The breadcrumb says "Isopods" there too, not "Shop".
add_filter( 'woocommerce_get_breadcrumb', function ( $crumbs ) {
	if ( $crumbs && izl_on_isopods_page() && is_shop() ) {
		$crumbs[ count( $crumbs ) - 1 ][0] = __( 'Isopods', 'izeltlab' );
	}
	return $crumbs;
} );

// 1.7.11: the breadcrumb is a strip under the header (style.css, woocommerce/global/breadcrumb.php), with a bold ›
// between the steps in place of Storefront's slash.
add_filter( 'woocommerce_breadcrumb_defaults', function ( $defaults ) {
	$defaults['delimiter'] = '<span class="izl-crumb-sep" aria-hidden="true">&#8250;</span>';
	return $defaults;
}, 20 );

add_filter( 'woocommerce_page_title', function ( $title ) {
	return izl_on_isopods_page() ? __( 'Isopods', 'izeltlab' ) : $title;
} );

// 3.20.0: WooCommerce named the shop page "Shop" when the shop was set up in English, and that word showed in the
// shop's heading, the browser tab and the breadcrumb. While the page is still called exactly that, the shop says
// "Bolt" (languages/hu_HU.po). A name you give the page yourself (Pages → Shop) is left as it is.
// 3.22.0 (Dan, 2026-11-25): "Minden termék", the same words as the front page button that leads there.
function izl_shop_word( $title, $id = 0 ) {
	if ( ! is_admin() && 'Shop' === trim( wp_strip_all_tags( (string) $title ) ) && ( ! $id || ! function_exists( 'wc_get_page_id' ) || (int) $id === wc_get_page_id( 'shop' ) ) ) {
		return __( 'All products', 'izeltlab' );
	}
	return $title;
}
add_filter( 'the_title', 'izl_shop_word', 10, 2 );
add_filter( 'post_type_archive_title', function ( $title ) {
	return izl_shop_word( $title );
} );
add_filter( 'woocommerce_page_title', function ( $title ) {
	return izl_shop_word( $title );
}, 20 );
add_filter( 'document_title_parts', function ( $parts ) {
	if ( isset( $parts['title'] ) ) {
		$parts['title'] = izl_shop_word( $parts['title'] );
	}
	return $parts;
} );

