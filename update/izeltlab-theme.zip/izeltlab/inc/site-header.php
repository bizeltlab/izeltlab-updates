<?php
// ==========================================================================
//  FILE: inc/site-header.php   (Ízeltláb theme)
//  WHAT: The top bar: logo, menu, search / account / cart icons and the cart counter. 3.11.0 (Dan, 2026-11-18): the
//        new top bar. Phone and tablet: menu button left, the name in the exact middle, search and cart right (the
//        account moves into the menu); the search field opens leftwards over the name (inc/finder.php). PC: three
//        balanced zones, name and menu left, the search field always in the middle, account and cart right.
//        3.13.0 (Dan, 2026-11-18, mock option 3 "Clean"): PC has name and menu left and three buttons right; the first
//        is a wide "Keresés…" button that looks a little like a search bar and opens the field leftwards on a click,
//        so the menu has room for more sections.
//        3.17.0 (Dan, 2026-11-19, front page mock F): PC only. The bar is taller (88px) with a bigger name, the menu
//        words leave it and three square buttons stay at the right (search, account, cart); under it a darker
//        category bar with a button per animal group and the free-shipping progress at its right end. Scrolled down,
//        the whole thing turns into one slim fixed bar (name, the group buttons, the three buttons).
//  SEEN: The top of every page.
//  SECTIONS IN THIS FILE:
//    1. Header: logo, menu, search / account / cart
//    2. The phone menu (since 3.11.0)
//    3. The cart button's hop (since 3.12.0)
//    4. The category bar and the slim top bar (since 3.17.0)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Header: logo, menu, search / account / cart
// ==========================================================================

add_action( 'init', function () {
	remove_action( 'storefront_header', 'storefront_secondary_navigation', 30 );
	remove_action( 'storefront_header', 'storefront_product_search', 40 );
	remove_action( 'storefront_header', 'storefront_header_cart', 60 );
	remove_action( 'storefront_header', 'storefront_primary_navigation_wrapper', 42 );
	remove_action( 'storefront_header', 'storefront_primary_navigation', 50 );
	remove_action( 'storefront_header', 'storefront_primary_navigation_wrapper_close', 68 );
	add_action( 'storefront_header', 'izl_menu_button', 15 ); // 3.11.0: before the name (Storefront's at 20)
	add_action( 'storefront_header', 'izl_header_nav', 30 );
	add_action( 'storefront_header', 'izl_header_icons', 35 );
	add_action( 'storefront_header', 'izl_cat_bar_slim', 32 ); // 3.17.0: the slim bar's group buttons (PC, scrolled)
	add_action( 'storefront_header', 'izl_cat_bar', 43 );      // 3.17.0: under the bar's row (closes at 41), before the search (45)
	// Sorting and count only above the products, not twice (the page numbers stay below).
	remove_action( 'woocommerce_after_shop_loop', 'woocommerce_catalog_ordering', 10 );
	remove_action( 'woocommerce_after_shop_loop', 'woocommerce_result_count', 20 );
	// Storefront's previous / next product photos, half hidden at the two screen edges: they look like a broken image.
	remove_action( 'woocommerce_after_single_product_summary', 'storefront_single_product_pagination', 30 );
} );

/**
 * The menu: a menu set under Appearance → Menus → "Main menu (Ízeltláb header)" if there is one,
 * otherwise Isopods and Supplies, made from the shop's own categories.
 */
function izl_header_nav() {
	echo '<nav class="izl-nav" aria-label="' . esc_attr__( 'Main menu', 'izeltlab' ) . '">';
	if ( has_nav_menu( 'izeltlab-main' ) ) {
		wp_nav_menu( array( 'theme_location' => 'izeltlab-main', 'container' => false, 'depth' => 1, 'fallback_cb' => false ) );
	} else {
		echo '<ul class="menu">';
		foreach ( izl_menu_items() as $item ) {
			echo '<li' . ( $item[2] ? ' class="is-current"' : '' ) . '><a href="' . esc_url( $item[1] ) . '"' . ( $item[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $item[0] ) . '</a></li>';
		}
		echo '</ul>';
	}
	echo '</nav>';
}

// 2.6.0: on phones the top bar has no menu row (the same slim bar on every page); the list pages show the menu links
// under their title instead (style.css .izl-list-menu, hidden on computers, where the header keeps its menu).
add_action( 'woocommerce_archive_description', 'izl_list_menu', 1 );
function izl_list_menu() {
	$items = izl_menu_items();
	if ( ! $items ) {
		return;
	}
	echo '<nav aria-label="' . esc_attr__( 'Main menu', 'izeltlab' ) . '"><ul class="izl-list-menu">';
	foreach ( $items as $item ) {
		echo '<li' . ( $item[2] ? ' class="is-current"' : '' ) . '><a href="' . esc_url( $item[1] ) . '"' . ( $item[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $item[0] ) . '</a></li>';
	}
	echo '</ul></nav>';
}

function izl_menu_items() {
	// 3.11.0 (Dan, 2026-11-18): "Kezdőknek" left the menu (top bar, the list pages' menu, the search chips); the shop's
	// filter bar keeps its Kezdő button.
	$items    = array();
	$isopods  = izl_isopods_url();
	$supplies = izl_supplies_term();
	if ( $isopods ) {
		$items[] = array( __( 'Isopods', 'izeltlab' ), $isopods, izl_on_isopods_page() );
	}
	if ( $supplies ) {
		$items[] = array( __( 'Supplies', 'izeltlab' ), get_term_link( $supplies ), function_exists( 'is_product_category' ) && is_product_category( IZL_SUPPLIES ) );
	}
	return $items;
}

function izl_icon( $name ) {
	$paths = array(
		'search' => '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
		'user'   => '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>',
		'cart'   => '<path d="M2.5 3.8h3l2.5 11h10l2.5-8h-14"/><circle cx="9.5" cy="18.8" r="1.4"/><circle cx="16.5" cy="18.8" r="1.4"/>', // 3.12.0: centred in its button
		'close'  => '<path d="M6 6l12 12M18 6L6 18"/>', // 3.13.0: the PC search's close button
	);
	return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $paths[ $name ] . '</svg>';
}

// The count on the cart icon. 1.7.18: it carries the cart total too (data-total), so the free-shipping progress on the
// product page knows it right after an add to cart.
function izl_cart_count_html() {
	$n = function_exists( 'WC' ) && WC()->cart ? (int) WC()->cart->get_cart_contents_count() : 0;
	return '<span class="izl-cart-count' . ( $n ? '' : ' is-empty' ) . '" data-total="' . esc_attr( izl_cart_total() ) . '">' . (int) $n . '</span>';
}

function izl_header_icons() {
	if ( ! function_exists( 'wc_get_cart_url' ) ) {
		return;
	}
	echo '<div class="izl-icons">';
	// 2.6.0: opens the search panel under the top bar (inc/finder.php); a plain link to it without JavaScript
	echo '<a class="izl-icon izl-search-btn" href="#izl-sp" role="button" aria-controls="izl-sp" aria-expanded="false" aria-label="' . esc_attr__( 'Search', 'izeltlab' ) . '" title="' . esc_attr__( 'Search', 'izeltlab' ) . '">' . izl_icon( 'search' ) . '<span class="izl-search-word" aria-hidden="true">' . esc_html__( 'Search…', 'izeltlab' ) . '</span></a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '<a class="izl-icon izl-acc" href="' . esc_url( wc_get_page_permalink( 'myaccount' ) ) . '" aria-label="' . esc_attr__( 'My account', 'izeltlab' ) . '" title="' . esc_attr__( 'My account', 'izeltlab' ) . '">' . izl_icon( 'user' ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '<a class="izl-icon izl-cart" href="' . esc_url( wc_get_cart_url() ) . '" aria-label="' . esc_attr__( 'Cart', 'izeltlab' ) . '" title="' . esc_attr__( 'Cart', 'izeltlab' ) . '">' . izl_icon( 'cart' ) . izl_cart_count_html() . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	do_action( 'izl_after_cart_icon' ); // 2.1.0: the mini cart (inc/launch.php)
	echo '</div>';
}

// The count on the cart icon follows "add to cart" without a reload.
add_filter( 'woocommerce_add_to_cart_fragments', function ( $fragments ) {
	$fragments['span.izl-cart-count'] = izl_cart_count_html();
	return $fragments;
} );

// ==========================================================================
//  The phone menu (since 3.11.0)
// ==========================================================================

// The menu button at the left end of the phone's top bar (hidden on PC, style.css section 49). It opens the menu panel
// (izl_menu_panel); without JavaScript it is a plain link to it (#izl-menu, opened by :target).
function izl_menu_button() {
	echo '<a class="izl-icon izl-menu-btn" href="#izl-menu" role="button" aria-controls="izl-menu" aria-expanded="false" aria-label="' . esc_attr__( 'Menu', 'izeltlab' ) . '" title="' . esc_attr__( 'Menu', 'izeltlab' ) . '"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 6h16M4 12h16M4 18h16"/></svg></a>';
}

// The menu panel: slides in from the left over a dimmed page. The shop's areas (the same as the PC menu), then the
// account. Closes with its X, a tap on the dimmed page, Esc or a link. Printed at the end of the page, so the top bar
// (fixed on some pages) does not hold it.
add_action( 'wp_footer', 'izl_menu_panel', 5 );
function izl_menu_panel() {
	echo '<div class="izl-menu" id="izl-menu"><a class="izl-menu-dim" href="#" tabindex="-1" aria-hidden="true"></a>';
	echo '<nav class="izl-menu-in" aria-label="' . esc_attr__( 'Main menu', 'izeltlab' ) . '">';
	echo '<p class="izl-menu-top"><span class="izl-menu-name" aria-hidden="true">ízeltláb</span><a class="izl-menu-x" href="#" aria-label="' . esc_attr__( 'Close menu', 'izeltlab' ) . '"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6L6 18"/></svg></a></p>';
	echo '<ul class="izl-menu-list">';
	if ( has_nav_menu( 'izeltlab-main' ) ) {
		wp_nav_menu( array( 'theme_location' => 'izeltlab-main', 'container' => false, 'items_wrap' => '%3$s', 'depth' => 1, 'fallback_cb' => false ) );
	} else {
		foreach ( izl_menu_items() as $item ) {
			echo '<li' . ( $item[2] ? ' class="is-current"' : '' ) . '><a href="' . esc_url( $item[1] ) . '"' . ( $item[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $item[0] ) . '</a></li>';
		}
	}
	if ( function_exists( 'wc_get_page_permalink' ) ) {
		echo '<li class="izl-menu-acc"><a href="' . esc_url( wc_get_page_permalink( 'myaccount' ) ) . '">' . izl_icon( 'user' ) . esc_html__( 'My account', 'izeltlab' ) . '</a></li>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</ul></nav></div>';
	// opening and closing (a few lines, so they live here rather than in a file of their own)
	$js = <<<'JS'
(function(){var m=document.getElementById('izl-menu'),bs=document.querySelectorAll('.izl-menu-btn');if(!m||!bs.length){return}var last=null;function set(on){for(var i=0;i<bs.length;i++){bs[i].setAttribute('aria-expanded',on?'true':'false')}}function open(b,kb){if(window.izlFindClose){window.izlFindClose()}last=b||bs[0];m.classList.add('is-open');document.documentElement.classList.add('izl-menu-on');set(true);var f=kb&&m.querySelector('.izl-menu-list a');if(f){f.focus({preventScroll:true})}}function close(back){m.classList.remove('is-open');document.documentElement.classList.remove('izl-menu-on');set(false);if('#izl-menu'===location.hash&&history.replaceState){history.replaceState(null,'',location.pathname+location.search)}if(back&&last&&last.offsetParent){last.focus({preventScroll:true})}}for(var i=0;i<bs.length;i++){bs[i].addEventListener('click',function(e){e.preventDefault();if(m.classList.contains('is-open')){close(true)}else{open(this,0===e.detail)}})}m.addEventListener('click',function(e){var a=e.target.closest('a');if(!a){return}if(a.classList.contains('izl-menu-dim')||a.classList.contains('izl-menu-x')){e.preventDefault();close(true)}else{close(false)}});document.addEventListener('keydown',function(e){if('Escape'===e.key&&m.classList.contains('is-open')){close(true)}});window.addEventListener('pageshow',function(e){if(e.persisted){close(false)}});if('#izl-menu'===location.hash){open()}})();
JS;
	echo '<script>' . $js . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}

// ==========================================================================
//  The cart button's hop (since 3.12.0)
// ==========================================================================

// 3.12.0 (Dan, 2026-11-18): when something goes into the cart on any page (the lists' "Kosárba" buttons, WooCommerce's
// added_to_cart), the cart button in the top bar bounces once and its number pops, as on the product page (where
// assets/product.js does it at the press itself). style.css .izl-cart.is-bump, .izl-cart-count.is-pop.
add_action( 'wp_footer', function () {
	if ( ! function_exists( 'wc_get_cart_url' ) ) {
		return;
	}
	$js = <<<'JS'
(function(){var $=window.jQuery;if(!$||document.body.classList.contains('single-product')){return}$(document.body).on('added_to_cart',function(){window.requestAnimationFrame(function(){document.querySelectorAll('.izl-icon.izl-cart').forEach(function(a){var n=a.querySelector('.izl-cart-count');a.classList.remove('is-bump');void a.offsetWidth;a.classList.add('is-bump');if(n){n.classList.remove('is-pop');void n.offsetWidth;n.classList.add('is-pop')}})})})})();
JS;
	echo '<script>' . $js . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}, 30 );

// ==========================================================================
//  The category bar and the slim top bar (since 3.17.0)
// ==========================================================================

/**
 * The animal groups for the category bar: every top category that has products (its own or its sub-categories'),
 * in a fixed order: isopods (one button, the "Isopods" page), springtails, cockroaches, spiders, any other category,
 * the supplies last. A group's button is lit (yellow) on its own pages: its category pages, and the product pages of
 * its species. Each: array( label, url, is_current ).
 */
function izl_cat_items() {
	static $items = null;
	if ( null !== $items ) {
		return $items;
	}
	$items = array();
	if ( ! taxonomy_exists( 'product_cat' ) ) {
		return $items;
	}
	$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'pad_counts' => true ) );
	if ( ! $terms || is_wp_error( $terms ) ) {
		return $items;
	}
	// the top group of the page on show: a category page's own top category, or a product page's group
	$here = 0;
	if ( function_exists( 'is_product_category' ) && is_product_category() ) {
		$t = get_queried_object();
		$a = get_ancestors( $t->term_id, 'product_cat', 'taxonomy' );
		$here = $a ? (int) end( $a ) : (int) $t->term_id;
	} elseif ( function_exists( 'is_product' ) && is_product() ) {
		$g    = izl_group_term( get_the_ID() );
		$here = $g ? (int) $g->term_id : 0;
	}
	$names    = array(
		'isopoda'    => __( 'Isopods', 'izeltlab' ),
		'collembola' => __( 'Springtails', 'izeltlab' ),
		'blattodea'  => __( 'Cockroaches', 'izeltlab' ),
		'arachnida'  => __( 'Spiders', 'izeltlab' ),
	);
	$order    = array( 'isopoda' => 0, 'collembola' => 1, 'blattodea' => 2, 'arachnida' => 3 );
	$isopods  = wp_list_pluck( izl_isopod_terms(), 'term_id' );
	$skip     = (int) get_option( 'default_product_cat', 0 ); // "Uncategorized"
	$rows     = array();
	$iso_on   = function_exists( 'is_shop' ) && is_shop() && izl_isopods_view(); // the "Isopods" page (all isopod categories)
	foreach ( $terms as $t ) {
		if ( $t->parent || (int) $t->term_id === $skip || (int) $t->count < 1 ) {
			continue;
		}
		$kind = function_exists( 'fsz_term_kind' ) ? fsz_term_kind( $t ) : '';
		if ( '' === $kind && in_array( (int) $t->term_id, array_map( 'intval', $isopods ), true ) ) {
			$kind = 'isopoda'; // a Codex category with no group word in its name
		}
		$on = (int) $t->term_id === $here;
		if ( 'isopoda' === $kind ) {
			// all isopod categories share one button, the "Isopods" page
			// (one isopod category: its own page; several: the "Isopods" page)
			if ( isset( $rows['isopoda'] ) ) {
				$url             = izl_isopods_url();
				$rows['isopoda'] = array( 0, $names['isopoda'], $url ? $url : $rows['isopoda'][2], $rows['isopoda'][3] || $on );
				continue;
			}
			$link = get_term_link( $t );
			if ( is_wp_error( $link ) ) {
				continue;
			}
			$rows['isopoda'] = array( 0, $names['isopoda'], $link, $on || $iso_on );
			continue;
		}
		$link = get_term_link( $t );
		if ( is_wp_error( $link ) ) {
			continue;
		}
		if ( IZL_SUPPLIES === $t->slug ) {
			$rows[ 'id' . $t->term_id ] = array( 9, __( 'Supplies', 'izeltlab' ), $link, $on );
		} elseif ( isset( $order[ $kind ] ) ) {
			$rows[ 'id' . $t->term_id ] = array( 1 + $order[ $kind ], $names[ $kind ], $link, $on );
		} else {
			$rows[ 'id' . $t->term_id ] = array( 5, $t->name, $link, $on );
		}
	}
	uasort( $rows, function ( $a, $b ) {
		return $a[0] - $b[0];
	} );
	foreach ( $rows as $r ) {
		$items[] = array( $r[1], $r[2], $r[3] );
	}
	return $items;
}

function izl_cat_links() {
	$out = '';
	foreach ( izl_cat_items() as $item ) {
		$out .= '<a class="izl-cb' . ( $item[2] ? ' is-on' : '' ) . '" href="' . esc_url( $item[1] ) . '"' . ( $item[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $item[0] ) . '</a>';
	}
	return $out;
}

// The bar under the top bar's row (PC; phones never show it, style.css section 3.17.0).
function izl_cat_bar() {
	$links = izl_cat_links();
	echo '<div class="izl-cbar"><nav class="col-full" aria-label="' . esc_attr__( 'Categories', 'izeltlab' ) . '">' . $links . izl_cbar_ship_html() . '</nav></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
}

// The same buttons inside the row, shown only in the slim bar (html.izl-slim), where the category bar is hidden.
function izl_cat_bar_slim() {
	$links = izl_cat_links();
	if ( '' !== $links ) {
		echo '<nav class="izl-cbar-slim" aria-label="' . esc_attr__( 'Categories', 'izeltlab' ) . '">' . $links . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

/**
 * The free-shipping progress at the bar's right end, the same bar as in the basket and the buy box. An empty basket
 * says where free shipping starts; then how much is still missing; then that it is free. The cached pages are
 * drawn with an empty basket; WooCommerce's cart refresh redraws it for a shopper with something in the basket.
 */
function izl_cbar_ship_html() {
	$goal = function_exists( 'izl_free_ship' ) ? (float) izl_free_ship() : 0;
	if ( $goal <= 0 || ! function_exists( 'WC' ) ) {
		return '<div class="izl-cbar-ship"></div>';
	}
	$line = WC()->cart && ! WC()->cart->is_empty() ? izl_free_line() : '';
	if ( '' === $line ) {
		/* translators: %s: the amount, e.g. 20 000 Ft */
		$txt  = sprintf( __( 'Free shipping over %s', 'izeltlab' ), html_entity_decode( wp_strip_all_tags( wc_price( $goal ) ) ) );
		$line = '<p class="izl-prog" role="status"><span class="izl-prog-t">' . esc_html( $txt ) . '</span><span class="izl-prog-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><i style="width:0%"></i></span></p>';
	}
	return '<div class="izl-cbar-ship">' . $line . '</div>';
}

add_filter( 'woocommerce_add_to_cart_fragments', function ( $fragments ) {
	$fragments['div.izl-cbar-ship'] = izl_cbar_ship_html();
	return $fragments;
} );

/**
 * The slim bar (PC): once the page is scrolled about 260px down, the top bar is pinned to the top of the screen as one
 * slim row (style.css html.izl-slim) and slides in; back near the top it is the full bar again, where it was. A
 * 1px marker 260px from the top is watched (no work on every scroll step); while the bar is pinned, a stand-in of
 * its height keeps the page from jumping.
 */
add_action( 'wp_footer', function () {
	$js = <<<'JS'
(function(){var h=document.getElementById('masthead');if(!h||!window.IntersectionObserver){return}var pc=window.matchMedia('(min-width:1024px)'),r=document.documentElement,at=document.createElement('div'),ph=document.createElement('div'),on=false;at.className='izl-slim-at';at.setAttribute('aria-hidden','true');ph.className='izl-slim-ph';document.body.appendChild(at);h.parentNode.insertBefore(ph,h);function set(want){want=want&&pc.matches;if(want===on){return}on=want;if(on){var nx=h.nextElementSibling,t0=nx?nx.getBoundingClientRect().top:0,hh=h.offsetHeight+(parseFloat(getComputedStyle(h).marginBottom)||0);r.classList.add('izl-slim');ph.style.height=hh+'px';if(nx){ph.style.height=Math.max(0,hh+t0-nx.getBoundingClientRect().top)+'px'}}else{r.classList.remove('izl-slim');ph.style.height=''}if(window.izlFindPlace){window.izlFindPlace()}}var last=null;new IntersectionObserver(function(es){last=es[es.length-1];set(!last.isIntersecting&&last.boundingClientRect.top<0)}).observe(at);var f=function(){set(!!last&&!last.isIntersecting&&last.boundingClientRect.top<0)};pc.addEventListener?pc.addEventListener('change',f):pc.addListener(f)})();
JS;
	echo '<script>' . $js . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}, 31 );
