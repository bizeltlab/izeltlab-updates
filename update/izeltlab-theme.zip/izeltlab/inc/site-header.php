<?php
// ==========================================================================
//  FILE: inc/site-header.php   (Ízeltláb theme)
//  WHAT: The top bar: logo, menu, search / account / cart icons and the cart counter. 3.11.0 (Dan, 2026-11-18): the
//        new top bar. Phone and tablet: menu button left, the name in the exact middle, search and cart right (the
//        account moves into the menu); the search field opens leftwards over the name (inc/finder.php). PC: three
//        balanced zones, name and menu left, the search field always in the middle, account and cart right.
//        3.13.0 (Dan, 2026-11-18, mock option 3 "Clean"): PC has name and menu left and three buttons right; the first
//        is a wide "Keresés…" button that looks a little like a search bar and opens the field leftwards on a click,
//        so the menu has room for more sections.
//  SEEN: The top of every page.
//  SECTIONS IN THIS FILE:
//    1. Header: logo, menu, search / account / cart
//    2. The phone menu (since 3.11.0)
//    3. The cart button's hop (since 3.12.0)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Header: logo, menu, search / account / cart
// ==========================================================================

add_action( 'init', function () {
	remove_action( 'storefront_header', 'storefront_secondary_navigation', 30 );
	remove_action( 'storefront_header', 'storefront_product_search', 40 );
	remove_action( 'storefront_header', 'storefront_header_cart', 60 );
	remove_action( 'storefront_header', 'storefront_primary_navigation_wrapper', 42 );
	remove_action( 'storefront_header', 'storefront_primary_navigation', 50 );
	remove_action( 'storefront_header', 'storefront_primary_navigation_wrapper_close', 68 );
	add_action( 'storefront_header', 'izl_menu_button', 15 ); // 3.11.0: before the name (Storefront's at 20)
	add_action( 'storefront_header', 'izl_header_nav', 30 );
	add_action( 'storefront_header', 'izl_header_icons', 35 );
	// Sorting and count only above the products, not twice (the page numbers stay below).
	remove_action( 'woocommerce_after_shop_loop', 'woocommerce_catalog_ordering', 10 );
	remove_action( 'woocommerce_after_shop_loop', 'woocommerce_result_count', 20 );
	// Storefront's previous / next product photos, half hidden at the two screen edges: they look like a broken image.
	remove_action( 'woocommerce_after_single_product_summary', 'storefront_single_product_pagination', 30 );
} );

/**
 * The menu: a menu set under Appearance → Menus → "Main menu (Ízeltláb header)" if there is one,
 * otherwise Isopods and Supplies, made from the shop's own categories.
 */
function izl_header_nav() {
	echo '<nav class="izl-nav" aria-label="' . esc_attr__( 'Main menu', 'izeltlab' ) . '">';
	if ( has_nav_menu( 'izeltlab-main' ) ) {
		wp_nav_menu( array( 'theme_location' => 'izeltlab-main', 'container' => false, 'depth' => 1, 'fallback_cb' => false ) );
	} else {
		echo '<ul class="menu">';
		foreach ( izl_menu_items() as $item ) {
			echo '<li' . ( $item[2] ? ' class="is-current"' : '' ) . '><a href="' . esc_url( $item[1] ) . '"' . ( $item[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $item[0] ) . '</a></li>';
		}
		echo '</ul>';
	}
	echo '</nav>';
}

// 2.6.0: on phones the top bar has no menu row (the same slim bar on every page); the list pages show the menu links
// under their title instead (style.css .izl-list-menu, hidden on computers, where the header keeps its menu).
add_action( 'woocommerce_archive_description', 'izl_list_menu', 1 );
function izl_list_menu() {
	$items = izl_menu_items();
	if ( ! $items ) {
		return;
	}
	echo '<nav aria-label="' . esc_attr__( 'Main menu', 'izeltlab' ) . '"><ul class="izl-list-menu">';
	foreach ( $items as $item ) {
		echo '<li' . ( $item[2] ? ' class="is-current"' : '' ) . '><a href="' . esc_url( $item[1] ) . '"' . ( $item[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $item[0] ) . '</a></li>';
	}
	echo '</ul></nav>';
}

function izl_menu_items() {
	// 3.11.0 (Dan, 2026-11-18): "Kezdőknek" left the menu (top bar, the list pages' menu, the search chips); the shop's
	// filter bar keeps its Kezdő button.
	$items    = array();
	$isopods  = izl_isopods_url();
	$supplies = izl_supplies_term();
	if ( $isopods ) {
		$items[] = array( __( 'Isopods', 'izeltlab' ), $isopods, izl_on_isopods_page() );
	}
	if ( $supplies ) {
		$items[] = array( __( 'Supplies', 'izeltlab' ), get_term_link( $supplies ), function_exists( 'is_product_category' ) && is_product_category( IZL_SUPPLIES ) );
	}
	return $items;
}

function izl_icon( $name ) {
	$paths = array(
		'search' => '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
		'user'   => '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>',
		'cart'   => '<path d="M2.5 3.8h3l2.5 11h10l2.5-8h-14"/><circle cx="9.5" cy="18.8" r="1.4"/><circle cx="16.5" cy="18.8" r="1.4"/>', // 3.12.0: centred in its button
		'close'  => '<path d="M6 6l12 12M18 6L6 18"/>', // 3.13.0: the PC search's close button
	);
	return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $paths[ $name ] . '</svg>';
}

// The count on the cart icon. 1.7.18: it carries the cart total too (data-total), so the free-shipping progress on the
// product page knows it right after an add to cart.
function izl_cart_count_html() {
	$n = function_exists( 'WC' ) && WC()->cart ? (int) WC()->cart->get_cart_contents_count() : 0;
	return '<span class="izl-cart-count' . ( $n ? '' : ' is-empty' ) . '" data-total="' . esc_attr( izl_cart_total() ) . '">' . (int) $n . '</span>';
}

function izl_header_icons() {
	if ( ! function_exists( 'wc_get_cart_url' ) ) {
		return;
	}
	echo '<div class="izl-icons">';
	// 2.6.0: opens the search panel under the top bar (inc/finder.php); a plain link to it without JavaScript
	echo '<a class="izl-icon izl-search-btn" href="#izl-sp" role="button" aria-controls="izl-sp" aria-expanded="false" aria-label="' . esc_attr__( 'Search', 'izeltlab' ) . '" title="' . esc_attr__( 'Search', 'izeltlab' ) . '">' . izl_icon( 'search' ) . '<span class="izl-search-word" aria-hidden="true">' . esc_html__( 'Search…', 'izeltlab' ) . '</span></a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '<a class="izl-icon izl-acc" href="' . esc_url( wc_get_page_permalink( 'myaccount' ) ) . '" aria-label="' . esc_attr__( 'My account', 'izeltlab' ) . '" title="' . esc_attr__( 'My account', 'izeltlab' ) . '">' . izl_icon( 'user' ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '<a class="izl-icon izl-cart" href="' . esc_url( wc_get_cart_url() ) . '" aria-label="' . esc_attr__( 'Cart', 'izeltlab' ) . '" title="' . esc_attr__( 'Cart', 'izeltlab' ) . '">' . izl_icon( 'cart' ) . izl_cart_count_html() . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	do_action( 'izl_after_cart_icon' ); // 2.1.0: the mini cart (inc/launch.php)
	echo '</div>';
}

// The count on the cart icon follows "add to cart" without a reload.
add_filter( 'woocommerce_add_to_cart_fragments', function ( $fragments ) {
	$fragments['span.izl-cart-count'] = izl_cart_count_html();
	return $fragments;
} );

// ==========================================================================
//  The phone menu (since 3.11.0)
// ==========================================================================

// The menu button at the left end of the phone's top bar (hidden on PC, style.css section 49). It opens the menu panel
// (izl_menu_panel); without JavaScript it is a plain link to it (#izl-menu, opened by :target).
function izl_menu_button() {
	echo '<a class="izl-icon izl-menu-btn" href="#izl-menu" role="button" aria-controls="izl-menu" aria-expanded="false" aria-label="' . esc_attr__( 'Menu', 'izeltlab' ) . '" title="' . esc_attr__( 'Menu', 'izeltlab' ) . '"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 6h16M4 12h16M4 18h16"/></svg></a>';
}

// The menu panel: slides in from the left over a dimmed page. The shop's areas (the same as the PC menu), then the
// account. Closes with its X, a tap on the dimmed page, Esc or a link. Printed at the end of the page, so the top bar
// (fixed on some pages) does not hold it.
add_action( 'wp_footer', 'izl_menu_panel', 5 );
function izl_menu_panel() {
	echo '<div class="izl-menu" id="izl-menu"><a class="izl-menu-dim" href="#" tabindex="-1" aria-hidden="true"></a>';
	echo '<nav class="izl-menu-in" aria-label="' . esc_attr__( 'Main menu', 'izeltlab' ) . '">';
	echo '<p class="izl-menu-top"><span class="izl-menu-name" aria-hidden="true">ízeltláb</span><a class="izl-menu-x" href="#" aria-label="' . esc_attr__( 'Close menu', 'izeltlab' ) . '"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6L6 18"/></svg></a></p>';
	echo '<ul class="izl-menu-list">';
	if ( has_nav_menu( 'izeltlab-main' ) ) {
		wp_nav_menu( array( 'theme_location' => 'izeltlab-main', 'container' => false, 'items_wrap' => '%3$s', 'depth' => 1, 'fallback_cb' => false ) );
	} else {
		foreach ( izl_menu_items() as $item ) {
			echo '<li' . ( $item[2] ? ' class="is-current"' : '' ) . '><a href="' . esc_url( $item[1] ) . '"' . ( $item[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $item[0] ) . '</a></li>';
		}
	}
	if ( function_exists( 'wc_get_page_permalink' ) ) {
		echo '<li class="izl-menu-acc"><a href="' . esc_url( wc_get_page_permalink( 'myaccount' ) ) . '">' . izl_icon( 'user' ) . esc_html__( 'My account', 'izeltlab' ) . '</a></li>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</ul></nav></div>';
	// opening and closing (a few lines, so they live here rather than in a file of their own)
	$js = <<<'JS'
(function(){var m=document.getElementById('izl-menu'),bs=document.querySelectorAll('.izl-menu-btn');if(!m||!bs.length){return}var last=null;function set(on){for(var i=0;i<bs.length;i++){bs[i].setAttribute('aria-expanded',on?'true':'false')}}function open(b,kb){if(window.izlFindClose){window.izlFindClose()}last=b||bs[0];m.classList.add('is-open');document.documentElement.classList.add('izl-menu-on');set(true);var f=kb&&m.querySelector('.izl-menu-list a');if(f){f.focus({preventScroll:true})}}function close(back){m.classList.remove('is-open');document.documentElement.classList.remove('izl-menu-on');set(false);if('#izl-menu'===location.hash&&history.replaceState){history.replaceState(null,'',location.pathname+location.search)}if(back&&last&&last.offsetParent){last.focus({preventScroll:true})}}for(var i=0;i<bs.length;i++){bs[i].addEventListener('click',function(e){e.preventDefault();if(m.classList.contains('is-open')){close(true)}else{open(this,0===e.detail)}})}m.addEventListener('click',function(e){var a=e.target.closest('a');if(!a){return}if(a.classList.contains('izl-menu-dim')||a.classList.contains('izl-menu-x')){e.preventDefault();close(true)}else{close(false)}});document.addEventListener('keydown',function(e){if('Escape'===e.key&&m.classList.contains('is-open')){close(true)}});window.addEventListener('pageshow',function(e){if(e.persisted){close(false)}});if('#izl-menu'===location.hash){open()}})();
JS;
	echo '<script>' . $js . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}

// ==========================================================================
//  The cart button's hop (since 3.12.0)
// ==========================================================================

// 3.12.0 (Dan, 2026-11-18): when something goes into the cart on any page (the lists' "Kosárba" buttons, WooCommerce's
// added_to_cart), the cart button in the top bar bounces once and its number pops, as on the product page (where
// assets/product.js does it at the press itself). style.css .izl-cart.is-bump, .izl-cart-count.is-pop.
add_action( 'wp_footer', function () {
	if ( ! function_exists( 'wc_get_cart_url' ) ) {
		return;
	}
	$js = <<<'JS'
(function(){var $=window.jQuery;if(!$||document.body.classList.contains('single-product')){return}$(document.body).on('added_to_cart',function(){window.requestAnimationFrame(function(){document.querySelectorAll('.izl-icon.izl-cart').forEach(function(a){var n=a.querySelector('.izl-cart-count');a.classList.remove('is-bump');void a.offsetWidth;a.classList.add('is-bump');if(n){n.classList.remove('is-pop');void n.offsetWidth;n.classList.add('is-pop')}})})})})();
JS;
	echo '<script>' . $js . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}, 30 );
