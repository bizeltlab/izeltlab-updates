<?php
// ==========================================================================
//  FILE: inc/site-header.php   (Ízeltláb theme)
//  WHAT: The top bar: logo, menu, search / account / cart icons and the cart counter. 3.11.0 (Dan, 2026-11-18): the
//        new top bar. Phone and tablet: menu button left, the name in the exact middle, search and cart right (the
//        account moves into the menu); the search field opens leftwards over the name (inc/finder.php). PC: three
//        balanced zones, name and menu left, the search field always in the middle, account and cart right.
//        3.13.0 (Dan, 2026-11-18, mock option 3 "Clean"): PC has name and menu left and three buttons right; the first
//        is a wide "Keresés…" button that looks a little like a search bar and opens the field leftwards on a click,
//        so the menu has room for more sections.
//        3.17.0 (Dan, 2026-11-19, front page mock F): PC only. The bar is taller (88px) with a bigger name, the menu
//        words leave it and three square buttons stay at the right (search, account, cart); under it a darker
//        category bar with a button per animal group and the free-shipping progress at its right end. Scrolled down,
//        the whole thing turns into one slim fixed bar (name, the group buttons, the three buttons).
//  SEEN: The top of every page.
//  SECTIONS IN THIS FILE:
//    1. Header: logo, menu, search / account / cart
//    2. The phone menu (since 3.11.0)
//    3. The cart button's hop (since 3.12.0)
//    4. The category bar and the slim top bar (since 3.17.0)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Header: logo, menu, search / account / cart
// ==========================================================================

add_action( 'init', function () {
	remove_action( 'storefront_header', 'storefront_secondary_navigation', 30 );
	remove_action( 'storefront_header', 'storefront_product_search', 40 );
	remove_action( 'storefront_header', 'storefront_header_cart', 60 );
	remove_action( 'storefront_header', 'storefront_primary_navigation_wrapper', 42 );
	remove_action( 'storefront_header', 'storefront_primary_navigation', 50 );
	remove_action( 'storefront_header', 'storefront_primary_navigation_wrapper_close', 68 );
	add_action( 'storefront_header', 'izl_menu_button', 15 ); // 3.11.0: before the name (Storefront's at 20)
	add_action( 'storefront_header', 'izl_header_nav', 30 );
	add_action( 'storefront_header', 'izl_header_icons', 35 );
	add_action( 'storefront_header', 'izl_cat_bar_slim', 32 ); // 3.17.0: the slim bar's group buttons (PC, scrolled)
	add_action( 'storefront_header', 'izl_cat_bar', 43 );      // 3.17.0: under the bar's row (closes at 41), before the search (45)
	// Sorting and count only above the products, not twice (the page numbers stay below).
	remove_action( 'woocommerce_after_shop_loop', 'woocommerce_catalog_ordering', 10 );
	remove_action( 'woocommerce_after_shop_loop', 'woocommerce_result_count', 20 );
	// Storefront's previous / next product photos, half hidden at the two screen edges: they look like a broken image.
	remove_action( 'woocommerce_after_single_product_summary', 'storefront_single_product_pagination', 30 );
} );

/**
 * The menu: a menu set under Appearance → Menus → "Main menu (Ízeltláb header)" if there is one,
 * otherwise Isopods and Supplies, made from the shop's own categories.
 */
function izl_header_nav() {
	echo '<nav class="izl-nav" aria-label="' . esc_attr__( 'Main menu', 'izeltlab' ) . '">';
	if ( has_nav_menu( 'izeltlab-main' ) ) {
		wp_nav_menu( array( 'theme_location' => 'izeltlab-main', 'container' => false, 'depth' => 1, 'fallback_cb' => false ) );
	} else {
		echo '<ul class="menu">';
		foreach ( izl_menu_items() as $item ) {
			echo '<li' . ( $item[2] ? ' class="is-current"' : '' ) . '><a href="' . esc_url( $item[1] ) . '"' . ( $item[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $item[0] ) . '</a></li>';
		}
		echo '</ul>';
	}
	echo '</nav>';
}

// 2.6.0: on phones the top bar has no menu row (the same slim bar on every page); the list pages show the menu links
// under their title instead (style.css .izl-list-menu, hidden on computers, where the header keeps its menu).
add_action( 'woocommerce_archive_description', 'izl_list_menu', 1 );
function izl_list_menu() {
	$items = izl_menu_items();
	if ( ! $items ) {
		return;
	}
	echo '<nav aria-label="' . esc_attr__( 'Main menu', 'izeltlab' ) . '"><ul class="izl-list-menu">';
	foreach ( $items as $item ) {
		echo '<li' . ( $item[2] ? ' class="is-current"' : '' ) . '><a href="' . esc_url( $item[1] ) . '"' . ( $item[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $item[0] ) . '</a></li>';
	}
	echo '</ul></nav>';
}

function izl_menu_items() {
	// 3.22.0 (Dan, 2026-11-25): the phone menu lists the header's buttons (the groups and genera ticked in the Groups
	// dialog, those not set to "PC only"), in the same order
	if ( function_exists( 'izl_header_buttons_for' ) ) {
		$items = array();
		foreach ( izl_header_buttons_for( 'phone' ) as $b ) {
			$items[] = array( $b[0], $b[1], $b[2] );
		}
		if ( $items ) {
			return $items;
		}
	}
	// 3.11.0 (Dan, 2026-11-18): "Kezdőknek" left the menu (top bar, the list pages' menu, the search chips); the shop's
	// filter bar keeps its Kezdő button.
	$items    = array();
	$isopods  = izl_isopods_url();
	$supplies = izl_supplies_term();
	if ( $isopods ) {
		$items[] = array( __( 'Isopods', 'izeltlab' ), $isopods, izl_on_isopods_page() );
	}
	if ( $supplies ) {
		$items[] = array( __( 'Supplies', 'izeltlab' ), get_term_link( $supplies ), function_exists( 'is_product_category' ) && is_product_category( IZL_SUPPLIES ) );
	}
	return $items;
}

function izl_icon( $name ) {
	$paths = array(
		'search' => '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
		'user'   => '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>',
		'cart'   => '<path d="M2.5 3.8h3l2.5 11h10l2.5-8h-14"/><circle cx="9.5" cy="18.8" r="1.4"/><circle cx="16.5" cy="18.8" r="1.4"/>', // 3.12.0: centred in its button
		'close'  => '<path d="M6 6l12 12M18 6L6 18"/>', // 3.13.0: the PC search's close button
	);
	return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $paths[ $name ] . '</svg>';
}

// The count on the cart icon. 1.7.18: it carries the cart total too (data-total), so the free-shipping progress on the
// product page knows it right after an add to cart.
function izl_cart_count_html() {
	$n = function_exists( 'WC' ) && WC()->cart ? (int) WC()->cart->get_cart_contents_count() : 0;
	return '<span class="izl-cart-count' . ( $n ? '' : ' is-empty' ) . '" data-total="' . esc_attr( izl_cart_total() ) . '">' . (int) $n . '</span>';
}

function izl_header_icons() {
	if ( ! function_exists( 'wc_get_cart_url' ) ) {
		return;
	}
	echo '<div class="izl-icons">';
	// 2.6.0: opens the search panel under the top bar (inc/finder.php); a plain link to it without JavaScript
	echo '<a class="izl-icon izl-search-btn" href="#izl-sp" role="button" aria-controls="izl-sp" aria-expanded="false" aria-label="' . esc_attr__( 'Search', 'izeltlab' ) . '" title="' . esc_attr__( 'Search', 'izeltlab' ) . '">' . izl_icon( 'search' ) . '<span class="izl-search-word" aria-hidden="true">' . esc_html__( 'Search…', 'izeltlab' ) . '</span></a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '<a class="izl-icon izl-acc" href="' . esc_url( wc_get_page_permalink( 'myaccount' ) ) . '" aria-label="' . esc_attr__( 'My account', 'izeltlab' ) . '" title="' . esc_attr__( 'My account', 'izeltlab' ) . '">' . izl_icon( 'user' ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '<a class="izl-icon izl-cart" href="' . esc_url( wc_get_cart_url() ) . '" aria-label="' . esc_attr__( 'Cart', 'izeltlab' ) . '" title="' . esc_attr__( 'Cart', 'izeltlab' ) . '">' . izl_icon( 'cart' ) . izl_cart_count_html() . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	do_action( 'izl_after_cart_icon' ); // 2.1.0: the mini cart (inc/launch.php)
	echo '</div>';
}

// The count on the cart icon follows "add to cart" without a reload.
add_filter( 'woocommerce_add_to_cart_fragments', function ( $fragments ) {
	$fragments['span.izl-cart-count'] = izl_cart_count_html();
	return $fragments;
} );

// ==========================================================================
//  The phone menu (since 3.11.0)
// ==========================================================================

// The menu button at the left end of the phone's top bar (hidden on PC, style.css section 49). It opens the menu panel
// (izl_menu_panel); without JavaScript it is a plain link to it (#izl-menu, opened by :target).
function izl_menu_button() {
	echo '<a class="izl-icon izl-menu-btn" href="#izl-menu" role="button" aria-controls="izl-menu" aria-expanded="false" aria-label="' . esc_attr__( 'Menu', 'izeltlab' ) . '" title="' . esc_attr__( 'Menu', 'izeltlab' ) . '"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 6h16M4 12h16M4 18h16"/></svg></a>';
}

// The menu panel: slides in from the left over a dimmed page. The shop's areas (the same as the PC menu), then the
// account. Closes with its X, a tap on the dimmed page, Esc or a link. Printed at the end of the page, so the top bar
// (fixed on some pages) does not hold it.
add_action( 'wp_footer', 'izl_menu_panel', 5 );
function izl_menu_panel() {
	echo '<div class="izl-menu" id="izl-menu"><a class="izl-menu-dim" href="#" tabindex="-1" aria-hidden="true"></a>';
	echo '<nav class="izl-menu-in" aria-label="' . esc_attr__( 'Main menu', 'izeltlab' ) . '">';
	echo '<p class="izl-menu-top"><span class="izl-menu-name" aria-hidden="true">ízeltláb</span><a class="izl-menu-x" href="#" aria-label="' . esc_attr__( 'Close menu', 'izeltlab' ) . '"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6L6 18"/></svg></a></p>';
	echo '<ul class="izl-menu-list">';
	if ( has_nav_menu( 'izeltlab-main' ) ) {
		wp_nav_menu( array( 'theme_location' => 'izeltlab-main', 'container' => false, 'items_wrap' => '%3$s', 'depth' => 1, 'fallback_cb' => false ) );
	} else {
		foreach ( izl_menu_items() as $item ) {
			echo '<li' . ( $item[2] ? ' class="is-current"' : '' ) . '><a href="' . esc_url( $item[1] ) . '"' . ( $item[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $item[0] ) . '</a></li>';
		}
	}
	if ( function_exists( 'wc_get_page_permalink' ) ) {
		echo '<li class="izl-menu-acc"><a href="' . esc_url( wc_get_page_permalink( 'myaccount' ) ) . '">' . izl_icon( 'user' ) . esc_html__( 'My account', 'izeltlab' ) . '</a></li>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</ul></nav></div>';
	// opening and closing (a few lines, so they live here rather than in a file of their own)
	$js = <<<'JS'
(function(){var m=document.getElementById('izl-menu'),bs=document.querySelectorAll('.izl-menu-btn');if(!m||!bs.length){return}var last=null;function set(on){for(var i=0;i<bs.length;i++){bs[i].setAttribute('aria-expanded',on?'true':'false')}}function open(b,kb){if(window.izlFindClose){window.izlFindClose()}last=b||bs[0];m.classList.add('is-open');document.documentElement.classList.add('izl-menu-on');set(true);var f=kb&&m.querySelector('.izl-menu-list a');if(f){f.focus({preventScroll:true})}}function close(back){m.classList.remove('is-open');document.documentElement.classList.remove('izl-menu-on');set(false);if('#izl-menu'===location.hash&&history.replaceState){history.replaceState(null,'',location.pathname+location.search)}if(back&&last&&last.offsetParent){last.focus({preventScroll:true})}}for(var i=0;i<bs.length;i++){bs[i].addEventListener('click',function(e){e.preventDefault();if(m.classList.contains('is-open')){close(true)}else{open(this,0===e.detail)}})}m.addEventListener('click',function(e){var a=e.target.closest('a');if(!a){return}if(a.classList.contains('izl-menu-dim')||a.classList.contains('izl-menu-x')){e.preventDefault();close(true)}else{close(false)}});document.addEventListener('keydown',function(e){if('Escape'===e.key&&m.classList.contains('is-open')){close(true)}});window.addEventListener('pageshow',function(e){if(e.persisted){close(false)}});if('#izl-menu'===location.hash){open()}})();
JS;
	echo '<script>' . $js . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}

// ==========================================================================
//  The cart button's hop (since 3.12.0)
// ==========================================================================

// 3.12.0 (Dan, 2026-11-18): when something goes into the cart on any page (the lists' "Kosárba" buttons, WooCommerce's
// added_to_cart), the cart button in the top bar bounces once and its number pops, as on the product page (where
// assets/product.js does it at the press itself). style.css .izl-cart.is-bump, .izl-cart-count.is-pop.
add_action( 'wp_footer', function () {
	if ( ! function_exists( 'wc_get_cart_url' ) ) {
		return;
	}
	$js = <<<'JS'
(function(){var $=window.jQuery;if(!$||document.body.classList.contains('single-product')){return}$(document.body).on('added_to_cart',function(){window.requestAnimationFrame(function(){document.querySelectorAll('.izl-icon.izl-cart').forEach(function(a){var n=a.querySelector('.izl-cart-count');a.classList.remove('is-bump');void a.offsetWidth;a.classList.add('is-bump');if(n){n.classList.remove('is-pop');void n.offsetWidth;n.classList.add('is-pop')}})})})})();
JS;
	echo '<script>' . $js . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}, 30 );

// ==========================================================================
//  The category bar and the slim top bar (since 3.17.0)
// ==========================================================================

/**
 * 3.21.0: the group settings kept for the header and the front page (Dan, 2026-11-24, groups from the site): the order
 * of the group buttons (one order for the header bar and the front page tiles / buttons), each button's own text and
 * the small line on its front page tile. Keys: "isopoda" (the one Isopods button) or "id<term id>". Option izl_groups,
 * written by the Groups dialog (inc/edit-groups.php).
 */
function izl_groups_cfg() {
	$c = get_option( 'izl_groups', array() );
	$c = is_array( $c ) ? $c : array();
	// 3.22.0: links (a button's own address), where (a button only on "pc" or only on "phone") and also (a group key =>
	// the genus term ids that show on that group's page too, while staying in their own group)
	foreach ( array( 'order', 'names', 'lines', 'links', 'where', 'also' ) as $k ) {
		$c[ $k ] = isset( $c[ $k ] ) && is_array( $c[ $k ] ) ? $c[ $k ] : array();
	}
	// 3.21.1: the groups ticked for the header (null = never set: every group that has products)
	$c['shown'] = isset( $c['shown'] ) && is_array( $c['shown'] ) ? array_values( array_map( 'strval', $c['shown'] ) ) : null;
	return $c;
}

/**
 * 3.21.0: a top group's card type set in the Groups dialog (term meta izl_kind) wins over the one Codex reads from the
 * name: one of isopoda / blattodea / collembola / arachnida, or "none" for no Codex card. Not set = by the name.
 */
function izl_group_kind_filter( $kind, $term ) {
	if ( $term && ! empty( $term->term_id ) ) {
		$set = (string) get_term_meta( $term->term_id, 'izl_kind', true );
		if ( 'none' === $set ) {
			return '';
		}
		if ( in_array( $set, array( 'isopoda', 'blattodea', 'collembola', 'arachnida' ), true ) ) {
			return $set;
		}
	}
	return $kind;
}
add_filter( 'fsz_group_kind', 'izl_group_kind_filter', 10, 2 );

/**
 * The animal groups for the category bar: every top category that has products (its own or its sub-categories').
 * Without an order set: isopods (one button, the "Isopods" page), springtails, cockroaches, spiders, any other
 * category, the supplies last. 3.21.0: the order set in the Groups dialog comes first (groups it does not name follow
 * in the fixed order) and a button text set there replaces the name. 3.21.1 (Dan, 2026-11-24): only the groups ticked
 * in the Groups dialog get a button (never set: every group with products), and an empty group never shows, not even
 * to shop managers. A group's button is lit (yellow) on its own pages: its category pages, and the product pages of
 * its species. Each: array( label, url, is_current, 'key' => .., 'term' => term id, 'kind' => .., 'empty' => bool,
 * 'shown' => bool ). $all = true: every group that could have a button, ticked or not, empty or not (the dialog's list).
 */
function izl_cat_items( $all = false ) {
	static $cache = array();
	$k = $all ? 1 : 0;
	if ( ! isset( $cache[ $k ] ) ) {
		$cache[ $k ] = izl_cat_items_build( (bool) $all );
	}
	return $cache[ $k ];
}

function izl_cat_items_build( $all ) {
	$items = array();
	if ( ! taxonomy_exists( 'product_cat' ) ) {
		return $items;
	}
	$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'pad_counts' => true ) );
	if ( ! $terms || is_wp_error( $terms ) ) {
		return $items;
	}
	// the top group of the page on show: a category page's own top category, or a product page's group
	$here = 0;
	if ( function_exists( 'is_product_category' ) && is_product_category() ) {
		$t = get_queried_object();
		$a = get_ancestors( $t->term_id, 'product_cat', 'taxonomy' );
		$here = $a ? (int) end( $a ) : (int) $t->term_id;
	} elseif ( function_exists( 'is_product' ) && is_product() ) {
		$g    = izl_group_term( get_the_ID() );
		$here = $g ? (int) $g->term_id : 0;
	}
	$names    = array(
		'isopoda'    => __( 'Isopods', 'izeltlab' ),
		'collembola' => __( 'Springtails', 'izeltlab' ),
		'blattodea'  => __( 'Cockroaches', 'izeltlab' ),
		'arachnida'  => __( 'Spiders', 'izeltlab' ),
	);
	$order    = array( 'isopoda' => 0, 'collembola' => 1, 'blattodea' => 2, 'arachnida' => 3 );
	$isopods  = array_map( 'intval', wp_list_pluck( izl_isopod_terms(), 'term_id' ) );
	$skip     = (int) get_option( 'default_product_cat', 0 ); // "Uncategorized"
	$rows     = array();
	$iso_on   = function_exists( 'is_shop' ) && is_shop() && izl_isopods_view(); // the "Isopods" page (all isopod categories)
	foreach ( $terms as $t ) {
		if ( $t->parent ) {
			continue;
		}
		$empty = (int) $t->count < 1;
		$kind  = function_exists( 'fsz_term_kind' ) ? fsz_term_kind( $t ) : '';
		// the default category is left out only while it is the plain "Uncategorized" one: on the live shop it was
		// renamed to ISOPODA and holds the isopods (3.18.0)
		if ( (int) $t->term_id === $skip && '' === $kind && ! in_array( (int) $t->term_id, $isopods, true ) ) {
			continue;
		}
		if ( '' === $kind && in_array( (int) $t->term_id, $isopods, true ) ) {
			$kind = 'isopoda'; // a Codex category with no group word in its name
		}
		$on = (int) $t->term_id === $here;
		if ( 'isopoda' === $kind ) {
			// all isopod categories share one button, the "Isopods" page
			// (one isopod category: its own page; several: the "Isopods" page)
			if ( isset( $rows['isopoda'] ) ) {
				if ( $empty ) {
					continue; // an empty isopod category does not take the button over
				}
				$url             = izl_isopods_url();
				$was             = $rows['isopoda'];
				$rows['isopoda'] = array( 0, $names['isopoda'], $url ? $url : ( $was[6] ? get_term_link( $t ) : $was[2] ), $was[3] || $on, $was[6] ? (int) $t->term_id : $was[4], 'isopoda', false );
				continue;
			}
			$link = get_term_link( $t );
			if ( is_wp_error( $link ) ) {
				continue;
			}
			$rows['isopoda'] = array( 0, $names['isopoda'], $link, $on || $iso_on, (int) $t->term_id, 'isopoda', $empty );
			continue;
		}
		$link = get_term_link( $t );
		if ( is_wp_error( $link ) ) {
			continue;
		}
		if ( IZL_SUPPLIES === $t->slug ) {
			$rows[ 'id' . $t->term_id ] = array( 9, __( 'Supplies', 'izeltlab' ), $link, $on, (int) $t->term_id, 'supplies', $empty );
		} elseif ( isset( $order[ $kind ] ) ) {
			$rows[ 'id' . $t->term_id ] = array( 1 + $order[ $kind ], $names[ $kind ], $link, $on, (int) $t->term_id, $kind, $empty );
		} else {
			$rows[ 'id' . $t->term_id ] = array( 5, $t->name, $link, $on, (int) $t->term_id, '', $empty );
		}
	}
	// the order set in the Groups dialog: named groups first, in that order (stable sort: ties keep the fixed order)
	$cfg  = izl_groups_cfg();
	$pos  = array_flip( array_values( array_map( 'strval', $cfg['order'] ) ) );
	$keys = array_keys( $rows );
	usort( $keys, function ( $a, $b ) use ( $rows, $pos ) {
		$pa = isset( $pos[ $a ] ) ? $pos[ $a ] : 1000 + $rows[ $a ][0];
		$pb = isset( $pos[ $b ] ) ? $pos[ $b ] : 1000 + $rows[ $b ][0];
		return $pa - $pb;
	} );
	// 3.22.0: a group whose own categories are empty still gets its button when a genus shown there too has products
	$counts = wp_list_pluck( $terms, 'count', 'term_id' );
	foreach ( $cfg['also'] as $gkey => $ids ) {
		if ( isset( $rows[ $gkey ] ) && $rows[ $gkey ][6] ) {
			foreach ( (array) $ids as $tid ) {
				if ( ! empty( $counts[ (int) $tid ] ) ) {
					$rows[ $gkey ][6] = false;
					break;
				}
			}
		}
	}
	foreach ( $keys as $key ) {
		$r     = $rows[ $key ];
		$shown = null === $cfg['shown'] ? ! $r[6] : in_array( $key, $cfg['shown'], true );
		if ( ! $all && ( $r[6] || ! $shown ) ) {
			continue; // empty, or not ticked for the header
		}
		$label   = isset( $cfg['names'][ $key ] ) && '' !== trim( (string) $cfg['names'][ $key ] ) ? (string) $cfg['names'][ $key ] : $r[1];
		$items[] = array( $label, $r[2], $r[3], 'key' => $key, 'term' => $r[4], 'kind' => $r[5], 'empty' => $r[6], 'shown' => $shown, 'default' => $r[1] );
	}
	return $items;
}

/**
 * 3.22.0: the header key of a top category: "isopoda" for every isopod group (they share one button), else
 * "id<term id>" (the same as izl_cat_items_build() and the Groups dialog).
 */
function izl_top_key( $term ) {
	static $iso = null;
	if ( null === $iso ) {
		$iso = array_map( 'intval', wp_list_pluck( izl_isopod_terms(), 'term_id' ) );
	}
	$kind = function_exists( 'fsz_term_kind' ) ? fsz_term_kind( $term ) : '';
	return 'isopoda' === $kind || ( '' === $kind && in_array( (int) $term->term_id, $iso, true ) ) ? 'isopoda' : 'id' . (int) $term->term_id;
}

/**
 * 3.22.0 (Dan, 2026-11-25): the header's buttons: the groups (izl_cat_items) and, ticked in the Groups dialog, single
 * genera (a group's subcategories: "Porcellio", "Cubaris"…), in one order. A genus key is "g<term id>". Each button
 * can have its own text, its own address and be shown on PC only or on phones only. Never set: the groups with
 * products, as before; genera only once ticked. Empty ones never show.
 * Each: array( label, url, is_current, 'key', 'type' => group|genus, 'term', 'group' => its group's key, 'name' (its
 * own name), 'empty', 'shown', 'where' => ''|pc|phone, 'count' ). $all = true: every button that could be (the dialog).
 */
function izl_header_buttons( $all = false ) {
	static $cache = array();
	$k = $all ? 1 : 0;
	if ( isset( $cache[ $k ] ) ) {
		return $cache[ $k ];
	}
	$cfg    = izl_groups_cfg();
	$pos    = array_flip( array_values( array_map( 'strval', $cfg['order'] ) ) );
	$groups = izl_cat_items( true );
	$terms  = taxonomy_exists( 'product_cat' ) ? get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'pad_counts' => true ) ) : array();
	$terms  = is_array( $terms ) ? $terms : array();
	$byid   = array();
	foreach ( $terms as $t ) {
		$byid[ (int) $t->term_id ] = $t;
	}
	// the page on show: its category (and the ones above it), or a product page's categories
	$here = array();
	if ( function_exists( 'is_product_category' ) && is_product_category() ) {
		$q    = get_queried_object();
		$here = array_merge( array( (int) $q->term_id ), array_map( 'intval', get_ancestors( $q->term_id, 'product_cat', 'taxonomy' ) ) );
	} elseif ( function_exists( 'is_product' ) && is_product() ) {
		foreach ( wp_get_post_terms( get_the_ID(), 'product_cat', array( 'fields' => 'ids' ) ) as $tid ) {
			$here = array_merge( $here, array( (int) $tid ), array_map( 'intval', get_ancestors( $tid, 'product_cat', 'taxonomy' ) ) );
		}
	}
	$rows = array();
	foreach ( $groups as $gi => $g ) {
		$base   = isset( $pos[ $g['key'] ] ) ? $pos[ $g['key'] ] : 1000 + $gi * 10;
		$rows[] = array( $base, array( $g[0], $g[1], $g[2], 'key' => $g['key'], 'type' => 'group', 'term' => $g['term'], 'group' => $g['key'], 'name' => $g['default'], 'empty' => $g['empty'], 'count' => 0 ) );
		// its genera: the subcategories right under its top categories (all isopod groups share the one key)
		$gn = 0;
		foreach ( $terms as $t ) {
			$top = $t->parent ? ( isset( $byid[ (int) $t->parent ] ) ? $byid[ (int) $t->parent ] : null ) : null;
			if ( ! $top || $top->parent || izl_top_key( $top ) !== $g['key'] ) {
				continue;
			}
			$key  = 'g' . (int) $t->term_id;
			$link = get_term_link( $t );
			if ( is_wp_error( $link ) ) {
				continue;
			}
			$rows[] = array( isset( $pos[ $key ] ) ? $pos[ $key ] : $base + 0.01 * ( ++$gn ), array( $t->name, $link, in_array( (int) $t->term_id, $here, true ), 'key' => $key, 'type' => 'genus', 'term' => (int) $t->term_id, 'group' => $g['key'], 'name' => $t->name, 'empty' => (int) $t->count < 1, 'count' => (int) $t->count ) );
		}
	}
	usort( $rows, function ( $a, $b ) {
		return $a[0] <=> $b[0];
	} );
	$out = array();
	foreach ( $rows as $r ) {
		$b          = $r[1];
		$key        = $b['key'];
		$b['shown'] = null === $cfg['shown'] ? ( 'group' === $b['type'] && ! $b['empty'] ) : in_array( $key, $cfg['shown'], true );
		$b['where'] = isset( $cfg['where'][ $key ] ) && in_array( $cfg['where'][ $key ], array( 'pc', 'phone' ), true ) ? $cfg['where'][ $key ] : '';
		$b['link']  = isset( $cfg['links'][ $key ] ) ? (string) $cfg['links'][ $key ] : '';
		$b['label'] = isset( $cfg['names'][ $key ] ) ? (string) $cfg['names'][ $key ] : '';
		if ( 'genus' === $b['type'] && '' !== trim( $b['label'] ) ) {
			$b[0] = $b['label']; // (a group's own text is already in izl_cat_items)
		}
		if ( '' !== trim( $b['link'] ) ) {
			$b[1] = $b['link'];
			$b[2] = false; // an own address: lit only by its own page (not worked out here)
		}
		if ( ! $all && ( $b['empty'] || ! $b['shown'] ) ) {
			continue;
		}
		$out[] = $b;
	}
	$cache[ $k ] = $out;
	return $out;
}

// The buttons for one place: "pc" (the category bar) or "phone" (the phone menu).
function izl_header_buttons_for( $place ) {
	return array_values( array_filter( izl_header_buttons(), function ( $b ) use ( $place ) {
		return '' === $b['where'] || $place === $b['where'];
	} ) );
}

function izl_cat_links() {
	$out = '';
	foreach ( izl_header_buttons_for( 'pc' ) as $item ) {
		$out .= '<a class="izl-cb' . ( $item[2] ? ' is-on' : '' ) . ( 'genus' === $item['type'] ? ' is-genus' : '' ) . '" href="' . esc_url( $item[1] ) . '"' . ( $item[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $item[0] ) . '</a>';
	}
	return $out;
}

// The bar under the top bar's row (PC; phones never show it, style.css section 3.17.0).
function izl_cat_bar() {
	$links = izl_cat_links();
	$edit  = function_exists( 'izl_groups_header_buttons' ) ? izl_groups_header_buttons() : ''; // 3.21.0: shop managers only (inc/edit-groups.php)
	echo '<div class="izl-cbar"><nav class="col-full" aria-label="' . esc_attr__( 'Categories', 'izeltlab' ) . '">' . $links . $edit . izl_cbar_ship_html() . '</nav></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
}

// The same buttons inside the row, shown only in the slim bar (html.izl-slim), where the category bar is hidden.
function izl_cat_bar_slim() {
	$links = izl_cat_links();
	if ( '' !== $links ) {
		echo '<nav class="izl-cbar-slim" aria-label="' . esc_attr__( 'Categories', 'izeltlab' ) . '">' . $links . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

/**
 * The free-shipping progress at the bar's right end. 3.19.0 (Dan, 2026-11-20/22): nothing while the basket is empty (an
 * empty basket hearing "free over 20 000 Ft" thinks of the cost; with something in it, free shipping is a nice bonus),
 * then a ring that fills up with two short lines next to it: "INGYENES SZÁLLÍTÁSIG / még 4 700 Ft", once free
 * "SZÁLLÍTÁS / ✓ ingyenes!". No button look (the buttons at the left are the groups). Lined up with the top bar:
 * the ring's right edge on the cart button's, the text's right edge on the account button's, the first line's
 * capitals on the group buttons' top edge, the second line's foot on their bottom edge (style.css section 56). The
 * cached pages are drawn with an empty basket; WooCommerce's cart refresh redraws it for a shopper with something in it.
 */
function izl_cbar_ship_html() {
	$goal = function_exists( 'izl_free_ship' ) ? (float) izl_free_ship() : 0;
	if ( $goal <= 0 || ! function_exists( 'WC' ) || ! WC()->cart || WC()->cart->is_empty() || ! function_exists( 'izl_cart_total' ) ) {
		return '<div class="izl-cbar-ship"></div>';
	}
	$sum  = (float) izl_cart_total();
	$left = max( 0, $goal - $sum );
	$pct  = max( 3, min( 100, round( $sum / $goal * 100 ) ) );
	$done = $left <= 0;
	if ( $done ) {
		$top = _x( 'Shipping', 'free shipping ring, first line', 'izeltlab' );
		$low = '<span class="izl-prog-ck" aria-hidden="true">✓</span>' . esc_html_x( 'free!', 'free shipping ring, second line', 'izeltlab' );
	} else {
		$top = _x( 'To free shipping', 'free shipping ring, first line', 'izeltlab' );
		/* translators: %s: amount still missing, e.g. 4 700 Ft (free shipping ring, second line) */
		$low = sprintf( esc_html_x( '%s more', 'free shipping ring, second line', 'izeltlab' ), '<b>' . esc_html( html_entity_decode( wp_strip_all_tags( wc_price( $left ) ), ENT_QUOTES, 'UTF-8' ) ) . '</b>' );
	}
	$truck = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M2 6h12v10H2zM14 9h4l3 3.5V16h-7"/><circle cx="6" cy="17.5" r="2"/><circle cx="17" cy="17.5" r="2"/></svg>';
	return '<div class="izl-cbar-ship' . ( $done ? ' is-done' : '' ) . '"><p class="izl-ring-t" role="status"><span class="izl-ring-a">' . esc_html( $top ) . '</span><span class="izl-ring-b">' . $low . '</span></p>'
		. '<span class="izl-ring" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' . (int) $pct . '" style="--izl-p:' . (int) $pct . '">' . $truck . '</span></div>';
}

add_filter( 'woocommerce_add_to_cart_fragments', function ( $fragments ) {
	$fragments['div.izl-cbar-ship'] = izl_cbar_ship_html();
	return $fragments;
} );

/**
 * The slim bar (PC): once the page is scrolled about 260px down, the top bar is pinned to the top of the screen as one
 * slim row (style.css html.izl-slim) and slides in; back near the top it is the full bar again, where it was. A
 * 1px marker 260px from the top is watched (no work on every scroll step); while the bar is pinned, a stand-in of
 * its height keeps the page from jumping.
 */
add_action( 'wp_footer', function () {
	$js = <<<'JS'
(function(){var h=document.getElementById('masthead');if(!h||!window.IntersectionObserver){return}var pc=window.matchMedia('(min-width:1024px)'),r=document.documentElement,at=document.createElement('div'),ph=document.createElement('div'),on=false;at.className='izl-slim-at';at.setAttribute('aria-hidden','true');ph.className='izl-slim-ph';document.body.appendChild(at);h.parentNode.insertBefore(ph,h);function set(want){want=want&&pc.matches;if(want===on){return}on=want;if(on){var nx=h.nextElementSibling,t0=nx?nx.getBoundingClientRect().top:0,hh=h.offsetHeight+(parseFloat(getComputedStyle(h).marginBottom)||0);r.classList.add('izl-slim');ph.style.height=hh+'px';if(nx){ph.style.height=Math.max(0,hh+t0-nx.getBoundingClientRect().top)+'px'}}else{r.classList.remove('izl-slim');ph.style.height=''}if(window.izlFindPlace){window.izlFindPlace()}}var last=null;new IntersectionObserver(function(es){last=es[es.length-1];set(!last.isIntersecting&&last.boundingClientRect.top<0)}).observe(at);var f=function(){set(!!last&&!last.isIntersecting&&last.boundingClientRect.top<0)};pc.addEventListener?pc.addEventListener('change',f):pc.addListener(f)})();
JS;
	echo '<script>' . $js . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}, 31 );
