<?php
// ==========================================================================
//  FILE: inc/layout.php   (Ízeltláb theme)
//  WHAT: Page layout: full-width shop pages, number of tiles per row, how many related products.
//  SEEN: Shop lists, product pages.
//  SECTIONS IN THIS FILE:
//    1. Layout: full width shop pages
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Layout: full width shop pages
// ==========================================================================

// No sidebar on the shop, product, cart, checkout and account pages and on the front page: the tiles get the room.
function izl_full_width() {
	return is_front_page() || ( function_exists( 'is_woocommerce' ) && ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) );
}

// 3.13.0: Storefront's sticky add-to-cart bar ("You're viewing: ... Choose options") is gone for good: the product
// drawer already keeps Kosárba in reach. The theme setting is forced off, so Storefront prints no bar and loads no
// sticky-add-to-cart script. (2.1.2's guard against its fatal error on "Coming soon" pages is no longer needed.)
add_filter( 'theme_mod_storefront_sticky_add_to_cart', '__return_false' );
add_action( 'init', function () {
	remove_action( 'storefront_after_footer', 'storefront_sticky_single_add_to_cart', 999 );
} );

add_action( 'wp', function () {
	if ( izl_full_width() ) {
		remove_action( 'storefront_sidebar', 'storefront_get_sidebar', 10 );
	}
} );

add_filter( 'body_class', function ( $classes ) {
	if ( izl_full_width() ) {
		$classes[] = 'storefront-full-width-content';
	}
	return $classes;
} );

add_filter( 'storefront_loop_columns', function () {
	return 4;
} );

add_filter( 'woocommerce_output_related_products_args', function ( $args ) {
	$args['posts_per_page'] = 6; // 1.7.0: the small-tile row under every product page
	$args['columns']        = 6;
	$args['orderby']        = 'none'; // 3.23.0: keep the order of inc/product-row.php (sold-out ones last)
	$args['order']          = 'asc';
	return $args;
} );

add_filter( 'woocommerce_upsell_display_args', function ( $args ) {
	$args['posts_per_page'] = 4;
	$args['columns']        = 4;
	return $args;
} );
