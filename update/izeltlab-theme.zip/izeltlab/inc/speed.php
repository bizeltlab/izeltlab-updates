<?php
// ==========================================================================
//  FILE: inc/speed.php   (Ízeltláb theme)
//  WHAT: 3.13.0 speed work (Dan's PageSpeed list, 2026-11-18): "lite mode" for old or weak phones, stylesheets that
//        are not needed for the first screen load without holding the page up, and no cart check while the cart is
//        empty. 3.14.0 (2026-11-19): the three tiny stylesheets are written into the page, and jQuery no longer holds
//        up the first paint on shopping pages. Nothing here changes the look on an ordinary phone or computer.
//  SEEN: Behind the scenes, on every page. Lite mode: only on weak phones (or with ?lite=1 in the address).
//  SWITCH OFF: add_filter( 'izl_lite_mode', '__return_false' ); add_filter( 'izl_late_styles', '__return_empty_array' );
//              add_filter( 'izl_skip_empty_cart_check', '__return_false' ); add_filter( 'izl_no_jquery_migrate', '__return_false' );
//              add_filter( 'izl_inline_styles', '__return_empty_array' ); add_filter( 'izl_jquery_late', '__return_false' );
//  SECTIONS IN THIS FILE:
//    1. Lite mode: weak phones get a calmer page
//    2. Stylesheets for below the first screen: loaded without holding the page up
//    3. No cart check while the cart is empty
//    4. No jQuery Migrate for shoppers
//    5. Tiny stylesheets: written into the page
//    6. jQuery after the first paint on shopping pages
//    7. A photo size between the small and the big one
//    8. No emoji loader (since 3.17.0)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Lite mode: weak phones get a calmer page
// ==========================================================================

// Dan's 8-year-old Android lagged. A phone with little memory (2 GB or less), or 4 GB with 4 cores or fewer, or one
// that asks to save data, gets the classes "izl-lite fsz-lite" on <html> before anything is drawn. The stylesheets
// (style.css section 51, Codex codex.css) then stop the endless little motions there: the walking isopod in the search,
// the leaf litter drift, the blur behind the front page cards, the glowing and pulsing lights and buttons, the card's
// slow float, and the front page's back cards stand still like pictures. Phones that do not tell their memory
// (iPhones) are never lite. Test it on any device: add ?lite=1 to an address (?lite=0 turns it back off; it is
// remembered on that browser).
add_action( 'wp_head', function () {
	if ( ! apply_filters( 'izl_lite_mode', true ) ) {
		return;
	}
	echo "<script>(function(){var n=navigator,c=n.connection||{},m=n.deviceMemory,k=n.hardwareConcurrency,f=null,q=location.search.match(/[?&]lite=([01])/);try{if(q){localStorage.setItem('izl-lite',q[1])}f=localStorage.getItem('izl-lite')}catch(e){}if(f?'1'===f:!!(c.saveData||(m&&m<=2)||(m&&m<=4&&k&&k<=4))){document.documentElement.className+=' izl-lite fsz-lite'}})();</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}, 0 );

// 3.14.0: <html> also gets "izl-js" (JavaScript runs on this page), so style.css can leave out what a script is about
// to build (the phone product page's buy drawer, style.css section 52) without hiding it from browsers without scripts.
add_action( 'wp_head', function () {
	echo "<script>document.documentElement.classList.add('izl-js')</script>\n";
}, 0 );

// ==========================================================================
//  Stylesheets for below the first screen: loaded without holding the page up
// ==========================================================================

// On product pages and the front page, three stylesheets only style things further down (the footer, the cart and
// checkout looks, the blocks of a product description and footer widgets). 3.14.0: the shop list, category and search
// pages too (checked: none of the three styles anything on their first screen, phone or computer). The browser fetched them before it drew
// anything; now it draws the first screen first and applies them as they arrive (the classic media="print" swap; the
// <noscript> copy keeps them for browsers without JavaScript). The mini cart's hidden start is in style.css section 51,
// so it never shows unstyled.
function izl_late_styles() {
	static $late = null;
	if ( null === $late ) {
		$late = array();
		$wc = function_exists( 'is_product' );
		if ( ( $wc && ( is_product() || is_shop() || is_product_taxonomy() ) ) || is_front_page() || ( is_search() && 'product' === get_query_var( 'post_type' ) ) ) {
			$late = array( 'izeltlab-launch', 'wp-block-library', 'wc-blocks-style' );
		}
		$late = (array) apply_filters( 'izl_late_styles', $late );
	}
	return $late;
}
add_filter( 'style_loader_tag', function ( $tag, $handle ) {
	if ( is_admin() || ! in_array( $handle, izl_late_styles(), true ) || false !== strpos( $tag, 'onload=' ) ) {
		return $tag;
	}
	$late = preg_replace( '/\smedia=([\'"])all\1/', ' media="print" onload="this.media=\'all\'"', $tag, 1, $n );
	if ( ! $n ) {
		return $tag; // a stylesheet for a special media: left as it is
	}
	return $late . '<noscript>' . trim( $tag ) . "</noscript>\n";
}, 10, 2 );

// ==========================================================================
//  No cart check while the cart is empty
// ==========================================================================

// WooCommerce's cart-fragments script asks the server for the cart (an uncached request) on the first page of every
// visit, even when nothing is in the cart. While the "items in cart" cookie is missing (the cart is empty) it now stays
// quiet: the header's 0 and the empty mini cart are already right. Once something goes into the cart the cookie is
// there and it works as before (the count also follows "Kosárba" straight away without it).
add_action( 'wp_enqueue_scripts', function () {
	if ( ! apply_filters( 'izl_skip_empty_cart_check', true ) || ! wp_script_is( 'wc-cart-fragments', 'registered' ) ) {
		return;
	}
	wp_add_inline_script( 'wc-cart-fragments', "if(!/(^|;\\s*)woocommerce_items_in_cart=/.test(document.cookie)&&'undefined'!==typeof wc_cart_fragments_params){window.izlCartFrag=wc_cart_fragments_params;wc_cart_fragments_params=void 0}", 'before' );
}, 300 );

// ==========================================================================
//  No jQuery Migrate for shoppers
// ==========================================================================

// jQuery Migrate only helps very old add-ons that still use jQuery's removed functions. Nothing on the shop's pages does
// (WooCommerce, Storefront, Codex, Bolt and this theme use today's jQuery), yet it was fetched before the page could be
// drawn and was one of the longest tasks on an old phone. Shoppers' pages leave it out; the dashboard keeps it.
add_action( 'wp_default_scripts', function ( $scripts ) {
	if ( is_admin() || ! apply_filters( 'izl_no_jquery_migrate', true ) || empty( $scripts->registered['jquery'] ) ) {
		return;
	}
	$scripts->registered['jquery']->deps = array_values( array_diff( $scripts->registered['jquery']->deps, array( 'jquery-migrate' ) ) );
} );

// ==========================================================================
//  Tiny stylesheets: written into the page
// ==========================================================================

// 3.14.0 (PageSpeed, 2026-11-19): three stylesheets are only 1-2 KB each, yet the browser had to fetch each one before it
// could draw anything (500 ms each in PageSpeed's slow-phone test, and the fonts could only start after fonts.css came
// back): the theme's font list (fonts.css), Codex's font list (font.css) and Bolt's styles (bolt.css). Their text is now
// written straight into the page, with the same rules in the same place, so the fonts start at once. Only a stylesheet
// for all screens, smaller than 6 KB and readable on the server is written in; anything else keeps its <link>.
function izl_inline_styles() {
	return (array) apply_filters( 'izl_inline_styles', array( 'izeltlab-fonts', 'codex-font', 'izeltlab-bolt' ) );
}
add_filter( 'style_loader_tag', function ( $tag, $handle, $href, $media = 'all' ) {
	if ( is_admin() || ! in_array( $handle, izl_inline_styles(), true ) || ( $media && 'all' !== $media ) ) {
		return $tag;
	}
	$css = izl_local_css( (string) $href );
	if ( null === $css ) {
		return $tag;
	}
	return "<style id='" . esc_attr( $handle ) . "-css'>" . $css . "</style>\n";
}, 20, 4 );

// The text of a stylesheet of this site from its address, with its url(...) links made full (they were relative to the
// file). Null when it is not on this site, missing, or too big to write into every page.
function izl_local_css( $href ) {
	$url  = preg_replace( '/[?#].*$/', '', $href );
	$base = untrailingslashit( content_url() );
	if ( 0 === strpos( $url, '//' ) ) {
		$url = ( is_ssl() ? 'https:' : 'http:' ) . $url;
	}
	$home = preg_replace( '#^https?:#', '', $base );
	$rel  = null;
	foreach ( array( $base, 'http:' . $home, 'https:' . $home ) as $root ) {
		if ( 0 === strpos( $url, $root . '/' ) ) {
			$rel = substr( $url, strlen( $root ) );
			break;
		}
	}
	if ( null === $rel || false !== strpos( $rel, '..' ) || ! preg_match( '/\.css$/', $rel ) ) {
		return null;
	}
	$file = WP_CONTENT_DIR . $rel;
	$size = is_readable( $file ) ? (int) filesize( $file ) : 0;
	if ( $size < 1 || $size > 6144 ) {
		return null;
	}
	$css = (string) file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	$dir = substr( $url, 0, strrpos( $url, '/' ) + 1 );
	$css = preg_replace_callback( '/url\(\s*([\'"]?)([^\'")]+)\1\s*\)/', function ( $m ) use ( $dir ) {
		$u = trim( $m[2] );
		if ( preg_match( '#^(data:|https?:|//|/|\#)#i', $u ) ) {
			return $m[0];
		}
		return 'url(' . $m[1] . $dir . $u . $m[1] . ')';
	}, $css );
	$css = preg_replace( '#/\*.*?\*/#s', '', $css ); // the files' heading comments are for people, not browsers
	$css = preg_replace( '/\s*\n\s*/', "\n", $css );
	return false !== stripos( $css, '</style' ) ? null : trim( $css );
}

// ==========================================================================
//  jQuery after the first paint on shopping pages
// ==========================================================================

// 3.14.0 (PageSpeed, 2026-11-19): jQuery (31 KB) was fetched in the page's head, and the browser could not draw anything
// until it had arrived and run (0.6-1 s in PageSpeed's slow-phone test). Nothing on the first screen needs it: the theme,
// Codex and Bolt draw with plain JavaScript, and WooCommerce's own head scripts already wait for the page anyway
// ("defer"). On the front page, product pages, shop lists, categories and product search, for visitors who are not
// logged in, jQuery and every script that needs it now load at the end of the page instead, in the same order. The
// basket, checkout and account pages (payment add-ons may write jQuery code into the page) and logged-in editors keep
// the old way. The theme's own small jQuery snippets in the page already wait for jQuery (inc/site-header.php section 3
// runs after the scripts; inc/swift.php only uses it when a page comes back from the browser's memory).
add_action( 'wp_enqueue_scripts', function () {
	if ( is_admin() || is_user_logged_in() || ! apply_filters( 'izl_jquery_late', true ) || ! function_exists( 'is_product' ) ) {
		return;
	}
	$shopping = is_front_page() || is_product() || is_shop() || is_product_taxonomy() || ( is_search() && 'product' === get_query_var( 'post_type' ) );
	if ( ! $shopping || is_cart() || is_checkout() || is_account_page() ) {
		return;
	}
	$scripts = wp_scripts();
	$needs   = array();
	$check   = function ( $handle ) use ( &$check, &$needs, $scripts ) {
		if ( isset( $needs[ $handle ] ) ) {
			return $needs[ $handle ];
		}
		$needs[ $handle ] = false; // guards against a dependency loop
		if ( empty( $scripts->registered[ $handle ] ) ) {
			return false;
		}
		$hit = in_array( $handle, array( 'jquery', 'jquery-core', 'jquery-migrate' ), true );
		foreach ( (array) $scripts->registered[ $handle ]->deps as $dep ) {
			$hit = $check( $dep ) || $hit;
		}
		$needs[ $handle ] = $hit;
		return $hit;
	};
	foreach ( array_merge( array( 'jquery', 'jquery-core', 'jquery-migrate' ), (array) $scripts->queue ) as $handle ) {
		$check( $handle );
	}
	// every script that needs jQuery, even one only loaded as another's helper (jQuery BlockUI), moves to the end; a
	// helper that does not need jQuery stays where it is (it still loads before the scripts that use it)
	foreach ( $needs as $handle => $hit ) {
		if ( $hit ) {
			$scripts->add_data( $handle, 'group', 1 );
		}
	}
}, 9999 );

// ==========================================================================
//  A photo size between the small and the big one
// ==========================================================================

// 3.14.0 (Dan, 2026-11-19: "find a long term solution to image delivery"): a photo had files 300, 416, 768 and 1024px
// wide (plus the original). A phone that needed about 500-600 dots for a tile or the card (most phones) had to take the
// 768px file, twice the weight of what it could show. WordPress now also makes a 600px file of every upload (same shape
// as the photo, never cropped); the browser picks it by itself through the photo's srcset, so nothing looks different.
// Photos uploaded before get it from "Optimise existing photos" (Ízeltláb Bolt → Photos).
// SWITCH OFF: add_filter( 'izl_mid_photo_size', '__return_false' );
add_action( 'after_setup_theme', function () {
	if ( apply_filters( 'izl_mid_photo_size', true ) ) {
		add_image_size( 'izl-600', 600, 0, false );
	}
}, 20 );

// ==========================================================================
//  No emoji loader (since 3.17.0)
// ==========================================================================

// WordPress adds a small script and a stylesheet to every page that check whether the browser can draw emoji and, if
// not, fetch a picture font for them. Every browser the shop is made for draws emoji itself, and the shop's texts use
// none, so shoppers' pages leave them out (one script and one stylesheet less before the page is drawn). The
// dashboard keeps them. SWITCH OFF: add_filter( 'izl_no_emoji_loader', '__return_false' );
add_action( 'init', function () {
	if ( ! apply_filters( 'izl_no_emoji_loader', true ) ) {
		return;
	}
	// wherever this WordPress version hooks them (the head, or the footer in newer versions)
	foreach ( array( 'wp_head', 'wp_footer', 'wp_print_footer_scripts', 'wp_enqueue_scripts', 'wp_print_styles' ) as $hook ) {
		foreach ( array( 'print_emoji_detection_script', 'wp_print_emoji_detection_script', 'print_emoji_styles', 'wp_enqueue_emoji_styles' ) as $fn ) {
			$at = has_action( $hook, $fn );
			if ( false !== $at ) {
				remove_action( $hook, $fn, $at );
			}
		}
	}
	add_filter( 'emoji_svg_url', '__return_false' );
} );
