<?php
// ==========================================================================
//  FILE: inc/speed.php   (Ízeltláb theme)
//  WHAT: 3.13.0 speed work (Dan's PageSpeed list, 2026-11-18): "lite mode" for old or weak phones, stylesheets that
//        are not needed for the first screen load without holding the page up, and no cart check while the cart is
//        empty. Nothing here changes the look on an ordinary phone or computer.
//  SEEN: Behind the scenes, on every page. Lite mode: only on weak phones (or with ?lite=1 in the address).
//  SWITCH OFF: add_filter( 'izl_lite_mode', '__return_false' ); add_filter( 'izl_late_styles', '__return_empty_array' );
//              add_filter( 'izl_skip_empty_cart_check', '__return_false' ); add_filter( 'izl_no_jquery_migrate', '__return_false' );
//  SECTIONS IN THIS FILE:
//    1. Lite mode: weak phones get a calmer page
//    2. Stylesheets for below the first screen: loaded without holding the page up
//    3. No cart check while the cart is empty
//    4. No jQuery Migrate for shoppers
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Lite mode: weak phones get a calmer page
// ==========================================================================

// Dan's 8-year-old Android lagged. A phone with little memory (2 GB or less), or 4 GB with 4 cores or fewer, or one
// that asks to save data, gets the classes "izl-lite fsz-lite" on <html> before anything is drawn. The stylesheets
// (style.css section 51, Codex codex.css) then stop the endless little motions there: the walking isopod in the search,
// the leaf litter drift, the blur behind the front page cards, the glowing and pulsing lights and buttons, the card's
// slow float, and the front page's back cards stand still like pictures. Phones that do not tell their memory
// (iPhones) are never lite. Test it on any device: add ?lite=1 to an address (?lite=0 turns it back off; it is
// remembered on that browser).
add_action( 'wp_head', function () {
	if ( ! apply_filters( 'izl_lite_mode', true ) ) {
		return;
	}
	echo "<script>(function(){var n=navigator,c=n.connection||{},m=n.deviceMemory,k=n.hardwareConcurrency,f=null,q=location.search.match(/[?&]lite=([01])/);try{if(q){localStorage.setItem('izl-lite',q[1])}f=localStorage.getItem('izl-lite')}catch(e){}if(f?'1'===f:!!(c.saveData||(m&&m<=2)||(m&&m<=4&&k&&k<=4))){document.documentElement.className+=' izl-lite fsz-lite'}})();</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}, 0 );

// ==========================================================================
//  Stylesheets for below the first screen: loaded without holding the page up
// ==========================================================================

// On product pages and the front page, three stylesheets only style things further down (the footer, the cart and
// checkout looks, the blocks of a product description and footer widgets). The browser fetched them before it drew
// anything; now it draws the first screen first and applies them as they arrive (the classic media="print" swap; the
// <noscript> copy keeps them for browsers without JavaScript). The mini cart's hidden start is in style.css section 51,
// so it never shows unstyled.
function izl_late_styles() {
	static $late = null;
	if ( null === $late ) {
		$late = array();
		if ( ( function_exists( 'is_product' ) && is_product() ) || is_front_page() ) {
			$late = array( 'izeltlab-launch', 'wp-block-library', 'wc-blocks-style' );
		}
		$late = (array) apply_filters( 'izl_late_styles', $late );
	}
	return $late;
}
add_filter( 'style_loader_tag', function ( $tag, $handle ) {
	if ( is_admin() || ! in_array( $handle, izl_late_styles(), true ) || false !== strpos( $tag, 'onload=' ) ) {
		return $tag;
	}
	$late = preg_replace( '/\smedia=([\'"])all\1/', ' media="print" onload="this.media=\'all\'"', $tag, 1, $n );
	if ( ! $n ) {
		return $tag; // a stylesheet for a special media: left as it is
	}
	return $late . '<noscript>' . trim( $tag ) . "</noscript>\n";
}, 10, 2 );

// ==========================================================================
//  No cart check while the cart is empty
// ==========================================================================

// WooCommerce's cart-fragments script asks the server for the cart (an uncached request) on the first page of every
// visit, even when nothing is in the cart. While the "items in cart" cookie is missing (the cart is empty) it now stays
// quiet: the header's 0 and the empty mini cart are already right. Once something goes into the cart the cookie is
// there and it works as before (the count also follows "Kosárba" straight away without it).
add_action( 'wp_enqueue_scripts', function () {
	if ( ! apply_filters( 'izl_skip_empty_cart_check', true ) || ! wp_script_is( 'wc-cart-fragments', 'registered' ) ) {
		return;
	}
	wp_add_inline_script( 'wc-cart-fragments', "if(!/(^|;\\s*)woocommerce_items_in_cart=/.test(document.cookie)&&'undefined'!==typeof wc_cart_fragments_params){window.izlCartFrag=wc_cart_fragments_params;wc_cart_fragments_params=void 0}", 'before' );
}, 300 );

// ==========================================================================
//  No jQuery Migrate for shoppers
// ==========================================================================

// jQuery Migrate only helps very old add-ons that still use jQuery's removed functions. Nothing on the shop's pages does
// (WooCommerce, Storefront, Codex, Bolt and this theme use today's jQuery), yet it was fetched before the page could be
// drawn and was one of the longest tasks on an old phone. Shoppers' pages leave it out; the dashboard keeps it.
add_action( 'wp_default_scripts', function ( $scripts ) {
	if ( is_admin() || ! apply_filters( 'izl_no_jquery_migrate', true ) || empty( $scripts->registered['jquery'] ) ) {
		return;
	}
	$scripts->registered['jquery']->deps = array_values( array_diff( $scripts->registered['jquery']->deps, array( 'jquery-migrate' ) ) );
} );

