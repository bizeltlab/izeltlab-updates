<?php
// ==========================================================================
//  FILE: inc/edit-buy-box.php   (Ízeltláb theme)
//  WHAT: ADMIN ONLY. The "Edit buy box" button and the data its dialog needs (saving is in inc/shop-core.php).
//  SEEN: Only by logged-in shop managers, on product pages.
//  SECTIONS IN THIS FILE:
//    1. Buy box editor: the button and its data (saving: inc/shop-core.php)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Buy box editor: the button and its data (saving: inc/shop-core.php)
// ==========================================================================

// What the editor shows: price of the base pack, base pack, the packs on offer (multiples), available.
function izl_buybox_data( $product ) {
	$id     = $product->get_id();
	$packs  = izl_is_codex( $id );
	$group  = izl_group_term( $id );
	$mults  = array();
	$price  = '';
	$avail  = $product->is_in_stock();
	if ( $product instanceof WC_Product_Variable ) {
		foreach ( $product->get_children() as $vid ) {
			$v = wc_get_product( $vid );
			if ( ! $v ) {
				continue;
			}
			$m = (int) $v->get_meta( '_izl_mult' );
			if ( $m > 0 ) {
				$mults[] = $m;
				if ( '' === $price && '' !== (string) $v->get_regular_price() ) {
					$price = (float) $v->get_regular_price() / $m;
				}
			} elseif ( '' === $price && '' !== (string) $v->get_regular_price() ) {
				$price = (float) $v->get_regular_price(); // packs made by hand before 1.3.6: the first one's price
			}
		}
	} else {
		$price = '' === (string) $product->get_regular_price() ? '' : (float) $product->get_regular_price();
	}
	return array(
		'id'         => $id,
		'packs'      => $packs,
		'price'      => '' === $price ? '' : round( $price, wc_get_price_decimals() ),
		'base'       => (int) get_post_meta( $id, '_izl_base_pack', true ),
		'groupBase'  => izl_group_base_pack( $group ),
		'groupName'  => $group ? $group->name : '',
		'mults'      => $mults ? array_values( array_unique( $mults ) ) : IZL_PACK_MULTS,
		'allMults'   => IZL_PACK_MULTS,
		'available'  => $avail,
		'low'        => $packs && 'yes' === get_post_meta( $id, '_fsz_low', true ), // 1.7.17: the Codex "Running low" light
		'handMade'   => $product instanceof WC_Product_Variable && ! $mults && (bool) $product->get_children(),
		'ship'       => izl_ship_type( $id ),
		'rowTitle'   => (string) get_post_meta( $id, '_izl_row_title', true ),
		'rowDefault' => izl_row_default( $id, true ),
		'currency'   => html_entity_decode( get_woocommerce_currency_symbol() ),
		'freeShip'   => izl_free_ship(), // 1.7.18: shop-wide, only for shop managers
		'canShop'    => current_user_can( 'manage_woocommerce' ),
	);
}

// The editor's button and dialog, at the top of the buy box, for whoever can edit the product.
add_action( 'woocommerce_single_product_summary', function () {
	global $product;
	if ( ! $product instanceof WC_Product || ! current_user_can( 'edit_post', $product->get_id() ) ) {
		return;
	}
	echo '<div class="izl-admin-strip"><button type="button" class="izl-buybox-open">Edit buy box</button>';
	if ( izl_is_codex( $product->get_id() ) ) {
		// 2.0.6: Edit next to it changes the product's own name here (the same text box as the sales line)
		echo '<p class="izl-admin-name" data-izl-edit="_izl_name">Hidden name (only search engines and screen readers get it): <b class="izl-edit-text">' . esc_html( $product->get_name() ) . '</b><button type="button" class="izl-edit-btn">Edit</button></p>';
	}
	echo '</div>';
	echo '<script type="application/json" id="izl-buybox-data">' . wp_json_encode( izl_buybox_data( $product ) ) . '</script>';
}, 4 );
