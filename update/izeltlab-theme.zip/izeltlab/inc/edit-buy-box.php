<?php
// ==========================================================================
//  FILE: inc/edit-buy-box.php   (Ízeltláb theme)
//  WHAT: ADMIN ONLY. The "Edit buy box" button and the data its dialog needs (saving is in inc/shop-core.php), and
//        (3.21.0) the stock line with − / + next to it.
//  SEEN: Only by logged-in shop managers, on product pages.
//  SECTIONS IN THIS FILE:
//    1. Buy box editor: the button and its data (saving: inc/shop-core.php)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Buy box editor: the button and its data (saving: inc/shop-core.php)
// ==========================================================================

// What the editor shows: price of the base pack, base pack, the packs (count, price, own price?), the start pack,
// available, stock and the "Kevés van" limit. 3.21.0: any pack size; no free-shipping amount (Customizer only) and no
// "default for the whole group" switch any more (Dan, 2026-11-24).
function izl_buybox_data( $product ) {
	$id    = $product->get_id();
	$packs = izl_is_codex( $id );
	$group = izl_group_term( $id );
	$list  = izl_pack_list( $product );
	$base  = izl_base_pack( $id );
	$price = '';
	foreach ( $list as $p ) {
		if ( ! $p['own'] && '' !== $p['price'] ) {
			$price = (float) $p['price'] * $base / max( 1, $p['count'] ); // back to the base pack's price
			break;
		}
	}
	if ( '' === $price && $product instanceof WC_Product_Variable ) {
		foreach ( $product->get_children() as $vid ) {
			$v = wc_get_product( $vid );
			if ( $v && '' !== (string) $v->get_regular_price() ) {
				$price = (float) $v->get_regular_price(); // packs made by hand before 1.3.6: the first one's price
				break;
			}
		}
	} elseif ( '' === $price ) {
		$price = '' === (string) $product->get_regular_price() ? '' : (float) $product->get_regular_price();
	}
	if ( $packs && ! $list ) {
		foreach ( IZL_PACK_MULTS as $m ) {
			$list[] = array( 'count' => $base * $m, 'price' => '', 'own' => false );
		}
	}
	$start = 0;
	if ( $product instanceof WC_Product_Variable ) {
		$def = (string) $product->get_variation_default_attribute( sanitize_title( IZL_PACK_ATTR ) );
		foreach ( $list as $p ) {
			if ( '' !== $def && sanitize_title( izl_pack_label( $p['count'], true ) ) === sanitize_title( $def ) ) {
				$start = $p['count'];
			}
		}
	}
	return array(
		'id'         => $id,
		'packs'      => $packs,
		'price'      => '' === $price ? '' : round( $price, wc_get_price_decimals() ),
		'base'       => $base,
		'groupBase'  => izl_group_base_pack( $group ),
		'groupName'  => $group ? $group->name : '',
		'list'       => array_map( function ( $p ) {
			return array( 'count' => (int) $p['count'], 'price' => $p['own'] ? $p['price'] : '' );
		}, $list ),
		'start'      => $start ? $start : ( $list ? (int) $list[0]['count'] : 0 ),
		'max'        => IZL_PACK_MAX,
		'available'  => 'yes' !== get_post_meta( $id, '_izl_paused', true ) && ( $product->is_in_stock() || null !== izl_stock_left( $id ) ),
		'stock'      => izl_stock_left( $id ),
		'lowAt'      => izl_low_at( $id ),
		'low'        => $packs && 'yes' === get_post_meta( $id, '_fsz_low', true ), // 1.7.17: the Codex "Running low" light
		'handMade'   => $product instanceof WC_Product_Variable && ! izl_pack_list( $product ) && (bool) $product->get_children(),
		'ship'       => izl_ship_type( $id ),
		'rowTitle'   => (string) get_post_meta( $id, '_izl_row_title', true ),
		'rowDefault' => izl_row_default( $id, true ),
		'currency'   => html_entity_decode( get_woocommerce_currency_symbol() ),
	);
}

// 3.21.0: the stock line over the buy box (shop managers only): "Készlet: 120 db" with − / + and the number to type
// into; saves at once (inc/shop-core.php wp_ajax_izl_stock_set). Empty = not counted.
function izl_stock_strip( $product ) {
	$id   = $product->get_id();
	$left = izl_stock_left( $id );
	$unit = izl_is_codex( $id ) ? 'pcs' : 'items';
	return '<div class="izl-stock-edit" data-id="' . (int) $id . '" data-nonce="' . esc_attr( wp_create_nonce( 'izl_stock' ) ) . '">'
		. '<span class="izl-se-label">Stock</span>'
		. '<button type="button" class="izl-se-btn" data-add="-1" aria-label="One less">−</button>'
		. '<input type="number" class="izl-se-num" min="0" step="1" inputmode="numeric" placeholder="–" title="Empty = not counted" value="' . ( null === $left ? '' : (int) $left ) . '" aria-label="Stock">'
		. '<button type="button" class="izl-se-btn" data-add="1" aria-label="One more">+</button>'
		. '<span class="izl-se-unit">' . esc_html( $unit ) . '</span><span class="izl-se-state" aria-live="polite"></span></div>';
}

// The editor's button and dialog, at the top of the buy box, for whoever can edit the product.
add_action( 'woocommerce_single_product_summary', function () {
	global $product;
	if ( ! $product instanceof WC_Product || ! current_user_can( 'edit_post', $product->get_id() ) ) {
		return;
	}
	echo '<div class="izl-admin-strip"><button type="button" class="izl-buybox-open">Edit buy box</button>' . izl_stock_strip( $product ); // phpcs:ignore WordPress.Security.EscapeOutput
	if ( izl_is_codex( $product->get_id() ) ) {
		// 2.0.6: Edit next to it changes the product's own name here (the same text box as the sales line)
		echo '<p class="izl-admin-name" data-izl-edit="_izl_name" title="Only search engines and screen readers get it">Hidden name<span class="izl-admin-why"> (only search engines and screen readers get it)</span>: <b class="izl-edit-text">' . esc_html( $product->get_name() ) . '</b><button type="button" class="izl-edit-btn">Edit</button></p>';
	}
	echo '</div>';
	echo '<script type="application/json" id="izl-buybox-data">' . wp_json_encode( izl_buybox_data( $product ) ) . '</script>';
}, 4 );

// 3.8.0: WordPress's "Edit product" in the admin bar is called "WooEdit" (Dan: it opens the product's WooCommerce
// settings); the page's own Edit link is hidden on a computer (style.css section 45), so it takes no room there.
add_action(
	'admin_bar_menu',
	function ( $bar ) {
		$node = $bar->get_node( 'edit' );
		if ( $node && is_singular( 'product' ) ) {
			$node        = (array) $node;
			$node['title'] = 'WooEdit';
			$bar->add_node( $node );
		}
	},
	999
);
