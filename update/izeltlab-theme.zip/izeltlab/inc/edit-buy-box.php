<?php
// ==========================================================================
//  FILE: inc/edit-buy-box.php   (Ízeltláb theme)
//  WHAT: ADMIN ONLY. The "Termék adatok" button and the data its window needs (3.23.0: one floating window for the
//        stock, group, texts, price, packs and shipping; saving is in inc/shop-core.php and below).
//  SEEN: Only by logged-in shop managers, on product pages.
//  SECTIONS IN THIS FILE:
//    1. Buy box editor: the button and its data (saving: inc/shop-core.php)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Buy box editor: the button and its data (saving: inc/shop-core.php)
// ==========================================================================

// What the editor shows: price of the base pack, base pack, the packs (count, price, own price?), the start pack,
// available and stock (3.24.0: the "Kevés van" limit is automatic, 5 base packs). 3.21.0: any pack size; no free-shipping amount (Customizer only) and no
// "default for the whole group" switch any more (Dan, 2026-11-24).
function izl_buybox_data( $product ) {
	$id    = $product->get_id();
	$packs = izl_is_codex( $id );
	$group = izl_group_term( $id );
	$list  = izl_pack_list( $product );
	$base  = izl_base_pack( $id );
	$price = '';
	foreach ( $list as $p ) {
		if ( ! $p['own'] && '' !== $p['price'] ) {
			$price = (float) $p['price'] * $base / max( 1, $p['count'] ); // back to the base pack's price
			break;
		}
	}
	if ( '' === $price && $product instanceof WC_Product_Variable ) {
		foreach ( $product->get_children() as $vid ) {
			$v = wc_get_product( $vid );
			if ( $v && '' !== (string) $v->get_regular_price() ) {
				$price = (float) $v->get_regular_price(); // packs made by hand before 1.3.6: the first one's price
				break;
			}
		}
	} elseif ( '' === $price ) {
		$price = '' === (string) $product->get_regular_price() ? '' : (float) $product->get_regular_price();
	}
	if ( $packs && ! $list ) {
		foreach ( IZL_PACK_MULTS as $m ) {
			$list[] = array( 'count' => $base * $m, 'price' => '', 'own' => false );
		}
	}
	$start = 0;
	if ( $product instanceof WC_Product_Variable ) {
		$def = (string) $product->get_variation_default_attribute( sanitize_title( IZL_PACK_ATTR ) );
		foreach ( $list as $p ) {
			if ( '' !== $def && sanitize_title( izl_pack_label( $p['count'], true ) ) === sanitize_title( $def ) ) {
				$start = $p['count'];
			}
		}
	}
	return array(
		'id'         => $id,
		'packs'      => $packs,
		'price'      => '' === $price ? '' : round( $price, wc_get_price_decimals() ),
		'base'       => $base,
		'groupBase'  => izl_group_base_pack( $group ),
		'groupName'  => $group ? $group->name : '',
		'list'       => array_map( function ( $p ) {
			return array( 'count' => (int) $p['count'], 'price' => $p['own'] ? $p['price'] : '' );
		}, $list ),
		'start'      => $start ? $start : ( $list ? (int) $list[0]['count'] : 0 ),
		'max'        => IZL_PACK_MAX,
		'available'  => 'yes' !== get_post_meta( $id, '_izl_paused', true ) && ( $product->is_in_stock() || null !== izl_stock_left( $id ) ),
		'stock'      => izl_stock_left( $id ),
		'lowAt'      => izl_low_at( $id ), // 3.24.0: automatic (5 base packs), shown in a hint only
		'handMade'   => $product instanceof WC_Product_Variable && ! izl_pack_list( $product ) && (bool) $product->get_children(),
		'ship'       => izl_ship_type( $id ),
		'rowTitle'   => (string) get_post_meta( $id, '_izl_row_title', true ),
		'rowDefault' => izl_row_default( $id, true ),
		'currency'   => html_entity_decode( get_woocommerce_currency_symbol() ),
		// 3.23.0: the rest of the "Termék adatok" window
		'name'       => $packs ? $product->get_name() : null,
		'headline'   => (string) get_post_meta( $id, '_izl_headline', true ),
		'hasTip'     => $product instanceof WC_Product_Variable && count( $product->get_children() ) > 1,
		'packTip'    => (string) get_post_meta( $id, '_izl_pack_tip', true ),
		'tipDefault' => trim( (string) izl_pmod( 'izl_pack_tip' ) ),
		'groups'     => izl_group_options( $id ),
		'groupNonce' => wp_create_nonce( 'izl_product_group' ),
	);
}

// 3.22.0 (Dan, 2026-11-25): which group and genus the product is in, to change right here (no trip to the admin):
// every category as a tree ("Ászkák", "— Porcellio"). The product then sits in the chosen one and the ones above it
// (as WooCommerce does), saved by wp_ajax_izl_product_group below. 3.23.0: a list for the "Termék adatok" window,
// { now: term id, list: [ [ term id, "— Porcellio" ], ... ] }.
function izl_group_options( $id ) {
	$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'orderby' => 'name' ) );
	$out   = array( 'now' => 0, 'list' => array() );
	if ( ! is_array( $terms ) || ! $terms ) {
		return $out;
	}
	$mine = wp_get_post_terms( $id, 'product_cat', array( 'fields' => 'ids' ) );
	$mine = is_array( $mine ) ? array_map( 'intval', $mine ) : array();
	$kids = array();
	foreach ( $terms as $t ) {
		$kids[ (int) $t->parent ][] = $t;
	}
	// the deepest one it is in: its genus if it has one, else its group
	$deep = -1;
	foreach ( $mine as $tid ) {
		$n = count( get_ancestors( $tid, 'product_cat', 'taxonomy' ) );
		if ( $n > $deep ) {
			$deep       = $n;
			$out['now'] = $tid;
		}
	}
	$walk = function ( $parent, $depth ) use ( &$walk, &$out, $kids ) {
		foreach ( isset( $kids[ $parent ] ) ? $kids[ $parent ] : array() as $t ) {
			$out['list'][] = array( (int) $t->term_id, str_repeat( '— ', $depth ) . html_entity_decode( $t->name ) );
			$walk( (int) $t->term_id, $depth + 1 );
		}
	};
	$walk( 0, 0 );
	return $out;
}

add_action( 'wp_ajax_izl_product_group', function () {
	if ( ! check_ajax_referer( 'izl_product_group', false, false ) ) {
		wp_send_json_error( 'The security check ran out. Reload the page and try again.', 403 );
	}
	$id   = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
	$term = isset( $_POST['term'] ) ? get_term( absint( $_POST['term'] ), 'product_cat' ) : null;
	if ( ! $id || ! current_user_can( 'edit_post', $id ) || 'product' !== get_post_type( $id ) ) {
		wp_send_json_error( 'Not allowed.', 403 );
	}
	if ( ! $term || is_wp_error( $term ) ) {
		wp_send_json_error( 'This group is gone. Reload the page.' );
	}
	$chain = array_merge( array( (int) $term->term_id ), array_map( 'intval', get_ancestors( $term->term_id, 'product_cat', 'taxonomy' ) ) );
	$r     = wp_set_object_terms( $id, $chain, 'product_cat' );
	if ( is_wp_error( $r ) ) {
		wp_send_json_error( $r->get_error_message() );
	}
	if ( function_exists( 'wc_delete_product_transients' ) ) {
		wc_delete_product_transients( $id );
	}
	if ( function_exists( 'wp_cache_clear_cache' ) ) {
		wp_cache_clear_cache(); // WP Super Cache: the lists and header counts change
	}
	wp_send_json_success();
} );

// The editor's button and dialog, at the top of the buy box, for whoever can edit the product.
add_action( 'woocommerce_single_product_summary', function () {
	global $product;
	if ( ! $product instanceof WC_Product || ! current_user_can( 'edit_post', $product->get_id() ) ) {
		return;
	}
	// 3.23.0: one button; the window itself is built by assets/product-edit.js ("Edit photos" joins this row)
	echo '<div class="izl-admin-strip"><button type="button" class="izl-buybox-open izl-pd-open" aria-expanded="false">Termék adatok</button></div>';
	echo '<script type="application/json" id="izl-buybox-data">' . wp_json_encode( izl_buybox_data( $product ) ) . '</script>';
}, 4 );

// 3.8.0: WordPress's "Edit product" in the admin bar is called "WooEdit" (Dan: it opens the product's WooCommerce
// settings); the page's own Edit link is hidden on a computer (style.css section 45), so it takes no room there.
add_action(
	'admin_bar_menu',
	function ( $bar ) {
		$node = $bar->get_node( 'edit' );
		if ( $node && is_singular( 'product' ) ) {
			$node        = (array) $node;
			$node['title'] = 'WooEdit';
			$bar->add_node( $node );
		}
	},
	999
);
