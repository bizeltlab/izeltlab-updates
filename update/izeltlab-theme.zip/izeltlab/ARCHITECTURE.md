# Ízeltláb shop: where is what

This guide is the same in all three parts (theme, Codex, Bolt). It is written for the shop's owner: you do not
need to be a programmer to find the right place. The file lists at the end are made by the build from the
files' own headings, so they are always current.

## 1. The three parts

| Part | Folder on the server | What it does |
|---|---|---|
| **Ízeltláb theme** | `wp-content/themes/izeltlab` | The look of the whole shop: top bar, front page, product tiles, product page with the buy box, cart, footer. |
| **Codex** (plugin) | `wp-content/plugins/codex` | The species card: its data, its look, the "Edit card" tools, the Codex settings page. |
| **Ízeltláb Bolt** (plugin) | `wp-content/plugins/izeltlab-bolt` | Everything behind the counter: checkout rules, emails, cookie banner, search index, order desk, coming soon page, SEO, security, backups. |

Storefront (the parent theme) and WooCommerce do the basic shop work. Never edit their files: an update of
theirs would erase the change.

## 2. How every file is laid out

Every file starts with the same four lines:

```
FILE: inc/product-ticket.php   (Ízeltláb theme)
WHAT: The buy ticket: stock stamp, shipping lines, the price row, pack buttons ...
SEEN: Every product page.
SECTIONS IN THIS FILE:
  1. ...
  2. ...
```

Inside the file, each section starts with a banner you can search for:

```
// ==========================================================================
//  The price row
// ==========================================================================
```

Lines that start with `//` (or sit between `/*` and `*/`) are notes for people. The shop ignores them, so
you can add your own.

Labels in the headings:

- **EDITORS ONLY / ADMIN ONLY / STAFF ONLY**: tools you see when you are logged in. Shoppers never load them.
- **DASHBOARD**: only runs inside the WordPress dashboard.

## 3. I want to change ...

| I want to change | Open | Look for |
|---|---|---|
| A colour of the shop (teal, yellow, background) | theme `style.css` | Section 1 "Tokens": the `--izl-...` lines at the top |
| The colour themes of the card | Dashboard → WooCommerce → Codex | (no file needed) |
| The look of the card itself | Codex `assets/codex.css` | The section list at the top of the file |
| The top bar (logo, menu, icons) | theme `inc/site-header.php`, look in `style.css` | "Header" |
| The header search | theme `inc/finder.php`, `assets/finder.js` | Section list at the top |
| Front page texts and cards | Dashboard → Appearance → Customize → Ízeltláb front page | (no file needed) |
| Front page layout | theme `front-page.php`, `inc/front-page.php` | |
| Product tiles on shop lists | theme `inc/shop-list.php` | "Product tiles" |
| The shop page: filter bar, tiles per row, sold-out order, free-shipping line, empty list | theme `inc/shop-page.php`, `assets/shop.js`, look in `style.css` | Section list at the top; style.css section "The shop page". Sidebar layout instead of the bar: the `izl_shop_filter_layout` filter ("side") |
| The buy box: price row, pack buttons, stock stamp | theme `inc/product-ticket.php` | Section list at the top |
| Sales line, pack question | on the product page itself, logged in: click the text | (no file needed) |
| Trust points and common questions | theme `inc/product-trust.php` | |
| What the buttons do on the product page | theme `assets/product.js` | Section list at the top (the phone drawer is the biggest part) |
| Price, packs, availability of a product | product page, logged in: "Edit buy box" | (no file needed) |
| Cart page, mini cart, thank-you page, footer | theme `inc/launch.php`, look in `assets/launch.css` | Section list at the top |
| Free shipping amount, shipping days, holidays, pack rules | `inc/shop-core.php` (same file in the theme and Bolt) | Section list at the top. Change both copies the same way. |
| Your own closed days | Dashboard → WooCommerce → Ízeltláb Bolt | (no file needed) |
| Checkout texts and consent boxes | Bolt `inc/checkout.php` | |
| Emails (look, footer) | Bolt `inc/emails.php` | |
| Cookie banner | Bolt `inc/consent.php`, look in `assets/bolt.css` | |
| Coming soon page | Bolt `inc/soon.php` | |
| Legal page texts | Dashboard → Pages (the drafts Bolt made) | (no file needed) |
| What the shop search finds | Bolt `inc/search.php` | "Building the search text of one product" |
| A field on the Codex card | Codex `inc/admin-fields.php` | `fsz_field_keys()` and `fsz_search_fields()` |
| Hungarian wording of a button or label | the translation files, see part 5 | |

Tip for looks: in Chrome, right-click the thing on the page → **Inspect**. The panel shows the class name
(for example `izl-px-num`, the big price). Search for that name in `style.css`. The file's sections are in the order
they were written and a later section corrects earlier ones, so edit the **last** rule that sets the thing,
and do not move rules around.

## 4. Editing a file on the live shop, safely

1. **Make a backup first**: Dashboard → UpdraftPlus → Backup Now.
2. Open the file:
   - Dashboard → Appearance → Theme File Editor (theme) or Plugins → Plugin File Editor (Codex, Bolt).
     Bolt turns these editors off for safety. To use them, untick "Turn off the theme/plugin file editor"
     on the Ízeltláb Bolt settings page, and tick it again when you are done.
   - Or the hosting's File Manager.
3. Change one small thing and save.
4. Press **Delete Cache** (WP Super Cache), then reload the page with Ctrl+F5.

Good to know:

- **Your edit shows at once.** Shoppers normally get small built copies of the stylesheets and scripts
  (`*.min.css`, `*.min.js`). The shop notices when you edited the readable file and serves that one instead,
  until the next update.
- **Stylesheets (`.css`) are the safe ones.** A mistake there changes a look, nothing more.
- **PHP files can stop the shop** if a bracket or semicolon goes missing. WordPress's own editor checks the
  file and refuses to save a broken one; the hosting's File Manager does not. If the shop shows an error
  after an edit, undo the edit, or restore the backup.
- **An update replaces every file of that part.** Hand edits are gone after "Update all". Write down what you
  changed and where, and ask for it to be built into the next version.
- `inc/shop-core.php` and the updater exist in more than one part and must stay identical. Leave the updater
  alone.

## 5. Texts

- Texts you set yourself: the Customizer panels (front page, product page), the Ízeltláb Bolt settings page,
  the Codex settings page, and the texts you click on the product page while logged in.
- All other Hungarian wording lives in translation files: `languages/hu_HU.po` (theme),
  `languages/codex-hu_HU.po`, `languages/izeltlab-bolt-hu_HU.po`. They are in the **source zip** of each
  release, and the shop reads their compiled form (`.mo`), which the build makes. So a wording change is a
  small build job, not a live edit.

## 6. For whoever builds the next version

The source zip of a release (`source/izeltlab-source-...zip`) holds the whole workspace:

```
izeltlab/        the theme
codex/           the Codex plugin
izeltlab-bolt/   the Bolt plugin
shared/          shop-core.php, updater.php, this guide: ONE source, copied into the parts by the build
build/           build.js and its helpers
```

One command does everything: `node build/build.js` (add `--zip <folder>` for the release zips and their
fingerprints). It copies the shared files, makes the minified copies and the lighter stylesheet, compiles the
translations, writes this guide's file lists, and then checks: PHP syntax, the same version number in every
place, editors-only functions never called without a guard, and that the lighter stylesheet is style.css in
the same order with only product-page rules left out. `build/REGRESSION.md` describes the before/after
comparison of the whole shop that every release has to pass with zero differences.

Rules that keep the shop the same:

- **Loaders.** `functions.php` (theme), `codex.php` and `izeltlab-bolt.php` only load files from `inc/`, one
  file per feature, in a fixed order. A new feature is a new file with the standard heading, plus one
  `require` line in the loader.
- **Editors-only files** are loaded only when a login cookie is present (`izl_editor_may_be_here()`,
  `fsz_editor_may_be_here()`). Anything that calls into them from a shopper file must ask
  `function_exists()` first; the build checks this.
- **style.css is never reordered.** Its sections are history: later ones override earlier ones. New rules go
  at the end, in a new section with a banner. The build makes `style.lite.min.css` for every page that is not
  a product page by leaving out rules that can only match on a product page (`build/product-only.js` proves
  each class from the source). A rule for a new class is kept everywhere unless the class is printed only by
  the product page's files.
- **Codex's stylesheets are printed last in the page head** (`codex/inc/assets.php`), so a Codex rule wins
  against an equally strong rule of any other stylesheet. Do not rely on a theme rule beating a Codex rule of
  the same strength.
- **A new Codex card field**: add it to `fsz_field_keys()` and to one group of `fsz_search_fields()`
  (`codex/inc/admin-fields.php`). The card editor, the cleanup tool and Bolt's search read those lists.
- **A new skin**: a stylesheet in `codex/assets/skins/`, plus its entry in the skin list in
  `codex/inc/settings.php`.
- **Shared files**: edit `shared/shop-core.php` and `shared/updater.php` only; the build copies them.
- **Prefixes and saved data**: `izl_` (theme), `fsz_` (Codex), `izb_` (Bolt). Never rename a function prefix
  or a saved setting key; the live shop's data depends on them.
- **Unused files** (`izeltlab/inc/unused-files.php`): Storefront's icon stylesheet is swapped for a short copy
  only while Storefront's file is byte-for-byte the one the build saw; block and brand styles are skipped
  only on pages that cannot use them. Each has a filter to switch it back on.

## 7. File lists

### Ízeltláb theme

| File | What it does | Where you see it |
|---|---|---|
| `404.php` | The "no such page" page in the shop's look. | Any address that does not exist. |
| `front-page.php` | The front page's layout: hero text and cards, then the sections with product rows. | The front page. |
| `functions.php` | The theme's starting point. It only sets the version and loads the files in inc/, one file per feature. Storefront does the shop work (cart, checkout, account); this theme changes the look, the header, the product tiles, the front page and the product page. With the Codex plugin on, tiles and pages show the Codex number, difficulty and colour of each species. |  |
| `header.php` | The page skeleton above the content: the <head> and the top bar's frame (Storefront's header.php with small changes). | The top of every page. |
| `style.css` | The theme's whole look, except the cart / checkout / footer pages (assets/launch.css) and the Codex card itself (the Codex plugin). The sections are in the order they were written: a later section corrects earlier ones, so do not move rules between sections. To change something, search for its class name (right-click the element in the browser → Inspect shows it) and edit the LAST rule that sets it. About half of this file is for the product page only; the build makes style.lite.min.css (this file without those rules) for every other page. | Every page. |
| `assets/carousel.js` | The front page's card carousel: the hero cards turn, the one in front is the active one. | The front page, with more than one hero card. |
| `assets/cart.js` | The cart page: quantity changes without a reload, the pinned Pénztár bar, the free-shipping line. | The cart page. |
| `assets/finder.js` | The header search: opens the panel, asks the server while you type, draws the results. | The magnifier icon in the top bar. |
| `assets/fonts.css` | The shop's own fonts (Izeltlab Sans = IBM Plex Sans, the logo's Space Mono). The mono font comes from Codex's copy. | All text on the shop. |
| `assets/hero-link.js` | The front page: the card in front opens its product page. | The front page. |
| `assets/home-edit.js` | ADMIN ONLY. The "Edit cards" panel of the front page. | The front page, for logged-in admins. |
| `assets/home-phone.js` | The front page on a phone: the title on one line, the cards at the product page's size. | The front page on phones. |
| `assets/launch.css` | The look of the cart, mini cart, checkout, thank-you page, account, footer, 404 and legal pages. | Loaded on every page (the footer and the mini cart are everywhere). |
| `assets/photos.js` | EDITORS ONLY. The "Edit photos" dialog of supply products (choose, reorder, zoom and position). | Supply product pages, for logged-in editors. |
| `assets/product-edit.js` | EDITORS ONLY. Edit the sales line and pack tip in place, and the buy box editor (price, packs, availability). | Product pages, only for logged-in editors. |
| `assets/product.js` | The product page for shoppers: quantity buttons, pack buttons, the big price, stock and shipping lines, Kosárba without a reload, the phone's bottom drawer, the photo pop-out. | Every product page. (Editors' tools: assets/product-edit.js.) |
| `assets/shop.js` | The shop page (since 3.2.0): the filter bar works in place, the address and the sort keep the choice, the phone's "Szűrők" panel, Kezdő pointed out on a first visit, the free-shipping line follows the cart. | The shop and category lists (inc/shop-page.php prints the markup). |
| `inc/edit-buy-box.php` | ADMIN ONLY. The "Edit buy box" button and the data its dialog needs (saving is in inc/shop-core.php). | Only by logged-in shop managers, on product pages. |
| `inc/edit-front-page.php` | ADMIN ONLY. The "Edit cards" panel on the front page (how many cards, which species). | Only by logged-in admins, on the front page. |
| `inc/edit-new-product.php` | ADMIN ONLY. The "New product" bar over the shop lists and the draft bar (Publish / Delete) over a draft product. | Only by logged-in shop managers. |
| `inc/finder.php` | The header search: the panel under the top bar and the live results while typing. | The magnifier icon in the top bar, on every page. |
| `inc/front-page.php` | The front page: its texts and settings, the hero cards, the product rows, and its Customizer panel. | The front page; Appearance → Customize → Ízeltláb front page. |
| `inc/helpers.php` | Theme setup and small helpers the other files use: the shop's teal, the isopod list address, the Codex difficulty levels. | Nothing on its own; other files call these. |
| `inc/launch.php` | The "launch" pages in the shop's look: cart (free-shipping bar, Szállítás block, pinned Pénztár bar, empty cart), mini cart, thank-you page, footer, search with no results, the login screen. | Cart, checkout, thank-you page, the footer of every page, wp-login.php. |
| `inc/layout.php` | Page layout: full-width shop pages, number of tiles per row, how many related products. | Shop lists, product pages. |
| `inc/look.php` | The site-wide look that is set in the page head: the shop keeps its own colours (no dark mode), the phone/PC layout switch, the logo and the browser icons. | Every page: logo, browser tab icon, colours. |
| `inc/minified-files.php` | Picks the small (minified) copy of each stylesheet and script for shoppers, and the readable source when it was edited by hand. | Every shop page (behind the scenes). |
| `inc/photos.php` | EDITORS ONLY tools for supply products: the "Edit photos" dialog (server side) and the framed photo on the page. | Product pages of supplies (the photo); the Edit photos button for editors. |
| `inc/product-fonts.php` | Tells the browser to fetch the product page's fonts with the page, so texts do not swap fonts a moment later. | Product pages (behind the scenes). |
| `inc/product-page.php` | The product page layout: the buy box next to the Codex card, its settings, and the "Tedd mellé" supplies. | Every product page. |
| `inc/product-row.php` | Supply product pages and the product row under a product (title, which products, the description, the tag pills). | Product pages of supplies; the row of tiles under every product. |
| `inc/product-script.php` | Loads the product page script (assets/product.js) with its settings, and the product page's Customizer panel. | Product pages; Appearance → Customize → Ízeltláb product page. |
| `inc/product-texts.php` | The buy box texts: sales line, Codex tag chips, the pack question. | Product pages, above the price. |
| `inc/product-ticket.php` | The buy ticket: stock stamp, shipping lines, the price row, pack buttons and the quantity − / + buttons, printed ready by the server. | Product pages: the white ticket with the price and Kosárba vele!. |
| `inc/product-trust.php` | Trust points and common questions under the buy box, and the cart button's text. | Product pages, under the cart button. |
| `inc/shop-core.php` | The shop's rules and data: Codex helpers, shop texts, whole-forint prices, packs, photo frames, free shipping amount, shipping days and holidays. This one file is copied by the build into the theme (inc/) and Bolt (inc/); edit it in shared/ only. | Prices, packs, shipping dates and the free-shipping bar everywhere. |
| `inc/shop-list.php` | The shop and category lists: the difficulty pills and the product tiles (photo, name, price, cart button). | The isopod list, category pages, product rows on the front page and under products. |
| `inc/shop-page.php` | The shop page (since 3.2.0): the slim filter bar (Csoport switches, Nehézség buttons, the phone's "Szűrők" bar), the grid's room, in-stock-first order, "Utolsó N db" and sold-out tiles, the free-shipping line above the grid and the friendly empty list. The script is assets/shop.js, the look the last section of style.css. | The shop, the isopod list and category lists (not search results, not the product rows elsewhere). |
| `inc/site-header.php` | The top bar: logo, menu, search / account / cart icons and the cart counter. | The top of every page. |
| `inc/styles.php` | Loads the theme's stylesheets, fonts and the front page scripts. | Every page (fonts and styles); the front page (card scripts). |
| `inc/swift.php` | Phones only: product pages open smoothly from a list (the next page is fetched early and slides in). | Phones, when a tile is tapped. |
| `inc/titles.php` | Small text changes: no Storefront credit in the footer, the breadcrumb trail, the shop page title. | Breadcrumbs and titles on shop pages; the footer. |
| `inc/unused-files.php` | Stops loading Storefront files the shop does not use: the icon font's 1 500 unused classes, the block styles on pages without blocks, the brand styles and script while the shop has no brands. Nothing here changes the look: a file is only left out where none of its rules can apply. | Behind the scenes, on every page (less to download). |
| `inc/updater.php` | Updates from the shop's GitHub repository: finds new versions of the theme, Codex and Bolt, checks each zip's fingerprint, installs, rolls back, clears the page cache. This one file is copied by the build into the theme (inc/), Codex and Bolt (inc/); edit it in shared/ only. | Dashboard → Settings → Ízeltláb updates, and the "Ízeltláb updates" box on the Dashboard home. |
| `woocommerce/content-product.php` | One product tile (calls izl_product_tile() in inc/shop-list.php). | Shop, category and search lists, product rows. |
| `woocommerce/global/breadcrumb.php` | The breadcrumb strip under the top bar. | Shop lists and product pages. |
| `woocommerce/loop/result-count.php` | The short count above the products ("12 faj"). | Shop and category lists. |

### Codex

| File | What it does | Where you see it |
|---|---|---|
| `codex.php` | The plugin's starting point. It only sets the version and loads the files in inc/, one file per feature. |  |
| `updater.php` | Updates from the shop's GitHub repository: finds new versions of the theme, Codex and Bolt, checks each zip's fingerprint, installs, rolls back, clears the page cache. This one file is copied by the build into the theme (inc/), Codex and Bolt (inc/); edit it in shared/ only. | Dashboard → Settings → Ízeltláb updates, and the "Ízeltláb updates" box on the Dashboard home. |
| `assets/codex-admin.css` | DASHBOARD. The look of the Codex settings page and the Codex box on the product edit page. | Dashboard only. |
| `assets/codex-admin.js` | DASHBOARD. The Codex settings page: list editors, colour pickers, the live preview. | Dashboard → WooCommerce → Codex. |
| `assets/codex-edit.css` | EDITORS ONLY. The look of "Edit card": outlines, the bottom bar, the pop-ups. | Product pages of species, for logged-in editors. |
| `assets/codex-edit.js` | EDITORS ONLY. "Edit card" on the product page: type into the card, set bars and badges, choose photos and colours, save. | Product pages of species, for logged-in editors. |
| `assets/codex.css` | The whole look of the Codex card (device, screen, bars, badges, Leírás page), for phone and PC. Sizes use the card's own unit (--u), so the card scales as one piece. | Every Codex card. |
| `assets/codex.js` | Brings the Codex card to life: fits the names, the Leírás page switch, photo slides, the 3D tilt and sheen, the wake-up animation, the number plate. | Every Codex card. |
| `assets/skins/swiss.css` | The "Swiss" skin: an alternative look of the card, chosen in the Codex settings. | Codex cards, only when this skin is chosen. |
| `assets/swipe.js` | Moving between species on their product pages without a page load (2.3.0). Phones and touch screens: a sideways swipe anywhere on the page (also beside the card) brings the next species from the right or the previous one from the left; the new card is already visible while the finger moves and comes forward from behind ("Depth"). PC: no swipe; the small side cards (or the arrow keys) do the same move. The next and previous pages are fetched in the background, then the page content is swapped in place and the address bar follows (the back button works). Anything unusual: a normal page load instead. 2.4.0: the swap happens while the cards are still moving and the real card takes over in mid-move (no jump when it lands); the finger is followed with touch events (iPhone). The neighbours and the side cards: inc/card-swipe.php; the look: codex.css section 7. | Product pages of species (only where a Codex card shows). |
| `inc/admin-fields.php` | DASHBOARD. The Codex box on the product edit page, the group colour fields on categories, the list of all Codex fields, and saving them. | Products → edit a product; Products → Categories. |
| `inc/admin-settings.php` | DASHBOARD ONLY. The Codex settings page (lists, colours, preview) and the cleanup tool for old data. | Dashboard → WooCommerce → Codex. |
| `inc/assets.php` | Loads Codex's stylesheet, fonts and script on the shop pages (the small built copies for shoppers). | Every page that shows a Codex card. |
| `inc/card-data.php` | Small facts of one card: its Codex number (#001), the two names, the tags and the corner badge. | The top of every Codex card. |
| `inc/card-parts.php` | Parts the card is built from: the difficulty levels and gauge, the colour values of one card, the device label, the group and its colour. | The difficulty pill, the colours and the group label of every card. |
| `inc/card-photos.php` | The photos on the card's screen: which photos, how each is framed (zoom and position), and which file size each screen gets. | The photo on every Codex card. |
| `inc/card-swipe.php` | Card swipe on species pages: the previous and next species in Codex number order (wrapping round), the "Előző #N" / "Következő #N" edge tabs (phone) and small side cards (PC wide, with the first-visit "előző" / "következő" hints), and the small head script that lets a card slide in after a normal page load. The swipe, the move without a page load (2.3.0) and the fetching ahead: assets/swipe.js. | Product pages of species (only where a Codex card shows). |
| `inc/card.php` | Builds the whole Codex card: the main page and the Leírás page behind the round arrow. | Every Codex card: product pages, the front page, phone and PC. |
| `inc/colours.php` | The card's colour themes (device colour, darker frame, screen tint) and the colour maths behind them. Also who may quick-edit a card. | The colours of every Codex card. |
| `inc/edit-dialog.php` | EDITORS ONLY. The pop-ups of "Edit card" on the product page: photos, badge, colour theme. | Only by logged-in editors, after pressing Edit card. |
| `inc/product-page.php` | Puts the card on the product page in place of the photo gallery, with the small scripts that size it before the first paint and the early photo download. | Product pages of species. |
| `inc/quick-edit-save.php` | EDITORS ONLY. Saves what "Edit card" on the product page changed. | Behind the scenes, when an editor presses Save on a card. |
| `inc/settings.php` | Codex's settings: the default values, the skins, the labels on the card, upgrades from older versions, and the helpers that read the lists (stat bars, stats). | Nothing on its own; every other Codex file reads its settings from here. |
| `inc/shop-filter.php` | The difficulty filter on shop lists. | Shop and category lists. |
| `inc/tags.php` | Keeps the Codex tags in step with WooCommerce's product tags. | Behind the scenes; tag chips link to the shop filtered by tag. |
| `inc/text-format.php` | Text on the card: coloured marks, the Leírás (description) text, the fun fact, Hungarian hyphenation. | The Leírás page and the fun fact bubble of the card. |
| `inc/traits.php` | The trait badges (the three small icons), the group stamp and the in-stock check. | The badge bubble on the card. |
| `inc/which-products.php` | Decides which products get a Codex card (the chosen categories). | Behind the scenes. |

### Ízeltláb Bolt

| File | What it does | Where you see it |
|---|---|---|
| `izeltlab-bolt.php` | The plugin's starting point: the default settings, reading a setting (izb_opt), and loading the files in inc/, one file per feature. | Nothing on its own. WHERE IS WHAT: read ARCHITECTURE.md in this folder. |
| `assets/bolt.css` | The look of the cookie banner and the sign-up forms. | Every page. |
| `assets/bolt.js` | Shop side: the cookie banner, the sign-up forms ("Szólj, ha újra lesz!", newsletter), loading analytics after consent. | Every page. |
| `assets/pult.css` | STAFF ONLY. The look of the order desk. | Staff only. |
| `assets/pult.js` | STAFF ONLY. The order desk ("Rendelés-pult"): today's orders to pack and ship. | The pill in the corner for staff; the secret phone page. |
| `inc/accounting.php` | The accountant's export: orders of a month as a CSV file. | Dashboard → WooCommerce → Accountant export. |
| `inc/analytics.php` | Visitor statistics (GA4 or Plausible), loaded only after "Elfogadom" on the cookie banner. | Behind the scenes, when an analytics ID is set. |
| `inc/backup.php` | Sets up UpdraftPlus backups with one button (database daily, files weekly). | Dashboard → WooCommerce → Ízeltláb Bolt. |
| `inc/cache.php` | Page caching that cannot break the cart: which pages are never cached, and the browser-cache lines. | Behind the scenes; Ízeltláb Bolt settings page. |
| `inc/checkout.php` | Checkout the Hungarian way: the order button text, the required consent boxes, the legal lines. | The checkout page. |
| `inc/consent.php` | The cookie banner. | The bottom of every page until the visitor answers. |
| `inc/emails.php` | The look and wording of the shop's emails (teal head, yellow button), Reply-To, the footer with company data. | Every order email. |
| `inc/holidays.php` | The shop's own closed days, added to the public holidays the shipping dates skip. | Shipping dates everywhere. |
| `inc/htaccess.php` | Writes the server lines (.htaccess) the shop needs with one button: compression and security headers, tested first, with Undo. | Dashboard → WooCommerce → Ízeltláb Bolt → "Turn on compression and server headers". |
| `inc/packing.php` | The printable packing slip of an order. | Dashboard → an order → Print packing slip. |
| `inc/privacy.php` | GDPR tools: sign-up emails are part of WordPress's personal data export and erase. | Dashboard → Tools → Export / Erase personal data. |
| `inc/pult.php` | The "Rendelés-pult" (order desk): today's orders to pack and ship, on the shop for staff, on a secret phone link, and in the morning mail. | The small pill in the corner for staff; the secret phone page; the morning email. |
| `inc/restock.php` | Sold-out species stay in the shop; the restock list shows who waits for what. | Dashboard → WooCommerce → Restock list. |
| `inc/search.php` | A shop search that knows the species: every product gets a small search index built from its Codex card (names, traits, level, group). | The shop search and the header search results. |
| `inc/security.php` | Security switches: secret login address, cleaner page head, security headers, XML-RPC off. | Behind the scenes; the login address. |
| `inc/seo.php` | SEO basics without an SEO plugin: descriptions, share image and address, canonical tags, product data for Google, sitemap. | Search results and link previews (behind the scenes). |
| `inc/settings.php` | The Ízeltláb Bolt settings page, and its one-click buttons: Apply shop settings, Create legal page drafts, Send test mail. | Dashboard → WooCommerce → Ízeltláb Bolt. |
| `inc/shop-core.php` | The shop's rules and data: Codex helpers, shop texts, whole-forint prices, packs, photo frames, free shipping amount, shipping days and holidays. This one file is copied by the build into the theme (inc/) and Bolt (inc/); edit it in shared/ only. | Prices, packs, shipping dates and the free-shipping bar everywhere. |
| `inc/signups.php` | Sign-ups: "Szólj, ha újra lesz!" on sold-out products and the newsletter line in the footer; the back-in-stock mail; the CSV export. | Sold-out product pages, the footer, the coming soon page. |
| `inc/smtp.php` | Sends the shop's mail through SMTP (Gmail app password), so order mails do not land in spam. | Behind the scenes. |
| `inc/soon.php` | The "Hamarosan nyitunk!" (coming soon) page for visitors, and "View as visitor" for the logged-in owner. | Every page while coming soon is on; the admin bar switch. |
| `inc/speed.php` | Photos that load fast without looking different: WebP copies, right sizes, "Optimise existing photos". | Behind the scenes; the button on the Ízeltláb Bolt settings page. |
| `inc/updater.php` | Updates from the shop's GitHub repository: finds new versions of the theme, Codex and Bolt, checks each zip's fingerprint, installs, rolls back, clears the page cache. This one file is copied by the build into the theme (inc/), Codex and Bolt (inc/); edit it in shared/ only. | Dashboard → Settings → Ízeltláb updates, and the "Ízeltláb updates" box on the Dashboard home. |
