// ==========================================================================
//  FILE: assets/codex.js   (Codex plugin)
//  WHAT: Brings the Codex card to life: fits the names, the Leírás page switch, photo slides, the 3D tilt
//        and sheen, the wake-up animation, the number plate.
//  SEEN: Every Codex card.
//  SECTIONS IN THIS FILE:
//    1. Fitting the names to the card
//    2. Screen: the Leírás page switch and the photo slides
//    3. The card's 3D: tilt, sheen, depth
//    4. Wake-up animation (the card switches on, the bars fill)
//    5. Phone: the Leírás page and tilting by moving the phone
//    6. Fun fact fitting
//    7. The number plate
//    8. Setting up one card, floating, start
// ==========================================================================

/* Codex: the name on one line, the photos and the detail page with the TV-line switch,
   and the 3D tilt that follows the mouse (strength from data-tilt, max degrees, 0 = off). */
(function () {
	var reduce = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

	// ==========================================================================
	//  Fitting the names to the card
	// ==========================================================================

	// The name's size comes from its length (codex.css: --fsz-chars, 0.62em per letter).
	// If the font in use is wider than that, shrink it until the name fits on one line.
	// The nickname in the name bar is as big as the bar allows; one that does not fit gets smaller (--fsz-fit).
	function fitName( el ) {
		if ( el.classList.contains( 'fsz-nick' ) ) {
			el.style.removeProperty( '--fsz-fit' );
			if ( el.clientWidth && el.scrollWidth > el.clientWidth + 1 ) {
				el.style.setProperty( '--fsz-fit', Math.max( 0.6, el.clientWidth / el.scrollWidth ).toFixed( 3 ) );
			}
			return;
		}
		el.style.removeProperty( '--fsz-k' );
		if ( ! el.clientWidth ) {
			return;
		}
		var over = el.scrollWidth / el.clientWidth;
		if ( over > 1.01 ) {
			el.style.setProperty( '--fsz-k', ( 0.62 * over * 1.02 ).toFixed( 3 ) );
		}
	}

	// The barcode at the end of the English name strip: hidden when the name leaves it no room (a gap of 0.8em).
	// Layout sizes (offset*), not screen boxes: the card is turned in 3D.
	function fitMark( en ) {
		var name = en.firstElementChild;
		en.classList.remove( 'no-mark' );
		if ( ! name || ! en.clientWidth ) {
			return;
		}
		var left = parseFloat( window.getComputedStyle( en, '::after' ).left );
		var gap = 0.8 * parseFloat( window.getComputedStyle( en ).fontSize );
		if ( ! isNaN( left ) && name.offsetLeft + name.offsetWidth + gap > left ) {
			en.classList.add( 'no-mark' );
		}
	}

	function fitNames( root ) {
		var els = ( root || document ).querySelectorAll( '.fsz-name' );
		for ( var i = 0; i < els.length; i++ ) {
			fitName( els[ i ] );
		}
		var ens = ( root || document ).querySelectorAll( '.fsz-en' );
		for ( var j = 0; j < ens.length; j++ ) {
			fitMark( ens[ j ] );
		}
	}

	// ==========================================================================
	//  Screen: the Leírás page switch and the photo slides
	// ==========================================================================

	// The TV-line switch (1 s): "from" fades out under rolling scan lines, swap() puts "to" in its place, "to" fades in.
	function crt( host, from, to, swap ) {
		if ( reduce ) {
			swap();
			return;
		}
		host.classList.remove( 'is-crt' );
		void host.offsetWidth; // restart the animation
		host.classList.add( 'is-crt' );
		from.classList.add( 'is-leaving' );
		window.setTimeout( function () {
			from.classList.remove( 'is-leaving' );
			// "to" starts faded and bright right away (no transition towards that), then settles in.
			to.style.transition = 'none';
			to.classList.add( 'is-entering' );
			swap();
			void to.offsetWidth;
			to.style.transition = '';
			window.requestAnimationFrame( function () {
				window.requestAnimationFrame( function () {
					to.classList.remove( 'is-entering' );
				} );
			} );
		}, 450 );
		window.setTimeout( function () {
			host.classList.remove( 'is-crt' );
		}, 1000 );
	}

	// The round arrow switches the screen to the detail page, "Back" switches back.
	function bindScreens( card ) {
		var screen = card.querySelector( '.fsz-screen' );
		var main = screen && screen.querySelector( '.fsz-page-main' );
		var more = screen && screen.querySelector( '.fsz-page-more' );
		var open = main && main.querySelector( '.fsz-more' );
		var back = more && more.querySelector( '.fsz-back' );
		var body = more && more.querySelector( '.fsz-more-body' );
		if ( ! open || ! back ) {
			return;
		}
		// Longer texts scroll inside the screen; a soft fade at the bottom while there is more below.
		function hint() {
			if ( body ) {
				body.classList.toggle( 'is-more-below', body.scrollTop + body.clientHeight < body.scrollHeight - 2 );
			}
		}
		function go( toMore ) {
			if ( screen.classList.contains( 'is-crt' ) || toMore === ! more.hidden ) {
				return;
			}
			crt( screen, toMore ? main : more, toMore ? more : main, function () {
				more.hidden = ! toMore;
				if ( toMore ) {
					placeBack();
				}
				if ( toMore && body ) {
					body.scrollTop = 0;
					hint();
					if ( more.fszEnd ) {
						more.fszEnd();
					}
				}
				main.classList.toggle( 'is-away', toMore );
				open.setAttribute( 'aria-expanded', toMore ? 'true' : 'false' );
				fitNames( toMore ? more : main );
				( toMore ? more : open ).focus( { preventScroll: true } );
			} );
		}
		// 1.64.0 (computers): Vissza sits exactly where Leírás sits, mirrored: its left edge as far from the screen's left
		// edge as Leírás's right edge is from the right one, the same middle height. Measured from the layout (the
		// screen's own offsets; inside the small footer box the tilt's scale is taken out), so it is exact at any size.
		// Phones keep their tuned spot (codex.css).
		function placeBack() {
			var foot = more.querySelector( '.fsz-more-foot' ), row = open.parentNode;
			if ( ! foot || ! row ) {
				return;
			}
			if ( window.matchMedia && window.matchMedia( '(max-width: 767px)' ).matches ) {
				foot.style.left = foot.style.bottom = '';
				return;
			}
			// the pills' press animation (a small hop every 10 s) is held off while measuring
			var an = [ open.style.animation, back.style.animation ];
			open.style.animation = back.style.animation = 'none';
			var rr = row.getBoundingClientRect(), ro = rr.width && row.offsetWidth ? rr.width / row.offsetWidth : 1;
			var rh = rr.height && row.offsetHeight ? rr.height / row.offsetHeight : 1, or = open.getBoundingClientRect();
			var at = offsetTo( row, screen );
			if ( ! at.hit || ! or.width ) {
				open.style.animation = an[ 0 ];
				back.style.animation = an[ 1 ];
				return;
			}
			var x = at.x + ( or.left - rr.left ) / ro, w = or.width / ro;
			var y = at.y + ( or.top - rr.top ) / rh, h = or.height / rh;
			var gap = screen.clientWidth - ( x + w ), mid = y + h / 2;
			var fr = foot.getBoundingClientRect(), br = back.getBoundingClientRect();
			var fs = fr.width && foot.offsetWidth ? fr.width / foot.offsetWidth : 1, fv = fr.height && foot.offsetHeight ? fr.height / foot.offsetHeight : 1;
			var bl = ( br.left - fr.left ) / fs, bmid = ( br.top - fr.top ) / fv + br.height / fv / 2;
			open.style.animation = an[ 0 ];
			back.style.animation = an[ 1 ];
			foot.style.left = Math.round( ( gap - bl ) * 10 ) / 10 + 'px';
			foot.style.bottom = Math.round( ( screen.clientHeight - ( mid - bmid ) - foot.offsetHeight ) * 10 ) / 10 + 'px';
		}
		window.addEventListener( 'resize', function () {
			if ( ! more.hidden ) {
				placeBack();
			}
		} );
		// The outline lights up after a click and when focus lands on the button, then fades back after 5 s.
		function lit( b ) {
			b.classList.add( 'is-lit' );
			window.clearTimeout( b.fszLit );
			b.fszLit = window.setTimeout( function () {
				b.classList.remove( 'is-lit' );
			}, 5000 );
		}
		[ open, back ].forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				lit( b );
			} );
			b.addEventListener( 'focus', function () {
				lit( b );
			} );
			b.addEventListener( 'touchstart', function () {}, { passive: true } ); // 1.68.0: iPhones show the :active press only with a touch listener
		} );
		open.addEventListener( 'click', function () {
			go( true );
		} );
		back.addEventListener( 'click', function () {
			go( false );
		} );
		more.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key && ! e.target.isContentEditable ) {
				go( false );
			}
		} );
		if ( body ) {
			body.addEventListener( 'scroll', hint, { passive: true } );
			body.addEventListener( 'input', hint ); // typing in quick edit
		}
	}

	// Several photos: the next one every 10 seconds, or right away on a click.
	function bindSlides( card ) {
		var box = card.querySelector( '.fsz-slides' );
		var imgs = box ? box.querySelectorAll( ':scope > img' ) : [];
		if ( imgs.length < 2 ) {
			return;
		}
		var photo = box.parentNode, dots = card.querySelectorAll( '.fsz-strip-dots i' );
		var cur = 0, busy = false, seen = true, timer = 0;
		imgs[ 0 ].classList.add( 'is-active' );

		function show( i ) {
			var from = imgs[ cur ], to = imgs[ i ];
			if ( busy || i === cur ) {
				return;
			}
			if ( ! to.complete ) {
				// Not loaded yet: switch as soon as it is.
				to.loading = 'eager';
				to.addEventListener( 'load', function () {
					show( i );
				}, { once: true } );
				return;
			}
			busy = true;
			cur = i;
			crt( box, from, to, function () {
				from.classList.remove( 'is-active' );
				to.classList.add( 'is-active' );
				box.classList.toggle( 'is-moved', 0 !== i );
				for ( var d = 0; d < dots.length; d++ ) {
					dots[ d ].classList.toggle( 'is-on', d === i );
				}
			} );
			window.setTimeout( function () {
				busy = false;
			}, reduce ? 0 : 1000 );
		}
		function next() {
			show( ( cur + 1 ) % imgs.length );
		}
		function prev() {
			show( ( cur - 1 + imgs.length ) % imgs.length );
		}
		function tick() {
			// Only while it can be seen: not in a background tab, off screen or behind the detail page.
			if ( ! document.hidden && seen && document.body.contains( card ) && ! card.querySelector( '.fsz-page-main.is-away' ) ) {
				next();
			}
		}
		// first: ms until the first change (default the full 10 s). On page load every card waits a random part of it,
		// so cards next to each other change at different moments; after that every 10 s.
		function restart( first ) {
			window.clearTimeout( timer );
			window.clearInterval( timer );
			if ( reduce ) {
				return; // no automatic changes for visitors who turned off animations; a click still works
			}
			timer = window.setTimeout( function () {
				tick();
				timer = window.setInterval( tick, 10000 );
			}, undefined === first ? 10000 : first );
		}
		// Swipe (finger or mouse drag): left = next, right = previous. Up and down still scroll the page (codex.css touch-action).
		var start = null, swiped = false;
		photo.addEventListener( 'pointerdown', function ( e ) {
			start = { x: e.clientX, y: e.clientY };
			// Keep following the pointer when the drag ends outside the photo.
			if ( 'mouse' === e.pointerType ) {
				try {
					photo.setPointerCapture( e.pointerId ); // 1.57.0: the mouse only; a finger keeps scrolling the page
				} catch ( err ) {}
				e.preventDefault(); // no text selection or image dragging with the mouse
			}
		} );
		photo.addEventListener( 'pointerup', function ( e ) {
			if ( ! start ) {
				return;
			}
			var dx = e.clientX - start.x, dy = e.clientY - start.y;
			start = null;
			if ( Math.abs( dx ) > 10 || Math.abs( dy ) > 10 ) {
				swiped = true; // a drag, not a click: the click that may follow is ignored
				window.setTimeout( function () {
					swiped = false;
				}, 400 );
			}
			if ( Math.abs( dx ) > 40 && Math.abs( dx ) > Math.abs( dy ) * 1.2 ) {
				( dx < 0 ? next : prev )();
				restart();
			}
		} );
		photo.addEventListener( 'pointercancel', function () {
			start = null;
		} );
		// Two-finger swipe on a laptop trackpad (sideways scrolling): one photo per gesture.
		var sum = 0, lock = false, quiet = 0;
		photo.addEventListener( 'wheel', function ( e ) {
			if ( Math.abs( e.deltaX ) <= Math.abs( e.deltaY ) ) {
				return; // up and down still scroll the page
			}
			e.preventDefault(); // and the browser does not go back a page
			window.clearTimeout( quiet );
			quiet = window.setTimeout( function () {
				sum = 0;
				lock = false; // the gesture is over
			}, 250 );
			sum += e.deltaX;
			if ( ! lock && Math.abs( sum ) > 50 ) {
				lock = true;
				( sum > 0 ? next : prev )();
				restart();
			}
		}, { passive: false } );
		photo.addEventListener( 'dragstart', function ( e ) {
			e.preventDefault(); // a mouse drag swipes instead of dragging the image away
		} );
		photo.addEventListener( 'click', function () {
			if ( swiped ) {
				return;
			}
			next();
			restart();
		} );
		photo.addEventListener( 'keydown', function ( e ) {
			if ( 'Enter' === e.key || ' ' === e.key ) {
				e.preventDefault();
				next();
				restart();
			}
		} );
		if ( 'IntersectionObserver' in window ) {
			new window.IntersectionObserver( function ( entries ) {
				seen = entries[ entries.length - 1 ].isIntersecting;
			} ).observe( photo );
		}
		card.fszSlides = { restart: restart };
		if ( ! card.fszWake ) {
			restart( 2000 + Math.random() * 8000 ); // 2-10 s: random start, never right after load
		} // a card that wakes up (wake()) starts them itself: first change at 11 s, then every 10 s
	}


	// ==========================================================================
	//  The card's 3D: tilt, sheen, depth
	// ==========================================================================

	// The resting angle (settings: turn right, tilt down; codex.css --fsz-turn/--fsz-lean), in degrees.
	function restAngle( el ) {
		var cs = window.getComputedStyle( el );
		return {
			turn: parseFloat( cs.getPropertyValue( '--fsz-turn' ) ) || 0,
			lean: parseFloat( cs.getPropertyValue( '--fsz-lean' ) ) || 0
		};
	}

	// The fake resting edge (codex.css --fsz-kx/--fsz-ky, 1 = full step right and down) for a total turn (ry) and tilt (rx):
	// full when the card faces straight on, gone where the real side shows. ref = the angle at which it is gone.
	// 1.57.0: written on the slices themselves (the only ones that use it), so a tilt restyles 24 slices instead of the
	// whole card.
	function setEdge( el, rx, ry, ref ) {
		var kx = Math.max( 0, Math.min( 2, 1 - ry / ref ) ).toFixed( 3 ), ky = Math.max( 0, Math.min( 2, 1 + rx / ref ) ).toFixed( 3 );
		var list = el.fszSlices && el.fszSlices.length ? el.fszSlices : [ el ];
		if ( el.fszKx === kx && el.fszKy === ky ) {
			return;
		}
		el.fszKx = kx;
		el.fszKy = ky;
		for ( var i = 0; i < list.length; i++ ) {
			list[ i ].style.setProperty( '--fsz-kx', kx );
			list[ i ].style.setProperty( '--fsz-ky', ky );
		}
	}

	// 1.57.0: the glass sheen's place (codex.css --fsz-gx), set on the screens only (registered as not inherited), in
	// whole steps, so a mouse move restyles the screen's glass instead of everything on the card.
	function sheen( el, gx ) {
		if ( el.fszGx === gx ) {
			return;
		}
		el.fszGx = gx;
		var scr = el.fszScreens || ( el.fszScreens = el.querySelectorAll( '.fsz-screen' ) );
		for ( var i = 0; i < scr.length; i++ ) {
			scr[ i ].style.setProperty( '--fsz-gx', gx + '%' );
		}
	}

	// 1.57.0: the tilt as the card's own transform (the same as codex.css builds from --fsz-rx/--fsz-ry and the resting
	// angle), written straight, so a move restyles the card alone, not everything inside it.
	function turnTo( el, rx, ry, a ) {
		a = a || restAngle( el );
		el.style.transform = 'rotateX(' + ( rx - a.lean ).toFixed( 2 ) + 'deg) rotateY(' + ( ry + a.turn ).toFixed( 2 ) + 'deg)';
	}

	function edgeRef( el ) {
		var max = ( parseFloat( el.getAttribute( 'data-tilt' ) ) || 0 ) * 0.65;
		return max > 0 ? max : 6.5;
	}

	// The card at rest: its resting angle, the edge to match.
	function rest( el ) {
		var a = restAngle( el );
		setEdge( el, -a.lean, a.turn, edgeRef( el ) );
	}

	// Real depth, on every screen: the front stays straight and the thickness shows on the right and bottom (codex.css .has-depth).
	// 3D tilt 0 and no resting angle in the settings = the flat card. force: always (the edit card).
	function addDepth( el, force ) {
		var a = restAngle( el );
		if ( ! force && ! ( parseFloat( el.getAttribute( 'data-tilt' ) ) > 0 ) && ! a.turn && ! a.lean ) {
			return false;
		}
		if ( el.classList.contains( 'has-depth' ) ) {
			return true;
		}
		// Real depth: thin slices of the device stacked behind the front.
		// 24 slices 3.2px apart = about 77px thick (67px on phones); the deeper ones are darker for shading.
		var SLICES = 24, GAP = window.innerWidth >= 768 ? 3.2 : 2.8, PERSPECTIVE = 1000; // matches .fsz-wrap perspective; GAP follows the 15% larger desktop card
		el.fszSlices = [];
		for ( var i = 1; i <= SLICES; i++ ) {
			var slice = document.createElement( 'span' );
			slice.className = 'fsz-slice' + ( i === SLICES ? ' fsz-slice-back' : '' );
			slice.setAttribute( 'aria-hidden', 'true' );
			// Scale up to cancel the perspective shrink, so the side shows instead of hiding behind the front.
			// codex.css builds the transform: the resting step right and down (--i), the depth (--z) and this scale.
			slice.style.setProperty( '--i', String( i ) );
			slice.style.setProperty( '--z', ( -i * GAP ) + 'px' );
			slice.style.setProperty( '--s', ( ( PERSPECTIVE + i * GAP ) / PERSPECTIVE ).toFixed( 4 ) );
			// lit front edge, shaded towards the back: 1.57.0 a colour from --i in codex.css (was a brightness filter each)
			el.insertBefore( slice, el.firstChild );
			el.fszSlices.push( slice );
		}
		el.classList.add( 'has-depth' );
		return true;
	}

	// The mouse tilts the card on top of its resting turn.
	function bindTilt( el ) {
		var max = ( parseFloat( el.getAttribute( 'data-tilt' ) ) || 0 ) * 0.65; // 1.19.1: half of 1.18.2's range, the slider keeps its 0-20 steps
		var raf = 0, px = 0, py = 0, box = null, ang = null;
		if ( ! ( max > 0 ) ) {
			return;
		}
		// 1.57.0: the card's box and resting angle are read once per visit of the mouse (and after a scroll), not on every
		// move: each read made the browser lay out the page again.
		function forget() {
			box = null;
		}
		window.addEventListener( 'scroll', forget, { passive: true } );
		window.addEventListener( 'resize', forget );
		function set( rx, ry, gx ) {
			turnTo( el, rx, ry, ang );
			sheen( el, gx );
		}
		function apply() {
			raf = 0;
			if ( ! box ) {
				box = el.getBoundingClientRect();
				ang = restAngle( el );
			}
			var r = box;
			var x = Math.max( -0.5, Math.min( 0.5, ( px - r.left ) / r.width - 0.5 ) );
			var y = Math.max( -0.5, Math.min( 0.5, ( py - r.top ) / r.height - 0.5 ) );
			set( -y * 2 * max, x * 2 * max, Math.round( ( x + 0.5 ) * 100 ) );
			// The resting edge (right and bottom) for the whole angle, the resting one included.
			setEdge( el, -y * 2 * max - ang.lean, x * 2 * max + ang.turn, max );
		}
		el.addEventListener( 'mouseenter', forget );
		el.addEventListener( 'mousemove', function ( e ) {
			px = e.clientX;
			py = e.clientY;
			el.classList.add( 'is-tilting' );
			if ( ! raf ) {
				raf = window.requestAnimationFrame( apply );
			}
		} );
		el.addEventListener( 'mouseleave', function () {
			if ( raf ) {
				window.cancelAnimationFrame( raf );
				raf = 0;
			}
			el.classList.remove( 'is-tilting' );
			el.style.removeProperty( 'transform' ); // back to the resting angle of codex.css
			sheen( el, 50 );
			rest( el );
		} );
	}


	// 1.54.0 wake-up (the product page card only): when the card is at least half on screen, and again on every return
	// from the detail page: the photo alone (0.6 s), the gauge pops out and spins 8 turns to its level (2.2 s), then the
	// badges play left to right while the power bars fill in one wave and glow once, the fun fact types itself in (4.5 s),
	// the next photo dot blinks (5 s), Leírás pulses once (10 s), the photos start changing (11 s, then every 10 s).
	// Before this (.is-asleep, set by codex.php right after the card) the bars look empty; without JS they stay full.
	// Taps: a badge plays again, a bar fills again (its icon hops), the Nehézség bubble spins the gauge again.
	var LEVEL_ANGLE = [ 30, 90, 150 ]; // codex.css --fsz-needle per data-level

	// ==========================================================================
	//  Wake-up animation (the card switches on, the bars fill)
	// ==========================================================================

	function replay( el, cls ) {
		el.classList.remove( cls );
		void el.offsetWidth; // restart the animation
		el.classList.add( cls );
	}

	function wake( card ) {
		var main = card.querySelector( '.fsz-page-main' );
		var screen = card.querySelector( '.fsz-screen' );
		if ( reduce || ! main || ! screen ) {
			card.classList.remove( 'is-asleep' );
			return;
		}
		card.fszWake = true;
		card.classList.add( 'is-wake' );
		var dial = main.querySelector( '.fsz-dial' ), diff = main.querySelector( '.fsz-namebar .fsz-diff' );
		var needle = dial && dial.querySelector( '.fsz-needle' );
		var segs = dial ? [].slice.call( dial.querySelectorAll( '.fsz-seg' ) ) : [];
		var traits = [].slice.call( main.querySelectorAll( '.fsz-traits .fsz-trait' ) );
		var bars = [].slice.call( main.querySelectorAll( '.fsz-bar:not(.fsz-legend)' ) );
		var fun = main.querySelector( '.fsz-fun-text' ), chars = [];
		var badge = main.querySelector( '.fsz-badge' ), more = main.querySelector( '.fsz-more-btn' );
		var timers = [], raf = 0, busy = false, gaugeBusy = false, ghosts = [], fx = null;
		bars.forEach( function ( b ) {
			b.fszLit = [].slice.call( b.querySelectorAll( '.fsz-cell.is-on' ) );
		} );
		if ( needle ) {
			// Five faint copies of the needle trail it while it spins fast (motion blur).
			ghosts = [ 0.5, 0.34, 0.22, 0.13, 0.07 ].map( function ( op ) {
				var g = needle.cloneNode( false );
				g.setAttribute( 'class', 'fsz-ghost' );
				g.fszOp = op;
				needle.parentNode.insertBefore( g, needle );
				return g;
			} );
			fx = document.createElement( 'span' );
			fx.className = 'fsz-fx';
			fx.setAttribute( 'aria-hidden', 'true' );
			dial.appendChild( fx );
		}
		// The fun fact: one span per letter (the font is monospaced, so nothing moves), shown one by one.
		if ( fun ) {
			var walk = document.createTreeWalker( fun, window.NodeFilter.SHOW_TEXT ), nodes = [];
			while ( walk.nextNode() ) {
				nodes.push( walk.currentNode );
			}
			nodes.forEach( function ( n ) {
				var frag = document.createDocumentFragment();
				Array.from( n.nodeValue ).forEach( function ( c ) {
					var sp = document.createElement( 'span' );
					sp.className = 'fsz-ch';
					sp.textContent = c;
					frag.appendChild( sp );
					chars.push( sp );
				} );
				n.parentNode.replaceChild( frag, n );
			} );
		}

		function at( ms, f ) {
			timers.push( window.setTimeout( f, ms ) );
		}
		function level() {
			var l = parseInt( card.getAttribute( 'data-level' ), 10 );
			return l >= 1 && l <= 3 ? l : 0;
		}
		function stopGauge() {
			window.cancelAnimationFrame( raf );
			raf = 0;
			gaugeBusy = false;
			card.classList.remove( 'is-gauge-big', 'is-spinning' );
			if ( needle ) {
				needle.style.transform = '';
				needle.style.filter = '';
			}
			ghosts.forEach( function ( g ) {
				g.style.opacity = '0';
			} );
			segs.forEach( function ( sg ) {
				sg.classList.remove( 'is-pass' );
			} );
		}
		// Everything as it was printed: the finished card.
		function finish() {
			timers.forEach( window.clearTimeout );
			timers = [];
			busy = false;
			stopGauge();
			bars.forEach( function ( b ) {
				b.fszLit.forEach( function ( c ) {
					c.classList.add( 'is-on' );
					c.classList.remove( 'is-fade', 'is-glow' );
				} );
			} );
			if ( fun ) {
				fun.classList.remove( 'is-typing', 'is-blank' );
			}
			card.classList.remove( 'is-asleep' );
		}
		// Ready to play: bars empty, needle at the start, fun fact hidden.
		function prepare() {
			finish();
			bars.forEach( function ( b ) {
				b.fszLit.forEach( function ( c ) {
					c.classList.remove( 'is-on', 'is-fade', 'is-glow' );
				} );
			} );
			if ( needle && level() ) {
				needle.style.transform = 'rotate(0deg)';
			}
			if ( fun && chars.length ) {
				chars.forEach( function ( c ) {
					c.classList.remove( 'is-shown' );
				} );
				fun.classList.add( 'is-typing', 'is-blank' );
			}
			card.classList.remove( 'is-asleep' );
		}

		// The needle: 8 turns clockwise plus the way to its level in dur ms, very fast at first, slowing down exponentially.
		function spin( dur, done ) {
			var end = 2880 + LEVEL_ANGLE[ level() - 1 ], K = 6.5, N = 1 - Math.exp( -K ), t0 = window.performance.now();
			card.classList.add( 'is-gauge-big', 'is-spinning' );
			// Timed from the start, not from the first frame: a busy page skips frames but lands on time.
			function frame( now ) {
				var x = Math.min( 1, Math.max( 0, ( now - t0 ) / dur ) );
				var a = end * ( 1 - Math.exp( -K * x ) ) / N;
				var v = end * K * Math.exp( -K * x ) / N / dur; // degrees per ms
				var sp = Math.min( 1, v / 2.2 ), lag = Math.min( 28, v * 9 );
				needle.style.transform = 'rotate(' + a.toFixed( 2 ) + 'deg)';
				needle.style.filter = sp > 0.05 ? 'blur(' + ( sp * 0.7 ).toFixed( 2 ) + 'px)' : '';
				ghosts.forEach( function ( g, i ) {
					g.style.opacity = ( g.fszOp * sp ).toFixed( 3 );
					g.style.transform = 'rotate(' + ( a - lag * ( i + 1 ) ).toFixed( 2 ) + 'deg)';
				} );
				// The zone under the needle lights up (0-60 Kezdő, 60-120 Haladó, 120-180 Profi; below the dial none).
				var m = a % 360, z = m < 60 ? 0 : m < 120 ? 1 : m < 180 ? 2 : -1;
				segs.forEach( function ( sg, i ) {
					sg.classList.toggle( 'is-pass', i === z );
				} );
				if ( x < 1 ) {
					raf = window.requestAnimationFrame( frame );
				} else {
					raf = 0;
					stopGauge();
					done();
				}
			}
			raf = window.requestAnimationFrame( frame );
			// 1.70.0: a phone that stops drawing frames for a moment (seen on iPhones after Vissza) left the gauge popped
			// out and everything after it waiting (empty bars, no fun fact). The spin now ends on time without frames too.
			var dog = window.setTimeout( function () {
				if ( raf ) {
					stopGauge();
					done();
				}
			}, dur + 400 );
			timers.push( dog );
		}
		// It landed: its zone flashes; Haladó glows, Profi smokes and the bubble shakes.
		function landed() {
			var l = level(), win = dial.querySelector( '.fsz-seg.is-on' ) || segs[ l - 1 ];
			if ( win ) {
				replay( win, 'is-win' );
			}
			fx.innerHTML = '';
			if ( diff ) {
				diff.classList.remove( 'is-shake' );
			}
			if ( 2 === l ) {
				var g = document.createElement( 'span' );
				g.className = 'fsz-fx-glow';
				fx.appendChild( g );
			} else if ( 3 === l ) {
				[ [ -3, 0 ], [ 2, 180 ], [ -1, 380 ], [ 3, 560 ], [ 0, 760 ] ].forEach( function ( p ) {
					var d = document.createElement( 'span' );
					d.className = 'fsz-fx-puff';
					d.style.setProperty( '--fsz-dx', p[ 0 ] + 'px' );
					d.style.left = ( p[ 0 ] * 0.6 ) + 'px';
					d.style.animationDelay = p[ 1 ] + 'ms';
					fx.appendChild( d );
				} );
				if ( diff ) {
					replay( diff, 'is-shake' );
				}
			}
			window.clearTimeout( fx.fszDone );
			fx.fszDone = window.setTimeout( function () {
				fx.innerHTML = '';
				if ( diff ) {
					diff.classList.remove( 'is-shake' );
				}
				if ( win ) {
					win.classList.remove( 'is-win' );
				}
			}, 2600 );
		}
		function gauge( done ) {
			if ( ! needle || ! level() ) {
				at( 400, done );
				return;
			}
			gaugeBusy = true;
			needle.style.transform = 'rotate(0deg)';
			spin( 2200, function () {
				landed();
				done();
			} );
		}
		function playBadge( t ) {
			replay( t, 'is-play' );
			window.clearTimeout( t.fszPlay );
			t.fszPlay = window.setTimeout( function () {
				t.classList.remove( 'is-play' );
			}, 1300 );
		}
		// The lit cells of one bar fade on left to right (row: its place in the wave), then all of them glow once.
		function fill( b, row, glowAt ) {
			b.fszLit.forEach( function ( c, i ) {
				c.classList.remove( 'is-on', 'is-fade', 'is-glow' );
				at( i * 150 + row * 120, function () {
					c.classList.add( 'is-on' );
					replay( c, 'is-fade' );
				} );
				at( glowAt, function () {
					c.classList.remove( 'is-fade' );
					replay( c, 'is-glow' );
				} );
				at( glowAt + 950, function () {
					c.classList.remove( 'is-glow' );
				} );
			} );
		}
		function lastCell( b, row ) {
			return b.fszLit.length ? ( b.fszLit.length - 1 ) * 150 + row * 120 : 0;
		}
		function wave() {
			var last = 0;
			bars.forEach( function ( b, j ) {
				last = Math.max( last, lastCell( b, j ) );
			} );
			bars.forEach( function ( b, j ) {
				fill( b, j, last + 350 );
			} );
		}
		function type() {
			if ( ! fun || ! chars.length ) {
				return;
			}
			fun.classList.remove( 'is-blank' );
			chars.forEach( function ( c, i ) {
				at( i * 35, function () {
					c.classList.add( 'is-shown' );
				} );
			} );
			at( chars.length * 35, function () {
				fun.classList.remove( 'is-typing' );
			} );
		}
		function hintDot() {
			var dots = main.querySelectorAll( '.fsz-strip-dots i' );
			if ( dots.length < 2 ) {
				return;
			}
			var on = 0;
			for ( var i = 0; i < dots.length; i++ ) {
				if ( dots[ i ].classList.contains( 'is-on' ) ) {
					on = i;
				}
			}
			var d = dots[ ( on + 1 ) % dots.length ];
			replay( d, 'is-hint' );
			at( 950, function () {
				d.classList.remove( 'is-hint' );
			} );
		}
		// wait: ms of the photo alone (0.6 s on load, 0.3 s after the detail page).
		function run( wait ) {
			prepare();
			busy = true;
			if ( badge ) {
				at( 300, function () {
					replay( badge, 'is-wobble' );
				} );
				at( 1050, function () {
					badge.classList.remove( 'is-wobble' );
				} );
			}
			// The rest starts when the needle has landed (2.8 s; 0.4 s after the photo when the card has no level).
			at( wait, function () {
				gauge( function () {
					traits.forEach( function ( t, i ) {
						at( i * 250, function () {
							playBadge( t );
						} );
					} );
					wave();
					at( 1400, function () {
						busy = false;
					} );
					at( 1700, type );
					at( 2200, hintDot );
				} );
			} );
			if ( more ) {
				at( wait + 9400, function () {
					replay( more, 'is-kick' );
				} );
				at( wait + 10400, function () {
					more.classList.remove( 'is-kick' );
				} );
			}
			if ( card.fszSlides ) {
				card.fszSlides.restart( wait + 10400 );
			}
			// 1.70.0: whatever happened on the way, the card ends finished: bars lit, gauge back in its bubble, fun fact shown.
			at( wait + 7500, settle );
		}
		function settle() {
			if ( raf || gaugeBusy ) {
				stopGauge();
			}
			bars.forEach( function ( b ) {
				b.fszLit.forEach( function ( c ) {
					c.classList.add( 'is-on' );
				} );
			} );
			if ( fun ) {
				chars.forEach( function ( c ) {
					c.classList.add( 'is-shown' );
				} );
				fun.classList.remove( 'is-typing', 'is-blank' );
			}
			busy = false;
		}

		function startWake() {
			var later = function ( wait ) {
				window.requestAnimationFrame( function () {
					window.requestAnimationFrame( function () {
						if ( ! main.classList.contains( 'is-away' ) ) {
							run( wait );
						}
					} );
				} );
			};
			if ( card.fszPwr ) {
				var went = false, go = function () {
					if ( ! went ) {
						went = true;
						later( 150 );
					}
				};
				card.addEventListener( 'fsz-pwr-done', go, { once: true } );
				window.setTimeout( go, 3000 ); // 1.70.0: never wait for ever
			} else {
				later( 600 );
			}
		}
		// Plays once, when at least half of the card is on screen.
		prepare();
		if ( 'IntersectionObserver' in window ) {
			var io = new window.IntersectionObserver( function ( entries ) {
				for ( var i = 0; i < entries.length; i++ ) {
					if ( entries[ i ].isIntersecting && ! card.fszWoke ) {
						card.fszWoke = true;
						io.disconnect();
						// 1.61.0: two frames later, out of the busy first paint (a slow phone draws the page first).
						// 1.68.0: while the screen is powering on (codex.php fsz_sleep_script) it waits for the end of that.
						startWake();
					}
				}
			}, { threshold: 0.5 } );
			io.observe( card );
		} else {
			card.fszWoke = true;
			startWake();
		}
		// The detail page: the finished card behind it; back on the main page the sequence plays again.
		var away = main.classList.contains( 'is-away' );
		new window.MutationObserver( function () {
			var now = main.classList.contains( 'is-away' );
			if ( now === away ) {
				return;
			}
			away = now;
			if ( now ) {
				finish();
				return;
			}
			if ( ! card.fszWoke ) {
				return; // not played yet: it plays when it comes into view
			}
			prepare();
			( function ready() {
				if ( screen.classList.contains( 'is-crt' ) ) {
					timers.push( window.setTimeout( ready, 50 ) );
					return;
				}
				run( 300 );
			} )();
		} ).observe( main, { attributes: true, attributeFilter: [ 'class' ] } );

		// Taps (and clicks).
		traits.forEach( function ( t ) {
			t.addEventListener( 'click', function () {
				if ( ! busy ) {
					playBadge( t );
				}
			} );
		} );
		bars.forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				var ic = b.querySelector( '.fsz-bar-ic' );
				if ( busy || b.fszBusy ) {
					return;
				}
				b.fszBusy = true;
				if ( ic ) {
					replay( ic, 'is-hop' );
				}
				var end = lastCell( b, 0 ) + 350;
				fill( b, 0, end );
				window.setTimeout( function () {
					b.fszBusy = false;
					if ( ic ) {
						ic.classList.remove( 'is-hop' );
					}
				}, Math.max( 650, end + 950 ) );
			} );
		} );
		if ( diff ) {
			diff.addEventListener( 'click', function () {
				if ( ! busy && ! gaugeBusy ) {
					gauge( function () {} );
				}
			} );
		}
	}

	// ==========================================================================
	//  Phone: the Leírás page and tilting by moving the phone
	// ==========================================================================

	// One white flash over the card's screen (the theme calls it after "Add to cart").
	function flash( card ) {
		var screen = card && card.querySelector( '.fsz-screen' );
		if ( ! screen || reduce ) {
			return;
		}
		var f = screen.querySelector( ':scope > .fsz-flash' );
		if ( ! f ) {
			f = document.createElement( 'span' );
			f.className = 'fsz-flash';
			f.setAttribute( 'aria-hidden', 'true' );
			screen.appendChild( f );
		}
		replay( f, 'is-on' );
	}

	// 1.55.0: the detail page on a phone. The badge's meaning and the line move into the scrolling text (one badge,
	// codex.css), so all of it scrolls together; a mouse can drag the text too (touch scrolls natively), with a little
	// momentum; no text selection. The fade at the bottom goes when the end is reached. Back to the normal layout when
	// the screen gets wider.
	var PHONE = window.matchMedia ? window.matchMedia( '(max-width: 767px)' ) : null;

	function phoneMore( card ) {
		var more = card.querySelector( '.fsz-page-more' );
		var body = more && more.querySelector( '.fsz-more-body' );
		if ( ! body || card.classList.contains( 'is-editing' ) || body.fszPhone ) {
			return;
		}
		body.fszPhone = true;
		var whys = more.querySelector( '.fsz-whys' ), rule = more.querySelector( '.fsz-rule' );
		var home = whys ? whys.nextSibling : null;
		function place() {
			var on = PHONE && PHONE.matches;
			if ( on && rule && rule.parentNode !== body ) {
				body.insertBefore( rule, body.firstChild );
			}
			if ( on && whys && whys.parentNode !== body ) {
				body.insertBefore( whys, body.firstChild );
			}
			if ( ! on ) {
				if ( whys && whys.parentNode === body ) {
					more.insertBefore( whys, body );
				}
				if ( rule && rule.parentNode === body ) {
					more.insertBefore( rule, body );
				}
			}
			end();
		}
		function end() {
			body.classList.toggle( 'is-end', body.scrollTop + body.clientHeight >= body.scrollHeight - 4 );
		}
		body.addEventListener( 'scroll', end, { passive: true } );
		if ( PHONE ) {
			if ( PHONE.addEventListener ) {
				PHONE.addEventListener( 'change', place );
			} else if ( PHONE.addListener ) {
				PHONE.addListener( place );
			}
		}
		place();
		var y0 = null, last = 0, t0 = 0, v = 0, raf = 0;
		body.addEventListener( 'pointerdown', function ( e ) {
			if ( 'touch' === e.pointerType || ! PHONE || ! PHONE.matches || e.button > 0 || e.target.closest( 'a,button,[contenteditable]' ) ) {
				return;
			}
			window.cancelAnimationFrame( raf );
			y0 = last = e.clientY;
			t0 = window.performance.now();
			v = 0;
			body.setPointerCapture( e.pointerId );
			e.preventDefault();
		} );
		body.addEventListener( 'pointermove', function ( e ) {
			if ( null === y0 ) {
				return;
			}
			var dy = e.clientY - last, now = window.performance.now();
			if ( Math.abs( e.clientY - y0 ) > 3 ) {
				body.classList.add( 'is-drag' );
			}
			body.scrollTop -= dy;
			v = dy / Math.max( 1, now - t0 );
			t0 = now;
			last = e.clientY;
		} );
		function release() {
			if ( null === y0 ) {
				return;
			}
			y0 = null;
			body.classList.remove( 'is-drag' );
			var vel = reduce ? 0 : -v * 16;
			( function step() {
				if ( Math.abs( vel ) < 0.3 ) {
					return;
				}
				body.scrollTop += vel;
				vel *= 0.94;
				raf = window.requestAnimationFrame( step );
			} )();
		}
		body.addEventListener( 'pointerup', release );
		body.addEventListener( 'pointercancel', release );
		more.addEventListener( 'selectstart', function ( e ) {
			if ( PHONE && PHONE.matches && ! e.target.closest( '[contenteditable]' ) ) {
				e.preventDefault();
			}
		} );
		more.fszEnd = end;
	}

	// 1.55.0 gyro tilt: on Android (Chromium) the card follows how the phone is turned, like the mouse on a computer.
	// Zero = how the phone is held when it starts; smoothed; about 8 degrees at most. Not on iPhone yet (it needs a tap
	// and a permission pop-up: skipped wherever DeviceOrientationEvent.requestPermission exists), not over plain http,
	// not for visitors who turned off animations.
	function bindGyro( el ) {
		var max = Math.min( 8, ( parseFloat( el.getAttribute( 'data-tilt' ) ) || 0 ) * 0.65 );
		var D = window.DeviceOrientationEvent;
		if ( ! ( max > 0 ) || reduce || ! D || 'function' === typeof D.requestPermission || ! window.isSecureContext ) {
			return;
		}
		var zero = null, gx = 0, gy = 0, tx = 0, ty = 0, raf = 0, live = false, ang = restAngle( el );
		function frame() {
			raf = 0;
			gx += ( tx - gx ) * 0.12;
			gy += ( ty - gy ) * 0.12;
			turnTo( el, -gy, gx, ang ); // 1.69.0: no glass sheen on phones (codex.css), so it is not moved here
			setEdge( el, -gy - ang.lean, gx + ang.turn, max );
			if ( Math.abs( tx - gx ) > 0.02 || Math.abs( ty - gy ) > 0.02 ) {
				raf = window.requestAnimationFrame( frame );
			}
		}
		window.addEventListener( 'deviceorientation', function ( e ) {
			if ( null === e.beta || null === e.gamma || document.hidden ) {
				return;
			}
			if ( ! zero ) {
				zero = { b: e.beta, g: e.gamma };
			}
			if ( ! live ) {
				live = true;
				el.classList.add( 'is-gyro' ); // the levitation keeps going (codex.css), the tilt adds to it
			}
			var clamp = function ( v ) {
				return Math.max( -max, Math.min( max, v ) );
			};
			tx = clamp( ( e.gamma - zero.g ) * 0.5 );
			ty = clamp( ( e.beta - zero.b ) * 0.5 );
			if ( ! raf ) {
				raf = window.requestAnimationFrame( frame );
			}
		} );
		document.addEventListener( 'visibilitychange', function () {
			zero = null; // back on the page: the new way of holding the phone is the zero
		} );
	}

	// ==========================================================================
	//  Fun fact fitting
	// ==========================================================================

	// One card: detail page, photos, depth and (with a mouse) the tilt. Also used by the settings page preview.
	// 1.56.0 power-bar plate: the soft tinted panel behind the − + row and the bars, with the three stamped-in
	// separation lines between the rows, baked once into a PNG and laid in the screen's background tier (z -1 under
	// the content). Geometry comes from layout offsets, never getBoundingClientRect (the tilt would distort it and the
	// plate would shimmer). It is baked again only when the size or the card colours change.
	// 1.56.0: the fun fact never clips. It starts at its CSS size (15u) and steps down only when the text needs it
	// (small phone cards, long words), so a full 35-character fact always shows in its two lines.
	function fitFun( card ) {
		var t = card.querySelector( '.fsz-fun-text' ), steps = [ 14.5, 14, 13.5, 13, 12.5, 12 ];
		if ( ! t || ! t.offsetWidth ) {
			return;
		}
		t.style.fontSize = '';
		for ( var i = 0; i < steps.length && t.scrollHeight > t.clientHeight + 1; i++ ) {
			t.style.fontSize = 'calc(' + steps[ i ] + '*var(--fsz-u))';
		}
	}
	function fitFuns() {
		var all = document.querySelectorAll( '.fsz-device' );
		for ( var i = 0; i < all.length; i++ ) {
			fitFun( all[ i ] );
		}
	}

	var plateCv, plateCx;

	// ==========================================================================
	//  The number plate
	// ==========================================================================

	function piece( v, P ) {
		if ( v <= P[ 0 ][ 0 ] ) {
			return P[ 0 ][ 1 ];
		}
		for ( var i = 1; i < P.length; i++ ) {
			if ( v <= P[ i ][ 0 ] ) {
				var a = P[ i - 1 ], b = P[ i ];
				return a[ 1 ] + ( b[ 1 ] - a[ 1 ] ) * ( v - a[ 0 ] ) / ( b[ 0 ] - a[ 0 ] );
			}
		}
		return P[ P.length - 1 ][ 1 ];
	}
	function plateNum( s, d ) {
		var n = parseFloat( s );
		return isNaN( n ) ? d : Math.max( 0, Math.min( 1, n ) );
	}
	function plateRgb( c ) {
		plateCx.clearRect( 0, 0, 1, 1 );
		plateCx.fillStyle = '#000';
		plateCx.fillStyle = c;
		plateCx.fillRect( 0, 0, 1, 1 );
		var d = plateCx.getImageData( 0, 0, 1, 1 ).data;
		return [ d[ 0 ], d[ 1 ], d[ 2 ] ];
	}
	function plateBake( W, H, u, v, tint, ink ) {
		var S = Math.min( 3, Math.max( 1, Math.ceil( window.devicePixelRatio || 1 ) ) );
		plateCv.width = Math.max( 1, Math.round( W * S ) );
		plateCv.height = Math.max( 1, Math.round( H * S ) );
		var w = plateCv.width, h = plateCv.height, im = plateCx.createImageData( w, h ), D = im.data;
		var lh = v.lh, sy = v.sy, x0 = v.x0, R = 8 * u * S;
		var ln = v.ln.map( function ( n ) {
			return Math.round( n * S );
		} );
		function over( i, r, g, b, a ) {
			var da = D[ i + 3 ] / 255, oa = a + da * ( 1 - a );
			if ( oa <= 0 ) {
				return;
			}
			D[ i ] = ( r * a + D[ i ] * da * ( 1 - a ) ) / oa;
			D[ i + 1 ] = ( g * a + D[ i + 1 ] * da * ( 1 - a ) ) / oa;
			D[ i + 2 ] = ( b * a + D[ i + 2 ] * da * ( 1 - a ) ) / oa;
			D[ i + 3 ] = oa * 255 + Math.random() - 0.5; // a little dither, no banding in the fades
		}
		// Fades: L1 down from under the − + row, L2 in from the left, L3 down from the top of the − + bubbles.
		var L1 = [ [ lh + 7 * u, 0 ], [ lh + 20 * u, 0.35 ], [ lh + 34 * u, 0.75 ], [ lh + 49 * u, 1 ] ];
		var L2 = [ [ x0 - 44.6 * u, 0 ], [ x0 + 6 * u, 0.25 ], [ x0 + 53.6 * u, 0.7 ], [ x0 + 104 * u, 1 ] ];
		var L3 = [ [ sy - 8 * u, 0 ], [ sy + 2 * u, 0.18 ], [ sy + 16 * u, 0.55 ], [ sy + 30 * u, 0.88 ], [ sy + 40 * u, 1 ] ];
		function mask( px, py ) {
			var x = ( px + 0.5 ) / S, y = ( py + 0.5 ) / S, m1 = piece( y, L1 ), m2 = piece( x, L2 ), m3 = piece( y, L3 );
			return m1 + m2 * m3 - m1 * m2 * m3;
		}
		var px, py, m, i, k, r;
		for ( py = 0; py < h; py++ ) {
			for ( px = 0; px < w; px++ ) {
				m = mask( px, py );
				if ( m <= 0 ) {
					continue;
				}
				var cx0 = Math.min( px, w - 1 - px ), cy0 = Math.min( py, h - 1 - py );
				if ( cx0 < R && cy0 < R ) {
					var dx = R - cx0, dy = R - cy0;
					if ( dx * dx + dy * dy > R * R ) {
						continue;
					}
				}
				over( ( py * w + px ) * 4, tint[ 0 ], tint[ 1 ], tint[ 2 ], v.a * m );
			}
		}
		// Separation lines: S device pixels of ink, then S of white (stamped in), at least 2 CSS px in all.
		for ( k = 0; k < ln.length; k++ ) {
			for ( r = 0; r < 2 * S; r++ ) {
				py = ln[ k ] + r;
				if ( py < 0 || py >= h ) {
					continue;
				}
				for ( px = 0; px < w; px++ ) {
					m = mask( px, py );
					if ( m <= 0 ) {
						continue;
					}
					i = ( py * w + px ) * 4;
					if ( r < S ) {
						over( i, ink[ 0 ], ink[ 1 ], ink[ 2 ], v.la * m );
					} else {
						over( i, v.hiRgb[ 0 ], v.hiRgb[ 1 ], v.hiRgb[ 2 ], v.ha * m );
					}
				}
			}
		}
		plateCx.putImageData( im, 0, 0 );
		return plateCv.toDataURL( 'image/png' );
	}
	function offsetTo( el, stop ) {
		var x = 0, y = 0;
		while ( el && el !== stop ) {
			x += el.offsetLeft;
			y += el.offsetTop;
			el = el.offsetParent;
		}
		return { x: x, y: y, hit: el === stop };
	}
	function plateSync( card ) {
		var pm = card.querySelector( '.fsz-page-main' ), bars = pm && pm.querySelector( '.fsz-bars' );
		if ( ! bars ) {
			return;
		}
		var pl = card.fszPlate;
		if ( ! pl || ! pl.isConnected ) {
			pl = card.fszPlate = document.createElement( 'div' );
			pl.className = 'fsz-plate';
			pl.setAttribute( 'aria-hidden', 'true' );
			pm.appendChild( pl );
		}
		var lg = bars.querySelector( '.fsz-legend' ), scl = bars.querySelector( '.fsz-legend-scale' );
		var cells = Array.prototype.slice.call( bars.querySelectorAll( '.fsz-bar:not(.fsz-legend) .fsz-cells' ) );
		var W = bars.offsetWidth;
		if ( ! lg || ! scl || cells.length < 2 || ! W ) {
			return; // hidden (Leírás page on) or not laid out yet
		}
		var cs = window.getComputedStyle( card ), u = parseFloat( cs.getPropertyValue( '--fsz-u' ) ) || 1;
		var base = pl.offsetParent, a = offsetTo( bars, null ), b = offsetTo( base, null );
		var x = a.x - b.x - ( base ? base.clientLeft : 0 ), y = a.y - b.y - ( base ? base.clientTop : 0 );
		function rel( el ) {
			var o = offsetTo( el, bars );
			return { x: o.x, y: o.y, h: el.offsetHeight };
		}
		var rl = rel( lg ), rs = rel( scl ), rc = cells.map( rel ), ln = [];
		for ( var i = 0; i < 3 && i < rc.length - 1; i++ ) {
			ln.push( ( rc[ i ].y + rc[ i ].h + rc[ i + 1 ].y ) / 2 - 1 + 8 * u ); // centred between the pill rows
		}
		var v = { lh: rl.y + rl.h + 6 * u, sy: rs.y + 6 * u, x0: rs.x - 2 * u, ln: ln };
		var H = bars.offsetHeight + 10 * u;
		var dk = cs.getPropertyValue( '--fsz-device-dark' ).trim(), ik = cs.getPropertyValue( '--fsz-ink' ).trim();
		// 1.62.0 skins (codex.css top): own plate colours and strengths; unset = the card colours and today's strengths.
		var sk = [ '--fsz-plate-tint', '--fsz-plate-line', '--fsz-plate-hi', '--fsz-plate-a', '--fsz-plate-la', '--fsz-plate-ha' ].map( function ( n ) {
			return cs.getPropertyValue( n ).trim();
		} );
		dk = sk[ 0 ] || dk;
		ik = sk[ 1 ] || ik;
		v.hi = sk[ 2 ] || '#fff';
		v.a = plateNum( sk[ 3 ], 0.19 );
		v.la = plateNum( sk[ 4 ], 0.17 );
		v.ha = plateNum( sk[ 5 ], 0.5 );
		var key = [ x, y, W, H, u, dk, ik, v.lh, v.sy, v.x0, ln.join( ',' ), window.devicePixelRatio, sk.join( ',' ) ].join( '|' );
		if ( key === card.fszPlateKey ) {
			return;
		}
		card.fszPlateKey = key;
		pl.style.left = x + 'px';
		pl.style.top = ( y - 8 * u ) + 'px';
		pl.style.width = W + 'px';
		pl.style.height = H + 'px';
		if ( ! plateCv ) {
			plateCv = document.createElement( 'canvas' );
			plateCx = plateCv.getContext( '2d', { willReadFrequently: true } );
		}
		try {
			v.hiRgb = plateRgb( v.hi );
			pl.style.backgroundImage = 'url(' + plateBake( W, H, u, v, plateRgb( dk || '#14605F' ), plateRgb( ik || '#1E3B3B' ) ) + ')';
		} catch ( err ) {
			pl.style.backgroundImage = 'none';
		}
	}
	function plate( card ) {
		var wait = 0;
		function later() {
			window.cancelAnimationFrame( wait );
			wait = window.requestAnimationFrame( function () {
				plateSync( card );
			} );
		}
		later();
		if ( window.ResizeObserver ) {
			var ro = new window.ResizeObserver( later ), bars = card.querySelector( '.fsz-page-main .fsz-bars' );
			ro.observe( card );
			if ( bars ) {
				ro.observe( bars );
			}
		}
		window.addEventListener( 'resize', later );
		window.addEventListener( 'load', later );
		if ( document.fonts && document.fonts.ready ) {
			document.fonts.ready.then( later );
		}
		// The Leírás page turning back shows the bars again. 1.57.0: not the tilt's own transitions (the card and its 24
		// slices end one on every mouse move; each one re-measured the plate).
		card.addEventListener( 'transitionend', function ( e ) {
			if ( e.target === card || ( e.target.classList && e.target.classList.contains( 'fsz-slice' ) ) ) {
				return;
			}
			// 1.65.0: nor the photo fades and the photo dots (every few seconds; each one measured the card again).
			if ( e.target.closest && e.target.closest( '.fsz-slides,.fsz-strip-dots' ) ) {
				return;
			}
			later();
		} );
		if ( card.classList.contains( 'is-editing' ) ) {
			window.setInterval( later, 700 ); // the editor changes colours and rows live
		}
	}

	// ==========================================================================
	//  Setting up one card, floating, start
	// ==========================================================================

	// 1.57.0: a card out of sight pauses its endless moves (codex.css .is-offscreen).
	function offscreen( el ) {
		if ( ! ( 'IntersectionObserver' in window ) ) {
			return;
		}
		new window.IntersectionObserver( function ( entries ) {
			el.classList.toggle( 'is-offscreen', ! entries[ entries.length - 1 ].isIntersecting );
		}, { rootMargin: '40px' } ).observe( el );
	}

	function setup( el ) {
		var tilt = window.matchMedia && window.matchMedia( '(hover: hover) and (pointer: fine)' ).matches && ! reduce;
		// The wake-up plays on the product page card only (shoppers; the many cards of a list stay calm).
		// 2.3.0: a card swapped in by the card swipe (swipe.js, data-fsz-calm) arrives already switched on: no wake-up.
		var wakes = el.closest && el.closest( '.fsz-at-gallery' ) && ! el.classList.contains( 'is-editing' ) && ! el.hasAttribute( 'data-fsz-calm' );
		if ( wakes && ! reduce ) {
			el.fszWake = true; // bindSlides leaves the first photo change to wake()
		}
		bindScreens( el );
		bindSlides( el );
		offscreen( el );
		if ( addDepth( el ) ) {
			rest( el );
			if ( tilt ) {
				bindTilt( el );
			} else if ( el.closest && el.closest( '.fsz-at-gallery' ) && ! el.classList.contains( 'is-editing' ) ) {
				bindGyro( el );
			}
		}
		phoneMore( el );
		fitNames( el );
		plate( el );
		fitFun( el );
		if ( el.classList.contains( 'is-editing' ) ) {
			el.addEventListener( 'input', function () {
				fitFun( el );
			} );
		}
		if ( wakes ) {
			wake( el );
		} else {
			el.classList.remove( 'is-asleep' );
		}
	}
	/* 2.3.0: the card swipe's incoming card (swipe.js) is a still picture of the next species' card while it slides in:
	   dressed once like a live card (names fitted, depth and resting turn, fun fact, power-bar plate), with no listeners,
	   timers or animations of its own, so it can be thrown away after the swap. */
	function still( el ) {
		fitNames( el );
		if ( addDepth( el ) ) {
			rest( el );
		}
		fitFun( el );
		window.requestAnimationFrame( function () {
			if ( el.isConnected ) {
				plateSync( el );
			}
		} );
	}
	window.Codex = { fitName: fitName, fitMark: fitMark, bindScreens: bindScreens, setup: setup, addDepth: addDepth, rest: rest, fit: fit, flash: flash, plate: plateSync, fitFun: fitFun, still: still };

	// The product page card fits the screen (fsz_fit_script in codex.php) again when the window or the fonts change.
	function fit() {
		if ( window.fszFit ) {
			window.fszFit();
		}
		floatSync();
	}

	/* 1.59.0: the float runs on the graphics chip. The stylesheet's float keyframes use var(), which Safari animates on the
	   main thread: the card is drawn again every frame and its SVG icons and photos snap to whole pixels while the text
	   glides (the badge and power-bar icons "flicker"). Here each card gets the same path with plain numbers (strength x
	   card unit, worked out again when the unit changes), which Safari moves as one finished picture. Same look. */
	var floatSheet = null, floatDone = {};
	function floatKeys( s, u ) {
		var k = 'fszF' + String( Math.round( s * u * 1000 ) ), d = '', i, t, r = function ( v ) {
			return ( Math.round( v * 1000 ) / 1000 ) + 'px';
		};
		if ( floatDone[ k ] ) {
			return k;
		}
		for ( i = 0; i <= 40; i++ ) {
			t = i / 40; // the stylesheet's path: the sideways drift turns twice, the up-down drift three times
			d += ( i * 2.5 ) + '%{translate:' + r( -0.35 * Math.cos( 4 * Math.PI * t ) * s * u ) + ' ' + r( 0.45 * Math.cos( 6 * Math.PI * t ) * s * u ) + '}';
		}
		if ( ! floatSheet ) {
			floatSheet = document.createElement( 'style' );
			floatSheet.id = 'fsz-float-keys';
			document.head.appendChild( floatSheet );
		}
		floatSheet.appendChild( document.createTextNode( '@keyframes ' + k + 'd{' + d + '}@keyframes ' + k + 's{from{rotate:1 -1 0 ' + ( -0.06 * s ) + 'deg}to{rotate:1 1 0 ' + ( 0.06 * s ) + 'deg}}' ) );
		floatDone[ k ] = 1;
		return k;
	}
	function floatSync() {
		if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
			return;
		}
		var els = document.querySelectorAll( '.fsz-device' );
		for ( var i = 0; i < els.length; i++ ) {
			var el = els[ i ], s = el.closest && el.closest( '.fsz-incoming' ) ? 0 : parseFloat( window.getComputedStyle( el ).getPropertyValue( '--fsz-float' ) ) || 0; // 2.5.0: not the card swipe's waiting cards
			if ( ! s ) {
				continue;
			}
			var p = document.createElement( 'div' ); // the card unit in px (it can be set in rem)
			p.style.cssText = 'position:absolute;visibility:hidden;pointer-events:none;height:0;width:calc(var(--fsz-u) * 1000)';
			el.appendChild( p );
			var u = p.offsetWidth / 1000 || 1;
			el.removeChild( p );
			var k = floatKeys( s, u ), n = k + 'd, ' + k + 's';
			if ( el.fszFloat !== n ) {
				el.fszFloat = n;
				el.style.animationName = n;
			}
		}
	}

	/* 1.65.0: the Leírás / Vissza press and arrow nudge (codex.css .is-poke) once every 10 s, first at 7.8 s, the same
	   beat as the old 10 s loops. One timer for every card on the page. */
	function poke() {
		var els = Array.prototype.filter.call( document.querySelectorAll( '.fsz-device' ), function ( el ) {
			return ! ( el.closest && el.closest( '.fsz-incoming' ) ); // 2.5.0: not the card swipe's waiting cards
		} ), i;
		for ( i = 0; i < els.length; i++ ) {
			els[ i ].classList.add( 'is-poke' );
		}
		window.setTimeout( function () {
			for ( i = 0; i < els.length; i++ ) {
				els[ i ].classList.remove( 'is-poke' );
			}
		}, 2400 );
	}

	function init() {
		if ( ! reduce ) {
			window.setTimeout( function () {
				poke();
				window.setInterval( poke, 10000 );
			}, 7800 );
		}
		floatSync();
		document.addEventListener( 'fsz:fit', floatSync );
		fitNames();
		if ( document.fonts && document.fonts.ready ) {
			document.fonts.ready.then( function () {
				fitNames();
				fit();
				fitFuns();
			} );
		}
		var wait;
		window.addEventListener( 'resize', function () {
			window.cancelAnimationFrame( wait );
			wait = window.requestAnimationFrame( function () {
				fit();
				fitNames();
				fitFuns();
			} );
		} );
		window.addEventListener( 'load', fit );
		// Depth everywhere; the tilt with a mouse only (touch screens and visitors who turned off animations keep the resting turn).
		var els = document.querySelectorAll( '.fsz-device[data-tilt]' );
		for ( var i = 0; i < els.length; i++ ) {
			setup( els[ i ] );
		}
	}
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
})();
