// ==========================================================================
//  FILE: assets/swipe.js   (Codex plugin)
//  WHAT: Card swipe on species pages: a clear sideways flick of the card (finger or mouse) goes to the next species
//        (left) or the previous one (right), the edge arrows go there too, and once the page is idle the two
//        neighbours are fetched ahead (phones: the page and its first photo only; PC Chrome: both pages prepared).
//        The neighbours, the arrows and the slide between pages: inc/card-swipe.php; the look: codex.css section 7.
//  SEEN: Product pages of species (only where a Codex card shows).
//  SECTIONS IN THIS FILE:
//    1. Going to a neighbour
//    2. The swipe (finger or mouse)
//    3. Where the arrows sit
//    4. Fetching the neighbours ahead
//    5. Start
// ==========================================================================
( function () {
	'use strict';
	var nav = document.querySelector( '.fsz-swipe' ), wrap = document.querySelector( '.fsz-wrap.fsz-at-gallery' );
	if ( ! nav || ! wrap || ! window.matchMedia ) {
		return;
	}
	var html = document.documentElement, data = {};
	try {
		data = JSON.parse( nav.getAttribute( 'data-fsz-swipe' ) || '{}' ) || {};
	} catch ( e ) {}
	var links = { prev: nav.querySelector( '.fsz-nb-prev' ), next: nav.querySelector( '.fsz-nb-next' ) };
	var reduce = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	// Cross-page slide (Chrome/Edge 126+, Safari 18.2+): the browser slides the card on from where it is let go.
	var slides = 'onpagereveal' in window;
	var going = false;

	// ==========================================================================
	//  1. Going to a neighbour
	// ==========================================================================

	// The mark the next page reads (inc/card-swipe.php, in its head): where we went, which way, when.
	function mark( dir ) {
		try {
			window.sessionStorage.setItem( 'fsz-swipe', JSON.stringify( { u: links[ dir ].href.split( '#' )[ 0 ], d: dir, t: Date.now() } ) );
		} catch ( e ) {}
		html.setAttribute( 'data-fsz-swipe', dir );
	}

	// After a swipe: the card keeps moving the way it was thrown while the next page comes. Where the browser slides
	// between pages it goes only part of the way (the slide carries on from there); elsewhere it leaves the screen.
	function go( dir, dx ) {
		if ( going || ! links[ dir ] ) {
			return;
		}
		going = true;
		mark( dir );
		var w = window.innerWidth, to = ( 'next' === dir ? -1 : 1 ) * ( slides ? Math.max( Math.abs( dx ), w * 0.22 ) : w * 0.8 );
		wrap.style.transition = reduce ? 'opacity .15s' : 'translate .26s cubic-bezier(.25,.6,.4,1),opacity .26s';
		if ( ! reduce ) {
			wrap.style.translate = Math.round( to ) + 'px 0';
		}
		wrap.style.opacity = slides ? '.45' : '0';
		window.location.href = links[ dir ].href;
	}

	// The arrows are plain links: a click only leaves the mark (a new tab or window stays a normal link).
	[ 'prev', 'next' ].forEach( function ( dir ) {
		var a = links[ dir ];
		if ( ! a ) {
			return;
		}
		a.addEventListener( 'click', function ( e ) {
			if ( e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey ) {
				return;
			}
			if ( going ) {
				e.preventDefault();
				return;
			}
			going = true;
			mark( dir );
		} );
	} );

	// ==========================================================================
	//  2. The swipe (finger or mouse)
	// ==========================================================================

	/* Only a clear sideways flick: the first 10 px decide. Mostly up or down = not a swipe (the page scrolls, the phone
	   drawer opens). Left alone: the photo when the card has several (a swipe there changes the photo), fields being
	   typed in, a card being edited, and the Leírás text under a mouse (the mouse drags it up and down). The card tilt
	   keeps working: the mouse tilt follows the pointer as before, the phone tilt follows the phone. Only translate and
	   opacity change while the card moves. */
	var g = null, raf = 0, W = 300, block = false;
	function skip( t, type ) {
		return ! t.closest || !! ( wrap.querySelector( '.fsz-device.is-editing' ) || t.closest( 'input,textarea,select,[contenteditable],.fsz-photo[role=button]' ) || ( 'mouse' === type && t.closest( '.fsz-more-body' ) ) );
	}
	function paint() {
		raf = 0;
		if ( ! g || ! g.on ) {
			return;
		}
		wrap.style.translate = Math.round( g.dx ) + 'px 0';
		wrap.style.opacity = String( Math.round( ( 1 - Math.min( 0.45, Math.abs( g.dx ) / W * 0.5 ) ) * 100 ) / 100 );
	}
	function move( e ) {
		if ( ! g || e.pointerId !== g.id ) {
			return;
		}
		if ( 'mouse' === g.type && ! ( e.buttons & 1 ) ) {
			g = null; // the button came up outside the card
			return;
		}
		var dx = e.clientX - g.x, dy = e.clientY - g.y;
		if ( ! g.on ) {
			if ( Math.abs( dx ) < 10 && Math.abs( dy ) < 10 ) {
				return;
			}
			if ( Math.abs( dx ) < Math.abs( dy ) * 1.5 ) {
				g = null; // up or down: not a swipe
				return;
			}
			g.on = true;
			W = wrap.getBoundingClientRect().width || 300;
			html.classList.add( 'fsz-dragging' );
			wrap.style.transition = 'none';
			if ( 'mouse' === g.type ) {
				try {
					wrap.setPointerCapture( g.id );
				} catch ( err ) {}
				var sel = window.getSelection && window.getSelection();
				if ( sel && sel.removeAllRanges ) {
					sel.removeAllRanges();
				}
			}
		}
		g.dx = dx;
		g.hist.push( [ e.timeStamp, e.clientX ] );
		if ( g.hist.length > 5 ) {
			g.hist.shift();
		}
		if ( ! raf ) {
			raf = window.requestAnimationFrame( paint );
		}
	}
	function end( e ) {
		if ( ! g || e.pointerId !== g.id ) {
			return;
		}
		var was = g;
		g = null;
		if ( ! was.on ) {
			return;
		}
		html.classList.remove( 'fsz-dragging' );
		if ( raf ) {
			window.cancelAnimationFrame( raf );
			raf = 0;
		}
		var h = was.hist, v = 0, dx = was.dx;
		if ( h.length > 1 ) {
			v = ( h[ h.length - 1 ][ 1 ] - h[ 0 ][ 1 ] ) / Math.max( 1, h[ h.length - 1 ][ 0 ] - h[ 0 ][ 0 ] ); // px per ms, the last moves
		}
		if ( 'pointercancel' !== e.type ) {
			block = true; // the click a mouse sends after the drag (on Leírás, a badge …) is not a click
			window.setTimeout( function () {
				block = false;
			}, 350 );
			if ( Math.abs( dx ) > Math.min( 110, W * 0.3 ) || ( Math.abs( dx ) > 36 && Math.abs( v ) > 0.45 && ( v < 0 ) === ( dx < 0 ) ) ) {
				go( dx < 0 ? 'next' : 'prev', dx );
				return;
			}
		}
		// Not far or fast enough: back to its place.
		wrap.style.transition = 'translate .3s cubic-bezier(.2,.8,.3,1),opacity .3s';
		wrap.style.translate = '';
		wrap.style.opacity = '';
		window.setTimeout( function () {
			if ( ! g && ! going ) {
				wrap.style.transition = '';
			}
		}, 340 );
	}
	wrap.addEventListener( 'pointerdown', function ( e ) {
		if ( going || ( g && g.on ) || ! e.isPrimary || e.button > 0 || skip( e.target, e.pointerType ) ) {
			return;
		}
		g = { id: e.pointerId, type: e.pointerType, x: e.clientX, y: e.clientY, dx: 0, on: false, hist: [ [ e.timeStamp, e.clientX ] ] };
	}, { passive: true } );
	wrap.addEventListener( 'pointermove', move, { passive: true } );
	wrap.addEventListener( 'pointerup', end );
	wrap.addEventListener( 'pointercancel', end );
	wrap.addEventListener( 'click', function ( e ) {
		if ( block ) {
			e.preventDefault();
			e.stopPropagation();
		}
	}, true );
	wrap.addEventListener( 'dragstart', function ( e ) {
		if ( g ) {
			e.preventDefault(); // a mouse drag moves the card, not a copy of its photo
		}
	} );
	// A finger moving sideways on the card is ours; up and down stay the browser's (scrolling, the phone drawer).
	wrap.style.touchAction = 'pan-y';

	// Back to this page with the back button (the browser kept it in memory): the card is back in its place.
	window.addEventListener( 'pageshow', function ( e ) {
		if ( e.persisted ) {
			going = false;
			g = null;
			wrap.style.transition = '';
			wrap.style.translate = '';
			wrap.style.opacity = '';
			html.removeAttribute( 'data-fsz-swipe' );
			html.classList.remove( 'fsz-dragging' );
		}
	} );

	// ==========================================================================
	//  3. Where the arrows sit
	// ==========================================================================

	// Phone (the card stays still on the screen): at the card's mid-height, so the arrows are never under the buy
	// drawer. Elsewhere at the window's mid-height, faded out while the card is mostly scrolled away.
	function place() {
		if ( 'fixed' !== window.getComputedStyle( wrap ).position ) {
			nav.style.removeProperty( '--fsz-swipe-y' );
			return;
		}
		var d = wrap.querySelector( '.fsz-device' ), r = ( d || wrap ).getBoundingClientRect();
		if ( r.height ) {
			nav.style.setProperty( '--fsz-swipe-y', Math.round( r.top + r.height / 2 ) + 'px' );
		}
	}
	document.addEventListener( 'fsz:fit', place );
	window.addEventListener( 'resize', function () {
		window.requestAnimationFrame( place );
	} );
	if ( 'IntersectionObserver' in window ) {
		new window.IntersectionObserver( function ( en ) {
			nav.classList.toggle( 'is-away', en[ en.length - 1 ].intersectionRatio < 0.3 );
		}, { threshold: [ 0, 0.3 ] } ).observe( wrap );
	}

	// ==========================================================================
	//  4. Fetching the neighbours ahead
	// ==========================================================================

	/* One species each side, once the page is idle, never on Save-Data or a slow connection:
	   - phones (and other browsers): the next and previous page's HTML and their first photo are downloaded only, never
	     drawn (the photo exactly as the page will ask for it, so it comes from the cache);
	   - PC Chrome/Edge: both pages are prepared whole in the background (prerender), so a swipe shows them at once. */
	function slow() {
		var c = navigator.connection;
		return !! ( c && ( c.saveData || /(^|-)(2g|3g)$/.test( c.effectiveType || '' ) ) ) || window.matchMedia( '(prefers-reduced-data: reduce)' ).matches;
	}
	function rules( kind, urls ) {
		var s = document.createElement( 'script' );
		s.type = 'speculationrules';
		var r = {};
		r[ kind ] = [ { source: 'list', urls: urls, eagerness: 'immediate' } ];
		s.textContent = JSON.stringify( r );
		document.head.appendChild( s );
	}
	function ahead() {
		if ( slow() ) {
			return;
		}
		var urls = [], imgs = [];
		[ 'next', 'prev' ].forEach( function ( dir ) {
			var n = data[ dir ];
			if ( n && n.u && urls.indexOf( n.u ) < 0 && n.u.split( '#' )[ 0 ] !== window.location.href.split( '#' )[ 0 ] ) {
				urls.push( n.u );
				if ( n.img && n.img[ 0 ] ) {
					imgs.push( n.img );
				}
			}
		} );
		if ( ! urls.length ) {
			return;
		}
		var phone = window.matchMedia( '(max-width: 767px), (hover: none), (pointer: coarse)' ).matches;
		var spec = window.HTMLScriptElement && window.HTMLScriptElement.supports && window.HTMLScriptElement.supports( 'speculationrules' );
		if ( ! phone && spec ) {
			rules( 'prerender', urls );
			return;
		}
		if ( spec ) {
			rules( 'prefetch', urls );
		} else {
			urls.forEach( function ( u ) {
				var l = document.createElement( 'link' );
				l.rel = 'prefetch';
				l.href = u;
				document.head.appendChild( l );
			} );
		}
		imgs.forEach( function ( m ) {
			var im = new window.Image(); // never put on the page, so never drawn
			im.decoding = 'async';
			if ( m[ 2 ] ) {
				im.sizes = m[ 2 ];
			}
			if ( m[ 1 ] ) {
				im.srcset = m[ 1 ];
			}
			im.src = m[ 0 ];
		} );
	}
	function idle() {
		window.setTimeout( function () {
			( window.requestIdleCallback || function ( f ) {
				return window.setTimeout( f, 1 );
			} )( ahead, { timeout: 4000 } );
		}, 2000 );
	}

	// ==========================================================================
	//  5. Start
	// ==========================================================================

	function start() {
		place();
		if ( 'complete' === document.readyState ) {
			idle();
		} else {
			window.addEventListener( 'load', idle );
		}
		// The slide mark has done its job once the page is on screen (where the browser slides, codex.css uses it
		// during the slide only; card-swipe.php takes it off when the slide ends).
		window.setTimeout( function () {
			if ( ! going ) {
				html.removeAttribute( 'data-fsz-swipe' );
			}
		}, 1500 );
	}
	// A page the browser prepared in advance (PC Chrome) starts only when it is shown.
	if ( document.prerendering ) {
		document.addEventListener( 'prerenderingchange', start, { once: true } );
	} else {
		start();
	}
} )();
