// ==========================================================================
//  FILE: assets/swipe.js   (Codex plugin)
//  WHAT: Moving between species on their product pages without a page load (2.3.0). Phones and touch screens: a
//        sideways swipe anywhere on the page (also beside the card) brings the next species from the right or the
//        previous one from the left; the new card is already visible while the finger moves and comes forward from
//        behind ("Depth"). PC: no swipe; the small side cards (or the arrow keys) do the same move. The next and
//        previous pages are fetched in the background, then the page content is swapped in place and the address
//        bar follows (the back button works). Anything unusual: a normal page load instead.
//        The neighbours and the side cards: inc/card-swipe.php; the look: codex.css section 7.
//  SEEN: Product pages of species (only where a Codex card shows).
//  SECTIONS IN THIS FILE:
//    1. The page now: card, side cards, neighbours
//    2. Fetching the neighbours ahead
//    3. The incoming card (a still picture of the next card)
//    4. The move and the swap
//    5. The swipe (finger only)
//    6. Side cards, arrows, the back button
//    7. PC: first-visit hints on the side cards
//    8. Where the phone tabs sit
//    9. Start
// ==========================================================================
( function () {
	'use strict';
	var html = document.documentElement, body = document.body;
	if ( ! document.querySelector( '.fsz-swipe' ) || ! document.querySelector( '.fsz-wrap.fsz-at-gallery' ) || ! window.matchMedia ) {
		return;
	}
	var mm = function ( q ) {
		return window.matchMedia( q ).matches;
	};
	var reduce = mm( '(prefers-reduced-motion: reduce)' );
	var GAP = 24, DUR = 540, EASE = 'cubic-bezier(.45,.05,.25,1)'; // the "Depth" move (Dan's pick, 2026-11-14)

	// ==========================================================================
	//  1. The page now: card, side cards, neighbours
	// ==========================================================================

	var nav, wrap, data, links, going = false, step = 0;
	function bind() {
		nav = document.querySelector( '.fsz-swipe' );
		wrap = document.querySelector( '.fsz-wrap.fsz-at-gallery:not(.fsz-incoming)' );
		data = {};
		try {
			data = JSON.parse( ( nav && nav.getAttribute( 'data-fsz-swipe' ) ) || '{}' ) || {};
		} catch ( e ) {}
		links = { prev: nav && nav.querySelector( '.fsz-nb-prev' ), next: nav && nav.querySelector( '.fsz-nb-next' ) };
	}
	function url( dir ) {
		return links[ dir ] ? links[ dir ].href.split( '#' )[ 0 ] : '';
	}

	// The page can be swapped in place only with the shop theme's product page helper (Ízeltláb theme 3.4.0+) and
	// Codex's card helper, for shoppers: an editor's page (admin bar, edit tools) changes with a normal page load.
	function canSwap() {
		return !! ( window.fetch && window.DOMParser && window.history && window.history.pushState && window.Codex && window.Codex.setup && window.izlProductPage && ! body.classList.contains( 'admin-bar' ) && ! document.querySelector( '.fsz-device.is-editing' ) );
	}

	// A normal page load (the 2.2.0 way): the next page reads the mark and slides its card in where the browser can.
	function load( dir, u ) {
		try {
			window.sessionStorage.setItem( 'fsz-swipe', JSON.stringify( { u: u, d: dir, t: Date.now() } ) );
		} catch ( e ) {}
		html.setAttribute( 'data-fsz-swipe', dir );
		window.location.href = u;
	}

	// ==========================================================================
	//  2. Fetching the neighbours ahead
	// ==========================================================================

	/* Each neighbour's page is fetched once the page is idle (never on Save-Data or a slow connection: then only when
	   a swipe starts), read into a document that is not shown, and kept until the next move. Scripts and styles that
	   page needs and this one does not have yet (for example the pack choice of a species sold in packs) are loaded
	   then, so the swap itself waits for nothing. The neighbour's first photo is fetched too (as the page will ask for
	   it), so the incoming card shows its picture at once. */
	var docs = {};
	function slow() {
		var c = navigator.connection;
		return !! ( c && ( c.saveData || /(^|-)(2g|3g)$/.test( c.effectiveType || '' ) ) ) || mm( '(prefers-reduced-data: reduce)' );
	}
	function have( sel ) {
		try {
			return !! document.querySelector( sel );
		} catch ( e ) {
			return true;
		}
	}
	function runInline( s ) {
		var n = document.createElement( 'script' );
		n.text = s.text;
		body.appendChild( n );
		body.removeChild( n );
	}
	// What the new page has outside its content that this one lacks: stylesheets, script templates, script files
	// (each with its settings, in page order).
	function needs( d ) {
		d.querySelectorAll( 'link[rel=stylesheet][href]' ).forEach( function ( l ) {
			if ( ! have( 'link[rel=stylesheet][href="' + l.getAttribute( 'href' ) + '"]' ) && ! ( l.id && document.getElementById( l.id ) ) ) {
				document.head.appendChild( document.importNode( l, true ) );
			}
		} );
		var chain = Promise.resolve();
		d.querySelectorAll( 'script' ).forEach( function ( s ) {
			if ( s.closest( '#content' ) ) {
				return;
			}
			if ( /text\/template/.test( s.type || '' ) ) {
				if ( s.id && ! document.getElementById( s.id ) ) {
					body.appendChild( document.importNode( s, true ) );
				}
				return;
			}
			var src = s.getAttribute( 'src' );
			if ( ! src || have( 'script[src="' + src + '"]' ) || ( s.id && document.getElementById( s.id ) ) ) {
				return;
			}
			var base = ( s.id || '' ).replace( /-js$/, '' );
			chain = chain.then( function () {
				return new Promise( function ( done ) {
					[ '-js-extra', '-js-before' ].forEach( function ( k ) {
						var x = base && d.getElementById( base + k );
						if ( x && ! document.getElementById( base + k ) ) {
							runInline( x );
						}
					} );
					var n = document.createElement( 'script' );
					n.src = src;
					if ( s.id ) {
						n.id = s.id;
					}
					n.async = false;
					n.onload = n.onerror = function () {
						var a = base && d.getElementById( base + '-js-after' );
						if ( a ) {
							runInline( a );
						}
						done();
					};
					body.appendChild( n );
				} );
			} );
		} );
		return chain;
	}
	function fetchDoc( u ) {
		if ( ! docs[ u ] ) {
			docs[ u ] = window.fetch( u, { credentials: 'same-origin' } ).then( function ( r ) {
				if ( ! r.ok ) {
					throw new Error( 'status ' + r.status );
				}
				return r.text();
			} ).then( function ( t ) {
				var d = new window.DOMParser().parseFromString( t, 'text/html' );
				if ( ! d.getElementById( 'content' ) || ! d.querySelector( '#content .fsz-wrap.fsz-at-gallery .fsz-device' ) ) {
					throw new Error( 'not a species page' );
				}
				return needs( d ).then( function () {
					return d;
				} );
			} );
			docs[ u ].catch( function () {
				delete docs[ u ];
			} );
		}
		return docs[ u ];
	}
	function photoAhead( dir ) {
		var m = data[ dir ] && data[ dir ].img;
		if ( ! m || ! m[ 0 ] ) {
			return;
		}
		var im = new window.Image(); // never put on the page, so never drawn
		im.decoding = 'async';
		if ( m[ 2 ] ) {
			im.sizes = m[ 2 ];
		}
		if ( m[ 1 ] ) {
			im.srcset = m[ 1 ];
		}
		im.src = m[ 0 ];
	}
	function ahead() {
		if ( slow() || ! canSwap() ) {
			return;
		}
		[ 'next', 'prev' ].forEach( function ( dir ) {
			var u = url( dir );
			if ( u && u !== window.location.href.split( '#' )[ 0 ] ) {
				fetchDoc( u );
				photoAhead( dir );
			}
		} );
	}
	function idle( wait ) {
		window.setTimeout( function () {
			( window.requestIdleCallback || function ( f ) {
				return window.setTimeout( f, 1 );
			} )( ahead, { timeout: 4000 } );
		}, wait );
	}

	// ==========================================================================
	//  3. The incoming card (a still picture of the next card)
	// ==========================================================================

	/* The next species' card, taken from its fetched page, laid exactly over this card (same size and place) and moved
	   to the side it comes from. It is dressed once (Codex.still: names, depth, plate) and has no life of its own; after
	   the swap the real card takes its place in the same spot, so nothing jumps. */
	// This card's place and size before it moves (taken when a swipe starts, or when a move starts without one).
	var base = null;
	function makeGhost( d ) {
		var src = d.querySelector( '#content .fsz-wrap.fsz-at-gallery' );
		if ( ! src || ! wrap ) {
			return null;
		}
		var g = document.importNode( src, true );
		g.querySelectorAll( 'script' ).forEach( function ( s ) {
			s.parentNode.removeChild( s );
		} );
		var r = base || wrap.getBoundingClientRect(), dev = wrap.querySelector( '.fsz-device' ), gd = g.querySelector( '.fsz-device' );
		g.classList.add( 'fsz-incoming' );
		g.setAttribute( 'aria-hidden', 'true' );
		g.setAttribute( 'inert', '' );
		g.style.cssText = wrap.style.cssText;
		[ [ 'position', 'fixed' ], [ 'left', r.left + 'px' ], [ 'top', r.top + 'px' ], [ 'right', 'auto' ], [ 'bottom', 'auto' ], [ 'width', r.width + 'px' ], [ 'height', r.height + 'px' ], [ 'margin', '0' ], [ 'z-index', '4' ], [ 'pointer-events', 'none' ], [ 'translate', 'none' ], [ 'transform', 'none' ], [ 'opacity', '0' ] ].forEach( function ( p ) {
			g.style.setProperty( p[ 0 ], p[ 1 ] );
		} );
		if ( dev && gd ) {
			var u = dev.style.getPropertyValue( '--fsz-u' );
			if ( u ) {
				gd.style.setProperty( '--fsz-u', u );
			}
		}
		wrap.parentNode.insertBefore( g, wrap.nextSibling );
		try {
			window.Codex.still( gd );
		} catch ( e ) {}
		return g;
	}

	// Where the cards are for a finger at dx (the "Depth" move): the outgoing card follows the finger and steps back,
	// the incoming one comes from its side, growing from behind and getting clearer.
	var W = 360;
	function pose( el, x ) {
		var f = Math.min( 1, Math.abs( x ) / W );
		el.style.translate = Math.round( x ) + 'px 0';
		el.style.scale = String( Math.round( ( 1 - 0.2 * f ) * 1000 ) / 1000 );
		el.style.opacity = String( Math.round( ( 1 - 0.55 * f ) * 100 ) / 100 );
	}
	function clear( el ) {
		[ 'transition', 'translate', 'scale', 'opacity' ].forEach( function ( k ) {
			el.style.removeProperty( k );
		} );
	}

	// ==========================================================================
	//  4. The move and the swap
	// ==========================================================================

	var ghost = null, gdir = '', gdoc = null;
	function dropGhost() {
		if ( ghost && ghost.parentNode ) {
			ghost.parentNode.removeChild( ghost );
		}
		ghost = null;
		gdir = '';
		gdoc = null;
	}
	function side( dir ) {
		return 'next' === dir ? 1 : -1; // the next species comes from the right
	}
	function ease( dur ) {
		return reduce ? 'opacity .15s' : 'translate ' + dur + 'ms ' + EASE + ',scale ' + dur + 'ms ' + EASE + ',opacity ' + dur + 'ms ease';
	}
	function after( ms, f ) {
		window.setTimeout( f, ms + 30 );
	}

	/* Go to a neighbour: the outgoing card leaves to one side and steps back while the incoming one comes forward from
	   the other, then the page content is swapped (one step, nothing drawn in between) and the real card takes the
	   incoming picture's place. dx: where the finger let go (0 for a tap or a click). pop: the back or forward button
	   (the address is already there). */
	function go( dir, dx, pop, to ) {
		var u = to || url( dir );
		if ( going || ! u ) {
			return;
		}
		if ( ! canSwap() ) {
			load( dir, u );
			return;
		}
		going = true;
		W = window.innerWidth || 360;
		if ( ! dx || ! base ) {
			base = wrap.getBoundingClientRect(); // a tap or a click: the card has not moved yet
		}
		var s = side( dir ), off = s * ( W + GAP ), p = Math.min( 1, Math.abs( dx ) / W );
		var dur = Math.round( DUR * ( 1 - 0.4 * p ) );
		try {
			window.localStorage.setItem( 'fsz-nb-hint', '1' ); // they know how to move on: no hints
		} catch ( e ) {}
		hintsOff();
		// the outgoing card leaves now; the incoming one follows as soon as its page is here (usually already)
		wrap.style.transition = ease( dur );
		void wrap.offsetWidth;
		if ( reduce ) {
			wrap.style.opacity = '0';
		} else {
			pose( wrap, -off );
		}
		fetchDoc( u ).then( function ( d ) {
			if ( ! ghost || gdir !== dir || gdoc !== d ) {
				dropGhost();
				ghost = makeGhost( d );
				gdir = dir;
				gdoc = d;
				if ( ghost && ! reduce ) {
					pose( ghost, off + dx );
				}
			}
			if ( ! ghost ) {
				throw new Error( 'no card' );
			}
			void ghost.offsetWidth;
			ghost.style.transition = ease( dur );
			void ghost.offsetWidth;
			if ( reduce ) {
				ghost.style.opacity = '1';
			} else {
				pose( ghost, 0 );
				ghost.style.opacity = '1';
			}
			after( dur, function () {
				try {
					swap( d, u, pop );
				} catch ( err ) {
					window.location.href = u;
				}
			} );
		} ).catch( function () {
			load( dir, u );
		} );
	}

	// The body's classes that came from the server (the rest were added by scripts and stay).
	var srvClass = body.className.split( /\s+/ ).filter( Boolean );

	function swap( d, u, pop ) {
		var cur = document.getElementById( 'content' ), nu = document.importNode( d.getElementById( 'content' ), true );
		var g = ghost;
		ghost = null;
		gdoc = null;
		// the new content's scripts: the card's sleep script is left out (the card arrives switched on), the others
		// run when the content is put in (the card fit)
		nu.querySelectorAll( 'script' ).forEach( function ( s ) {
			if ( s.type && ! /javascript|ecmascript/i.test( s.type ) ) {
				return;
			}
			if ( s.hasAttribute( 'data-fsz-sleep' ) ) {
				s.parentNode.removeChild( s );
				return;
			}
			var n = document.createElement( 'script' );
			n.text = s.text;
			s.parentNode.replaceChild( n, s );
		} );
		var nwrap = nu.querySelector( '.fsz-wrap.fsz-at-gallery' ), ndev = nwrap && nwrap.querySelector( '.fsz-device' );
		if ( ! ndev ) {
			throw new Error( 'no card' );
		}
		ndev.setAttribute( 'data-fsz-calm', '' );
		nwrap.style.visibility = 'hidden';
		document.dispatchEvent( new window.CustomEvent( 'fsz:swap', { detail: { url: u } } ) );
		window.izlProductPage.down(); // the phone drawer puts its parts back first
		if ( g ) {
			nwrap.parentNode.insertBefore( g, nwrap.nextSibling ); // the incoming picture stays on screen throughout
		}
		cur.parentNode.replaceChild( nu, cur );

		// the page around the content: body classes, title, head tags, the footer's sticky buy bar, page settings
		var was = srvClass, now = ( d.body.className || '' ).replace( /\bwoocommerce-no-js\b/, 'woocommerce-js' ).split( /\s+/ ).filter( Boolean );
		was.forEach( function ( c ) {
			if ( now.indexOf( c ) < 0 ) {
				body.classList.remove( c );
			}
		} );
		now.forEach( function ( c ) {
			body.classList.add( c );
		} );
		srvClass = now;
		document.title = d.title;
		[ 'link[rel=canonical]', 'link[rel=shortlink]', 'meta[name=description]', 'meta[property^="og:"]', 'meta[property^="product:"]', 'meta[name^="twitter:"]' ].forEach( function ( sel ) {
			var old = document.head.querySelectorAll( sel ), fresh = d.head.querySelectorAll( sel ), at = old.length ? old[ old.length - 1 ].nextSibling : null;
			old.forEach( function ( n ) {
				n.parentNode.removeChild( n );
			} );
			fresh.forEach( function ( n ) {
				document.head.insertBefore( document.importNode( n, true ), at );
			} );
		} );
		var sticky = document.querySelector( '.storefront-sticky-add-to-cart' ), sticky2 = d.querySelector( '.storefront-sticky-add-to-cart' );
		if ( sticky && sticky2 ) {
			sticky.parentNode.replaceChild( document.importNode( sticky2, true ), sticky );
		}
		d.querySelectorAll( 'script[id$="-js-extra"],script[id$="-js-before"]' ).forEach( function ( s ) {
			var mine = document.getElementById( s.id );
			if ( s.closest( '#content' ) || ( mine && mine.text === s.text ) ) {
				return;
			}
			runInline( s );
			if ( mine ) {
				mine.text = s.text;
			}
		} );
		if ( ! pop ) {
			step++;
			window.history.pushState( { fsz: step }, '', u );
		}

		// start the page again: WooCommerce's pack choice and tabs, the theme's buy box and drawer, the card
		var $ = window.jQuery;
		if ( $ ) {
			if ( $.fn.wc_variation_form ) {
				$( '.variations_form' ).each( function () {
					$( this ).wc_variation_form();
				} );
			}
			$( '.wc-tabs-wrapper, .woocommerce-tabs, #rating' ).trigger( 'init' );
		}
		window.izlProductPage.up();
		window.Codex.setup( ndev );
		if ( window.fszFit ) {
			window.fszFit();
		}
		bind();
		place();
		watch();
		hintsLater();
		// keep only the new neighbours' pages
		var keep = {};
		[ url( 'next' ), url( 'prev' ) ].forEach( function ( k ) {
			if ( docs[ k ] ) {
				keep[ k ] = docs[ k ];
			}
		} );
		docs = keep;
		// the real card shows once it has its size and place (the same for three frames in a row, at most ~0.7 s), in
		// the incoming picture's spot
		base = null;
		var last = '', same = 0, n = 0;
		( function settle() {
			var r = nwrap.getBoundingClientRect(), r2 = ndev.getBoundingClientRect();
			var k = [ r.left, r.top, r.width, r.height, r2.width, r2.height ].map( Math.round ).join( ',' );
			same = k === last ? same + 1 : 0;
			last = k;
			if ( ( same < 2 || n < 2 ) && n < 40 ) {
				n++;
				window.requestAnimationFrame( settle );
				return;
			}
			// a species whose card sits a little higher or lower (another fit): it glides from the picture's spot to its own
			if ( g && ! reduce ) {
				var a = g.getBoundingClientRect(), mx = ( a.left + a.width / 2 ) - ( r.left + r.width / 2 ), my = ( a.top + a.height / 2 ) - ( r.top + r.height / 2 ), sc = r.width ? a.width / r.width : 1;
				if ( Math.abs( mx ) > 1 || Math.abs( my ) > 1 || Math.abs( sc - 1 ) > 0.01 ) {
					nwrap.style.transition = 'none';
					nwrap.style.translate = Math.round( mx ) + 'px ' + Math.round( my ) + 'px';
					nwrap.style.scale = String( Math.round( sc * 1000 ) / 1000 );
					void nwrap.offsetWidth;
					nwrap.style.transition = ease( 220 );
					nwrap.style.translate = '0px 0px';
					nwrap.style.scale = '1';
					after( 220, function () {
						if ( wrap === nwrap && ! going && ! html.classList.contains( 'fsz-dragging' ) ) {
							clear( nwrap );
						}
					} );
				}
			}
			nwrap.style.visibility = '';
			if ( g && g.parentNode ) {
				g.parentNode.removeChild( g );
			}
			going = false;
			idle( 300 );
		} )();
	}

	// ==========================================================================
	//  5. The swipe (finger only)
	// ==========================================================================

	/* Phones and touch screens only (a mouse never swipes; PC has the side cards). Anywhere on the page except the top
	   bar, the open drawer, fields, a card being edited, the photo when the card has several (a swipe there changes the
	   photo) and the photo pop-out. Only a clear sideways move counts: the first 10 px decide, mostly up or down stays the
	   page's (the drawer). Only translate, scale and opacity change while the card moves. */
	var g = null, raf = 0, block = false;
	// a row that scrolls sideways itself (a tablet's product rows) keeps its own swipe
	function sideScroller( t ) {
		for ( var el = t; el && el !== body && el.nodeType === 1; el = el.parentNode ) {
			if ( el.scrollWidth > el.clientWidth + 1 && /auto|scroll/.test( window.getComputedStyle( el ).overflowX ) ) {
				return true;
			}
		}
		return false;
	}
	function skip( t ) {
		return ! t.closest || sideScroller( t ) || !! ( body.classList.contains( 'izl-open' ) || body.classList.contains( 'izl-popon' ) || document.querySelector( '.fsz-device.is-editing' ) || t.closest( '.site-header,#wpadminbar,.izl-drawer,.izl-pop,.fsz-incoming,input,textarea,select,[contenteditable],.fsz-photo[role=button]' ) );
	}
	function paint() {
		raf = 0;
		if ( ! g || ! g.on ) {
			return;
		}
		pose( wrap, g.dx );
		var dir = g.dx < 0 ? 'next' : 'prev';
		if ( ghost && gdir !== dir ) {
			dropGhost();
		}
		if ( ! ghost && g.docs[ dir ] ) {
			ghost = makeGhost( g.docs[ dir ] );
			gdir = dir;
			gdoc = g.docs[ dir ];
		}
		if ( ghost ) {
			pose( ghost, side( dir ) * ( W + GAP ) + g.dx );
		}
	}
	function move( e ) {
		if ( ! g || e.pointerId !== g.id ) {
			return;
		}
		var dx = e.clientX - g.x, dy = e.clientY - g.y;
		if ( ! g.on ) {
			if ( Math.abs( dx ) < 10 && Math.abs( dy ) < 10 ) {
				return;
			}
			if ( Math.abs( dx ) < Math.abs( dy ) * 1.5 || ! wrap ) {
				g = null; // up or down: not a swipe
				return;
			}
			g.on = true;
			W = window.innerWidth || 360;
			base = wrap.getBoundingClientRect();
			html.classList.add( 'fsz-dragging' );
			wrap.style.transition = 'none';
			// both neighbours' pages (usually fetched already): the incoming card appears as soon as one is here
			var gs = g;
			[ 'next', 'prev' ].forEach( function ( dir ) {
				var u = url( dir );
				if ( u ) {
					fetchDoc( u ).then( function ( d ) {
						gs.docs[ dir ] = d;
						if ( g === gs && ! raf ) {
							raf = window.requestAnimationFrame( paint );
						}
					}, function () {} );
				}
			} );
		}
		g.dx = dx;
		g.hist.push( [ e.timeStamp, e.clientX ] );
		if ( g.hist.length > 5 ) {
			g.hist.shift();
		}
		if ( ! raf ) {
			raf = window.requestAnimationFrame( paint );
		}
	}
	function end( e ) {
		if ( ! g || e.pointerId !== g.id ) {
			return;
		}
		var was = g;
		g = null;
		if ( ! was.on ) {
			return;
		}
		html.classList.remove( 'fsz-dragging' );
		if ( raf ) {
			window.cancelAnimationFrame( raf );
			raf = 0;
		}
		var h = was.hist, v = 0, dx = was.dx;
		if ( h.length > 1 ) {
			v = ( h[ h.length - 1 ][ 1 ] - h[ 0 ][ 1 ] ) / Math.max( 1, h[ h.length - 1 ][ 0 ] - h[ 0 ][ 0 ] ); // px per ms, the last moves
		}
		block = true; // the click a finger sends after the drag (on Leírás, a badge …) is not a click
		window.setTimeout( function () {
			block = false;
		}, 350 );
		if ( 'pointercancel' !== e.type && ( Math.abs( dx ) > Math.min( 110, W * 0.3 ) || ( Math.abs( dx ) > 36 && Math.abs( v ) > 0.45 && ( v < 0 ) === ( dx < 0 ) ) ) ) {
			go( dx < 0 ? 'next' : 'prev', dx );
			return;
		}
		// not far or fast enough: both cards back to their places
		wrap.style.transition = ease( 300 );
		pose( wrap, 0 );
		var gh = ghost;
		if ( gh ) {
			gh.style.transition = ease( 300 );
			pose( gh, side( gdir ) * ( W + GAP ) );
		}
		after( 300, function () {
			if ( ! g && ! going ) {
				clear( wrap );
				if ( gh === ghost ) {
					dropGhost();
				}
			}
		} );
	}
	document.addEventListener( 'pointerdown', function ( e ) {
		if ( going || ( g && g.on ) || ! e.isPrimary || 'mouse' === e.pointerType || ! wrap || skip( e.target ) ) {
			return;
		}
		g = { id: e.pointerId, x: e.clientX, y: e.clientY, dx: 0, on: false, hist: [ [ e.timeStamp, e.clientX ] ], docs: {} };
	}, { passive: true } );
	document.addEventListener( 'pointermove', move, { passive: true } );
	document.addEventListener( 'pointerup', end );
	document.addEventListener( 'pointercancel', end );
	document.addEventListener( 'click', function ( e ) {
		if ( block ) {
			e.preventDefault();
			e.stopPropagation();
		}
	}, true );
	// A finger moving sideways is ours; up and down stay the browser's (the drawer, the page).
	html.classList.add( 'fsz-swipe-on' );

	// ==========================================================================
	//  6. Side cards, arrows, the back button
	// ==========================================================================

	// The side cards (PC) and the edge tabs (phone) are plain links: a click moves in place (a new tab or window stays
	// a normal link).
	document.addEventListener( 'click', function ( e ) {
		var a = e.target.closest && e.target.closest( '.fsz-nb' );
		if ( ! a || e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey ) {
			return;
		}
		e.preventDefault();
		go( a.classList.contains( 'fsz-nb-prev' ) ? 'prev' : 'next', 0 );
	} );
	// PC: the arrow keys (not while typing, not with the photo pop-out open)
	document.addEventListener( 'keydown', function ( e ) {
		if ( ( 'ArrowLeft' !== e.key && 'ArrowRight' !== e.key ) || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey || e.defaultPrevented ) {
			return;
		}
		var t = e.target;
		if ( ! mm( '(hover: hover) and (pointer: fine)' ) || ( t && t.closest && t.closest( 'input,textarea,select,[contenteditable],.izl-pop,.fsz-photo' ) ) || body.classList.contains( 'izl-popon' ) || ! nav || ! window.getComputedStyle( nav ).display || 'none' === window.getComputedStyle( nav ).display ) {
			return;
		}
		go( 'ArrowRight' === e.key ? 'next' : 'prev', 0 );
	} );
	// Back and forward between swapped species: the same move, the way back from the left.
	window.addEventListener( 'popstate', function ( e ) {
		var st = e.state;
		if ( ! st || 'number' !== typeof st.fsz ) {
			return;
		}
		if ( going ) {
			window.location.reload();
			return;
		}
		var dir = st.fsz < step ? 'prev' : 'next';
		step = st.fsz;
		go( dir, 0, true, window.location.href.split( '#' )[ 0 ] );
	} );
	try {
		window.history.replaceState( Object.assign( {}, window.history.state || {}, { fsz: step } ), '' );
	} catch ( e ) {}
	// Back to this page from the browser's memory: everything in its place.
	window.addEventListener( 'pageshow', function ( e ) {
		if ( e.persisted ) {
			going = false;
			g = null;
			dropGhost();
			if ( wrap ) {
				clear( wrap );
			}
			html.removeAttribute( 'data-fsz-swipe' );
			html.classList.remove( 'fsz-dragging' );
		}
	} );

	// ==========================================================================
	//  7. PC: first-visit hints on the side cards
	// ==========================================================================

	/* A new visitor on PC (side cards showing) who has not used them: after 12 seconds on the page (counted only while the
	   tab is in front), faint "előző" and "következő" labels fade in next to the side cards for a few seconds, and from
	   then the side cards nudge inwards every 9 seconds until one is hovered or used. Once per visitor (localStorage
	   fsz-nb-hint). The look: codex.css section 7 (.is-hint, .is-nudge). */
	var HINT_AT = 12000, NUDGE_EVERY = 9000;
	var seen = 0, tick = 0, nudgeT = 0, hinted = false, lastT = 0;
	function told() {
		try {
			return !! window.localStorage.getItem( 'fsz-nb-hint' );
		} catch ( e ) {
			return true; // storage blocked: never nag
		}
	}
	function peeks() {
		return mm( '(min-width: 1200px) and (hover: hover) and (pointer: fine)' ) && nav && ! nav.classList.contains( 'is-away' );
	}
	function nudge() {
		if ( ! nav || ! hinted ) {
			return;
		}
		nav.classList.remove( 'is-nudge' );
		void nav.offsetWidth;
		nav.classList.add( 'is-nudge' );
		nudgeT = window.setTimeout( nudge, NUDGE_EVERY );
	}
	function hintsOff() {
		window.clearInterval( tick );
		window.clearTimeout( nudgeT );
		tick = 0;
		hinted = false;
		if ( nav ) {
			nav.classList.remove( 'is-hint', 'is-nudge' );
		}
	}
	function hintsLater() {
		if ( reduce || told() || tick || hinted ) {
			return;
		}
		lastT = Date.now();
		tick = window.setInterval( function () {
			var now = Date.now();
			if ( ! document.hidden && peeks() ) {
				seen += now - lastT;
			}
			lastT = now;
			if ( seen < HINT_AT ) {
				return;
			}
			window.clearInterval( tick );
			tick = 0;
			try {
				window.localStorage.setItem( 'fsz-nb-hint', '1' );
			} catch ( e ) {}
			hinted = true;
			nav.classList.add( 'is-hint' );
			nudge();
		}, 250 );
	}
	document.addEventListener( 'pointerover', function ( e ) {
		if ( hinted && e.target.closest && e.target.closest( '.fsz-nb' ) ) {
			window.clearTimeout( nudgeT );
			hinted = false;
			nav.classList.remove( 'is-nudge' );
		}
	} );

	// ==========================================================================
	//  8. Where the phone tabs sit
	// ==========================================================================

	// Phone (the card stays still on the screen): at the card's mid-height, so the tabs are never under the buy drawer.
	// Elsewhere at the window's mid-height, faded out while the card is mostly scrolled away.
	function place() {
		if ( ! nav || ! wrap ) {
			return;
		}
		if ( 'fixed' !== window.getComputedStyle( wrap ).position ) {
			nav.style.removeProperty( '--fsz-swipe-y' );
			return;
		}
		var d = wrap.querySelector( '.fsz-device' ), r = ( d || wrap ).getBoundingClientRect();
		if ( r.height ) {
			nav.style.setProperty( '--fsz-swipe-y', Math.round( r.top + r.height / 2 ) + 'px' );
		}
	}
	document.addEventListener( 'fsz:fit', function ( e ) {
		if ( ! e.target || ! e.target.classList || ! e.target.classList.contains( 'fsz-incoming' ) ) {
			place();
		}
	} );
	window.addEventListener( 'resize', function () {
		window.requestAnimationFrame( place );
	} );
	var io = null;
	function watch() {
		if ( ! ( 'IntersectionObserver' in window ) || ! wrap ) {
			return;
		}
		if ( io ) {
			io.disconnect();
		}
		io = new window.IntersectionObserver( function ( en ) {
			if ( nav ) {
				nav.classList.toggle( 'is-away', en[ en.length - 1 ].intersectionRatio < 0.3 );
			}
		}, { threshold: [ 0, 0.3 ] } );
		io.observe( wrap );
	}

	// ==========================================================================
	//  9. Start
	// ==========================================================================

	function start() {
		bind();
		place();
		watch();
		hintsLater();
		if ( 'complete' === document.readyState ) {
			idle( 2000 );
		} else {
			window.addEventListener( 'load', function () {
				idle( 2000 );
			} );
		}
		// The slide mark of a normal page load has done its job once the page is on screen.
		window.setTimeout( function () {
			if ( ! going ) {
				html.removeAttribute( 'data-fsz-swipe' );
			}
		}, 1500 );
	}
	if ( document.prerendering ) {
		document.addEventListener( 'prerenderingchange', start, { once: true } );
	} else {
		start();
	}
} )();
