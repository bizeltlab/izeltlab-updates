// ==========================================================================
//  FILE: assets/swipe.js   (Codex plugin)
//  WHAT: Moving between species on their product pages without a page load (2.3.0). Phones and touch screens: a
//        sideways swipe anywhere on the page (also beside the card) brings the next species from the right or the
//        previous one from the left; the new card is already visible while the finger moves and comes forward from
//        behind ("Depth"). PC: no swipe; the small side cards (or the arrow keys) do the same move. The address bar
//        follows (the back button works). Anything unusual: a normal page load instead.
//        2.6.0 (Dan, 2026-11-14: "only the Codex moves"): the page itself (top bar, drawer, the Vissza / Előre tabs)
//        stays; only the card is swapped. The next species' page is fetched ahead, the few parts that change are kept
//        (its card, its summary for the drawer, the text below, its address and title) and the rest is thrown away at
//        once. The incoming card itself becomes the card where it lands (no second card, no handover), the old card is
//        switched off completely and removed, and the drawer swaps only its contents (the price fades out and in):
//        Ízeltláb theme 3.9.0 izlProductPage.swap. Only the card on the screen is drawn: a waiting card is not drawn at
//        all until a finger starts to move sideways (a phone ran out of memory with several cards drawn: the crash).
//        The neighbours and the side cards: inc/card-swipe.php; the look: codex.css section 7.
//  SEEN: Product pages of species (only where a Codex card shows).
//  SECTIONS IN THIS FILE:
//    1. The page now: card, side cards, neighbours
//    2. Fetching the neighbours ahead (only the parts that change)
//    3. The incoming card
//    4. The move and the swap
//    5. The swipe (finger only)
//    6. Side cards, arrows, the back button
//    7. PC: first-visit hints on the side cards
//    8. Where the phone tabs sit
//    9. Start
// ==========================================================================
( function () {
	'use strict';
	var html = document.documentElement, body = document.body;
	if ( ! document.querySelector( '.fsz-swipe' ) || ! document.querySelector( '.fsz-wrap.fsz-at-gallery' ) || ! window.matchMedia ) {
		return;
	}
	var mm = function ( q ) {
		return window.matchMedia( q ).matches;
	};
	var reduce = mm( '(prefers-reduced-motion: reduce)' );
	var GAP = 24, DUR = 540, EASE = 'cubic-bezier(.45,.05,.25,1)'; // the "Depth" move (Dan's pick, 2026-11-14)

	// ==========================================================================
	//  1. The page now: card, side cards, neighbours
	// ==========================================================================

	var nav, wrap, data, links, going = false, step = 0;
	function bind() {
		nav = document.querySelector( '.fsz-swipe' );
		wrap = document.querySelector( '.fsz-wrap.fsz-at-gallery:not(.fsz-incoming)' );
		data = {};
		try {
			data = JSON.parse( ( nav && nav.getAttribute( 'data-fsz-swipe' ) ) || '{}' ) || {};
		} catch ( e ) {}
		links = { prev: nav && nav.querySelector( '.fsz-nb-prev' ), next: nav && nav.querySelector( '.fsz-nb-next' ) };
	}
	function url( dir ) {
		return links[ dir ] ? links[ dir ].href.split( '#' )[ 0 ] : '';
	}

	// The card can be swapped in place only with the shop theme's product page helper (Ízeltláb theme 3.9.0+: swap)
	// and Codex's card helper, for shoppers: an editor's page (admin bar, edit tools) changes with a normal page load.
	function canSwap() {
		return !! ( window.fetch && window.DOMParser && window.history && window.history.pushState && window.Codex && window.Codex.setup && window.Codex.drop && window.izlProductPage && window.izlProductPage.swap && ! body.classList.contains( 'admin-bar' ) && ! document.querySelector( '.fsz-device.is-editing' ) && wrap && wrap.parentNode );
	}

	// A normal page load (the 2.2.0 way): the next page reads the mark and slides its card in where the browser can.
	function load( dir, u ) {
		try {
			window.sessionStorage.setItem( 'fsz-swipe', JSON.stringify( { u: u, d: dir, t: Date.now() } ) );
		} catch ( e ) {}
		html.setAttribute( 'data-fsz-swipe', dir );
		window.location.href = u;
	}

	// ==========================================================================
	//  2. Fetching the neighbours ahead (only the parts that change)
	// ==========================================================================

	/* Each neighbour's page is fetched once the page is idle (never on Save-Data or a slow connection: then only when
	   a swipe starts): the shop's ready-made copy of the page (the page cache answers it at once). 2.6.0: it is read
	   once, the parts that change are kept as text (a "packet", see cut()) and the read page is thrown away. Scripts and
	   styles that page needs and this one does not have yet (for example the pack choice of a species sold in packs)
	   are loaded then, so the swap itself waits for nothing. The neighbour's first photo is fetched too, so the
	   incoming card shows its picture at once. */
	var packs = {};
	function slow() {
		var c = navigator.connection;
		return !! ( c && ( c.saveData || /(^|-)(2g|3g)$/.test( c.effectiveType || '' ) ) ) || mm( '(prefers-reduced-data: reduce)' );
	}
	function have( sel ) {
		try {
			return !! document.querySelector( sel );
		} catch ( e ) {
			return true;
		}
	}
	function runInline( text ) {
		var n = document.createElement( 'script' );
		n.text = text;
		body.appendChild( n );
		body.removeChild( n );
	}
	// What the new page has outside its content that this one lacks: stylesheets, script templates, script files
	// (each with its settings, in page order).
	function needs( d ) {
		d.querySelectorAll( 'link[rel=stylesheet][href]' ).forEach( function ( l ) {
			if ( ! have( 'link[rel=stylesheet][href="' + l.getAttribute( 'href' ) + '"]' ) && ! ( l.id && document.getElementById( l.id ) ) ) {
				document.head.appendChild( document.importNode( l, true ) );
			}
		} );
		var chain = Promise.resolve();
		d.querySelectorAll( 'script' ).forEach( function ( s ) {
			if ( s.closest( '#content' ) ) {
				return;
			}
			if ( /text\/template/.test( s.type || '' ) ) {
				if ( s.id && ! document.getElementById( s.id ) ) {
					body.appendChild( document.importNode( s, true ) );
				}
				return;
			}
			var src = s.getAttribute( 'src' );
			if ( ! src || have( 'script[src="' + src + '"]' ) || ( s.id && document.getElementById( s.id ) ) ) {
				return;
			}
			var base = ( s.id || '' ).replace( /-js$/, '' ), before = [], after = base && d.getElementById( base + '-js-after' );
			[ '-js-extra', '-js-before' ].forEach( function ( k ) {
				var x = base && d.getElementById( base + k );
				if ( x ) {
					before.push( [ base + k, x.text ] );
				}
			} );
			var at = after ? after.text : '', id = s.id;
			chain = chain.then( function () {
				return new Promise( function ( done ) {
					before.forEach( function ( x ) {
						if ( ! document.getElementById( x[ 0 ] ) ) {
							runInline( x[ 1 ] );
						}
					} );
					var n = document.createElement( 'script' );
					n.src = src;
					if ( id ) {
						n.id = id;
					}
					n.async = false;
					n.onload = n.onerror = function () {
						if ( at ) {
							runInline( at );
						}
						done();
					};
					body.appendChild( n );
				} );
			} );
		} );
		return chain;
	}
	var HEAD = [ 'link[rel=canonical]', 'link[rel=shortlink]', 'meta[name=description]', 'meta[property^="og:"]', 'meta[property^="product:"]', 'meta[name^="twitter:"]' ];
	function outer( n ) {
		return n ? n.outerHTML : '';
	}
	// Whether an element of the product box is one of the page's own parts (not the card, the tabs, the summary, a
	// script, or something the shop theme put there itself).
	function own( k ) {
		return 1 === k.nodeType && ! k.matches( '.fsz-wrap,nav.fsz-swipe,.summary,script,style,template,.izl-space,.izl-dim' );
	}
	/* 2.6.0: the parts of a species page that change, as text (nothing of the read page is kept): the card, the summary
	   (the drawer's contents), the edge tabs, the product box's other parts (the text below the card) and its classes,
	   the notices, the breadcrumb, the title and the head tags, the body classes, the footer's sticky buy bar and the
	   page settings scripts. */
	function cut( d, u ) {
		var w = d.querySelector( '#content .fsz-wrap.fsz-at-gallery' ), prod = w && w.parentNode;
		var sum = prod && ( prod.querySelector( '.summary.entry-summary' ) || d.querySelector( '#content .summary.entry-summary' ) );
		if ( ! w || ! w.querySelector( '.fsz-device' ) || ! sum ) {
			throw new Error( 'not a species page' );
		}
		var crumb = d.querySelector( '.storefront-breadcrumb' ), pk = {
			u: u,
			wrap: w.outerHTML,
			sum: sum.outerHTML,
			nav: outer( d.querySelector( '#content nav.fsz-swipe' ) ),
			attrs: Array.prototype.map.call( prod.attributes, function ( a ) {
				return [ a.name, a.value ];
			} ),
			rest: Array.prototype.filter.call( prod.children, own ).map( outer ),
			notices: Array.prototype.map.call( d.querySelectorAll( '#content .woocommerce-notices-wrapper' ), function ( n ) {
				return n.innerHTML;
			} ),
			crumb: crumb ? crumb.innerHTML : null,
			title: d.title,
			head: HEAD.map( function ( sel ) {
				return Array.prototype.map.call( d.head.querySelectorAll( sel ), outer );
			} ),
			body: d.body.className || '',
			sticky: outer( d.querySelector( '.storefront-sticky-add-to-cart' ) ),
			extra: Array.prototype.filter.call( d.querySelectorAll( 'script[id$="-js-extra"],script[id$="-js-before"]' ), function ( s ) {
				return ! s.closest( '#content' );
			} ).map( function ( s ) {
				return [ s.id, s.text ];
			} )
		};
		return pk;
	}
	function fetchPack( u ) {
		if ( ! packs[ u ] ) {
			packs[ u ] = window.fetch( u, { credentials: 'same-origin' } ).then( function ( r ) {
				if ( ! r.ok ) {
					throw new Error( 'status ' + r.status );
				}
				return r.text();
			} ).then( function ( t ) {
				var d = new window.DOMParser().parseFromString( t, 'text/html' );
				var pk = cut( d, u );
				return needs( d ).then( function () {
					return pk;
				} );
			} );
			packs[ u ].catch( function () {
				delete packs[ u ];
			} );
		}
		return packs[ u ];
	}
	function photoAhead( dir ) {
		var m = data[ dir ] && data[ dir ].img;
		if ( ! m || ! m[ 0 ] ) {
			return;
		}
		var im = new window.Image(); // never put on the page, so never drawn
		im.decoding = 'async';
		if ( m[ 2 ] ) {
			im.sizes = m[ 2 ];
		}
		if ( m[ 1 ] ) {
			im.srcset = m[ 1 ];
		}
		im.src = m[ 0 ];
	}
	function ahead() {
		if ( slow() || ! canSwap() ) {
			return;
		}
		[ 'next', 'prev' ].forEach( function ( dir ) {
			var u = url( dir );
			if ( u && u !== window.location.href.split( '#' )[ 0 ] ) {
				photoAhead( dir );
				// 2.5.0: and its card, built unseen (section 3), when the page is idle again
				fetchPack( u ).then( function ( pk ) {
					whenIdle( function () {
						prep( dir, pk );
					}, 0 );
				}, function () {} );
			}
		} );
	}
	function whenIdle( f, wait ) {
		window.setTimeout( function () {
			( window.requestIdleCallback || function ( k ) {
				return window.setTimeout( k, 1 );
			} )( f, { timeout: 4000 } );
		}, wait );
	}
	function idle( wait ) {
		whenIdle( ahead, wait );
	}

	// ==========================================================================
	//  3. The incoming card
	// ==========================================================================

	/* The next species' card (from its packet), laid exactly over this card (same size and place) and moved to the side
	   it comes from. It is dressed once (Codex.still: names, depth, plate) and slides in; 2.6.0: where it lands it
	   becomes the card itself (swap). */
	// This card's place and size before it moves (taken when a swipe starts, or when a move starts without one).
	var base = null;
	/* 2.6.0: the photos of parts that come in get their "sizes" as the plain width it gives on this screen (the same
	   photo file is chosen). Chrome keeps every photo whose sizes depend on the window on a list of its own, even after
	   it has left the page, and with it the whole card: after many swipes, many cards. Done on the parts before they
	   are on the page. */
	function still( root ) {
		var W0 = document.documentElement.clientWidth || window.innerWidth;
		Array.prototype.forEach.call( root.querySelectorAll( 'img[sizes]' ), function ( im ) {
			var v = null;
			( im.getAttribute( 'sizes' ) || '' ).split( ',' ).some( function ( part ) {
				var m = /^\s*(\(.*\))?\s*([\d.]+)(px|vw)\s*$/.exec( part );
				if ( ! m ) {
					return false;
				}
				if ( m[ 1 ] && ! mm( m[ 1 ] ) ) {
					return false;
				}
				v = Math.round( 'vw' === m[ 3 ] ? W0 * parseFloat( m[ 2 ] ) / 100 : parseFloat( m[ 2 ] ) );
				return true;
			} );
			if ( null !== v ) {
				im.setAttribute( 'sizes', v + 'px' );
			}
		} );
		return root;
	}
	function makeGhost( pk ) {
		if ( ! wrap ) {
			return null;
		}
		var t = document.createElement( 'template' );
		t.innerHTML = pk.wrap;
		var g = still( t.content ).firstElementChild;
		if ( ! g ) {
			return null;
		}
		g = document.adoptNode( g );
		g.querySelectorAll( 'script' ).forEach( function ( s ) {
			s.parentNode.removeChild( s );
		} );
		// 2.5.0: its first photo loads now, whatever the page said (a card waiting unseen would not load a lazy one)
		var im = g.querySelector( '.fsz-slides > img' );
		if ( im ) {
			im.setAttribute( 'loading', 'eager' );
		}
		var r = base || wrap.getBoundingClientRect(), dev = wrap.querySelector( '.fsz-device' ), gd = g.querySelector( '.fsz-device' );
		g.classList.add( 'fsz-incoming' );
		g.setAttribute( 'aria-hidden', 'true' );
		g.setAttribute( 'inert', '' );
		g.style.cssText = wrap.style.cssText;
		[ [ 'position', 'fixed' ], [ 'left', r.left + 'px' ], [ 'top', r.top + 'px' ], [ 'right', 'auto' ], [ 'bottom', 'auto' ], [ 'width', r.width + 'px' ], [ 'height', r.height + 'px' ], [ 'margin', '0' ], [ 'z-index', '4' ], [ 'pointer-events', 'none' ], [ 'translate', 'none' ], [ 'transform', 'none' ], [ 'opacity', '0' ], [ 'transition', 'none' ], [ 'scale', '1' ] ].forEach( function ( p ) {
			g.style.setProperty( p[ 0 ], p[ 1 ] );
		} );
		if ( dev && gd ) {
			var u = dev.style.getPropertyValue( '--fsz-u' );
			if ( u ) {
				gd.style.setProperty( '--fsz-u', u );
			}
		}
		g.fszSize = [ r.width, r.height ];
		wrap.parentNode.insertBefore( g, wrap.nextSibling );
		try {
			window.Codex.still( gd );
		} catch ( e ) {}
		return g;
	}

	/* 2.5.0: each neighbour's incoming card is built ahead, once the page is idle: dressed and with its first photo
	   decoded, so a swipe shows it at once and the finger's first move does no heavy work. A card waiting this way is
	   used (take) when its page is the one coming in and the card here still has the size it was built for; otherwise
	   a fresh one is made.
	   2.6.0: a waiting card is not drawn and not even laid out (content-visibility: hidden) until a finger starts to move
	   sideways towards it (warm): then, on a phone, it is drawn right behind the card at 1% (an iPhone draws a new card
	   in parts, so it is whole by the time it shows). 2.5.1 kept both waiting cards drawn all the time: with the card
	   and the moving ones that was up to five cards with their many 3D layers at once, and an iPhone ran out of memory
	   after a few swipes. Now at most two cards are drawn: the one here and, while it moves, the incoming one. */
	var ready = {};
	var CV = !! ( window.CSS && window.CSS.supports && window.CSS.supports( 'content-visibility', 'hidden' ) );
	// The card's first photo, decoded (ready to be drawn). cap: give up waiting after that many ms.
	function decoded( el, cap ) {
		var im = el && el.querySelector( '.fsz-slides > img' ), p;
		if ( ! im ) {
			return Promise.resolve();
		}
		if ( im.decode ) {
			p = im.decode().catch( function () {} );
		} else {
			p = im.complete ? Promise.resolve() : new Promise( function ( ok ) {
				im.addEventListener( 'load', ok );
				im.addEventListener( 'error', ok );
			} );
		}
		return cap ? Promise.race( [ p, new Promise( function ( ok ) {
			window.setTimeout( ok, cap );
		} ) ] ) : p;
	}
	function pinned() {
		return !! ( wrap && 'fixed' === window.getComputedStyle( wrap ).position ); // a phone: the card stays still on the screen
	}
	// Waiting, not drawn (2.6.0: and not laid out).
	function doze( el ) {
		[ 'translate', 'scale', 'transition' ].forEach( function ( k ) {
			el.style.removeProperty( k );
		} );
		el.style.visibility = 'hidden';
		el.style.opacity = '0';
		el.style.zIndex = '4';
		if ( CV ) {
			el.style.setProperty( 'content-visibility', 'hidden' );
		}
		el.fszWarm = false;
	}
	// A finger moves towards it: drawn behind the card at 1% (a phone), so it is whole when it shows.
	function warm( dir ) {
		var r = ready[ dir ];
		if ( ! r || r.el.fszWarm || ! r.el.isConnected ) {
			return;
		}
		r.el.fszWarm = true;
		r.el.style.removeProperty( 'content-visibility' );
		if ( pinned() ) {
			r.el.style.removeProperty( 'visibility' );
			r.el.style.opacity = '0.01';
			r.el.style.zIndex = '1';
		}
		decoded( r.el );
	}
	// The finger let go or went the other way: back to waiting undrawn.
	function cool( dir ) {
		[ 'next', 'prev' ].forEach( function ( k ) {
			var r = ready[ k ];
			if ( r && r.el.fszWarm && k !== dir ) {
				doze( r.el );
			}
		} );
	}
	function unready( dir ) {
		var r = ready[ dir ];
		if ( r ) {
			if ( r.el.parentNode ) {
				r.el.parentNode.removeChild( r.el );
			}
			delete ready[ dir ];
		}
	}
	function prep( dir, pk ) {
		var r = ready[ dir ], u = url( dir );
		if ( ! wrap || ! u || pk.u !== u || ! canSwap() || ( r && r.pk === pk && r.el.isConnected ) || ( ghost && gpk === pk ) ) {
			return;
		}
		if ( going || g ) {
			whenIdle( function () {
				prep( dir, pk );
			}, 600 ); // a finger or a move is busy: later
			return;
		}
		unready( dir );
		var el = makeGhost( pk );
		if ( ! el ) {
			return;
		}
		// laid out (unseen) while it is dressed and its plate is baked (Codex.still, next frame), then put to sleep
		el.style.visibility = 'hidden';
		ready[ dir ] = { pk: pk, el: el };
		decoded( el ).then( function () {
			window.requestAnimationFrame( function () {
				window.requestAnimationFrame( function () {
					var r2 = ready[ dir ];
					if ( r2 && r2.el === el && ! el.fszWarm && ghost !== el ) {
						doze( el );
					}
				} );
			} );
		} );
	}
	function take( dir, pk ) {
		var r = ready[ dir ];
		if ( r && r.pk === pk && r.el.isConnected ) {
			delete ready[ dir ];
			var el = r.el, b = base || wrap.getBoundingClientRect(), dev = wrap.querySelector( '.fsz-device' ), gd = el.querySelector( '.fsz-device' );
			if ( Math.abs( el.fszSize[ 0 ] - b.width ) < 1 && Math.abs( el.fszSize[ 1 ] - b.height ) < 1 ) {
				el.style.left = b.left + 'px';
				el.style.top = b.top + 'px';
				if ( dev && gd && dev.style.getPropertyValue( '--fsz-u' ) ) {
					gd.style.setProperty( '--fsz-u', dev.style.getPropertyValue( '--fsz-u' ) );
				}
				el.style.removeProperty( 'content-visibility' );
				el.style.removeProperty( 'visibility' );
				el.style.opacity = '0';
				el.style.zIndex = '4';
				el.fszWarm = false;
				return el;
			}
			el.parentNode.removeChild( el ); // the card here changed size (a turned phone): a fresh one fits better
		}
		return makeGhost( pk );
	}
	// The incoming card goes back to waiting (the finger turned round, or let go too early).
	function stash() {
		if ( ghost && gpk && gdir && ! ready[ gdir ] && ghost.isConnected ) {
			doze( ghost );
			ready[ gdir ] = { pk: gpk, el: ghost };
			ghost = null;
			gdir = '';
			gpk = null;
			return;
		}
		dropGhost();
	}

	// Where the cards are for a finger at dx (the "Depth" move): the outgoing card follows the finger and steps back,
	// the incoming one comes from its side, growing from behind and getting clearer.
	var W = 360;
	// (2.4.0: without an element, it gives the values only)
	function pose( el, x ) {
		var f = Math.min( 1, Math.abs( x ) / W );
		var v = { translate: Math.round( x ) + 'px 0px', scale: String( Math.round( ( 1 - 0.2 * f ) * 1000 ) / 1000 ), opacity: String( Math.round( ( 1 - 0.55 * f ) * 100 ) / 100 ) };
		if ( el ) {
			el.style.translate = v.translate;
			el.style.scale = v.scale;
			el.style.opacity = v.opacity;
		}
		return v;
	}
	function clear( el ) {
		[ 'transition', 'translate', 'scale', 'opacity' ].forEach( function ( k ) {
			el.style.removeProperty( k );
		} );
	}

	// ==========================================================================
	//  4. The move and the swap
	// ==========================================================================

	var ghost = null, gdir = '', gpk = null, land = null;
	// the card's last glide into its own spot: stopped when a new move starts
	function stopLand() {
		if ( land ) {
			try {
				land.cancel();
			} catch ( e ) {}
			land = null;
		}
	}
	function dropGhost() {
		if ( ghost && ghost.parentNode ) {
			ghost.parentNode.removeChild( ghost );
		}
		ghost = null;
		gdir = '';
		gpk = null;
	}
	function side( dir ) {
		return 'next' === dir ? 1 : -1; // the next species comes from the right
	}
	function ease( dur, how ) {
		how = how || EASE;
		return reduce ? 'opacity .15s' : 'translate ' + dur + 'ms ' + how + ',scale ' + dur + 'ms ' + how + ',opacity ' + dur + 'ms ease';
	}
	function after( ms, f ) {
		window.setTimeout( f, ms + 30 );
	}
	// After the next frame is on screen: the moves started now are already running on their own by then (the browser
	// draws them without this page's script), so the heavy work that follows cannot hold them up.
	function soon( f ) {
		window.requestAnimationFrame( function () {
			window.setTimeout( f, 0 );
		} );
	}
	var now = function () {
		return window.performance && window.performance.now ? window.performance.now() : Date.now();
	};
	// A move with its start time set here (2.4.0): it runs on even while the page is busy, and the page knows where it is.
	function fly( el, to, dur ) {
		var a = el.animate( [ { translate: el.style.translate || '0px', scale: el.style.scale || '1', opacity: el.style.opacity || '1' }, to ], { duration: dur, easing: EASE, fill: 'forwards' } );
		try {
			a.startTime = window.document.timeline.currentTime;
		} catch ( e ) {}
		el.style.translate = to.translate;
		el.style.scale = to.scale;
		el.style.opacity = to.opacity;
		return a;
	}

	/* Go to a neighbour: the outgoing card leaves to one side and steps back while the incoming one comes forward from
	   the other. 2.6.0: nothing else on the page changes while they move; once the incoming card has landed it becomes
	   the card (swap). dx: where the finger let go (0 for a tap or a click). pop: the back or forward button (the
	   address is already there). */
	function go( dir, dx, pop, to ) {
		var u = to || url( dir );
		if ( going || ! u ) {
			return;
		}
		if ( ! canSwap() ) {
			load( dir, u );
			return;
		}
		going = true;
		stopLand();
		if ( ! reduce ) {
			html.classList.add( 'fsz-going' ); // 2.5.0: the price fades out while the next one is on its way (codex.css section 7)
		}
		W = window.innerWidth || 360;
		if ( ! dx || ! base ) {
			base = wrap.getBoundingClientRect(); // a tap or a click: the card has not moved yet
		}
		var s = side( dir ), off = s * ( W + GAP ), p = Math.min( 1, Math.abs( dx ) / W );
		var dur = Math.round( DUR * ( 1 - 0.4 * p ) );
		try {
			window.localStorage.setItem( 'fsz-nb-hint', '1' ); // they know how to move on: no hints
		} catch ( e ) {}
		hintsOff();
		cool( dir );
		// the outgoing card leaves now; the incoming one follows as soon as its page is here (usually already)
		var out = wrap, anims = !! ( out.animate && window.document.timeline );
		if ( ! reduce && anims ) {
			out.style.transition = 'none';
			fly( out, pose( null, -off ), dur );
		} else {
			out.style.transition = ease( dur );
			void out.offsetWidth;
			if ( reduce ) {
				out.style.opacity = '0';
			} else {
				pose( out, -off );
			}
		}
		fetchPack( u ).then( function ( pk ) {
			if ( ! ghost || gdir !== dir || gpk !== pk ) {
				dropGhost();
				ghost = take( dir, pk );
				gdir = dir;
				gpk = pk;
				if ( ghost && ! reduce ) {
					pose( ghost, off + dx );
				}
			}
			if ( ! ghost ) {
				throw new Error( 'no card' );
			}
			var mv = { out: out, anim: null };
			void ghost.offsetWidth;
			if ( reduce || ! anims ) {
				ghost.style.transition = ease( dur );
				void ghost.offsetWidth;
				if ( ! reduce ) {
					pose( ghost, 0 );
				}
				ghost.style.opacity = '1';
			} else {
				ghost.style.transition = 'none';
				mv.anim = fly( ghost, { translate: '0px 0px', scale: '1', opacity: '1' }, dur );
			}
			// 2.5.1: the page changes only once the incoming card has landed: the move has the phone to itself.
			var done = false, run = function () {
				if ( done ) {
					return;
				}
				done = true;
				try {
					swap( pk, u, pop, mv );
				} catch ( err ) {
					if ( window.console ) {
						window.console.error( err );
					}
					window.location.href = u;
				}
			};
			if ( mv.anim && mv.anim.finished ) {
				mv.anim.finished.then( function () {
					soon( run );
				}, function () {
					soon( run );
				} );
			}
			after( dur + 80, run );
		} ).catch( function () {
			load( dir, u );
		} );
	}
	// 2.5.0: the price (and the rest of the drawer row) of the next species fades in once it is there
	function freshPrice() {
		html.classList.remove( 'fsz-going' );
		if ( ! reduce ) {
			html.classList.add( 'fsz-fresh' );
			after( 320, function () {
				html.classList.remove( 'fsz-fresh' );
			} );
		}
	}

	// The body's classes and the product box's classes that came from the server (the rest were added by scripts and stay).
	var srvClass = body.className.split( /\s+/ ).filter( Boolean ), prodClass = null;
	function classes( el, was, now ) {
		was.forEach( function ( c ) {
			if ( now.indexOf( c ) < 0 ) {
				el.classList.remove( c );
			}
		} );
		now.forEach( function ( c ) {
			el.classList.add( c );
		} );
	}
	// The page's own parts of the product box (the text below the card, never the shop theme's own boxes)
	var rest = [];
	function restNow() {
		rest = wrap && wrap.parentNode ? Array.prototype.filter.call( wrap.parentNode.children, own ) : [];
	}
	function frag( text ) {
		var t = document.createElement( 'template' );
		t.innerHTML = text;
		return document.adoptNode( still( t.content ) );
	}

	/* 2.6.0: the swap, once the incoming card has landed exactly where the card is.
	   1. That frame: the old card (gone from view, it has left) is switched off completely (Codex.drop: its timers and
	      listeners, so nothing keeps it in memory) and removed; the incoming card stays where it is and simply becomes
	      the card. No second card, no handover: nothing on the screen changes.
	   2. The next frame: the rest of what changes, all out of sight or unchanged to the eye: the address (pushState),
	      the title and head tags, the drawer's contents (theme swap: only the price shows, it fades in), the edge tabs,
	      the text below; the card comes to life (Codex.setup, already switched on). If the drawer's new contents moved
	      the card's spot by a few px (a species with packs), the card glides there. */
	function swap( pk, u, pop, mv ) {
		var gh = ghost, old = mv.out, pin = pinned();
		if ( ! gh || ! gh.isConnected || ! old || ! old.parentNode ) {
			throw new Error( 'no card' );
		}
		ghost = null;
		gdir = '';
		gpk = null;
		unready( 'next' ); // cards built for the old page's neighbours
		unready( 'prev' );
		var ndev = gh.querySelector( '.fsz-device' ), odev = old.querySelector( '.fsz-device' );
		// the card's own settings from the old card (the fit the drawer and Codex set), without the move
		var keep = [];
		for ( var i = 0; i < old.style.length; i++ ) {
			var k = old.style[ i ];
			if ( ! /^(translate|scale|opacity|transition|transform|will-change|visibility|content-visibility)/.test( k ) ) {
				keep.push( [ k, old.style.getPropertyValue( k ), old.style.getPropertyPriority( k ) ] );
			}
		}
		var spare = old.getAttribute( 'data-fsz-spare' );
		var d0 = ndev.getBoundingClientRect();
		// 1. the old card off and away, the incoming one is the card now
		if ( odev ) {
			window.Codex.drop( odev );
		}
		old.getAnimations && old.getAnimations().forEach( function ( a ) {
			a.cancel();
		} );
		old.parentNode.removeChild( old );
		if ( mv.anim ) {
			try {
				mv.anim.cancel(); // (it ended where the card's own place is: translate 0, scale 1, opacity 1)
			} catch ( e ) {}
		}
		gh.style.cssText = '';
		keep.forEach( function ( p ) {
			gh.style.setProperty( p[ 0 ], p[ 1 ], p[ 2 ] );
		} );
		if ( pin ) {
			gh.style.willChange = 'translate, scale, opacity'; // it stays its own picture on the phone (no redraw)
		}
		if ( null !== spare ) {
			gh.setAttribute( 'data-fsz-spare', spare );
		}
		gh.classList.remove( 'fsz-incoming' );
		gh.removeAttribute( 'aria-hidden' );
		gh.removeAttribute( 'inert' );
		ndev.setAttribute( 'data-fsz-calm', '' );
		wrap = gh;
		base = null;
		// the address now (the back button, a shared link), the rest next frame
		if ( ! pop ) {
			step++;
			window.history.pushState( { fsz: step }, '', u );
		}
		soon( function () {
			try {
				page( pk, u, d0 );
			} catch ( err ) {
				if ( window.console ) {
					window.console.error( err );
				}
				window.location.reload();
			}
		} );
	}

	function page( pk, u, d0 ) {
		var nw = wrap, ndev = nw.querySelector( '.fsz-device' ), prod = nw.parentNode;
		document.dispatchEvent( new window.CustomEvent( 'fsz:swap', { detail: { url: u } } ) );
		// the page settings that changed (the theme's window.izlProduct: this species' price for the guess …)
		pk.extra.forEach( function ( x ) {
			var mine = document.getElementById( x[ 0 ] );
			if ( mine && mine.text === x[ 1 ] ) {
				return;
			}
			runInline( x[ 1 ] );
			if ( mine ) {
				mine.text = x[ 1 ];
			}
		} );
		// body and product box classes, title, head tags
		var cls = pk.body.replace( /\bwoocommerce-no-js\b/, 'woocommerce-js' ).split( /\s+/ ).filter( Boolean );
		classes( body, srvClass, cls );
		srvClass = cls;
		var pc = null;
		pk.attrs.forEach( function ( a ) {
			if ( 'class' === a[ 0 ] ) {
				pc = a[ 1 ].split( /\s+/ ).filter( Boolean );
			} else if ( prod.getAttribute( a[ 0 ] ) !== a[ 1 ] ) {
				prod.setAttribute( a[ 0 ], a[ 1 ] );
			}
		} );
		if ( pc ) {
			classes( prod, prodClass || [], pc );
			prodClass = pc;
		}
		document.title = pk.title;
		HEAD.forEach( function ( sel, i ) {
			var old = document.head.querySelectorAll( sel ), at = old.length ? old[ old.length - 1 ].nextSibling : null;
			old.forEach( function ( n ) {
				n.parentNode.removeChild( n );
			} );
			pk.head[ i ].forEach( function ( h ) {
				document.head.insertBefore( frag( h ), at );
			} );
		} );
		// the drawer's (or the computer's buy box's) contents: the theme puts them in place
		var t = document.createElement( 'template' );
		t.innerHTML = pk.sum;
		var nsum = document.adoptNode( still( t.content ).firstElementChild );
		if ( ! window.izlProductPage.swap( nsum, nw ) ) {
			throw new Error( 'no summary' );
		}
		freshPrice();
		// the edge tabs (Vissza / Előre: the same tabs, the next numbers), the text below the card, the notices and the
		// breadcrumb, the footer's sticky buy bar
		var tabs = document.querySelector( '.fsz-swipe' );
		if ( tabs && pk.nav ) {
			tabs.parentNode.replaceChild( frag( pk.nav ), tabs );
		}
		// each new part takes the place of the old one in the same spot (some sit before the summary, some after it, and
		// the computer's two columns depend on that order); extra new parts follow the last one placed
		var news = frag( pk.rest.join( '' ) ), nn = Array.prototype.slice.call( news.children ), last = null;
		var olds = rest.filter( function ( n ) {
			return n.parentNode === prod;
		} );
		nn.forEach( function ( n, i ) {
			var o = olds[ i ];
			if ( o ) {
				prod.replaceChild( n, o );
			} else {
				prod.insertBefore( n, last ? last.nextSibling : null );
			}
			last = n;
		} );
		olds.slice( nn.length ).forEach( function ( n ) {
			n.parentNode.removeChild( n );
		} );
		rest.forEach( function ( n ) {
			if ( n.parentNode && nn.indexOf( n ) < 0 ) {
				n.parentNode.removeChild( n );
			}
		} );
		rest = nn;
		var $ = window.jQuery;
		if ( $ && nn.length ) {
			$( nn ).find( '.wc-tabs-wrapper, .woocommerce-tabs, #rating' ).addBack( '.wc-tabs-wrapper, .woocommerce-tabs' ).trigger( 'init' );
		}
		document.querySelectorAll( '#content .woocommerce-notices-wrapper' ).forEach( function ( n, i ) {
			var h = pk.notices[ i ] || '';
			if ( n.innerHTML !== h ) {
				n.innerHTML = h;
			}
		} );
		var crumb = document.querySelector( '.storefront-breadcrumb' );
		if ( crumb && null !== pk.crumb && crumb.innerHTML !== pk.crumb ) {
			crumb.innerHTML = pk.crumb;
		}
		// (a sold-out species has none: its bar goes; Storefront's scroll check reads a live list, so a new bar works, and
		// its "pick options" button scrolls to the species as on a page load)
		var sticky = document.querySelector( '.storefront-sticky-add-to-cart' ), foot = document.querySelector( '#colophon' );
		if ( pk.sticky ) {
			var ns = frag( pk.sticky ).firstElementChild;
			if ( sticky ) {
				sticky.parentNode.replaceChild( ns, sticky );
			} else if ( foot ) {
				foot.parentNode.insertBefore( ns, foot.nextSibling );
			}
			var sb = ns && ns.querySelector( '.storefront-sticky-add-to-cart__content-button' );
			if ( sb && ! prod.matches( '.product-type-simple,.product-type-external' ) ) {
				sb.addEventListener( 'click', function ( e ) {
					e.preventDefault();
					prod.scrollIntoView();
				} );
			}
		} else if ( sticky ) {
			sticky.parentNode.removeChild( sticky );
		}
		// the card comes to life (already switched on: no wake-up)
		window.Codex.setup( ndev );
		if ( window.fszFit ) {
			window.fszFit();
		}
		bind();
		place();
		watch();
		hintsLater();
		// keep only the new neighbours' packets
		var keepP = {};
		[ url( 'next' ), url( 'prev' ) ].forEach( function ( k ) {
			if ( packs[ k ] ) {
				keepP[ k ] = packs[ k ];
			}
		} );
		packs = keepP;
		// the drawer's new contents may have moved the card's spot a little (a species with packs): it glides there
		var d1 = ndev.getBoundingClientRect(), ms = 0;
		if ( ! reduce && d1.width && d0.width && ( Math.abs( d1.left - d0.left ) > 0.5 || Math.abs( d1.top - d0.top ) > 0.5 || Math.abs( d1.width - d0.width ) > 0.5 ) && nw.animate ) {
			var r = nw.getBoundingClientRect(), s = d0.width / d1.width;
			var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
			var tx = ( d0.left + d0.width / 2 ) - cx - s * ( ( d1.left + d1.width / 2 ) - cx );
			var ty = ( d0.top + d0.height / 2 ) - cy - s * ( ( d1.top + d1.height / 2 ) - cy );
			ms = 220;
			land = nw.animate( [ { translate: Math.round( tx * 10 ) / 10 + 'px ' + Math.round( ty * 10 ) / 10 + 'px', scale: String( Math.round( s * 10000 ) / 10000 ) }, { translate: '0px 0px', scale: '1' } ], { duration: ms, easing: EASE } );
			try {
				land.startTime = window.document.timeline.currentTime;
			} catch ( e ) {}
		}
		going = false;
		idle( 300 + ms );
	}

	// ==========================================================================
	//  5. The swipe (finger only)
	// ==========================================================================

	/* Phones and touch screens only (a mouse never swipes; PC has the side cards). Anywhere on the page except the top
	   bar, the open drawer, fields, a card being edited, the photo when the card has several (a swipe there changes the
	   photo) and the photo pop-out. Only a clear sideways move counts: the first 10 px decide, mostly up or down stays the
	   page's (the drawer). Only translate, scale and opacity change while the card moves. */
	var g = null, raf = 0, block = false;
	// a row that scrolls sideways itself (a tablet's product rows) keeps its own swipe
	function sideScroller( t ) {
		for ( var el = t; el && el !== body && el.nodeType === 1; el = el.parentNode ) {
			if ( el.scrollWidth > el.clientWidth + 1 && /auto|scroll/.test( window.getComputedStyle( el ).overflowX ) ) {
				return true;
			}
		}
		return false;
	}
	function skip( t ) {
		return ! t.closest || sideScroller( t ) || !! ( body.classList.contains( 'izl-open' ) || body.classList.contains( 'izl-popon' ) || document.querySelector( '.fsz-device.is-editing' ) || t.closest( '.site-header,#wpadminbar,.izl-drawer,.izl-pop,.fsz-incoming,input,textarea,select,[contenteditable],.fsz-photo[role=button]' ) );
	}
	function paint() {
		raf = 0;
		if ( ! g || ! g.on ) {
			return;
		}
		pose( wrap, g.dx );
		var dir = g.dx < 0 ? 'next' : 'prev';
		if ( ghost && gdir !== dir ) {
			stash();
		}
		cool( dir ); // 2.6.0: only the card coming in is drawn
		if ( ! ghost && g.packs[ dir ] ) {
			ghost = take( dir, g.packs[ dir ] );
			gdir = dir;
			gpk = g.packs[ dir ];
		}
		if ( ghost ) {
			pose( ghost, side( dir ) * ( W + GAP ) + g.dx );
		}
	}
	// p: one finger's place, from a touch or a pointer event: { id, x, y, t }
	function move( p, e ) {
		if ( ! g || p.id !== g.id ) {
			return;
		}
		var dx = p.x - g.x, dy = p.y - g.y;
		if ( ! g.on ) {
			if ( Math.abs( dx ) < 10 && Math.abs( dy ) < 10 ) {
				// 2.4.0: still deciding; a finger that so far goes more sideways than up or down keeps the page still
				// (iPhone: once the page starts to scroll, the finger is the browser's for the rest of the touch)
				if ( e && e.cancelable && Math.abs( dx ) > Math.abs( dy ) * 2 && Math.abs( dx ) > 2 ) {
					e.preventDefault();
					warm( dx < 0 ? 'next' : 'prev' ); // 2.6.0: the card it may bring is drawn now, unseen (section 3)
				}
				return;
			}
			if ( Math.abs( dx ) < Math.abs( dy ) * 1.5 || ! wrap || ( e && 'cancelable' in e && ! e.cancelable ) ) {
				g = null; // up or down (or the page is already scrolling): not a swipe
				cool( '' );
				return;
			}
			g.on = true;
			stopLand();
			W = window.innerWidth || 360;
			base = wrap.getBoundingClientRect();
			html.classList.add( 'fsz-dragging' );
			wrap.style.transition = 'none';
			// both neighbours' pages (usually fetched already): the incoming card appears as soon as one is here
			var gs = g;
			[ 'next', 'prev' ].forEach( function ( dir ) {
				var u = url( dir );
				if ( u ) {
					fetchPack( u ).then( function ( pk ) {
						gs.packs[ dir ] = pk;
						if ( g === gs && ! raf ) {
							raf = window.requestAnimationFrame( paint );
						}
					}, function () {} );
				}
			} );
		}
		if ( e && e.cancelable ) {
			e.preventDefault(); // the finger is ours now: the page does not scroll under it
		}
		g.dx = dx;
		g.hist.push( [ p.t, p.x ] );
		if ( g.hist.length > 5 ) {
			g.hist.shift();
		}
		if ( ! raf ) {
			raf = window.requestAnimationFrame( paint );
		}
	}
	function end( p, cancel ) {
		if ( ! g || p.id !== g.id ) {
			return;
		}
		var was = g;
		g = null;
		if ( ! was.on ) {
			cool( '' );
			return;
		}
		html.classList.remove( 'fsz-dragging' );
		if ( raf ) {
			window.cancelAnimationFrame( raf );
			raf = 0;
		}
		var h = was.hist, v = 0, dx = was.dx;
		if ( h.length > 1 ) {
			v = ( h[ h.length - 1 ][ 1 ] - h[ 0 ][ 1 ] ) / Math.max( 1, h[ h.length - 1 ][ 0 ] - h[ 0 ][ 0 ] ); // px per ms, the last moves
		}
		block = true; // the click a finger sends after the drag (on Leírás, a badge …) is not a click
		window.setTimeout( function () {
			block = false;
		}, 350 );
		if ( ! cancel && ( Math.abs( dx ) > Math.min( 110, W * 0.3 ) || ( Math.abs( dx ) > 36 && Math.abs( v ) > 0.45 && ( v < 0 ) === ( dx < 0 ) ) ) ) {
			go( dx < 0 ? 'next' : 'prev', dx );
			return;
		}
		// not far or fast enough: both cards back to their places
		wrap.style.transition = ease( 300 );
		pose( wrap, 0 );
		var gh = ghost;
		if ( gh ) {
			gh.style.transition = ease( 300 );
			pose( gh, side( gdir ) * ( W + GAP ) );
		}
		after( 300, function () {
			if ( ! g && ! going ) {
				clear( wrap );
				if ( gh === ghost ) {
					stash();
				}
			}
		} );
	}
	function begin( p, t ) {
		if ( going || ( g && g.on ) || ! wrap || skip( t ) ) {
			return;
		}
		g = { id: p.id, x: p.x, y: p.y, dx: 0, on: false, hist: [ [ p.t, p.x ] ], packs: {} };
	}
	/* 2.4.0: a finger is followed with touch events where the browser has them (iPhone: with pointer events Safari took
	   the finger back after a few pixels, pointercancel, and the card stopped); a pen (or a touch screen without touch
	   events) with pointer events. */
	var TOUCH = 'ontouchstart' in window;
	function tp( e ) {
		var k = e.changedTouches && e.changedTouches[ 0 ];
		return k ? { id: k.identifier, x: k.clientX, y: k.clientY, t: e.timeStamp } : null;
	}
	if ( TOUCH ) {
		document.addEventListener( 'touchstart', function ( e ) {
			var p = tp( e );
			if ( ! p || e.touches.length > 1 ) {
				g = null; // two fingers: a pinch, not a swipe
				return;
			}
			begin( p, e.target );
		}, { passive: true } );
		document.addEventListener( 'touchmove', function ( e ) {
			if ( ! g ) {
				return;
			}
			for ( var i = 0; i < e.changedTouches.length; i++ ) {
				var k = e.changedTouches[ i ];
				if ( k.identifier === g.id ) {
					move( { id: k.identifier, x: k.clientX, y: k.clientY, t: e.timeStamp }, e );
					return;
				}
			}
		}, { passive: false } );
		var tEnd = function ( e ) {
			if ( ! g ) {
				return;
			}
			for ( var i = 0; i < e.changedTouches.length; i++ ) {
				var k = e.changedTouches[ i ];
				if ( k.identifier === g.id ) {
					end( { id: k.identifier }, 'touchcancel' === e.type );
					return;
				}
			}
		};
		document.addEventListener( 'touchend', tEnd );
		document.addEventListener( 'touchcancel', tEnd );
	}
	var pp = function ( e ) {
		return { id: 'p' + e.pointerId, x: e.clientX, y: e.clientY, t: e.timeStamp };
	};
	document.addEventListener( 'pointerdown', function ( e ) {
		if ( ! e.isPrimary || 'mouse' === e.pointerType || ( TOUCH && 'touch' === e.pointerType ) ) {
			return;
		}
		begin( pp( e ), e.target );
	}, { passive: true } );
	document.addEventListener( 'pointermove', function ( e ) {
		if ( g && 'string' === typeof g.id ) {
			move( pp( e ), null );
		}
	}, { passive: true } );
	[ 'pointerup', 'pointercancel' ].forEach( function ( k ) {
		document.addEventListener( k, function ( e ) {
			if ( g && 'string' === typeof g.id ) {
				end( pp( e ), 'pointercancel' === e.type );
			}
		} );
	} );
	document.addEventListener( 'click', function ( e ) {
		if ( block ) {
			e.preventDefault();
			e.stopPropagation();
		}
	}, true );
	// A finger moving sideways is ours; up and down stay the browser's (the drawer, the page).
	html.classList.add( 'fsz-swipe-on' );

	// ==========================================================================
	//  6. Side cards, arrows, the back button
	// ==========================================================================

	// The side cards (PC) and the edge tabs (phone) are plain links: a click moves in place (a new tab or window stays
	// a normal link).
	document.addEventListener( 'click', function ( e ) {
		var a = e.target.closest && e.target.closest( '.fsz-nb' );
		if ( ! a || e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey ) {
			return;
		}
		e.preventDefault();
		go( a.classList.contains( 'fsz-nb-prev' ) ? 'prev' : 'next', 0 );
	} );
	// 2.4.0: a pointer over a side card or a tab fetches that species' page right away (if it is not here yet), so the
	// incoming card is ready when the click comes
	document.addEventListener( 'pointerover', function ( e ) {
		var a = e.target.closest && e.target.closest( '.fsz-nb' );
		if ( a && ! going && canSwap() ) {
			var u = url( a.classList.contains( 'fsz-nb-prev' ) ? 'prev' : 'next' );
			if ( u ) {
				fetchPack( u ).catch( function () {} );
			}
		}
	}, { passive: true } );
	// PC: the arrow keys (not while typing, not with the photo pop-out open)
	document.addEventListener( 'keydown', function ( e ) {
		if ( ( 'ArrowLeft' !== e.key && 'ArrowRight' !== e.key ) || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey || e.defaultPrevented ) {
			return;
		}
		var t = e.target;
		if ( ! mm( '(hover: hover) and (pointer: fine)' ) || ( t && t.closest && t.closest( 'input,textarea,select,[contenteditable],.izl-pop,.fsz-photo' ) ) || body.classList.contains( 'izl-popon' ) || ! nav || ! window.getComputedStyle( nav ).display || 'none' === window.getComputedStyle( nav ).display ) {
			return;
		}
		go( 'ArrowRight' === e.key ? 'next' : 'prev', 0 );
	} );
	// Back and forward between swapped species: the same move, the way back from the left.
	window.addEventListener( 'popstate', function ( e ) {
		var st = e.state;
		if ( ! st || 'number' !== typeof st.fsz ) {
			return;
		}
		if ( going ) {
			window.location.reload();
			return;
		}
		var dir = st.fsz < step ? 'prev' : 'next';
		step = st.fsz;
		go( dir, 0, true, window.location.href.split( '#' )[ 0 ] );
	} );
	try {
		window.history.replaceState( Object.assign( {}, window.history.state || {}, { fsz: step } ), '' );
	} catch ( e ) {}
	// Back to this page from the browser's memory: everything in its place.
	window.addEventListener( 'pageshow', function ( e ) {
		if ( e.persisted ) {
			going = false;
			g = null;
			dropGhost();
			unready( 'next' );
			unready( 'prev' );
			if ( wrap ) {
				clear( wrap );
			}
			html.removeAttribute( 'data-fsz-swipe' );
			html.classList.remove( 'fsz-dragging' );
		}
	} );

	// ==========================================================================
	//  7. PC: first-visit hints on the side cards
	// ==========================================================================

	/* A new visitor on PC (side cards showing) who has not used them: after 12 seconds on the page (counted only while the
	   tab is in front), faint "előző" and "következő" labels fade in next to the side cards for a few seconds, and from
	   then the side cards nudge inwards every 9 seconds until one is hovered or used. Once per visitor (localStorage
	   fsz-nb-hint). The look: codex.css section 7 (.is-hint, .is-nudge). */
	var HINT_AT = 12000, NUDGE_EVERY = 9000;
	var seen = 0, tick = 0, nudgeT = 0, hinted = false, lastT = 0;
	function told() {
		try {
			return !! window.localStorage.getItem( 'fsz-nb-hint' );
		} catch ( e ) {
			return true; // storage blocked: never nag
		}
	}
	function peeks() {
		return mm( '(min-width: 1200px) and (hover: hover) and (pointer: fine)' ) && nav && ! nav.classList.contains( 'is-away' );
	}
	function nudge() {
		if ( ! nav || ! hinted ) {
			return;
		}
		nav.classList.remove( 'is-nudge' );
		void nav.offsetWidth;
		nav.classList.add( 'is-nudge' );
		nudgeT = window.setTimeout( nudge, NUDGE_EVERY );
	}
	function hintsOff() {
		window.clearInterval( tick );
		window.clearTimeout( nudgeT );
		tick = 0;
		hinted = false;
		if ( nav ) {
			nav.classList.remove( 'is-hint', 'is-nudge' );
		}
	}
	function hintsLater() {
		if ( reduce || told() || tick || hinted ) {
			return;
		}
		lastT = Date.now();
		tick = window.setInterval( function () {
			var now = Date.now();
			if ( ! document.hidden && peeks() ) {
				seen += now - lastT;
			}
			lastT = now;
			if ( seen < HINT_AT ) {
				return;
			}
			window.clearInterval( tick );
			tick = 0;
			try {
				window.localStorage.setItem( 'fsz-nb-hint', '1' );
			} catch ( e ) {}
			hinted = true;
			nav.classList.add( 'is-hint' );
			nudge();
		}, 250 );
	}
	document.addEventListener( 'pointerover', function ( e ) {
		if ( hinted && e.target.closest && e.target.closest( '.fsz-nb' ) ) {
			window.clearTimeout( nudgeT );
			hinted = false;
			nav.classList.remove( 'is-nudge' );
		}
	} );

	// ==========================================================================
	//  8. Where the phone tabs sit
	// ==========================================================================

	// Phone (the card stays still on the screen): at the card's mid-height, so the tabs are never under the buy drawer.
	// Elsewhere at the window's mid-height, faded out while the card is mostly scrolled away.
	function place() {
		if ( ! nav || ! wrap ) {
			return;
		}
		if ( 'fixed' !== window.getComputedStyle( wrap ).position ) {
			nav.style.removeProperty( '--fsz-swipe-y' );
			return;
		}
		var d = wrap.querySelector( '.fsz-device' ), r = ( d || wrap ).getBoundingClientRect();
		if ( r.height ) {
			nav.style.setProperty( '--fsz-swipe-y', Math.round( r.top + r.height / 2 ) + 'px' );
		}
	}
	document.addEventListener( 'fsz:fit', function ( e ) {
		if ( ! e.target || ! e.target.classList || ! e.target.classList.contains( 'fsz-incoming' ) ) {
			place();
		}
	} );
	window.addEventListener( 'resize', function () {
		window.requestAnimationFrame( place );
	} );
	var io = null;
	function watch() {
		if ( ! ( 'IntersectionObserver' in window ) || ! wrap ) {
			return;
		}
		if ( io ) {
			io.disconnect();
		}
		io = new window.IntersectionObserver( function ( en ) {
			if ( nav ) {
				nav.classList.toggle( 'is-away', en[ en.length - 1 ].intersectionRatio < 0.3 );
			}
		}, { threshold: [ 0, 0.3 ] } );
		io.observe( wrap );
	}

	// ==========================================================================
	//  9. Start
	// ==========================================================================

	function start() {
		bind();
		restNow();
		if ( wrap && wrap.parentNode ) {
			prodClass = wrap.parentNode.className.split( /\s+/ ).filter( Boolean );
		}
		place();
		watch();
		hintsLater();
		if ( 'complete' === document.readyState ) {
			idle( 2000 );
		} else {
			window.addEventListener( 'load', function () {
				idle( 2000 );
			} );
		}
		// The slide mark of a normal page load has done its job once the page is on screen.
		window.setTimeout( function () {
			if ( ! going ) {
				html.removeAttribute( 'data-fsz-swipe' );
			}
		}, 1500 );
	}
	if ( document.prerendering ) {
		document.addEventListener( 'prerenderingchange', start, { once: true } );
	} else {
		start();
	}
} )();
