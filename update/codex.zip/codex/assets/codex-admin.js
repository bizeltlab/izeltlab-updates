// ==========================================================================
//  FILE: assets/codex-admin.js   (Codex plugin)
//  WHAT: DASHBOARD. The Codex settings page: list editors, colour pickers, the live preview.
//  SEEN: Dashboard → WooCommerce → Codex.
// ==========================================================================

/* Codex settings page: sortable lists (power bars, detail sections), category notes, the 3D tilt value,
   colour pickers and the live preview, which renders the card with the settings as they are on the page. */
jQuery( function ( $ ) {
	var form = $( '#fsz-settings-form' );
	var preview = $( '#fsz-preview' );
	var product = $( '#fsz-preview-product' );
	var timer = 0, request = null, rows = 0;

	// ---- live preview
	function render() {
		if ( ! preview.length || ! product.val() ) {
			return;
		}
		if ( request ) {
			request.abort();
		}
		// Everything in the form except WordPress' own fields, which belong to options.php.
		var data = form.serializeArray().filter( function ( f ) {
			return 0 === f.name.indexOf( 'fsz_settings[' );
		} );
		data.push( { name: 'action', value: 'fsz_preview' }, { name: 'nonce', value: CodexAdmin.nonce }, { name: 'product', value: product.val() } );
		preview.addClass( 'is-loading' );
		request = $.post( CodexAdmin.ajax, $.param( data ) ).done( function ( res ) {
			if ( res && res.success ) {
				preview.html( res.data.html );
				var card = preview.find( '.fsz-device' )[ 0 ];
				if ( card && window.Codex && window.Codex.setup ) {
					window.Codex.setup( card );
				}
			}
		} ).always( function () {
			preview.removeClass( 'is-loading' );
			request = null;
		} );
	}
	function later() {
		window.clearTimeout( timer );
		timer = window.setTimeout( render, 350 );
	}
	product.on( 'change', function () {
		$( '#fsz-preview-link' ).attr( 'href', product.find( ':selected' ).data( 'url' ) );
		render();
	} );
	form.on( 'input change', 'input, select', function ( e ) {
		if ( e.target !== product[ 0 ] ) {
			later();
		}
	} );

	// ---- lists: drag to sort, add, remove, bring back saved values
	function addRow( list, key, label, count ) {
		var tpl = list.find( '.fsz-row-tpl' ).html().split( '__i__' ).join( 'n' + ( rows++ ) );
		var row = $( $.parseHTML( $.trim( tpl ) ) );
		row.find( '.fsz-row-key' ).val( key || '' );
		row.find( '.fsz-row-label' ).val( label || '' );
		if ( count ) {
			row.find( '.fsz-row-count' ).text( count ).removeClass( 'is-empty' );
		}
		list.find( '.fsz-rows' ).append( row );
		return row;
	}
	$( '.fsz-list' ).each( function () {
		var list = $( this );
		list.find( '.fsz-rows' ).sortable( {
			handle: '.fsz-handle',
			axis: 'y',
			containment: 'parent',
			tolerance: 'pointer',
			placeholder: 'fsz-row-placeholder',
			forcePlaceholderSize: true,
			update: later
		} );
		list.on( 'click', '.fsz-add', function () {
			addRow( list ).find( '.fsz-row-label' ).trigger( 'focus' );
		} );
		list.on( 'click', '.fsz-row-remove', function () {
			$( this ).closest( '.fsz-row' ).remove();
			later();
		} );
		list.on( 'click', '.fsz-chip', function () {
			var chip = $( this );
			addRow( list, chip.data( 'key' ), chip.data( 'label' ), chip.data( 'count' ) ).find( '.fsz-row-label' ).trigger( 'focus' ).trigger( 'select' );
			chip.remove();
			if ( ! list.find( '.fsz-chip' ).length ) {
				list.find( '.fsz-lost' ).remove();
			}
			later();
		} );
	} );
	// Enter in a list name would submit the form: add the next row instead.
	form.on( 'keydown', '.fsz-row-label', function ( e ) {
		if ( 'Enter' === e.key ) {
			e.preventDefault();
			addRow( $( this ).closest( '.fsz-list' ) ).find( '.fsz-row-label' ).trigger( 'focus' );
		}
	} );

	// ---- categories: a ticked category includes its subcategories
	function cats() {
		$( '.fsz-cats input' ).each( function () {
			var inherited = $( this ).closest( 'ul' ).closest( 'li' ).parents( 'li' ).addBack().children( 'label' ).find( 'input:checked' ).length > 0;
			$( this ).closest( 'label' ).toggleClass( 'is-included', inherited && ! this.checked );
		} );
		$( '#fsz-cats-none' ).prop( 'hidden', $( '.fsz-cats input:checked' ).length > 0 );
	}
	form.on( 'change', '.fsz-cats input', cats );
	cats();

	// ---- 3D tilt value
	$( '#fsz-tilt' ).on( 'input', function () {
		$( '#fsz-tilt-val' ).text( this.value );
	} );

	// ---- colours
	$( '.fsz-color' ).wpColorPicker( {
		palettes: CodexAdmin.palettes,
		change: later,
		clear: later
	} );
} );
