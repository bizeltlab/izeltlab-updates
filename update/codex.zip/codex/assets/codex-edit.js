/* Codex quick edit: change the card right on the product page. Loaded only for people who may edit the product. */
(function () {
	var cfg = window.CodexEdit;
	if ( ! cfg || ! document.querySelector || ! window.fetch ) {
		return;
	}

	var HINT = 'Click a text, bar or the gauge to change it. Click the photo for the photos, its corner for the badge, the spot over the bar names for the badges, the Codex body for its colour.';
	var s = null; // the running edit session

	function el( tag, cls, text ) {
		var e = document.createElement( tag );
		if ( cls ) {
			e.className = cls;
		}
		if ( text ) {
			e.textContent = text;
		}
		return e;
	}

	function button( cls, text, act ) {
		var b = el( 'button', 'fsz-btn' + ( cls ? ' ' + cls : '' ), text );
		b.type = 'button';
		if ( act ) {
			b.setAttribute( 'data-fsz-act', act );
		}
		return b;
	}

	function clean( text ) {
		return text.replace( /\u00ad/g, '' ).replace( /\u00a0/g, ' ' ).replace( /\s+/g, ' ' ).trim();
	}

	// A detail page text keeps its line breaks: <br> and new blocks count as one.
	function readMulti( f ) {
		var out = '';
		( function walk( node ) {
			for ( var c = node.firstChild; c; c = c.nextSibling ) {
				if ( 3 === c.nodeType ) {
					out += c.nodeValue;
				} else if ( 'BR' === c.nodeName ) {
					out += '\n';
				} else {
					if ( /^(DIV|P)$/.test( c.nodeName ) && out && '\n' !== out.slice( -1 ) ) {
						out += '\n';
					}
					walk( c );
				}
			}
		} )( f );
		return out.replace( /\u00a0/g, ' ' ).replace( /[ \t]+\n/g, '\n' ).replace( /\n{3,}/g, '\n\n' ).trim();
	}

	function value( f ) {
		if ( f.hasAttribute( 'data-fsz-rich' ) ) {
			return marks( model( f ).chars );
		}
		return f.hasAttribute( 'data-multiline' ) ? readMulti( f ) : clean( f.textContent );
	}

	// What the shopper reads: the text without its formatting marks.
	function visible( f ) {
		return f.hasAttribute( 'data-fsz-rich' ) ? model( f ).chars.map( function ( c ) {
			return c.ch;
		} ).join( '' ) : value( f );
	}

	/* ---------------------------------------------------------------- formatting (1.52.0): bold, italic, underline, colour */

	// Saved as marks, the same as codex.php fsz_mark_runs(): **bold**, [i]…[/i], [u]…[/u], [red]…[/red].
	var COLORS = [ 'blue', 'green', 'amber', 'red', 'group' ];

	/*
	 * The field as letters, each with its style: { ch, b, i, u, c }. Line breaks (<br>, new blocks) are '\n' in a
	 * multi-line field. With at = [ node, offset ] it also tells which letter that point of the selection is before.
	 */
	function model( f, at ) {
		var chars = [];
		var pos = ( at || [] ).map( function () {
			return undefined;
		} );
		var multi = f.hasAttribute( 'data-multiline' );
		function mark( node, offset ) {
			each( at || [], function ( p, k ) {
				if ( undefined === pos[ k ] && p[ 0 ] === node && p[ 1 ] === offset ) {
					pos[ k ] = chars.length;
				}
			} );
		}
		function add( ch, st ) {
			chars.push( { ch: ch, b: st.b, i: st.i, u: st.u, c: st.c } );
		}
		( function walk( node, st ) {
			var i = 0;
			for ( var c = node.firstChild; c; c = c.nextSibling, i++ ) {
				mark( node, i );
				if ( 3 === c.nodeType ) {
					var t = c.nodeValue;
					for ( var j = 0; j < t.length; j++ ) {
						mark( c, j );
						add( t[ j ], st );
					}
					mark( c, t.length );
				} else if ( 'BR' === c.nodeName ) {
					add( '\n', st );
				} else if ( 1 === c.nodeType ) {
					if ( /^(DIV|P)$/.test( c.nodeName ) && chars.length && '\n' !== chars[ chars.length - 1 ].ch ) {
						add( '\n', st );
					}
					var n = c.nodeName;
					var dc = c.getAttribute( 'data-c' );
					walk( c, {
						b: st.b || 'STRONG' === n || 'B' === n,
						i: st.i || 'EM' === n || 'I' === n,
						u: st.u || 'U' === n,
						c: dc && COLORS.indexOf( dc ) >= 0 ? dc : st.c
					} );
				}
			}
			mark( node, i );
		} )( f, { b: false, i: false, u: false, c: '' } );
		// The same clean-up as plain fields: no soft hyphens, one space at a time, one line unless multi-line.
		var out = [];
		var map = []; // raw letter index -> cleaned index, for the selection
		each( chars, function ( c, k ) {
			map[ k ] = out.length;
			var ch = '\u00ad' === c.ch ? '' : ( '\u00a0' === c.ch || '\t' === c.ch || ( '\n' === c.ch && ! multi ) ? ' ' : c.ch );
			var prev = out[ out.length - 1 ];
			if ( ' ' === ch && ( ! prev || ' ' === prev.ch || '\n' === prev.ch ) ) {
				ch = '';
			}
			if ( '\n' === ch && prev && ' ' === prev.ch ) {
				out.pop();
			}
			if ( ch ) {
				out.push( { ch: ch, b: c.b, i: c.i, u: c.u, c: c.c } );
			}
		} );
		map[ chars.length ] = out.length;
		while ( out.length && /[ \n]/.test( out[ out.length - 1 ].ch ) ) {
			out.pop();
		}
		pos = pos.map( function ( p ) {
			return Math.min( undefined === p ? out.length : map[ p ], out.length );
		} );
		return { chars: out, pos: pos };
	}

	function same( a, b ) {
		return a.b === b.b && a.i === b.i && a.u === b.u && a.c === b.c;
	}

	// Letters to marks: the colour outside, then bold, italic, underline, with as few marks as needed.
	function marks( chars ) {
		var out = '';
		var open = [ '', false, false, false ];
		var tags = [ null, [ '**', '**' ], [ '[i]', '[/i]' ], [ '[u]', '[/u]' ] ];
		function close( from ) {
			for ( var j = 3; j >= from; j-- ) {
				if ( open[ j ] ) {
					out += 0 === j ? '[/' + open[ 0 ] + ']' : tags[ j ][ 1 ];
				}
			}
		}
		each( chars, function ( c ) {
			var want = [ c.c, c.b, c.i, c.u ];
			var lvl = 0;
			while ( lvl < 4 && want[ lvl ] === open[ lvl ] ) {
				lvl++;
			}
			close( lvl );
			for ( var j = lvl; j < 4; j++ ) {
				if ( want[ j ] ) {
					out += 0 === j ? '[' + want[ 0 ] + ']' : tags[ j ][ 0 ];
				}
			}
			open = want;
			out += c.ch;
		} );
		close( 0 );
		return out;
	}

	// Letters back into the field, as <strong>, <em>, <u> and coloured <span>s; line breaks as <br>.
	function render( f, chars ) {
		f.textContent = '';
		var i = 0;
		while ( i < chars.length ) {
			var j = i;
			var text = '';
			while ( j < chars.length && same( chars[ j ], chars[ i ] ) ) {
				text += chars[ j ].ch;
				j++;
			}
			var c = chars[ i ];
			var node = document.createDocumentFragment();
			text.split( '\n' ).forEach( function ( line, k ) {
				if ( k ) {
					node.appendChild( document.createElement( 'br' ) );
				}
				if ( line ) {
					node.appendChild( document.createTextNode( line ) );
				}
			} );
			[ [ c.u, 'u' ], [ c.i, 'em' ], [ c.b, 'strong' ] ].forEach( function ( w ) {
				if ( w[ 0 ] ) {
					var e = document.createElement( w[ 1 ] );
					e.appendChild( node );
					node = e;
				}
			} );
			if ( c.c ) {
				var sp = el( 'span', 'fsz-c-' + c.c );
				sp.setAttribute( 'data-c', c.c );
				sp.appendChild( node );
				node = sp;
			}
			f.appendChild( node );
			i = j;
		}
	}

	// Puts the selection back from letter positions after render().
	function select( f, from, to ) {
		var points = [];
		var n = 0;
		( function walk( node ) {
			for ( var c = node.firstChild; c; c = c.nextSibling ) {
				if ( 3 === c.nodeType ) {
					[ from, to ].forEach( function ( want, k ) {
						if ( ! points[ k ] && want <= n + c.nodeValue.length ) {
							points[ k ] = [ c, want - n ];
						}
					} );
					n += c.nodeValue.length;
				} else if ( 'BR' === c.nodeName ) {
					n++;
				} else {
					walk( c );
				}
			}
		} )( f );
		var range = document.createRange();
		range.setStart.apply( range, points[ 0 ] || [ f, f.childNodes.length ] );
		range.setEnd.apply( range, points[ 1 ] || [ f, f.childNodes.length ] );
		var sel = window.getSelection();
		sel.removeAllRanges();
		sel.addRange( range );
	}

	// The rich field and the letters the selection covers, or null.
	function selected() {
		var sel = window.getSelection();
		if ( ! s || ! sel.rangeCount || sel.isCollapsed ) {
			return null;
		}
		var r = sel.getRangeAt( 0 );
		var f = r.commonAncestorContainer.nodeType === 1 ? r.commonAncestorContainer : r.commonAncestorContainer.parentNode;
		f = f.closest( '[data-fsz-rich]' );
		if ( ! f || ! s.card.contains( f ) ) {
			return null;
		}
		var m = model( f, [ [ r.startContainer, r.startOffset ], [ r.endContainer, r.endOffset ] ] );
		var from = Math.min( m.pos[ 0 ], m.pos[ 1 ] );
		var to = Math.max( m.pos[ 0 ], m.pos[ 1 ] );
		return to > from ? { f: f, chars: m.chars, from: from, to: to } : null;
	}

	/*
	 * Bold, italic, underline: on for the selection, or off when all of it has it already. A colour likewise; 'clear'
	 * takes every style off.
	 */
	function format( kind, color ) {
		var x = selected();
		if ( ! x ) {
			return;
		}
		var part = x.chars.slice( x.from, x.to );
		var key = 'color' === kind ? 'c' : kind;
		var on = 'color' === kind ? ! part.every( function ( c ) {
			return c.c === color;
		} ) : ! part.every( function ( c ) {
			return c[ key ];
		} );
		each( part, function ( c ) {
			if ( 'clear' === kind ) {
				c.b = c.i = c.u = false;
				c.c = '';
			} else if ( 'color' === kind ) {
				c.c = on ? color : '';
			} else {
				c[ key ] = on;
			}
		} );
		render( x.f, x.chars );
		select( x.f, x.from, x.to );
		x.f.dispatchEvent( new Event( 'input' ) );
		placeTools();
	}

	// The small bar over selected words: B, I, U, the colours and "clear".
	function makeTools() {
		var bar = el( 'div', 'fsz-fmt' );
		bar.hidden = true;
		bar.setAttribute( 'role', 'toolbar' );
		bar.setAttribute( 'aria-label', 'Text formatting' );
		[ [ 'b', 'B', 'Bold (Ctrl+B)' ], [ 'i', 'I', 'Italic (Ctrl+I)' ], [ 'u', 'U', 'Underline (Ctrl+U)' ] ].forEach( function ( t ) {
			var b = el( 'button', 'fsz-fmt-' + t[ 0 ], t[ 1 ] );
			b.type = 'button';
			b.title = t[ 2 ];
			b.setAttribute( 'data-fmt', t[ 0 ] );
			bar.appendChild( b );
		} );
		bar.appendChild( el( 'span', 'fsz-fmt-sep' ) );
		COLORS.forEach( function ( c ) {
			var b = el( 'button', 'fsz-fmt-dot fsz-c-' + c );
			b.type = 'button';
			b.title = 'Colour: ' + c;
			b.setAttribute( 'aria-label', 'Colour: ' + c );
			b.setAttribute( 'data-fmt', 'color' );
			b.setAttribute( 'data-color', c );
			bar.appendChild( b );
		} );
		var x = el( 'button', 'fsz-fmt-clear', '×' );
		x.type = 'button';
		x.title = 'Clear formatting';
		x.setAttribute( 'data-fmt', 'clear' );
		bar.appendChild( x );
		// Keep the selection: the buttons never take the focus.
		bar.addEventListener( 'mousedown', function ( e ) {
			e.preventDefault();
		} );
		bar.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( '[data-fmt]' );
			if ( b ) {
				format( b.getAttribute( 'data-fmt' ), b.getAttribute( 'data-color' ) );
			}
		} );
		return bar;
	}

	function placeTools() {
		if ( ! s || ! s.tools ) {
			return;
		}
		var x = selected();
		s.tools.hidden = ! x;
		if ( ! x ) {
			return;
		}
		// The colour dots take the card's colours (the group colour is set on the card).
		s.tools.style.cssText = s.card.getAttribute( 'style' ) || '';
		var r = window.getSelection().getRangeAt( 0 ).getBoundingClientRect();
		var w = s.tools.offsetWidth;
		var left = Math.max( 8, Math.min( window.innerWidth - w - 8, r.left + r.width / 2 - w / 2 ) );
		var top = r.top - s.tools.offsetHeight - 8;
		s.tools.style.left = left + 'px';
		s.tools.style.top = ( top < 8 ? r.bottom + 8 : top ) + 'px';
	}

	function each( list, fn ) {
		for ( var i = 0; i < list.length; i++ ) {
			fn( list[ i ], i );
		}
	}

	/* ---------------------------------------------------------------- start / stop */

	function setup( wrap ) {
		var tpl = document.getElementById( 'fsz-edit-' + wrap.getAttribute( 'data-fsz-edit' ) );
		if ( ! tpl || ! tpl.content ) {
			return;
		}
		var bar = el( 'div', 'fsz-editbar' );
		var open = button( 'fsz-edit-open', 'Edit card' );
		bar.appendChild( open );
		wrap.parentNode.insertBefore( bar, wrap );
		refit();
		open.addEventListener( 'click', function () {
			start( wrap, tpl, bar );
		} );
	}

	function start( wrap, tpl, bar ) {
		if ( s ) {
			return;
		}
		var frag = tpl.content.cloneNode( true );
		s = {
			id: wrap.getAttribute( 'data-fsz-edit' ),
			wrap: wrap,
			bar: bar,
			original: wrap.querySelector( '.fsz-device' ),
			card: frag.querySelector( '.fsz-device' ),
			dialog: frag.querySelector( '.fsz-dialog' ),
			dock: makeDock(),
			dirty: false,
			saving: false
		};
		wrap.replaceChild( s.card, s.original );
		refit();
		document.body.appendChild( s.dialog );
		document.body.appendChild( s.dock );
		s.tools = makeTools();
		document.body.appendChild( s.tools );
		document.addEventListener( 'selectionchange', placeTools );
		window.addEventListener( 'scroll', placeTools, true );
		document.body.classList.add( 'fsz-quick-editing' );
		bar.hidden = true;

		prepareFields();
		prepareRatings();
		prepareDialog();
		s.card.addEventListener( 'click', onCardClick );
		each( s.card.querySelectorAll( '[data-fsz-toggle="low"]' ), function ( led ) {
			led.addEventListener( 'keydown', function ( e ) {
				if ( 'Enter' === e.key || ' ' === e.key ) {
					e.preventDefault();
					toggleLow( led );
				}
			} );
		} );
		if ( window.Codex && window.Codex.bindScreens ) {
			window.Codex.bindScreens( s.card ); // the arrow opens the detail page here too, to edit it
		}
		if ( window.Codex && window.Codex.addDepth ) {
			window.Codex.addDepth( s.card, true ); // thickness and resting angle, so the motion sliders show live
			window.Codex.rest( s.card );
		}
		each( s.card.querySelectorAll( '.fsz-name' ), fit );
		refresh();
	}

	function stop() {
		s.wrap.replaceChild( s.original, s.card );
		refit();
		s.dialog.parentNode.removeChild( s.dialog );
		s.dock.parentNode.removeChild( s.dock );
		s.tools.parentNode.removeChild( s.tools );
		document.removeEventListener( 'selectionchange', placeTools );
		window.removeEventListener( 'scroll', placeTools, true );
		document.body.classList.remove( 'fsz-quick-editing' );
		s.bar.hidden = false;
		s = null;
	}

	function cancel() {
		if ( s.dirty && ! window.confirm( 'Discard your changes?' ) ) {
			return;
		}
		stop();
	}

	function changed() {
		s.dirty = true;
		status( 'Unsaved changes.' );
	}

	/* ---------------------------------------------------------------- the bar at the bottom */

	function makeDock() {
		var dock = el( 'div', 'fsz-editdock' );
		dock.setAttribute( 'role', 'toolbar' );
		dock.setAttribute( 'aria-label', 'Codex quick edit' );
		var info = el( 'span', 'fsz-editdock-info' );
		info.appendChild( el( 'b', '', 'Quick edit' ) );
		var msg = el( 'span', 'fsz-editdock-status', HINT );
		msg.setAttribute( 'aria-live', 'polite' );
		info.appendChild( msg );
		dock.appendChild( info );
		var acts = el( 'span', 'fsz-editdock-actions' );
		if ( cfg.editUrl ) {
			// The full WooCommerce product editor in a new tab; quick edit stays open here.
			var more = el( 'a', 'fsz-btn fsz-editdock-more', 'Detailed settings' );
			more.href = cfg.editUrl;
			more.target = '_blank';
			more.rel = 'noopener';
			more.title = 'Open the WooCommerce product editor in a new tab';
			acts.appendChild( more );
		}
		acts.appendChild( button( '', 'Cancel', 'cancel' ) );
		acts.appendChild( button( 'is-primary', 'Save', 'save' ) );
		dock.appendChild( acts );
		dock.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( '[data-fsz-act]' );
			if ( ! b || ! s ) {
				return;
			}
			var act = b.getAttribute( 'data-fsz-act' );
			if ( 'cancel' === act ) {
				cancel();
			} else if ( 'save' === act ) {
				save();
			}
		} );
		return dock;
	}

	function status( text, error ) {
		var msg = s.dock.querySelector( '.fsz-editdock-status' );
		msg.textContent = text;
		msg.classList.toggle( 'is-error', !! error );
	}

	/* ---------------------------------------------------------------- texts */

	function prepareFields() {
		each( s.card.querySelectorAll( '[data-fsz-field]' ), function ( f ) {
			f.setAttribute( 'contenteditable', f.hasAttribute( 'data-fsz-rich' ) ? 'true' : 'plaintext-only' ); // formatted fields keep their <strong> etc.
			if ( 'true' !== f.getAttribute( 'contenteditable' ) && 'plaintext-only' !== f.contentEditable ) {
				f.setAttribute( 'contenteditable', 'true' ); // older browsers; pasting stays plain text below
			}
			f.setAttribute( 'role', 'textbox' );
			f.spellcheck = false;
			f.addEventListener( 'input', onInput );
			f.addEventListener( 'keydown', onFieldKey );
			f.addEventListener( 'paste', onPaste );
		} );
	}

	function onInput( e ) {
		var f = e.currentTarget;
		// An emptied field can keep a stray <br>, which would hide the placeholder.
		if ( '' === value( f ) && '' !== f.innerHTML ) {
			f.innerHTML = '';
		}
		if ( f.classList.contains( 'fsz-name' ) ) {
			fit( f );
		}
		if ( f.parentNode.classList.contains( 'fsz-en' ) && window.Codex && window.Codex.fitMark ) {
			window.Codex.fitMark( f.parentNode );
		}
		if ( f.hasAttribute( 'data-fsz-max' ) ) {
			limit( f );
		}
		if ( f.hasAttribute( 'data-fsz-words' ) ) {
			words( f );
		}
		// The detail page repeats the number and the name (an empty name shows the product title, as on the shop).
		each( s.card.querySelectorAll( '[data-fsz-copy="' + f.getAttribute( 'data-fsz-field' ) + '"]' ), function ( copy ) {
			var name = copy.classList.contains( 'fsz-name' );
			copy.textContent = clean( f.textContent ) || ( name && f.getAttribute( 'data-placeholder' ) ) || '';
			if ( name ) {
				fit( copy );
			}
		} );
		refresh();
		changed();
	}

	// The detail page text counts its words against about how many fit (more may be typed; the counter turns red).
	function words( f ) {
		var n = visible( f ).split( /\s+/ ).filter( Boolean ).length;
		var max = parseInt( f.getAttribute( 'data-fsz-words' ), 10 );
		var count = f.parentNode.querySelector( '.fsz-story-count' );
		if ( count ) {
			count.textContent = n + '/' + max;
			count.classList.toggle( 'is-full', n > max );
		}
	}

	// A field with a length limit (the fun fact) stops taking letters at the limit and shows its count.
	function limit( f ) {
		var max = parseInt( f.getAttribute( 'data-fsz-max' ), 10 );
		if ( f.hasAttribute( 'data-fsz-rich' ) ) {
			var m = model( f );
			if ( m.chars.length > max ) {
				render( f, m.chars.slice( 0, max ) ); // keeps the formatting of what stays
				focusEnd( f );
			}
		} else {
			var chars = Array.from( f.textContent );
			if ( chars.length > max ) {
				f.textContent = chars.slice( 0, max ).join( '' );
				focusEnd( f );
			}
		}
		var count = f.parentNode.querySelector( '.fsz-fun-count' );
		if ( count ) {
			var n = Array.from( visible( f ) ).length;
			count.textContent = n + '/' + max;
			// Red also when long words push it past the two lines the card shows.
			count.classList.toggle( 'is-full', n >= max || f.scrollHeight > f.clientHeight + 1 );
		}
	}

	function onFieldKey( e ) {
		var k = ( e.ctrlKey || e.metaKey ) && ! e.altKey ? e.key.toLowerCase() : '';
		if ( ( 'b' === k || 'i' === k || 'u' === k ) && e.currentTarget.hasAttribute( 'data-fsz-rich' ) ) {
			e.preventDefault(); // our own marks instead of the browser's
			format( k );
			return;
		}
		if ( 'Enter' === e.key && ! e.currentTarget.hasAttribute( 'data-multiline' ) ) {
			// One line per field: Enter moves on to the next one.
			e.preventDefault();
			var all = s.card.querySelectorAll( '[data-fsz-field]' );
			var i = Array.prototype.indexOf.call( all, e.currentTarget );
			if ( all[ i + 1 ] ) {
				focusEnd( all[ i + 1 ] );
			} else {
				e.currentTarget.blur();
			}
		} else if ( 'Escape' === e.key ) {
			e.currentTarget.blur();
		}
	}

	function onPaste( e ) {
		var data = e.clipboardData || window.clipboardData;
		if ( ! data ) {
			return;
		}
		e.preventDefault();
		var text = data.getData( 'text' ).replace( /\r\n?/g, '\n' );
		text = e.currentTarget.hasAttribute( 'data-multiline' ) ? text.replace( /[ \t]+/g, ' ' ) : text.replace( /\s+/g, ' ' );
		document.execCommand( 'insertText', false, text );
	}

	function focusEnd( f ) {
		f.focus();
		var range = document.createRange();
		range.selectNodeContents( f );
		range.collapse( false );
		var sel = window.getSelection();
		sel.removeAllRanges();
		sel.addRange( range );
	}

	// The name stays on one line: its size follows the length of what is typed (or of the placeholder).
	function fit( f ) {
		var text = clean( f.textContent ) || f.getAttribute( 'data-placeholder' ) || '';
		f.style.setProperty( '--fsz-chars', Math.max( 8, Array.from( text ).length ) );
		// On the hidden page it has no width yet; codex.js fits it when the page opens.
		if ( f.clientWidth && window.Codex ) {
			window.Codex.fitName( f );
		}
	}

	/* ---------------------------------------------------------------- bars and stars */

	function prepareRatings() {
		each( s.card.querySelectorAll( '[data-fsz-rating]' ), function ( r ) {
			r.setAttribute( 'role', 'slider' );
			r.setAttribute( 'aria-valuemin', '0' );
			r.setAttribute( 'aria-valuemax', '5' );
			r.removeAttribute( 'aria-hidden' );
			r.tabIndex = 0;
			r.title = 'Click a segment to set it. Click it again to hide the line.';
			setRating( r, rating( r ) );
			r.addEventListener( 'click', onRatingClick );
			r.addEventListener( 'keydown', onRatingKey );
		} );
	}

	function rating( r ) {
		return parseInt( r.getAttribute( 'data-value' ), 10 ) || 0;
	}

	// The difficulty level (1-3) of a saved value (1-5), as fsz_level() in codex.php.
	function levelOf( v ) {
		return v < 1 ? 0 : ( v <= 2 ? 1 : ( v <= 4 ? 2 : 3 ) );
	}

	// The difficulty gauge has three zones (Beginner, Intermediate, Expert) that save 1, 3 and 5; the bars have five cells.
	function isLevels( r ) {
		return 'difficulty' === r.getAttribute( 'data-fsz-rating' );
	}

	function setRating( r, v ) {
		v = Math.max( 0, Math.min( 5, v ) );
		r.setAttribute( 'data-value', v );
		if ( isLevels( r ) ) {
			var l = levelOf( v ), diff = r.closest( '.fsz-diff' ), words = [];
			try {
				words = JSON.parse( diff.getAttribute( 'data-words' ) || '[]' );
			} catch ( err ) {}
			r.setAttribute( 'aria-valuemax', '3' );
			r.setAttribute( 'aria-valuenow', l );
			r.setAttribute( 'aria-valuetext', l ? words[ l ] || l + ' / 3' : 'not shown' );
			each( r.children, function ( item, i ) {
				item.classList.toggle( 'is-on', i + 1 === l );
			} );
			var word = diff.querySelector( '.fsz-diff-word' );
			if ( word && words.length ) {
				word.textContent = words[ l ] || words[ 0 ];
			}
			return;
		}
		r.setAttribute( 'aria-valuenow', v );
		r.setAttribute( 'aria-valuetext', v ? v + ' / 5' : 'not shown' );
		each( r.children, function ( item, i ) {
			item.classList.toggle( 'is-on', i < v );
		} );
	}

	// The value a click on a segment sets: its position (bars), or its level's saved value (gauge).
	function segValue( r, item ) {
		return isLevels( r ) ? parseInt( item.getAttribute( 'data-save' ), 10 ) || 0 : Array.prototype.indexOf.call( r.children, item ) + 1;
	}

	function onRatingClick( e ) {
		var r = e.currentTarget;
		var item = e.target.closest( '.fsz-cell, .fsz-seg' );
		if ( ! item || item.parentNode !== r ) {
			return;
		}
		var v = segValue( r, item );
		setRating( r, ( isLevels( r ) ? levelOf( rating( r ) ) === levelOf( v ) : rating( r ) === v ) ? 0 : v );
		level();
		refresh();
		changed();
	}

	function onRatingKey( e ) {
		var r = e.currentTarget, v = rating( r );
		var keys = { ArrowRight: v + 1, ArrowUp: v + 1, ArrowLeft: v - 1, ArrowDown: v - 1, Home: 0, End: 5 };
		if ( isLevels( r ) ) {
			var saves = [ 0, 1, 3, 5 ], l = levelOf( v );
			keys = { ArrowRight: saves[ Math.min( 3, l + 1 ) ], ArrowUp: saves[ Math.min( 3, l + 1 ) ], ArrowLeft: saves[ Math.max( 0, l - 1 ) ], ArrowDown: saves[ Math.max( 0, l - 1 ) ], Home: 0, End: 5 };
		}
		if ( ! ( e.key in keys ) ) {
			return;
		}
		e.preventDefault();
		setRating( r, keys[ e.key ] );
		level();
		refresh();
		changed();
	}

	// The difficulty level on the card (the gauge needle and the first tag's colour) follows the rating, as fsz_render_card() sets it.
	function level() {
		var r = s.card.querySelector( '[data-fsz-rating="difficulty"]' ), v = r ? rating( r ) : 0;
		if ( v ) {
			s.card.setAttribute( 'data-level', String( levelOf( v ) ) );
		} else {
			s.card.removeAttribute( 'data-level' );
		}
	}

	/* ---------------------------------------------------------------- empty lines */

	// A line whose fields are all empty is hidden for visitors; in edit mode it is shown faded.
	function refresh() {
		each( s.card.querySelectorAll( '[data-fsz-row]' ), function ( row ) {
			var empty = true;
			each( row.querySelectorAll( '[data-fsz-field]' ), function ( f ) {
				if ( '' !== value( f ) ) {
					empty = false;
				}
			} );
			each( row.querySelectorAll( '[data-fsz-rating]' ), function ( r ) {
				if ( rating( r ) > 0 ) {
					empty = false;
				}
			} );
			row.classList.toggle( 'is-empty', empty );
		} );
	}

	/* ---------------------------------------------------------------- pop-ups: photos, colour theme */

	function form() {
		return s.dialog.querySelector( 'form' ).elements;
	}

	function prepareDialog() {
		var f = form();
		var on = s.dialog.querySelector( 'button.fsz-theme[aria-pressed="true"]' );
		s.color = f.color.getAttribute( 'data-picked' ) || ( on ? on.getAttribute( 'data-hex' ) : '' ); // '' = the default theme
		each( s.dialog.querySelectorAll( 'button.fsz-theme' ), function ( b ) {
			b.addEventListener( 'click', function () {
				setTheme( b.getAttribute( 'data-hex' ), b );
			} );
		} );
		f.color.addEventListener( 'input', function () {
			var sw = f.color.parentNode.querySelector( '.fsz-swatch' );
			sw.style.setProperty( 'background-color', f.color.value, 'important' ); // important: dark mode extensions leave it alone
			sw.firstChild.style.setProperty( 'background-color', dark( f.color.value ), 'important' );
			setTheme( f.color.value, f.color.parentNode );
		} );
		var picked = s.dialog.querySelector( '.fsz-badge-pick[aria-pressed="true"]' );
		s.badge = picked ? picked.getAttribute( 'data-badge' ) : '';
		each( s.dialog.querySelectorAll( '.fsz-badge-pick' ), function ( b ) {
			b.addEventListener( 'click', function () {
				setBadge( b );
			} );
		} );
		s.traits = Array.prototype.map.call( s.dialog.querySelectorAll( '.fsz-trait-pick[aria-pressed="true"]' ), function ( b ) {
			return b.getAttribute( 'data-trait' );
		} );
		each( s.dialog.querySelectorAll( '.fsz-trait-pick' ), function ( b ) {
			b.addEventListener( 'click', function () {
				toggleTrait( b );
			} );
		} );
		s.dialog.querySelector( '[data-fsz-add-photos]' ).addEventListener( 'click', addPhotos );
		prepareMotion();
		preparePhotos();
		applyColor();
	}

	function openDialog( section ) {
		each( s.dialog.querySelectorAll( '[data-fsz-section]' ), function ( part ) {
			part.hidden = part.getAttribute( 'data-fsz-section' ) !== section;
		} );
		var part = s.dialog.querySelector( '[data-fsz-section="' + section + '"]' );
		if ( ! part ) {
			return;
		}
		s.dialog.querySelector( 'h2' ).textContent = part.getAttribute( 'data-title' );
		s.dialog.className = 'fsz-dialog is-' + section;
		if ( ! s.dialog.open ) {
			s.dialog.showModal();
		}
		var target = part.querySelector( '[aria-pressed="true"], button, input' );
		if ( target ) {
			target.focus();
		}
	}

	// Click the photo for the photos, the badge for the badge, and anywhere else on the device (not the screen) for the colour.
	// 1.54.0: the yellow light is the "Running low" switch (it blinks while on).
	function toggleLow( led ) {
		var on = ! led.classList.contains( 'is-low' );
		led.classList.toggle( 'is-low', on );
		led.setAttribute( 'aria-checked', on ? 'true' : 'false' );
		changed();
	}

	function onCardClick( e ) {
		var low = e.target.closest( '[data-fsz-toggle="low"]' );
		var t = e.target.closest( '[data-fsz-open]' );
		if ( low ) {
			e.preventDefault();
			toggleLow( low );
		} else if ( t ) {
			e.preventDefault();
			openDialog( t.getAttribute( 'data-fsz-open' ) );
		} else if ( ! e.target.closest( '.fsz-screen' ) ) {
			openDialog( 'color' );
		}
	}

	/* motion: levitation and the resting angle, one setting for every card (codex.css --fsz-float/--fsz-turn/--fsz-lean) */

	function prepareMotion() {
		each( s.dialog.querySelectorAll( '.fsz-slider input' ), function ( input ) {
			input.addEventListener( 'input', function () {
				var unit = input.getAttribute( 'data-unit' );
				input.parentNode.querySelector( 'output' ).textContent = input.value + unit;
				s.card.style.setProperty( '--fsz-' + input.name, input.value + ( unit ? 'deg' : '' ) );
				if ( window.Codex && window.Codex.rest ) {
					window.Codex.rest( s.card );
				}
				s.motionChanged = true;
				changed();
			} );
		} );
	}

	/* colour theme */

	function setTheme( hex, chosen ) {
		s.color = hex;
		each( s.dialog.querySelectorAll( '.fsz-theme' ), function ( b ) {
			var on = b === chosen;
			b.classList.toggle( 'is-on', on );
			if ( 'BUTTON' === b.nodeName ) {
				b.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
			}
		} );
		applyColor();
		changed();
	}

	// The screen frame: the theme colour, darker (same as fsz_theme_dark() in codex.php).
	function dark( hex ) {
		var m = /^#?([0-9a-f]{6})$/i.exec( hex || '' );
		if ( ! m ) {
			return '';
		}
		return '#' + m[ 1 ].match( /../g ).map( function ( c ) {
			return ( '0' + Math.round( parseInt( c, 16 ) * 0.7 ).toString( 16 ) ).slice( -2 );
		} ).join( '' ).toUpperCase();
	}

	// The screen colours in a theme: its hue, the lightness of the settings colour (same contrast). Same as fsz_theme_tint().
	function hsl( hex ) {
		var m = /^#?([0-9a-f]{6})$/i.exec( hex || '' );
		if ( ! m ) {
			return null;
		}
		var c = m[ 1 ].match( /../g ).map( function ( x ) {
			return parseInt( x, 16 ) / 255;
		} );
		var max = Math.max.apply( null, c ), min = Math.min.apply( null, c ), l = ( max + min ) / 2, d = max - min, h;
		if ( ! d ) {
			return [ 0, 0, l ];
		}
		if ( max === c[ 0 ] ) {
			h = ( ( c[ 1 ] - c[ 2 ] ) / d + 6 ) % 6;
		} else if ( max === c[ 1 ] ) {
			h = ( c[ 2 ] - c[ 0 ] ) / d + 2;
		} else {
			h = ( c[ 0 ] - c[ 1 ] ) / d + 4;
		}
		return [ h * 60, d / ( 1 - Math.abs( 2 * l - 1 ) ), l ];
	}

	function tint( base, theme, minLight ) {
		var b = hsl( base ), t = hsl( theme );
		if ( ! b || ! t ) {
			return base;
		}
		var h = t[ 0 ], sat = Math.min( b[ 1 ], t[ 1 ] ), l = Math.max( b[ 2 ], minLight || 0 );
		var c = ( 1 - Math.abs( 2 * l - 1 ) ) * sat, x = c * ( 1 - Math.abs( ( h / 60 ) % 2 - 1 ) ), m = l - c / 2;
		var rgb = [ [ c, x, 0 ], [ x, c, 0 ], [ 0, c, x ], [ 0, x, c ], [ x, 0, c ], [ c, 0, x ] ][ Math.floor( h / 60 ) % 6 ];
		return '#' + rgb.map( function ( v ) {
			return ( '0' + Math.round( ( v + m ) * 255 ).toString( 16 ) ).slice( -2 );
		} ).join( '' ).toUpperCase();
	}

	function applyColor() {
		var c = s.color || cfg.defaultColor;
		s.card.style.setProperty( '--fsz-device', c );
		s.card.style.setProperty( '--fsz-device-dark', dark( c ) );
		// Every theme tints the screen (bright) and its text, as fsz_css_vars() does.
		[ 'screen', 'ink' ].forEach( function ( k ) {
			s.card.style.setProperty( '--fsz-' + k, tint( cfg[ k ], c, 'screen' === k ? parseFloat( cfg.screenLight ) : 0 ) );
		} );
	}

	/* trait badges: over the power bar names, and again with their sentence on the detail page */

	function toggleTrait( b ) {
		var key = b.getAttribute( 'data-trait' ), on = 'true' !== b.getAttribute( 'aria-pressed' );
		b.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
		s.traits = Array.prototype.filter.call( s.dialog.querySelectorAll( '.fsz-trait-pick' ), function ( x ) {
			return 'true' === x.getAttribute( 'aria-pressed' );
		} ).map( function ( x ) {
			return x.getAttribute( 'data-trait' );
		} );
		each( s.card.querySelectorAll( '[data-trait="' + key + '"]' ), function ( el ) {
			el.classList.toggle( 'is-off', ! on );
		} );
		var box = s.card.querySelector( '.fsz-traits' );
		if ( box ) {
			box.classList.toggle( 'is-empty', ! s.traits.length );
		}
		changed();
	}

	/* badge: the sticker on the photo's corner */

	function setBadge( b ) {
		s.badge = b.getAttribute( 'data-badge' );
		each( s.dialog.querySelectorAll( '.fsz-badge-pick' ), function ( x ) {
			x.setAttribute( 'aria-pressed', x === b ? 'true' : 'false' );
		} );
		var sticker = s.card.querySelector( '.fsz-badge' ), shown = b.querySelector( '.fsz-badge' );
		if ( sticker ) {
			sticker.className = 'fsz-badge ' + ( s.badge ? 'is-' + s.badge : 'is-empty' );
			sticker.textContent = shown ? shown.textContent : '+ Badge';
		}
		changed();
	}

	/* photos: the product's own photos, in the order the card shows them */

	function list() {
		return s.dialog.querySelector( '.fsz-pics' );
	}

	function preparePhotos() {
		prepareFramer();
		each( list().children, addControls );
		var dragged = null;
		list().addEventListener( 'dragstart', function ( e ) {
			dragged = e.target.closest( '.fsz-pic' );
			if ( dragged ) {
				dragged.classList.add( 'is-dragging' );
				e.dataTransfer.effectAllowed = 'move';
				e.dataTransfer.setData( 'text/plain', dragged.getAttribute( 'data-id' ) );
			}
		} );
		list().addEventListener( 'dragover', function ( e ) {
			var over = e.target.closest( '.fsz-pic' );
			if ( ! dragged || ! over || over === dragged ) {
				return;
			}
			e.preventDefault();
			var r = over.getBoundingClientRect();
			list().insertBefore( dragged, e.clientX > r.left + r.width / 2 ? over.nextSibling : over );
		} );
		list().addEventListener( 'dragend', function () {
			if ( dragged ) {
				dragged.classList.remove( 'is-dragging' );
				dragged = null;
				photosChanged();
			}
		} );
		syncPhotos();
	}

	function addControls( li ) {
		var bar = el( 'span', 'fsz-pic-btns' );
		var linked = li.classList.contains( 'is-linked' ); // a linked Codex image: always first, can only be removed
		li.tabIndex = 0;
		li.setAttribute( 'aria-label', 'Frame this photo' );
		li.addEventListener( 'click', function ( e ) {
			if ( ! e.target.closest( '.fsz-pic-btns' ) ) {
				openFramer( li );
			}
		} );
		li.addEventListener( 'keydown', function ( e ) {
			if ( e.target === li && ( 'Enter' === e.key || ' ' === e.key ) ) {
				e.preventDefault();
				openFramer( li );
			}
		} );
		( linked ? [ [ 'remove', '×', 'Remove' ] ] : [ [ 'left', '‹', 'Move earlier' ], [ 'right', '›', 'Move later' ], [ 'remove', '×', 'Remove' ] ] ).forEach( function ( b ) {
			var btn = button( 'fsz-pic-' + b[ 0 ], b[ 1 ] );
			btn.setAttribute( 'aria-label', b[ 2 ] );
			btn.title = b[ 2 ];
			btn.addEventListener( 'click', function () {
				if ( 'left' === b[ 0 ] && li.previousElementSibling ) {
					list().insertBefore( li, li.previousElementSibling );
				} else if ( 'right' === b[ 0 ] && li.nextElementSibling ) {
					list().insertBefore( li.nextElementSibling, li );
				} else if ( 'remove' === b[ 0 ] ) {
					li.parentNode.removeChild( li );
				}
				photosChanged();
			} );
			bar.appendChild( btn );
		} );
		li.appendChild( bar );
	}

	function photosChanged() {
		s.photosChanged = true;
		syncPhotos();
		changed();
	}

	// The first photo on the card, the "main" badge and the empty note follow the list.
	function syncPhotos() {
		var pinned = list().querySelector( '.is-linked' );
		if ( pinned && pinned !== list().firstElementChild ) {
			list().insertBefore( pinned, list().firstElementChild ); // the card always shows it first
		}
		var items = list().children;
		each( items, function ( li, i ) {
			li.classList.toggle( 'is-first', 0 === i );
		} );
		s.dialog.querySelector( '.fsz-pics-empty' ).hidden = items.length > 0;
		var photo = s.card.querySelector( '.fsz-photo' );
		if ( ! photo ) {
			return;
		}
		var full = items.length ? items[ 0 ].getAttribute( 'data-full' ) : '';
		var now = photo.querySelector( 'img' );
		if ( full && now && now.getAttribute( 'data-full' ) === full ) {
			setFrame( now, frameOf( items[ 0 ] ) );
			return;
		}
		var sticker = photo.querySelector( '.fsz-badge' ); // the badge stays on the new photo
		photo.textContent = '';
		photo.classList.toggle( 'is-empty', ! full );
		if ( full ) {
			var box = el( 'div', 'fsz-slides' ), img = el( 'img' );
			img.src = full;
			img.alt = '';
			img.setAttribute( 'data-full', full );
			setFrame( img, frameOf( items[ 0 ] ) );
			box.appendChild( img );
			photo.appendChild( box );
		} else {
			photo.appendChild( el( 'span', 'fsz-photo-empty', 'No photo yet' ) );
		}
		if ( sticker ) {
			photo.appendChild( sticker );
		}
	}

	/* framing: which part of a photo shows in the card's fixed 4:3 frame, like a profile photo crop */

	// [x %, y %, zoom]: the photo's point at x/y stays at the same place in the frame, zoom scales around it (codex.css).
	function frameOf( li ) {
		var f = ( li.getAttribute( 'data-frame' ) || '' ).split( ',' ).map( parseFloat );
		return 3 === f.length && f.every( isFinite ) ? f : [ 50, 50, 1 ];
	}

	function setFrame( img, f ) {
		img.style.setProperty( '--fsz-fx', f[ 0 ].toFixed( 1 ) + '%' );
		img.style.setProperty( '--fsz-fy', f[ 1 ].toFixed( 1 ) + '%' );
		img.style.setProperty( '--fsz-fz', f[ 2 ].toFixed( 3 ) );
	}

	function prepareFramer() {
		var part = s.dialog.querySelector( '[data-fsz-section="photos"]' );
		var box = el( 'div', 'fsz-framer' );
		box.hidden = true;
		box.innerHTML = '<div class="fsz-framer-frame" tabindex="0" aria-label="Photo framing: arrows move, plus and minus zoom"><img alt="" draggable="false"></div>' +
			'<label class="fsz-framer-zoom"><span aria-hidden="true">−</span><input type="range" min="1" max="3" step="0.01" aria-label="Zoom"><span aria-hidden="true">+</span></label>' +
			'<span class="fsz-dhint">Drag the photo to choose which part shows. Zoom with the slider (or the mouse wheel).</span>';
		var bar = el( 'div', 'fsz-framer-btns' );
		var reset = button( '', 'Reset' ), done = button( 'is-primary', 'Back to photos' );
		bar.appendChild( reset );
		bar.appendChild( done );
		box.appendChild( bar );
		part.insertBefore( box, part.firstChild );
		var frame = box.querySelector( '.fsz-framer-frame' ), img = frame.querySelector( 'img' ), zoom = box.querySelector( 'input' );
		var drag = null;

		function apply( f ) {
			s.framing.f = f;
			setFrame( img, f );
			zoom.value = String( f[ 2 ] );
			s.framing.li.setAttribute( 'data-frame', f.map( function ( n, i ) {
				return 2 === i ? n.toFixed( 3 ) : n.toFixed( 1 );
			} ).join( ',' ) );
			if ( s.framing.li === list().firstElementChild ) {
				syncPhotos(); // the card shows the first photo: it follows live
			}
			s.framesChanged = true;
			changed();
		}
		// How far the photo can move: its covered size times the zoom, minus the frame.
		function room() {
			var w = frame.clientWidth, h = frame.clientHeight, nw = img.naturalWidth || w, nh = img.naturalHeight || h;
			var c = Math.max( w / nw, h / nh ), z = s.framing.f[ 2 ];
			return [ nw * c * z - w, nh * c * z - h ];
		}
		frame.addEventListener( 'pointerdown', function ( e ) {
			drag = { x: e.clientX, y: e.clientY, f: s.framing.f.slice(), r: room() };
			frame.setPointerCapture( e.pointerId );
			frame.classList.add( 'is-dragging' );
			e.preventDefault();
		} );
		frame.addEventListener( 'pointermove', function ( e ) {
			if ( ! drag ) {
				return;
			}
			var f = drag.f.slice();
			[ e.clientX - drag.x, e.clientY - drag.y ].forEach( function ( d, i ) {
				if ( drag.r[ i ] > 0.5 ) {
					f[ i ] = Math.max( 0, Math.min( 100, drag.f[ i ] - d / drag.r[ i ] * 100 ) ); // the photo follows the pointer
				}
			} );
			apply( f );
		} );
		[ 'pointerup', 'pointercancel' ].forEach( function ( type ) {
			frame.addEventListener( type, function () {
				drag = null;
				frame.classList.remove( 'is-dragging' );
			} );
		} );
		// Keyboard: arrows move the photo, + and − zoom.
		frame.addEventListener( 'keydown', function ( e ) {
			var f = s.framing.f.slice(), k = { ArrowLeft: [ 0, 2 ], ArrowRight: [ 0, -2 ], ArrowUp: [ 1, 2 ], ArrowDown: [ 1, -2 ] }[ e.key ];
			if ( k ) {
				f[ k[ 0 ] ] = Math.max( 0, Math.min( 100, f[ k[ 0 ] ] + k[ 1 ] ) );
			} else if ( '+' === e.key || '=' === e.key || '-' === e.key ) {
				f[ 2 ] = Math.max( 1, Math.min( 3, f[ 2 ] + ( '-' === e.key ? -0.1 : 0.1 ) ) );
			} else {
				return;
			}
			e.preventDefault();
			apply( f );
		} );
		frame.addEventListener( 'wheel', function ( e ) {
			e.preventDefault();
			var f = s.framing.f.slice();
			f[ 2 ] = Math.max( 1, Math.min( 3, f[ 2 ] - e.deltaY * 0.002 ) );
			apply( f );
		}, { passive: false } );
		zoom.addEventListener( 'input', function () {
			var f = s.framing.f.slice();
			f[ 2 ] = parseFloat( zoom.value );
			apply( f );
		} );
		reset.addEventListener( 'click', function () {
			apply( [ 50, 50, 1 ] );
		} );
		done.addEventListener( 'click', closeFramer );
		s.dialog.addEventListener( 'close', closeFramer );
		s.framer = box;
	}

	function openFramer( li ) {
		s.framing = { li: li, f: frameOf( li ) };
		var img = s.framer.querySelector( 'img' );
		img.src = li.getAttribute( 'data-full' );
		setFrame( img, s.framing.f );
		s.framer.querySelector( 'input' ).value = String( s.framing.f[ 2 ] );
		s.framer.hidden = false;
		s.framer.parentNode.classList.add( 'is-framing' );
		s.dialog.querySelector( 'h2' ).textContent = 'Frame the photo';
		s.framer.querySelector( '.fsz-framer-frame' ).focus();
	}

	function closeFramer() {
		if ( ! s || ! s.framer || s.framer.hidden ) {
			return;
		}
		s.framer.hidden = true;
		s.framer.parentNode.classList.remove( 'is-framing' );
		s.dialog.querySelector( 'h2' ).textContent = s.framer.parentNode.getAttribute( 'data-title' );
		if ( s.framing && s.framing.li.parentNode ) {
			s.framing.li.focus();
		}
		s.framing = null;
	}

	function addPhotos() {
		if ( ! window.wp || ! window.wp.media ) {
			window.alert( 'The media library could not be loaded. Change the photos in the product editor instead.' );
			return;
		}
		if ( ! s.frame ) {
			s.frame = window.wp.media( {
				title: 'Add photos',
				library: { type: 'image' },
				multiple: 'add',
				button: { text: 'Add to the Codex' }
			} );
			s.frame.on( 'select', function () {
				s.frame.state().get( 'selection' ).each( function ( m ) {
					var a = m.toJSON(), sizes = a.sizes || {};
					if ( list().querySelector( '[data-id="' + a.id + '"]' ) ) {
						return; // already in the list
					}
					var li = el( 'li', 'fsz-pic' ), img = el( 'img' );
					li.setAttribute( 'data-id', a.id );
					li.setAttribute( 'data-full', ( sizes.woocommerce_single || sizes.large || sizes.medium_large || a ).url );
					li.draggable = true;
					img.src = ( sizes.thumbnail || sizes.medium || a ).url;
					img.alt = '';
					li.appendChild( img );
					addControls( li );
					list().appendChild( li );
				} );
				s.frame.state().get( 'selection' ).reset();
				photosChanged();
			} );
			// Back to the pop-up once the media library closes.
			s.frame.on( 'close', function () {
				window.setTimeout( function () {
					if ( s ) {
						openDialog( 'photos' );
					}
				}, 0 );
			} );
		}
		// The pop-up is modal and would block the media library, so it closes while that is open.
		s.dialog.close();
		s.frame.open();
	}

	/* ---------------------------------------------------------------- saving */

	function collect() {
		var data = new FormData();
		data.append( 'action', 'fsz_quick_edit_save' );
		data.append( 'nonce', cfg.nonce );
		data.append( 'id', s.id );
		each( s.card.querySelectorAll( '[data-fsz-field]' ), function ( field ) {
			data.append( 'fields[' + field.getAttribute( 'data-fsz-field' ) + ']', value( field ) );
		} );
		each( s.card.querySelectorAll( '[data-fsz-rating]' ), function ( r ) {
			data.append( 'fields[' + r.getAttribute( 'data-fsz-rating' ) + ']', rating( r ) );
		} );
		data.append( 'fields[color]', s.color );
		data.append( 'fields[badge]', s.badge );
		data.append( 'fields[traits]', ( s.traits || [] ).join( ',' ) );
		each( s.card.querySelectorAll( '[data-fsz-toggle="low"]' ), function ( led ) {
			data.append( 'fields[low]', led.classList.contains( 'is-low' ) ? 'yes' : '' );
		} );
		if ( s.photosChanged ) {
			data.append( 'photos', Array.prototype.map.call( list().children, function ( li ) {
				return li.getAttribute( 'data-id' );
			} ).join( ',' ) );
		}
		if ( s.framesChanged ) {
			var frames = {};
			each( list().children, function ( li ) {
				frames[ li.getAttribute( 'data-id' ) ] = frameOf( li );
			} );
			data.append( 'frames', JSON.stringify( frames ) );
		}
		if ( s.motionChanged ) {
			each( s.dialog.querySelectorAll( '.fsz-slider input' ), function ( input ) {
				data.append( 'motion[' + input.name + ']', input.value );
			} );
		}
		return data;
	}

	function busy( on ) {
		each( s.dock.querySelectorAll( 'button' ), function ( b ) {
			b.disabled = on;
		} );
	}

	function save() {
		if ( ! s || s.saving ) {
			return;
		}
		if ( s.dialog.open ) {
			s.dialog.close();
		}
		s.saving = true;
		busy( true );
		status( 'Saving…' );
		window.fetch( cfg.ajax, { method: 'POST', credentials: 'same-origin', body: collect() } )
			.then( function ( r ) {
				return r.text().then( function ( body ) {
					var res = null;
					try {
						res = JSON.parse( body );
					} catch ( err ) {}
					if ( res && res.success ) {
						return res.data || {};
					}
					if ( '-1' === body.trim() || 403 === r.status ) {
						throw new Error( res && res.data && res.data.message ? res.data.message : 'Your login has expired. Reload the page and try again.' );
					}
					throw new Error( res && res.data && res.data.message ? res.data.message : 'Saving failed. Please try again.' );
				} );
			} )
			.then( function ( out ) {
				// The photos: the server says what the card shows now; it must be what was chosen here.
				if ( out.photos && out.photos.join( ',' ) !== out.wanted.join( ',' ) ) {
					throw new Error( 'Saved, but the card still shows photos ' + ( out.photos.join( ', ' ) || 'none' ) + ' instead of ' + ( out.wanted.join( ', ' ) || 'none' ) + '. Take a screenshot of this message.' );
				}
				s.dirty = false;
				status( 'Saved. Reloading…' );
				// A fresh copy of the page, never one from the browser's cache.
				var url = new window.URL( window.location.href );
				url.searchParams.set( 'fsz', String( Date.now() ) );
				window.location.replace( url.toString() );
			} )
			.catch( function ( err ) {
				s.saving = false;
				busy( false );
				status( err && err.message ? err.message : 'Saving failed. Please try again.', true );
			} );
	}

	document.addEventListener( 'keydown', function ( e ) {
		if ( s && ( e.ctrlKey || e.metaKey ) && 's' === String( e.key ).toLowerCase() ) {
			e.preventDefault();
			save();
		}
	} );

	window.addEventListener( 'beforeunload', function ( e ) {
		if ( s && s.dirty ) {
			e.preventDefault();
			e.returnValue = '';
		}
	} );

	// The bar above the card and the edit card change the room, so the card fits the screen again (codex.js).
	function refit() {
		if ( window.fszFit ) {
			window.fszFit();
		}
	}

	function init() {
		each( document.querySelectorAll( '.fsz-wrap[data-fsz-edit]' ), setup );
	}
	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
})();
