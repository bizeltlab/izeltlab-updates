<?php
/**
 * Plugin Name: Codex
 * Description: Handheld-scanner style species card on live animal product pages. Fill in the data on the product edit page or by CSV import; the look is set in one place, in the settings.
 * Version: 2.5.1
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Dan
 * Text Domain: codex
 * Domain Path: /languages
 * WC requires at least: 7.0
 */

// ==========================================================================
//  FILE: codex.php   (Codex plugin)
//  WHAT: The plugin's starting point. It only sets the version and loads the files in inc/, one file per feature.
//  WHERE IS WHAT: read ARCHITECTURE.md in this folder ("I want to change X → open file Y").
//  ORDER MATTERS: the files below are loaded top to bottom. Do not reorder them.
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'FSZ_VERSION', '2.5.1' );

// Updates from the shop's GitHub repository (Settings → Ízeltláb updates), shared with the theme and Bolt.
require_once __DIR__ . '/updater.php';
IZL_Updater::add( 'codex', 'plugin', plugin_basename( __FILE__ ), 'Codex', FSZ_VERSION );
define( 'FSZ_FUN_MAX', 35 ); // fun fact: two lines in the bubble next to the Description button
define( 'FSZ_STORY_WORDS', 60 ); // the detail page text: about this many words fit above the four tiles (a guide, not a limit)
define( 'FSZ_URL', plugin_dir_url( __FILE__ ) );
define( 'FSZ_DIR', plugin_dir_path( __FILE__ ) );
define( 'FSZ_OPT', 'fsz_settings' );

add_action( 'init', function () {
	load_plugin_textdomain( 'codex', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}, 1 );

// True when the visitor carries a WordPress login cookie (or the request is a dashboard one). The EDITORS ONLY file
// below is loaded only then; it still checks the user's real rights before it does anything.
function fsz_editor_may_be_here() {
	if ( is_admin() ) {
		return true;
	}
	foreach ( array_keys( $_COOKIE ) as $name ) {
		if ( 0 === strpos( (string) $name, 'wordpress_logged_in_' ) ) {
			return true;
		}
	}
	return false;
}

// ==========================================================================
//  1. Settings and which products get a card
// ==========================================================================

require_once FSZ_DIR . 'inc/settings.php';       // defaults, skins, labels, upgrades, reading the lists
require_once FSZ_DIR . 'inc/which-products.php'; // which products get a Codex card

// ==========================================================================
//  2. The card
// ==========================================================================

require_once FSZ_DIR . 'inc/assets.php';      // stylesheet, fonts and script on shop pages
require_once FSZ_DIR . 'inc/colours.php';     // colour themes and colour maths
require_once FSZ_DIR . 'inc/card-data.php';   // Codex number, names, tags, badge
require_once FSZ_DIR . 'inc/traits.php';      // trait badges, group stamp
require_once FSZ_DIR . 'inc/text-format.php'; // coloured marks, Leírás text, hyphenation
require_once FSZ_DIR . 'inc/card-parts.php';  // difficulty gauge, card colours, group colours
require_once FSZ_DIR . 'inc/card-photos.php'; // photos, framing, sizes
require_once FSZ_DIR . 'inc/card.php';        // the card's HTML
if ( fsz_editor_may_be_here() ) {
	require_once FSZ_DIR . 'inc/edit-dialog.php'; // EDITORS ONLY: the Edit card pop-ups
}

// ==========================================================================
//  3. Where the card shows, and the shop filter
// ==========================================================================

require_once FSZ_DIR . 'inc/product-page.php'; // the card on the product page
require_once FSZ_DIR . 'inc/card-swipe.php';   // 2.2.0: swipe to the previous / next species, edge arrows; 2.3.0: without a page load
require_once FSZ_DIR . 'inc/shop-filter.php';  // difficulty filter on shop lists

// ==========================================================================
//  4. Editing and the dashboard
// ==========================================================================

require_once FSZ_DIR . 'inc/admin-fields.php';    // Codex box on the product edit page, group colours, saving fields
require_once FSZ_DIR . 'inc/tags.php';            // Codex tags = WooCommerce product tags
require_once FSZ_DIR . 'inc/quick-edit-save.php'; // saving "Edit card"
if ( is_admin() ) {
	require_once FSZ_DIR . 'inc/admin-settings.php'; // DASHBOARD ONLY: the settings page and the cleanup tool
}

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=codex' ) ) . '">Settings</a>' );
	return $links;
} );

add_action( 'before_woocommerce_init', function () {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
} );
