import sys,struct,re,ast
def parse(path):
    ents=[];cur={};key=None
    def flush():
        if 'msgid' in cur: ents.append(dict(cur))
        cur.clear()
    for line in open(path,encoding='utf-8'):
        line=line.strip()
        if not line or line.startswith('#'):
            if not line and cur: flush()
            continue
        m=re.match(r'(msgctxt|msgid_plural|msgid|msgstr(?:\[\d+\])?)\s+(".*")$',line)
        if m:
            k=m.group(1)
            if k in('msgctxt',) or (k=='msgid' and 'msgid' in cur): flush()
            key=k; cur[key]=ast.literal_eval(m.group(2)) if False else eval_str(m.group(2))
        elif line.startswith('"'): cur[key]+=eval_str(line)
    flush(); return ents
def eval_str(s):
    s=s[1:-1]; out=[];i=0
    while i<len(s):
        c=s[i]
        if c=='\\':
            n=s[i+1]; out.append({'n':'\n','t':'\t','"':'"','\\':'\\'}.get(n,n)); i+=2
        else: out.append(c); i+=1
    return ''.join(out)
ents=parse(sys.argv[1]); cat={}
for e in ents:
    k=e['msgid']
    if 'msgctxt' in e: k=e['msgctxt']+'\x04'+k
    if 'msgid_plural' in e:
        k+='\x00'+e['msgid_plural']; v='\x00'.join(e[x] for x in sorted(x for x in e if x.startswith('msgstr[')))
    else: v=e.get('msgstr','')
    if v or k=='': cat[k]=v
keys=sorted(cat); ids=b'';strs=b'';offs=[]
for k in keys:
    kb=k.encode();vb=cat[k].encode(); offs.append((len(ids),len(kb),len(strs),len(vb))); ids+=kb+b'\0'; strs+=vb+b'\0'
n=len(keys); ko=28; vo=ko+n*8; start=vo+n*8
kt=b''.join(struct.pack('<2I',l,start+o) for o,l,_,_ in offs)
vt=b''.join(struct.pack('<2I',l,start+len(ids)+o) for _,_,o,l in offs)
# hash table size 0, offset = string start (WP's MO reader treats it as end of the tables)
open(sys.argv[2],'wb').write(struct.pack('<7I',0x950412de,0,n,ko,vo,0,start)+kt+vt+ids+strs)
print(n,'entries')
