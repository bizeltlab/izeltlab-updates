"""Codex: build the stylesheets shoppers get (run from the plugin folder: python3 tools/build-css.py).

For each source in assets/ it writes assets/min/<name>.min.css (no comments, no line breaks) and
assets/min/<name>.scope.min.css (the same inside @scope, the copy Dark Reader leaves alone), and records each
source's md5 in assets/min/build.json. codex.php uses a built copy only while that md5 still matches its source.
"""
import hashlib, json, os, re

SOURCES = ['assets/codex.css', 'assets/codex-edit.css'] + sorted('assets/skins/' + f for f in os.listdir('assets/skins') if f.endswith('.css'))


def minify(css):
    out, i, q = [], 0, None
    while i < len(css):  # drop /* comments */, but never inside a string
        c = css[i]
        if q:
            out.append(c)
            if c == '\\':
                out.append(css[i + 1]); i += 1
            elif c == q:
                q = None
        elif c in '"\'':
            q = c; out.append(c)
        elif css.startswith('/*', i):
            i = css.index('*/', i) + 1
        else:
            out.append(c)
        i += 1
    lines = [l.strip() for l in ''.join(out).split('\n')]
    return ' '.join(l for l in lines if l).replace('} ', '}').replace('{ ', '{').replace('; ', ';')


os.makedirs('assets/min', exist_ok=True)
built = {}
for src in SOURCES:
    raw = open(src, 'rb').read()
    css = minify(raw.decode('utf-8'))
    name = os.path.basename(src)[:-4]
    open('assets/min/%s.min.css' % name, 'w', encoding='utf-8').write(css + '\n')
    open('assets/min/%s.scope.min.css' % name, 'w', encoding='utf-8').write('@scope (:root){' + css + '}\n')
    built[src] = hashlib.md5(raw).hexdigest()
    print(src, len(raw), '->', len(css.encode('utf-8')))
json.dump(built, open('assets/min/build.json', 'w'), indent=1)
