<?php
// ==========================================================================
//  FILE: inc/card-parts.php   (Codex plugin)
//  WHAT: Parts the card is built from: the difficulty levels and gauge, the colour values of one card, the device label, the group and its colour.
//  SEEN: The difficulty pill, the colours and the group label of every card.
//  SECTIONS IN THIS FILE:
//    1. Card parts: difficulty gauge, colours of one card, group colours
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Card parts: difficulty gauge, colours of one card, group colours
// ==========================================================================

/**
 * The three difficulty levels on the card. Saved values stay 1-5, which the shop filter counts: 1-2 is Beginner,
 * 3-4 Intermediate, 5 Expert. The editors save 1, 3 and 5, so values saved before 1.47.0 keep working.
 */
function fsz_levels() {
	return array(
		1 => array( 'save' => 1, 'word' => __( 'Beginner', 'codex' ) ),
		2 => array( 'save' => 3, 'word' => __( 'Intermediate', 'codex' ) ),
		3 => array( 'save' => 5, 'word' => __( 'Expert', 'codex' ) ),
	);
}

// The level (1-3) of a saved difficulty (1-5); 0 when none is set. Same as levelOf() in codex-edit.js.
function fsz_level( $diff ) {
	$diff = (int) $diff;
	return $diff < 1 ? 0 : ( $diff <= 2 ? 1 : ( $diff <= 4 ? 2 : 3 ) );
}

/**
 * The difficulty gauge: a half dial in three zones (the power bars' green, yellow and red) with a dark rim, and a
 * needle that codex.css turns to the level (data-level on the card). In edit mode the zones are the rating: click one
 * to set the level.
 */
function fsz_gauge( $diff, $edit ) {
	$point = function ( $a ) {
		return sprintf( '%.2f %.2f', 15 + 13 * cos( M_PI * ( 1 - $a ) ), 16 - 13 * sin( M_PI * ( 1 - $a ) ) );
	};
	$arc = function ( $a0, $a1 ) use ( $point ) {
		return 'M' . $point( $a0 ) . 'A13 13 0 0 1 ' . $point( $a1 );
	};
	$level = fsz_level( $diff );
	$segs  = '';
	foreach ( fsz_levels() as $i => $l ) {
		$segs .= '<path class="fsz-seg fsz-z' . $i . ( $i === $level ? ' is-on' : '' ) . '" data-save="' . (int) $l['save'] . '" d="' . $arc( ( $i - 1 ) / 3 + .012, $i / 3 - .012 ) . '"/>';
	}
	$rating = $edit ? ' data-fsz-rating="difficulty" data-value="' . (int) $diff . '" aria-label="' . esc_attr__( 'DIFFICULTY', 'codex' ) . '"' : '';
	return '<span class="fsz-dial"><svg class="fsz-gauge" viewBox="0 0 30 18"' . ( $edit ? '' : ' aria-hidden="true" focusable="false"' ) . '><path class="fsz-gauge-rim" d="' . $arc( 0, 1 ) . '"/><g class="fsz-segs"' . $rating . '>' . $segs . '</g><line class="fsz-needle" x1="15" y1="16" x2="5" y2="16"/><circle class="fsz-hub" cx="15" cy="16" r="2.6"/></svg></span>';
}

function fsz_css_vars( $product_id ) {
	$o      = fsz_opt();
	$device = fsz_product_color( $product_id );
	$vars   = array(
		'--fsz-device'      => $device,
		'--fsz-device-dark' => fsz_theme_dark( $device ),
		// Every theme (the default too) tints the screen: bright like a lit display, dark text in the same hue.
		'--fsz-screen'      => fsz_theme_tint( $o['screen'], $device, FSZ_SCREEN_LIGHT ),
		'--fsz-ink'         => fsz_theme_tint( $o['ink'], $device ),
	);
	$css = '';
	foreach ( $vars as $k => $v ) {
		$v = sanitize_hex_color( $v );
		if ( $v ) {
			$css .= $k . ':' . $v . ';';
		}
	}
	// Motion, the same for every card: levitation strength and the resting angle (codex.css).
	return $css . '--fsz-float:' . (int) $o['float'] . ';--fsz-turn:' . (int) $o['turn'] . 'deg;--fsz-lean:' . (int) $o['lean'] . 'deg;';
}

/**
 * The label on the device: the name of the product's main (top-level) category.
 * Categories under the card categories in the settings come first; Uncategorized is skipped
 * when the product has other categories.
 */
function fsz_device_label( $product_id ) {
	$term = fsz_group_term( $product_id );
	if ( ! $term ) {
		return '';
	}
	return function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $term->name, 'UTF-8' ) : strtoupper( $term->name );
}

// The device label's link: the group's shop page, so a shopper can browse the rest of the group.
function fsz_device_link( $product_id ) {
	$term = fsz_group_term( $product_id );
	$link = $term ? get_term_link( $term ) : '';
	return is_wp_error( $link ) ? '' : (string) $link;
}

/**
 * The product's group: its main (top-level) category, the one named on the device label.
 */
function fsz_group_term( $product_id ) {
	$terms = get_the_terms( $product_id, 'product_cat' );
	if ( ! $terms || is_wp_error( $terms ) ) {
		return null;
	}
	$default = (int) get_option( 'default_product_cat' );
	if ( count( $terms ) > 1 ) {
		$terms = array_values( array_filter( $terms, function ( $t ) use ( $default ) {
			return (int) $t->term_id !== $default;
		} ) );
	}
	$card_ids = fsz_category_ids();
	usort( $terms, function ( $a, $b ) use ( $card_ids ) {
		$ia = in_array( (int) $a->term_id, $card_ids, true ) ? 0 : 1;
		$ib = in_array( (int) $b->term_id, $card_ids, true ) ? 0 : 1;
		return $ia - $ib;
	} );
	$term = $terms[0];
	while ( $term->parent ) {
		$parent = get_term( $term->parent, 'product_cat' );
		if ( ! $parent || is_wp_error( $parent ) ) {
			break;
		}
		$term = $parent;
	}
	return $term;
}

/**
 * Group colours: a top category can have a Codex colour (term meta fsz_color); every card in it,
 * subcategories too, takes it. A colour picked for one product wins; no colour at all = the default theme.
 */
function fsz_group_color( $product_id ) {
	$term  = fsz_group_term( $product_id );
	$color = $term ? sanitize_hex_color( (string) get_term_meta( $term->term_id, 'fsz_color', true ) ) : '';
	return $color ? $color : (string) sanitize_hex_color( fsz_opt( 'device' ) );
}

function fsz_product_color( $product_id ) {
	$own = sanitize_hex_color( trim( (string) get_post_meta( $product_id, '_fsz_color', true ) ) );
	return $own ? $own : fsz_group_color( $product_id );
}

// Starting colours for the known groups (top categories, by name or slug); a colour already set stays.
function fsz_group_presets() {
	return array(
		'isopoda'    => '#1F8A8A', // teal
		'blattodea'  => '#C8692A', // copper orange
		'collembola' => '#3B8A3F', // green
		'arachnida'  => '#6E4BA8', // purple
	);
}

function fsz_seed_group_colors( $term_ids = null ) {
	if ( ! taxonomy_exists( 'product_cat' ) ) {
		return;
	}
	$terms = null === $term_ids
		? get_terms( array( 'taxonomy' => 'product_cat', 'parent' => 0, 'hide_empty' => false ) )
		: array_filter( array_map( function ( $id ) {
			return get_term( $id, 'product_cat' );
		}, (array) $term_ids ) );
	if ( is_wp_error( $terms ) ) {
		return;
	}
	$presets = fsz_group_presets();
	foreach ( $terms as $t ) {
		if ( ! $t || is_wp_error( $t ) || $t->parent || '' !== (string) get_term_meta( $t->term_id, 'fsz_color', true ) ) {
			continue;
		}
		foreach ( array( sanitize_title( $t->name ), $t->slug ) as $k ) {
			if ( isset( $presets[ $k ] ) ) {
				update_term_meta( $t->term_id, 'fsz_color', $presets[ $k ] );
				break;
			}
		}
	}
}
