<?php
// ==========================================================================
//  FILE: inc/settings.php   (Codex plugin)
//  WHAT: Codex's settings: the default values, the skins, the labels on the card, upgrades from older versions, and the helpers that read the lists (stat bars, stats).
//  SEEN: Nothing on its own; every other Codex file reads its settings from here.
//  SECTIONS IN THIS FILE:
//    1. Settings
//    2. Upgrades
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Settings
// ==========================================================================

function fsz_defaults() {
	return array(
		'categories'   => 'live-animals, isopods, springtails',
		'bars'         => "Size\nCourage\nAppetite\nbreeding | Fertility",
		'show_photo'   => '1',
		'device'       => '#1F8A8A',
		'screen'       => '#C9DBA5',
		'ink'          => '#2F3B1E',
		'filter'       => '1',
		'hide_wc'      => '0',
		'tilt'         => '10',
		'float'        => '8', // levitation strength, 0-20 (0 = still)
		'turn'         => '6', // resting angle: turned to the right, degrees (-15 to 15)
		'lean'         => '5', // resting angle: tipped down, degrees (-15 to 15)
		'skin'         => 'default', // 1.62.0: the card's look, see fsz_skins()
	);
}

/**
 * 1.62.0 skins: one look for every card, chosen in the settings (Look > Skin). A skin is one stylesheet that loads after
 * codex.css and only restyles the card (colours, fonts, borders, radii, shadows, effects), never moves anything; the
 * rules and the knobs it can set are at the top of assets/codex.css. 'file' is relative to the plugin folder; another
 * plugin or the theme can add its own skin with the fsz_skins filter and an absolute 'url' instead of 'file'.
 */
function fsz_skins() {
	$skins = array(
		'default' => array( 'label' => 'Default', 'file' => '' ),
		'swiss'   => array( 'label' => 'Swiss (test skin)', 'file' => 'assets/skins/swiss.css' ),
	);
	return (array) apply_filters( 'fsz_skins', $skins );
}

// The chosen skin's slug, 'default' when none or when the saved one is gone.
function fsz_skin() {
	$slug  = (string) fsz_opt( 'skin' );
	$skins = fsz_skins();
	return isset( $skins[ $slug ] ) ? $slug : 'default';
}

// Loads one skin's stylesheet (with its Dark Reader copy) after the card's.
function fsz_skin_style( $slug ) {
	$skins = fsz_skins();
	if ( 'default' === $slug || empty( $skins[ $slug ] ) ) {
		return;
	}
	$sk = $skins[ $slug ];
	if ( ! empty( $sk['file'] ) && is_readable( FSZ_DIR . $sk['file'] ) ) {
		fsz_style( 'codex-skin-' . $slug, $sk['file'], array( 'codex' ) );
	} elseif ( ! empty( $sk['url'] ) ) {
		wp_enqueue_style( 'codex-skin-' . $slug, $sk['url'], array( 'codex' ), FSZ_VERSION );
	}
}

/**
 * Default power bar and detail page labels, translatable. A label typed in the settings
 * that matches one of these is shown in the site language on the card.
 */
function fsz_default_labels() {
	return array(
		'Breeding'        => __( 'Breeding', 'codex' ),
		'Size'            => __( 'Size', 'codex' ),
		'Humidity'        => __( 'Humidity', 'codex' ),
		'Activity'        => __( 'Activity', 'codex' ),
		'Appetite'        => __( 'Appetite', 'codex' ),
		'Courage'         => __( 'Courage', 'codex' ),
		'Fertility'       => __( 'Fertility', 'codex' ),
		'Origin'          => __( 'Origin', 'codex' ),
		'Housing'         => __( 'Housing', 'codex' ),
		'Feeding'         => __( 'Feeding', 'codex' ),
		'Good to know'    => __( 'Good to know', 'codex' ),
	);
}

function fsz_label( $label ) {
	$t = fsz_default_labels();
	return isset( $t[ $label ] ) ? $t[ $label ] : $label;
}

// A list key from a label: "Good to know" -> good_to_know.
function fsz_key( $label ) {
	return str_replace( '-', '_', sanitize_title( $label ) );
}

// ==========================================================================
//  Upgrades
// ==========================================================================

add_action( 'init', function () {
	if ( FSZ_VERSION === get_option( 'fsz_version' ) ) {
		return;
	}
	$version = (string) get_option( 'fsz_version', '' );
	// A new install: the known groups start with their colour (after WooCommerce has registered the categories).
	// 1.48.0: the steps for updates from before 1.40.0 are gone; every install is past them.
	if ( '' === $version ) {
		add_action( 'init', function () {
			fsz_seed_group_colors();
		}, 20 );
	}
	// 1.51.0: the detail page sections become one text; each product's sections are put into it once.
	if ( '' !== $version && version_compare( $version, '1.51.0', '<' ) ) {
		fsz_merge_sections();
	}
	// 1.48.0: the star colour and the facts list are no longer settings.
	$saved = get_option( FSZ_OPT );
	if ( is_array( $saved ) && ( isset( $saved['star'] ) || isset( $saved['facts'] ) ) ) {
		unset( $saved['star'], $saved['facts'] );
		update_option( FSZ_OPT, $saved );
	}
	update_option( 'fsz_version', FSZ_VERSION );
}, 5 );

/**
 * 1.51.0: the old detail sections (Origin, Housing ...) of each product go into its one text, as "Heading: text" lines in
 * the old order, headings in the shop language. Only where that text is still empty. The old values stay saved, so
 * they can be checked and then deleted under Clean up old data.
 */
function fsz_merge_sections() {
	global $wpdb;
	$saved = get_option( FSZ_OPT );
	$list  = is_array( $saved ) && isset( $saved['more'] ) ? $saved['more'] : "Origin\nHousing\nFeeding\nBreeding\nGood to know";
	$rows  = fsz_list_rows( $list );
	// Headings in the shop language, also when an admin with another language runs the update.
	$mo   = new MO();
	$file = FSZ_DIR . 'languages/codex-' . get_locale() . '.mo';
	$mo   = is_readable( $file ) && $mo->import_from_file( $file ) ? $mo : null;
	$ids  = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key LIKE %s AND meta_value <> ''", $wpdb->esc_like( '_fsz_more_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	foreach ( $ids as $id ) {
		if ( '' !== trim( (string) get_post_meta( $id, '_fsz_story', true ) ) ) {
			continue;
		}
		$keys  = array_keys( $rows );
		$lines = array();
		foreach ( get_post_meta( $id ) as $k => $v ) {
			if ( 0 === strpos( $k, '_fsz_more_' ) && ! in_array( substr( $k, 10 ), $keys, true ) ) {
				$keys[] = substr( $k, 10 ); // a section no longer in the list: last
			}
		}
		foreach ( $keys as $key ) {
			$text = trim( (string) get_post_meta( $id, '_fsz_more_' . $key, true ) );
			if ( '' === $text ) {
				continue;
			}
			$label   = isset( $rows[ $key ] ) ? $rows[ $key ] : fsz_key_label( $key );
			$label   = $mo ? $mo->translate( $label ) : $label;
			$lines[] = $label . ': ' . $text;
		}
		if ( $lines ) {
			update_post_meta( $id, '_fsz_story', implode( "\n", $lines ) );
		}
	}
	if ( is_array( $saved ) && isset( $saved['more'] ) ) {
		unset( $saved['more'] );
		update_option( FSZ_OPT, $saved );
	}
}

function fsz_opt( $key = null ) {
	$opts = wp_parse_args( (array) get_option( FSZ_OPT, array() ), fsz_defaults() );
	return null === $key ? $opts : ( isset( $opts[ $key ] ) ? $opts[ $key ] : '' );
}

/**
 * Rows of a "one per line" list as [key, label], labels as typed. A line is either "Label" or "key | Label".
 * The key stays stable when you reorder or rename lines, so saved values never move to another bar.
 */
function fsz_list_rows( $text ) {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		if ( false !== strpos( $line, '|' ) ) {
			list( $key, $label ) = array_map( 'trim', explode( '|', $line, 2 ) );
		} else {
			$key   = $line;
			$label = $line;
		}
		$key = fsz_key( $key );
		if ( '' !== $key && '' !== $label ) {
			$out[ $key ] = $label;
		}
	}
	return $out;
}

// The list with its labels in the site language (default labels are translated).
function fsz_parse_list( $text ) {
	return array_map( 'fsz_label', fsz_list_rows( $text ) );
}

function fsz_bars() {
	return fsz_parse_list( fsz_opt( 'bars' ) );
}

/**
 * The four standard power bars: default label, and the keys or labels (English or Hungarian,
 * as a key) that count as the same bar. Used for the bar icons and the 1.40.0 upgrade.
 */
function fsz_bar_kinds() {
	return array(
		'size'     => array( 'Size', array( 'size', 'meret', 'termet' ) ),
		'courage'  => array( 'Courage', array( 'courage', 'batorsag' ) ),
		'appetite' => array( 'Appetite', array( 'appetite', 'etvagy', 'falanksag' ) ),
		'breeding' => array( 'Fertility', array( 'breeding', 'fertility', 'breeding_rate', 'szaporodas', 'szaporasag' ) ),
	);
}

// Which standard bar a list row is, from its key or its label; '' for a bar you added yourself.
function fsz_bar_kind( $key, $label = '' ) {
	foreach ( fsz_bar_kinds() as $kind => $def ) {
		if ( in_array( $key, $def[1], true ) || ( '' !== $label && in_array( fsz_key( $label ), $def[1], true ) ) ) {
			return $kind;
		}
	}
	return '';
}

// The small icon in front of a standard bar's name (16 px grid; .fsz-kf / .fsz-ks are cut-outs in the tile colour).
function fsz_bar_icon( $kind ) {
	$icons = array(
		'size'     => '<path d="M8 13V3.2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M4 7 8 3l4 4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 15h10" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
		'courage'  => '<path d="M8 .8 14.4 3v4.2c0 4-2.8 6.8-6.4 8-3.6-1.2-6.4-4-6.4-8V3z" fill="currentColor"/><path d="M8 3 9.1 4.4V9.6H6.9V4.4z" class="fsz-kf"/><path d="M5 10h6M8 10v2.6" class="fsz-ks" stroke-width="1.4" stroke-linecap="round"/>',
		'appetite' => '<path d="M2.5 13.5C2.5 6 6.5 2 14 2 14 9.5 10 13.5 2.5 13.5Z" fill="currentColor"/><path d="M1.2 14.8 3.6 12.4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><circle cx="12.1" cy="9.3" r="2.2" class="fsz-kf"/><circle cx="8.9" cy="12.3" r="1.9" class="fsz-kf"/><path d="M3.6 12.4 12.6 3.4" class="fsz-ks" stroke-width="1" stroke-linecap="round"/>',
		'breeding' => '<text x="8" y="12.6" text-anchor="middle" font-size="11.5" fill="currentColor">×2</text>',
	);
	return isset( $icons[ $kind ] ) ? '<span class="fsz-bar-ic" aria-hidden="true"><svg viewBox="0 0 16 16" focusable="false">' . $icons[ $kind ] . '</svg></span>' : '';
}

/**
 * 1.51.0: the four tiles under the detail page text, key => array( label, icon ). Short free text each ("70-80%", "5 cm").
 * The icons are drawn like the power bar icons.
 */
function fsz_stats() {
	return array(
		'humidity'  => array( _x( 'Humidity', 'detail page tile', 'codex' ), '<path d="M8 1.2C8 1.2 3 7 3 10.2a5 5 0 0 0 10 0C13 7 8 1.2 8 1.2Z" fill="currentColor"/><path d="M5.6 10.3a2.4 2.4 0 0 0 2.1 2.3" class="fsz-ks" stroke-width="1.3" stroke-linecap="round"/>' ),
		'substrate' => array( _x( 'Substrate depth', 'detail page tile', 'codex' ), '<path d="M8 5.2V2.6M8 3.4C6.9 1.9 5.5 2 5.2 2.4M8 3.4c1.1-1.5 2.5-1.4 2.8-1" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/><rect x="1.5" y="5.4" width="13" height="2.8" rx="1" fill="currentColor"/><rect x="1.5" y="9" width="13" height="2.6" rx="1" fill="currentColor" opacity=".7"/><rect x="1.5" y="12.4" width="13" height="2.4" rx="1" fill="currentColor" opacity=".45"/>' ),
		'protein'   => array( _x( 'Protein', 'detail page tile', 'codex' ), '<path d="M1.2 8c2.1-3.5 6.8-4.5 10.4 0-3.6 4.5-8.3 3.5-10.4 0Z" fill="currentColor"/><path d="M11.4 8 15 5v6Z" fill="currentColor"/><circle cx="4.5" cy="7.3" r="1" class="fsz-kf"/>' ),
		'offspring' => array( _x( 'Offspring', 'detail page tile', 'codex' ), '<ellipse cx="5.8" cy="8.4" rx="4.6" ry="3.3" fill="currentColor"/><path d="M4 5.4v6M6.5 5.2v6.4" class="fsz-ks" stroke-width="1" stroke-linecap="round"/><circle cx="12.6" cy="5.6" r="1.8" fill="currentColor"/><circle cx="13" cy="10.9" r="1.5" fill="currentColor"/>' ),
	);
}

// Words in a text, as the edit counter counts them.
function fsz_word_count( $text ) {
	return count( preg_split( '/\s+/u', trim( (string) $text ), -1, PREG_SPLIT_NO_EMPTY ) );
}

// A readable name for a saved key that is not in a list any more.
function fsz_key_label( $key ) {
	foreach ( array_keys( fsz_default_labels() ) as $label ) {
		if ( fsz_key( $label ) === $key ) {
			return $label;
		}
	}
	return ucfirst( str_replace( '_', ' ', $key ) );
}
