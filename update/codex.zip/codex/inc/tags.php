<?php
// ==========================================================================
//  FILE: inc/tags.php   (Codex plugin)
//  WHAT: Keeps the Codex tags in step with WooCommerce's product tags.
//  SEEN: Behind the scenes; tag chips link to the shop filtered by tag.
//  SECTIONS IN THIS FILE:
//    1. Tags = WooCommerce product tags
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Tags = WooCommerce product tags
// ==========================================================================

/**
 * The Codex tags are also the product's WooCommerce tags, so each one has its own shop page (the theme links them next
 * to the price). Runs whenever _fsz_tags changes: the product box, quick edit and the CSV import alike. Tags added to
 * the product another way stay; a tag taken out of the Codex tags is taken off the product too.
 */
function fsz_sync_tags( $product_id ) {
	if ( ! taxonomy_exists( 'product_tag' ) || 'product' !== get_post_type( $product_id ) || ! empty( $GLOBALS['fsz_deleting'][ $product_id ] ) ) {
		return;
	}
	$tags = fsz_tags( $product_id );
	$old  = get_post_meta( $product_id, '_fsz_tags_synced', true );
	$old  = is_array( $old ) ? $old : array();
	$cur  = wp_get_object_terms( $product_id, 'product_tag', array( 'fields' => 'names' ) );
	if ( is_wp_error( $cur ) ) {
		return;
	}
	$cur  = array_map( 'wp_specialchars_decode', $cur );
	$keep = array_diff( $cur, array_diff( $old, $tags ) );
	wp_set_object_terms( $product_id, array_values( array_unique( array_merge( $keep, $tags ) ) ), 'product_tag' );
	if ( $tags ) {
		update_post_meta( $product_id, '_fsz_tags_synced', $tags );
	} else {
		delete_post_meta( $product_id, '_fsz_tags_synced' );
	}
}

foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $fsz_hook ) {
	add_action( $fsz_hook, function ( $meta_id, $object_id, $meta_key ) {
		if ( '_fsz_tags' === $meta_key ) {
			fsz_sync_tags( (int) $object_id );
		}
	}, 10, 3 );
}
unset( $fsz_hook );

// A product being deleted loses its terms first, then its meta: its tags must not be put back on the way out.
add_action( 'before_delete_post', function ( $post_id ) {
	$GLOBALS['fsz_deleting'][ (int) $post_id ] = true;
} );
