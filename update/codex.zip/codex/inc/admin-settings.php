<?php
// ==========================================================================
//  FILE: inc/admin-settings.php   (Codex plugin)
//  WHAT: DASHBOARD ONLY. The Codex settings page (lists, colours, preview) and the cleanup tool for old data.
//  SEEN: Dashboard → WooCommerce → Codex.
//  SECTIONS IN THIS FILE:
//    1. Admin: settings page
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Admin: settings page
// ==========================================================================

add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'Codex', 'Codex', 'manage_woocommerce', 'codex', 'fsz_settings_page' );
}, 60 );

add_action( 'admin_init', function () {
	register_setting( 'fsz_group', FSZ_OPT, array( 'sanitize_callback' => 'fsz_sanitize_settings' ) );
} );

/**
 * A list from the settings page (rows of key + label, in the order shown) as "one per line" text.
 * A row without a key is new: its key comes from its label. Plain text (older saves, upgrades) is kept as it is.
 */
function fsz_rows_text( $v ) {
	if ( ! is_array( $v ) ) {
		return sanitize_textarea_field( (string) $v );
	}
	$lines = array();
	$used  = array();
	foreach ( $v as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$label = trim( str_replace( '|', '/', sanitize_text_field( isset( $row['label'] ) ? $row['label'] : '' ) ) );
		$key   = isset( $row['key'] ) ? trim( (string) $row['key'] ) : '';
		$key   = fsz_key( '' === $key ? $label : $key );
		if ( '' === $label || '' === $key ) {
			continue;
		}
		// Two rows with the same name still get their own values.
		$base = $key;
		for ( $n = 2; isset( $used[ $key ] ); $n++ ) {
			$key = $base . '_' . $n;
		}
		$used[ $key ] = true;
		$lines[]      = fsz_key( $label ) === $key ? $label : $key . ' | ' . $label;
	}
	return implode( "\n", $lines );
}

function fsz_sanitize_settings( $in ) {
	$def   = fsz_defaults();
	$saved = (array) get_option( FSZ_OPT, array() );
	$out   = array();
	foreach ( $def as $k => $d ) {
		$v = isset( $in[ $k ] ) ? $in[ $k ] : '';
		if ( in_array( $k, array( 'float', 'turn', 'lean' ), true ) ) {
			// Set in the edit card (motion), not on the settings page: keep what is saved when it is not sent.
			$v         = isset( $in[ $k ] ) ? $v : ( isset( $saved[ $k ] ) ? $saved[ $k ] : $d );
			$out[ $k ] = 'float' === $k ? (string) max( 0, min( 20, (int) $v ) ) : (string) max( -15, min( 15, (int) $v ) );
		} elseif ( 'bars' === $k ) {
			$out[ $k ] = fsz_rows_text( $v );
		} elseif ( 'skin' === $k ) {
			$v         = sanitize_key( $v );
			$out[ $k ] = array_key_exists( $v, fsz_skins() ) ? $v : 'default';
		} elseif ( 'tilt' === $k ) {
			$out[ $k ] = (string) max( 0, min( 20, (int) $v ) );
		} elseif ( in_array( $k, array( 'show_photo', 'filter', 'hide_wc' ), true ) ) {
			$out[ $k ] = '1' === $v ? '1' : '0';
		} elseif ( 'categories' === $k ) {
			// Ticked boxes send slugs; older saves are comma separated text.
			$out[ $k ] = is_array( $v ) ? implode( ', ', array_filter( array_map( 'sanitize_title', $v ) ) ) : sanitize_text_field( $v );
		} else {
			$c         = sanitize_hex_color( $v );
			$out[ $k ] = $c ? $c : $d;
		}
	}
	return $out;
}

// Products with a saved value per field key, for one kind of field ('bar').
function fsz_saved_counts( $prefix ) {
	global $wpdb;
	$meta = '_fsz_' . $prefix . '_';
	$rows = $wpdb->get_results( $wpdb->prepare( "SELECT m.meta_key, COUNT(DISTINCT m.post_id) AS n FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE p.post_type = 'product' AND p.post_status <> 'trash' AND m.meta_key LIKE %s AND m.meta_value <> '' AND m.meta_value <> '0' GROUP BY m.meta_key", $wpdb->esc_like( $meta ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$out  = array();
	foreach ( $rows as $r ) {
		$out[ substr( $r->meta_key, strlen( $meta ) ) ] = (int) $r->n;
	}
	return $out;
}

function fsz_products_text( $n ) {
	return $n ? sprintf( 1 === $n ? '%d product' : '%d products', $n ) : 'Not filled in yet';
}

function fsz_list_row( $name, $i, $key, $label, $n ) {
	$field = $name . '[' . $i . ']';
	echo '<li class="fsz-row">';
	echo '<span class="fsz-handle" title="Drag to change the order" aria-hidden="true"></span>';
	echo '<input type="hidden" class="fsz-row-key" name="' . esc_attr( $field . '[key]' ) . '" value="' . esc_attr( $key ) . '">';
	echo '<input type="text" class="fsz-row-label" name="' . esc_attr( $field . '[label]' ) . '" value="' . esc_attr( $label ) . '" aria-label="Name" placeholder="Name">';
	echo '<span class="fsz-row-count' . ( $n ? '' : ' is-empty' ) . '">' . esc_html( fsz_products_text( $n ) ) . '</span>';
	echo '<button type="button" class="fsz-row-remove" title="Remove from the card. Values already filled in are kept." aria-label="Remove"></button>';
	echo '</li>';
}

/**
 * A list on the settings page: drag to sort, rename in place (the hidden key keeps the values), add, remove.
 * Saved values whose row was removed or renamed the old way are offered back below the list.
 */
function fsz_list_editor( $list, $prefix, $add ) {
	$name   = FSZ_OPT . '[' . $list . ']';
	$rows   = fsz_list_rows( fsz_opt( $list ) );
	$counts = fsz_saved_counts( $prefix );
	echo '<div class="fsz-list" data-name="' . esc_attr( $name ) . '"><ol class="fsz-rows">';
	$i = 0;
	foreach ( $rows as $key => $label ) {
		fsz_list_row( $name, $i++, $key, $label, isset( $counts[ $key ] ) ? $counts[ $key ] : 0 );
	}
	echo '</ol>';
	echo '<button type="button" class="button fsz-add"><span aria-hidden="true">+</span> ' . esc_html( $add ) . '</button>';
	$lost = array_diff_key( $counts, $rows );
	if ( $lost ) {
		echo '<div class="fsz-lost"><p><b>Values not on the card.</b> These were filled in earlier, but their line was removed or renamed. Click one to bring it back with its values, then rename it.</p><div class="fsz-lost-chips">';
		foreach ( $lost as $key => $n ) {
			echo '<button type="button" class="fsz-chip" data-key="' . esc_attr( $key ) . '" data-label="' . esc_attr( fsz_key_label( $key ) ) . '" data-count="' . esc_attr( fsz_products_text( $n ) ) . '">+ ' . esc_html( fsz_key_label( $key ) ) . ' <span>' . esc_html( fsz_products_text( $n ) ) . '</span></button>';
		}
		echo '</div></div>';
	}
	echo '<template class="fsz-row-tpl">';
	fsz_list_row( $name, '__i__', '', '', 0 );
	echo '</template></div>';
}

// Product categories as a tree of checkboxes; a ticked category includes its subcategories.
function fsz_category_tree( $terms, $parent, $chosen, $setup = null ) {
	$kids = array_filter( $terms, function ( $t ) use ( $parent ) {
		return (int) $t->parent === (int) $parent;
	} );
	if ( ! $kids ) {
		return;
	}
	echo '<ul' . ( $parent ? '' : ' class="fsz-cats"' ) . '>';
	foreach ( $kids as $t ) {
		// A group that is not set up (and everything in it) cannot be ticked.
		$ok = null === $setup ? '' !== fsz_term_kind( $t ) : $setup;
		echo '<li><label class="fsz-cat' . ( $ok ? '' : ' is-off' ) . '"><input type="checkbox" name="' . esc_attr( FSZ_OPT ) . '[categories][]" value="' . esc_attr( $t->slug ) . '"' . checked( $ok && in_array( $t->slug, $chosen, true ), true, false ) . disabled( ! $ok, true, false ) . '> <span class="fsz-cat-name">' . esc_html( $t->name ) . '</span> <span class="fsz-cat-count">' . (int) $t->count . '</span>' . ( ! $ok && null === $setup ? ' <span class="fsz-cat-note">no card: not a set-up group</span>' : '' ) . '</label>';
		fsz_category_tree( $terms, $t->term_id, $chosen, $ok );
		echo '</li>';
	}
	echo '</ul>';
}

// Published products that show the card, for the preview.
function fsz_preview_products() {
	$ids = fsz_category_ids();
	if ( ! $ids ) {
		return array();
	}
	$posts = get_posts( array(
		'post_type'   => 'product',
		'post_status' => 'publish',
		'numberposts' => 100,
		'orderby'     => 'date',
		'order'       => 'ASC',
		'tax_query'   => array( array( 'taxonomy' => 'product_cat', 'terms' => $ids ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
	) );
	return array_values( array_filter( $posts, function ( $p ) {
		return fsz_is_live( $p->ID );
	} ) );
}

function fsz_preview_html( $product_id ) {
	return $product_id ? '<div class="fsz-wrap">' . fsz_render_card( $product_id ) . '</div>' : '';
}

// The preview with the settings as they are on the page, not saved yet.
add_action( 'wp_ajax_fsz_preview', function () {
	check_ajax_referer( 'fsz_preview', 'nonce' );
	$id = isset( $_POST['product'] ) ? absint( $_POST['product'] ) : 0;
	if ( ! current_user_can( 'manage_woocommerce' ) || ! $id || 'product' !== get_post_type( $id ) ) {
		wp_send_json_error( null, 403 );
	}
	$in       = isset( $_POST[ FSZ_OPT ] ) && is_array( $_POST[ FSZ_OPT ] ) ? wp_unslash( $_POST[ FSZ_OPT ] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$settings = fsz_sanitize_settings( $in );
	add_filter( 'pre_option_' . FSZ_OPT, function () use ( $settings ) {
		return $settings;
	} );
	wp_send_json_success( array( 'html' => fsz_preview_html( $id ) ) );
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( 'woocommerce_page_codex' !== $hook ) {
		return;
	}
	// The card itself, for the preview, with every skin (each one is scoped to its data-fsz-skin, so the preview can switch).
	fsz_style( 'codex', 'assets/codex.css' );
	foreach ( array_keys( fsz_skins() ) as $slug ) {
		fsz_skin_style( $slug );
	}
	wp_enqueue_style( 'codex-font', FSZ_URL . 'assets/fonts/ibm-plex-mono/font.css', array(), FSZ_VERSION );
	wp_enqueue_script( 'codex', FSZ_URL . 'assets/codex.js', array(), FSZ_VERSION, true );
	wp_enqueue_style( 'codex-admin', FSZ_URL . 'assets/codex-admin.css', array( 'wp-color-picker' ), FSZ_VERSION );
	wp_enqueue_script( 'codex-admin', FSZ_URL . 'assets/codex-admin.js', array( 'jquery', 'jquery-ui-sortable', 'wp-color-picker', 'codex' ), FSZ_VERSION, true );
	wp_localize_script( 'codex-admin', 'CodexAdmin', array(
		'ajax'     => admin_url( 'admin-ajax.php' ),
		'nonce'    => wp_create_nonce( 'fsz_preview' ),
		'palettes' => array_keys( fsz_themes() ),
		'empty'    => fsz_products_text( 0 ),
	) );
}, 20 );

function fsz_settings_page() {
	$o        = fsz_opt();
	$opt      = FSZ_OPT;
	$chosen   = array_filter( array_map( 'sanitize_title', explode( ',', $o['categories'] ) ) );
	$terms    = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
	$terms    = is_wp_error( $terms ) ? array() : $terms;
	$missing  = array_diff( $chosen, wp_list_pluck( $terms, 'slug' ) );
	$products = fsz_preview_products();
	$first    = $products ? $products[0]->ID : 0;
	$switch   = function ( $key, $title, $desc ) use ( $o, $opt ) {
		echo '<label class="fsz-switch"><input type="checkbox" role="switch" name="' . esc_attr( $opt ) . '[' . esc_attr( $key ) . ']" value="1"' . checked( $o[ $key ], '1', false ) . '><span class="fsz-switch-ui" aria-hidden="true"></span><span class="fsz-switch-text"><b>' . esc_html( $title ) . '</b><span>' . esc_html( $desc ) . '</span></span></label>';
	};
	?>
	<div class="wrap fsz-settings">
		<form method="post" action="options.php" id="fsz-settings-form">
			<?php settings_fields( 'fsz_group' ); ?>
			<header class="fsz-header">
				<div>
					<h1>Codex</h1>
					<p>The species card on your live animal product pages.</p>
				</div>
				<?php submit_button( 'Save changes', 'primary large', 'submit', false ); ?>
			</header>
			<?php settings_errors(); ?>
			<hr class="wp-header-end">

			<div class="fsz-layout">
				<div class="fsz-main">

					<section class="fsz-panel">
						<h2>Where the card shows</h2>
						<div class="fsz-field">
							<div class="fsz-field-head"><b>Categories</b><span>Products in a ticked category get the card. Its subcategories are included. Only the set-up groups (Isopoda, Blattodea, Collembola, Arachnida) can have it; every other group, such as supplies, never shows the card.</span></div>
							<?php if ( $terms ) : ?>
								<?php fsz_category_tree( $terms, 0, $chosen ); ?>
							<?php else : ?>
								<p class="fsz-note">No product categories yet. Add them under Products → Categories.</p>
							<?php endif; ?>
							<p class="fsz-note is-warning" id="fsz-cats-none"<?php echo $chosen ? ' hidden' : ''; ?>>No category ticked: the card is not shown on any product.</p>
							<?php if ( $missing ) : ?>
								<p class="fsz-note is-warning">Not found and removed when you save: <?php echo esc_html( implode( ', ', $missing ) ); ?></p>
							<?php endif; ?>
						</div>
					</section>

					<section class="fsz-panel">
						<h2>Product page and shop</h2>
						<?php
						$switch( 'show_photo', 'Photos on the screen', 'The product photos show on the Codex screen. They change every 10 seconds, on a click or a swipe.' );
						$switch( 'hide_wc', 'Hide WooCommerce details', 'On card products: no short description, categories/tags or Description/Reviews tabs. Title, price and cart button stay.' );
						$switch( 'filter', 'Difficulty filter in the shop', 'A dropdown above the product list to show species up to a difficulty.' );
						?>
					</section>

					<section class="fsz-panel">
						<h2>Power bars</h2>
						<p class="fsz-panel-desc">The rated lines on the card, in this order. Drag to reorder. Renaming keeps the values already filled in.</p>
						<?php fsz_list_editor( 'bars', 'bar', 'Add power bar' ); ?>
					</section>

					<section class="fsz-panel">
						<h2>Look</h2>
						<div class="fsz-field">
							<div class="fsz-field-head"><b><label for="fsz-skin">Skin</label></b><span>The style of every card. A skin changes colours, lines and effects only; everything stays in its place.</span></div>
							<select id="fsz-skin" name="<?php echo esc_attr( $opt ); ?>[skin]">
								<?php foreach ( fsz_skins() as $slug => $sk ) : ?>
									<option value="<?php echo esc_attr( $slug ); ?>"<?php selected( fsz_skin(), $slug ); ?>><?php echo esc_html( isset( $sk['label'] ) ? $sk['label'] : $slug ); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						<div class="fsz-field">
							<div class="fsz-field-head"><b><label for="fsz-tilt">3D tilt</label></b><span>How far the card turns toward the mouse. 0 = flat. Phones always get the still card.</span></div>
							<div class="fsz-range"><input type="range" id="fsz-tilt" min="0" max="20" step="1" name="<?php echo esc_attr( $opt ); ?>[tilt]" value="<?php echo esc_attr( $o['tilt'] ); ?>"><output for="fsz-tilt" id="fsz-tilt-val"><?php echo esc_html( $o['tilt'] ); ?></output></div>
						</div>
						<div class="fsz-colors">
							<?php
							$colors = array(
								'device' => array( 'Default theme', 'For groups without a colour. Each group (Products › Categories) and each species can have its own. The screen frame is a darker shade.' ),
								'screen' => array( 'Screen', 'How soft the screen is. The hue follows the theme.' ),
								'ink'    => array( 'Screen text', 'How dark the text is. The hue follows the theme.' ),
							);
							$def = fsz_defaults();
							foreach ( $colors as $k => $c ) {
								echo '<div class="fsz-color-field"><div class="fsz-field-head"><b>' . esc_html( $c[0] ) . '</b><span>' . esc_html( $c[1] ) . '</span></div><input type="text" class="fsz-color" name="' . esc_attr( $opt ) . '[' . esc_attr( $k ) . ']" value="' . esc_attr( $o[ $k ] ) . '" data-default-color="' . esc_attr( $def[ $k ] ) . '" aria-label="' . esc_attr( $c[0] ) . '"></div>';
							}
							?>
						</div>
					</section>

					<details class="fsz-panel fsz-csv">
						<summary><h2>CSV import columns</h2></summary>
						<p class="fsz-panel-desc">Products → Import, tick "Update existing products". Products are matched by SKU. _fsz_name is the nickname, _fsz_trade the English name; _fsz_badge is new, sale, rare or empty; _fsz_traits lists the badges over the power bars, comma separated: cleanup, ball, feeder.</p>
						<code><?php
						$cols = array( 'SKU', 'Meta: _fsz_name', 'Meta: _fsz_trade', 'Meta: _fsz_latin', 'Meta: _fsz_difficulty', 'Meta: _fsz_tags', 'Meta: _fsz_badge', 'Meta: _fsz_traits', 'Meta: _fsz_image' );
						foreach ( array_keys( fsz_bars() ) as $k ) {
							$cols[] = 'Meta: _fsz_bar_' . $k;
						}
						$cols = array_merge( $cols, array( 'Meta: _fsz_fun', 'Meta: _fsz_color' ) );
						$cols[] = 'Meta: _fsz_story';
						foreach ( array_keys( fsz_stats() ) as $k ) {
							$cols[] = 'Meta: _fsz_stat_' . $k;
						}
						echo esc_html( implode( ',', $cols ) );
						?></code>
					</details>

					<?php $old = fsz_old_data(); ?>
					<section class="fsz-panel fsz-cleanup">
						<h2>Clean up old data</h2>
						<?php if ( isset( $_GET['fsz_cleaned'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
							<p class="fsz-note"><?php echo esc_html( sprintf( 'Deleted %d old values.', absint( $_GET['fsz_cleaned'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification ?></p>
						<?php endif; ?>
						<?php if ( $old ) : ?>
							<p class="fsz-panel-desc">Values saved on products that no card line uses any more. Deleting them cannot be undone, and they can no longer be brought back under the lists above.</p>
							<ul class="fsz-old">
								<?php foreach ( $old as $row ) : ?>
									<li><b><?php echo esc_html( $row[0] ); ?></b> <span><?php echo esc_html( fsz_products_text( $row[1] ) ); ?></span></li>
								<?php endforeach; ?>
							</ul>
							<button type="submit" form="fsz-cleanup" class="button button-link-delete" onclick="return window.confirm( 'Delete these saved values from every product? This cannot be undone.' )">Delete old data</button>
						<?php else : ?>
							<p class="fsz-panel-desc">Nothing to clean up: the card uses every saved value.</p>
						<?php endif; ?>
					</section>

					<div class="fsz-save"><?php submit_button( 'Save changes', 'primary large', 'submit', false ); ?></div>
				</div>

				<aside class="fsz-side">
					<div class="fsz-panel fsz-preview-panel">
						<div class="fsz-preview-head">
							<h2>Live preview</h2>
							<?php if ( $products ) : ?>
								<select id="fsz-preview-product" aria-label="Product to preview">
									<?php foreach ( $products as $p ) : ?>
										<option value="<?php echo (int) $p->ID; ?>" data-url="<?php echo esc_url( get_permalink( $p ) ); ?>"><?php echo esc_html( html_entity_decode( get_the_title( $p ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ); ?></option>
									<?php endforeach; ?>
								</select>
							<?php endif; ?>
						</div>
						<?php if ( $products ) : ?>
							<div class="fsz-preview" id="fsz-preview" aria-live="polite"><?php echo fsz_preview_html( $first ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
							<p class="fsz-preview-foot"><span>Changes show here before you save.</span> <a id="fsz-preview-link" href="<?php echo esc_url( get_permalink( $first ) ); ?>" target="_blank" rel="noopener">Open product page ↗</a></p>
						<?php else : ?>
							<p class="fsz-note">No product shows the card yet. Tick a category with products, save, and a preview appears here.</p>
						<?php endif; ?>
					</div>
				</aside>
			</div>
		</form>
		<form id="fsz-cleanup" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="fsz_cleanup">
			<?php wp_nonce_field( 'fsz_cleanup' ); ?>
		</form>
	</div>
	<?php
}

/**
 * 1.48.0: values saved on products that no card line uses any more: the fields taken off the card (ability, weak point,
 * pack, the facts) and power bars or detail sections that are no longer in the lists. Meta key => array( label, products ).
 */
function fsz_old_data() {
	global $wpdb;
	$used = array();
	foreach ( fsz_field_keys() as $k ) {
		$used[] = '_fsz_' . $k;
	}
	$fixed = array(
		'_fsz_ability' => 'Ability',
		'_fsz_weak'    => 'Weak point',
		'_fsz_pack'    => 'Pack',
	);
	$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT meta_key, COUNT(DISTINCT post_id) AS n FROM {$wpdb->postmeta} WHERE meta_key LIKE %s GROUP BY meta_key", $wpdb->esc_like( '_fsz_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$out   = array();
	foreach ( $rows as $r ) {
		$k     = (string) $r->meta_key;
		$label = '';
		if ( isset( $fixed[ $k ] ) ) {
			$label = $fixed[ $k ];
		} elseif ( 0 === strpos( $k, '_fsz_fact_' ) ) {
			$label = 'Fact: ' . fsz_key_label( substr( $k, 10 ) );
		} elseif ( 0 === strpos( $k, '_fsz_bar_' ) && ! in_array( $k, $used, true ) ) {
			$label = 'Power bar: ' . fsz_key_label( substr( $k, 9 ) );
		} elseif ( 0 === strpos( $k, '_fsz_more_' ) && ! in_array( $k, $used, true ) ) {
			$label = 'Detail section: ' . fsz_key_label( substr( $k, 10 ) );
		}
		if ( '' !== $label ) {
			$out[ $k ] = array( $label, (int) $r->n );
		}
	}
	return $out;
}

add_action( 'admin_post_fsz_cleanup', function () {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( 'Sorry, you are not allowed to do this.' );
	}
	check_admin_referer( 'fsz_cleanup' );
	global $wpdb;
	$n = 0;
	foreach ( array_keys( fsz_old_data() ) as $key ) {
		$n += (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s", $key ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}
	wp_cache_flush();
	wp_safe_redirect( admin_url( 'admin.php?page=codex&fsz_cleaned=' . $n ) );
	exit;
} );
