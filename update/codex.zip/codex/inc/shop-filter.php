<?php
// ==========================================================================
//  FILE: inc/shop-filter.php   (Codex plugin)
//  WHAT: The difficulty filter on shop lists.
//  SEEN: Shop and category lists.
//  SECTIONS IN THIS FILE:
//    1. Shop filter: difficulty
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Shop filter: difficulty
// ==========================================================================

add_action( 'woocommerce_before_shop_loop', function () {
	// 1.48.0: not printed under the Ízeltláb theme, whose difficulty pills do the same job (it only hid the dropdown).
	// Another theme can turn it off with the fsz_filter_dropdown filter.
	if ( '1' !== fsz_opt( 'filter' ) || ! apply_filters( 'fsz_filter_dropdown', ! function_exists( 'izl_has_codex' ) ) ) {
		return;
	}
	$ids = fsz_category_ids();
	if ( is_product_category() ) {
		$cur = get_queried_object();
		if ( ! $cur || ! in_array( (int) $cur->term_id, $ids, true ) ) {
			return;
		}
	} elseif ( ! is_shop() ) {
		return;
	}
	$sel = isset( $_GET['max_difficulty'] ) ? (int) $_GET['max_difficulty'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	echo '<form class="fsz-filter" method="get"><label for="fsz-max-difficulty">' . esc_html__( 'Difficulty:', 'codex' ) . '</label> <select id="fsz-max-difficulty" name="max_difficulty" onchange="this.form.submit()">';
	echo '<option value="0">' . esc_html__( 'All', 'codex' ) . '</option>';
	// Up to a level: Beginner (saved 1-2), Beginner and Intermediate (1-4). Expert and up is every species, so "All".
	$levels = fsz_levels();
	$ups    = array(
		2 => $levels[1]['word'],
		/* translators: 1: Beginner, 2: Intermediate */
		4 => sprintf( __( '%1$s + %2$s', 'codex' ), $levels[1]['word'], $levels[2]['word'] ),
	);
	foreach ( $ups as $i => $text ) {
		echo '<option value="' . (int) $i . '"' . selected( $sel, $i, false ) . '>' . esc_html( $text ) . '</option>';
	}
	echo '</select>';
	foreach ( $_GET as $k => $v ) { // phpcs:ignore WordPress.Security.NonceVerification
		if ( 'max_difficulty' !== $k && is_scalar( $v ) ) {
			echo '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( wp_unslash( $v ) ) . '">';
		}
	}
	echo '<noscript><button type="submit">' . esc_html__( 'Filter', 'codex' ) . '</button></noscript></form>';
}, 25 );

add_action( 'woocommerce_product_query', function ( $q ) {
	if ( '1' !== fsz_opt( 'filter' ) ) {
		return;
	}
	$sel = isset( $_GET['max_difficulty'] ) ? (int) $_GET['max_difficulty'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	if ( $sel < 1 || $sel > 5 ) {
		return;
	}
	$mq   = (array) $q->get( 'meta_query' );
	$mq[] = array(
		'key'     => '_fsz_difficulty',
		'value'   => array( 1, $sel ),
		'type'    => 'NUMERIC',
		'compare' => 'BETWEEN',
	);
	$q->set( 'meta_query', $mq );
} );
