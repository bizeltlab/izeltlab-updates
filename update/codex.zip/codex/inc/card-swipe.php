<?php
// ==========================================================================
//  FILE: inc/card-swipe.php   (Codex plugin)
//  WHAT: Card swipe on species pages: the previous and next species in Codex number order (wrapping round), the
//        "Előző #N" / "Következő #N" edge arrows (PC wide: the neighbour cards peeking in), and the small head
//        script that lets a swiped-to card slide in. The finger/mouse swipe and the fetching ahead: assets/swipe.js.
//  SEEN: Product pages of species (only where a Codex card shows).
//  SECTIONS IN THIS FILE:
//    1. The neighbours
//    2. The edge arrows and peeks (HTML)
//    3. The slide between pages (page head)
//    4. Loading the swipe script
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Switch it off: add_filter( 'fsz_card_swipe', '__return_false' );
function fsz_swipe_on() {
	return (bool) apply_filters( 'fsz_card_swipe', true );
}

// ==========================================================================
//  1. The neighbours
// ==========================================================================

/**
 * The species before and after this one in Codex number order (#001, #002 …), wrapping round: the last one's next is
 * #001. Sold-out species stay in the line (greyed on the arrow). Hidden cards and unpublished products are not in it.
 * Returns array( 'prev' => id, 'next' => id ), or an empty array when there is no other species. The list is the one
 * the Codex numbers come from (transient fsz_numbers), so it costs nothing extra.
 */
function fsz_neighbours( $product_id ) {
	$product_id = (int) $product_id;
	fsz_codex_number( $product_id ); // fills the list when it is not there yet
	$list = get_transient( 'fsz_numbers' );
	if ( ! is_array( $list ) || ! isset( $list[ $product_id ] ) || count( $list ) < 2 ) {
		return array();
	}
	asort( $list );
	$ids = array_map( 'intval', array_keys( $list ) );
	$i   = array_search( $product_id, $ids, true );
	$n   = count( $ids );
	return array(
		'prev' => $ids[ ( $i - 1 + $n ) % $n ],
		'next' => $ids[ ( $i + 1 ) % $n ],
	);
}

// ==========================================================================
//  2. The edge arrows and peeks (HTML)
// ==========================================================================

/**
 * Two links at the screen edges, printed after the product page card. Phone and tablet: slim see-through tabs at the
 * card's mid-height ("Előző #001"). PC wide: the neighbour's card peeks in at the edge (its colour and first photo,
 * a small lazy picture that a phone never loads), its name shows on hover. The data-fsz-swipe JSON tells swipe.js
 * where to go and which first photo to fetch ahead.
 */
function fsz_swipe_nav( $product_id ) {
	if ( ! fsz_swipe_on() ) {
		return '';
	}
	$nb = fsz_neighbours( $product_id );
	if ( ! $nb ) {
		return '';
	}
	$data  = array();
	$links = '';
	foreach ( array( 'prev', 'next' ) as $dir ) {
		$id   = $nb[ $dir ];
		$url  = get_permalink( $id );
		$num  = fsz_codex_number( $id );
		$name = fsz_names( $id )['nick'];
		$out  = ! fsz_in_stock( function_exists( 'wc_get_product' ) ? wc_get_product( $id ) : null );
		/* translators: %s: the Codex number of the previous species, e.g. #001 */
		$word  = 'prev' === $dir ? sprintf( __( 'Previous %s', 'codex' ), $num ) : sprintf( __( 'Next %s', 'codex' ), $num ); // phpcs:ignore WordPress.WP.I18n.MissingTranslatorsComment
		$photo = fsz_first_photo( $id );
		$data[ $dir ] = array(
			'u'   => $url,
			'img' => $photo ? array( $photo['src'], $photo['srcset'], $photo['sizes'] ) : null,
		);
		$ids   = fsz_card_image_ids( $id );
		$thumb = $ids ? wp_get_attachment_image_src( (int) reset( $ids ), 'woocommerce_thumbnail' ) : false;
		$peek  = '<span class="fsz-nb-peek" aria-hidden="true"><span class="fsz-nb-scr">' . ( $thumb ? '<img src="' . esc_url( $thumb[0] ) . '" alt="" width="' . (int) $thumb[1] . '" height="' . (int) $thumb[2] . '" loading="lazy" decoding="async">' : '' ) . '</span></span>';
		$links .= '<a class="fsz-nb fsz-nb-' . $dir . ( $out ? ' is-out' : '' ) . '" href="' . esc_url( $url ) . '" rel="' . $dir . '" aria-label="' . esc_attr( $word . ' – ' . $name ) . '" style="--fsz-nb:' . esc_attr( fsz_product_color( $id ) ) . '">'
			. $peek
			. '<span class="fsz-nb-tab" aria-hidden="true"><i class="fsz-nb-chev"></i><span class="fsz-nb-word">' . esc_html( $word ) . '</span></span>'
			. '<span class="fsz-nb-name" aria-hidden="true"><b>' . esc_html( $word ) . '</b> ' . esc_html( $name ) . '</span>'
			. '</a>';
	}
	return '<nav class="fsz-swipe" aria-label="' . esc_attr__( 'Species', 'codex' ) . '" data-fsz-swipe="' . esc_attr( wp_json_encode( $data ) ) . '">' . $links . '</nav>';
}

// ==========================================================================
//  3. The slide between pages (page head)
// ==========================================================================

/**
 * Browsers that can (Chrome and Edge 126+, Safari 18.2+) slide the card from one species page into the next: both
 * pages opt in here (@view-transition), and the slide plays only when swipe.js marked the move (a swipe or an edge
 * arrow); every other move between two species pages (back button, a link) is a normal page change. The script reads
 * the mark the page before left (sessionStorage fsz-swipe: where it went, which way, when) and sets
 * html[data-fsz-swipe=next|prev] for codex.css; a page the browser prepared in advance reads it when it is shown.
 * Other browsers simply load the page.
 */
add_action( 'wp_head', 'fsz_swipe_head', 2 );
function fsz_swipe_head() {
	if ( ! fsz_swipe_on() || ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}
	$id = (int) get_queried_object_id();
	if ( ! $id || ! fsz_is_live( $id ) || ! fsz_neighbours( $id ) ) {
		return;
	}
	$js = <<<'JS'
(function(){var h=document.documentElement,mark=function(){var v=null;try{v=JSON.parse(sessionStorage.getItem('fsz-swipe')||'null');if(v){sessionStorage.removeItem('fsz-swipe')}}catch(e){}if(v&&v.u===location.href.split('#')[0]&&Date.now()-v.t<9000){h.setAttribute('data-fsz-swipe',v.d)}};if(!document.prerendering){mark()}document.addEventListener('prerenderingchange',mark);addEventListener('pageswap',function(e){if(e.viewTransition&&!h.hasAttribute('data-fsz-swipe')){e.viewTransition.skipTransition()}});addEventListener('pagereveal',function(e){var t=e.viewTransition;if(!h.hasAttribute('data-fsz-swipe')){mark()}if(!t){return}if(!h.hasAttribute('data-fsz-swipe')){t.skipTransition();return}t.finished.then(function(){h.removeAttribute('data-fsz-swipe')},function(){h.removeAttribute('data-fsz-swipe')})})})()
JS;
	echo '<style id="fsz-swipe-vt">@view-transition{navigation:auto}</style><script>' . trim( $js ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}

// ==========================================================================
//  4. Loading the swipe script
// ==========================================================================

add_action( 'wp_enqueue_scripts', function () {
	if ( ! fsz_swipe_on() || ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}
	$id = (int) get_queried_object_id();
	if ( $id && fsz_is_live( $id ) && fsz_neighbours( $id ) ) {
		wp_enqueue_script( 'codex-swipe', fsz_script_url( 'assets/swipe.js' ), array(), fsz_asset_ver( 'assets/swipe.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
	}
}, 20 );
