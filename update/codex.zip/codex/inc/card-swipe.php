<?php
// ==========================================================================
//  FILE: inc/card-swipe.php   (Codex plugin)
//  WHAT: Card swipe on species pages: the previous and next species in Codex number order (wrapping round), the
//        "Előző #N" / "Következő #N" edge tabs (phone) and small side cards (PC wide, with the first-visit "előző" /
//        "következő" hints), and the small head script that lets a card slide in after a normal page load. The swipe,
//        the move without a page load (2.3.0) and the fetching ahead: assets/swipe.js.
//  SEEN: Product pages of species (only where a Codex card shows).
//  SECTIONS IN THIS FILE:
//    1. The neighbours
//    2. The edge arrows and peeks (HTML)
//    3. The slide between pages (page head)
//    4. Loading the swipe script
//    5. The filtered line (2.7.0)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Switch it off: add_filter( 'fsz_card_swipe', '__return_false' );
function fsz_swipe_on() {
	return (bool) apply_filters( 'fsz_card_swipe', true );
}

// ==========================================================================
//  1. The neighbours
// ==========================================================================

/**
 * The species before and after this one in Codex number order (#001, #002 …), wrapping round: the last one's next is
 * #001. Sold-out species stay in the line (greyed on the arrow). Hidden cards and unpublished products are not in it.
 * Returns array( 'prev' => id, 'next' => id ), or an empty array when there is no other species. The list is the one
 * the Codex numbers come from (transient fsz_numbers), so it costs nothing extra.
 */
function fsz_neighbours( $product_id ) {
	$product_id = (int) $product_id;
	fsz_codex_number( $product_id ); // fills the list when it is not there yet
	$list = get_transient( 'fsz_numbers' );
	if ( ! is_array( $list ) || ! isset( $list[ $product_id ] ) || count( $list ) < 2 ) {
		return array();
	}
	asort( $list );
	$ids = array_map( 'intval', array_keys( $list ) );
	$i   = array_search( $product_id, $ids, true );
	$n   = count( $ids );
	return array(
		'prev' => $ids[ ( $i - 1 + $n ) % $n ],
		'next' => $ids[ ( $i + 1 ) % $n ],
	);
}

// ==========================================================================
//  2. The edge arrows and peeks (HTML)
// ==========================================================================

/**
 * 2.7.0: one side link (the phone tab, the PC side card) for species $id as the previous or next one, and its data for
 * swipe.js (the address and the first photo to fetch ahead). Also used by the filtered line (section 5).
 */
function fsz_nb_link( $id, $dir ) {
	$id   = (int) $id;
	$url  = get_permalink( $id );
	$num  = fsz_codex_number( $id );
	$name = fsz_names( $id )['nick'];
	$out  = ! fsz_in_stock( function_exists( 'wc_get_product' ) ? wc_get_product( $id ) : null );
	/* translators: %s: the Codex number of the previous species, e.g. #001 */
	$word  = 'prev' === $dir ? sprintf( __( 'Previous %s', 'codex' ), $num ) : sprintf( __( 'Next %s', 'codex' ), $num ); // phpcs:ignore WordPress.WP.I18n.MissingTranslatorsComment
	// 2.9.0 (Dan): both phone tabs are the same size (as long as the longer word, "Következő"): each tab also holds the
	// other tab's word, unseen, in the same spot (codex.css .fsz-nb-twin), so the two words take the same room
	$twin  = 'prev' === $dir ? sprintf( __( 'Next %s', 'codex' ), $num ) : sprintf( __( 'Previous %s', 'codex' ), $num ); // phpcs:ignore WordPress.WP.I18n.MissingTranslatorsComment
	$photo = fsz_first_photo( $id );
	$data  = array(
		'u'   => $url,
		'img' => $photo ? array( $photo['src'], $photo['srcset'], $photo['sizes'] ) : null,
	);
	$ids   = fsz_card_image_ids( $id );
	$thumb = $ids ? wp_get_attachment_image_src( (int) reset( $ids ), 'woocommerce_thumbnail' ) : false;
	$peek  = '<span class="fsz-nb-peek" aria-hidden="true"><span class="fsz-nb-scr">' . ( $thumb ? '<img src="' . esc_url( $thumb[0] ) . '" alt="" width="' . (int) $thumb[1] . '" height="' . (int) $thumb[2] . '" loading="lazy" decoding="async">' : '' ) . '</span></span>';
	// 2.3.0: the faint first-visit hint next to the side card (PC; swipe.js shows it once, codex.css .is-hint)
	$hint   = 'prev' === $dir ? _x( 'previous', 'side card hint', 'codex' ) : _x( 'next', 'side card hint', 'codex' );
	$link = '<a class="fsz-nb fsz-nb-' . $dir . ( $out ? ' is-out' : '' ) . '" href="' . esc_url( $url ) . '" rel="' . $dir . '" aria-label="' . esc_attr( $word . ' – ' . $name ) . '" style="--fsz-nb:' . esc_attr( fsz_product_color( $id ) ) . '">'
		. $peek
		. '<span class="fsz-nb-hint" aria-hidden="true">' . esc_html( $hint ) . '</span>'
		. '<span class="fsz-nb-tab" aria-hidden="true"><i class="fsz-nb-chev"></i><span class="fsz-nb-word"><span class="fsz-nb-say">' . esc_html( $word ) . '</span><span class="fsz-nb-twin">' . esc_html( $twin ) . '</span></span></span>'
		. '<span class="fsz-nb-name" aria-hidden="true"><b>' . esc_html( $word ) . '</b> ' . esc_html( $name ) . '</span>'
		. '</a>';
	return array( $link, $data );
}

/**
 * Two links at the screen edges, printed after the product page card. Phone and tablet: slim see-through tabs at the
 * card's mid-height ("Előző #001"). PC wide: the neighbour's card peeks in at the edge, small and set back (a third of
 * it shows: its colour and first photo, a small lazy picture that a phone never loads), its name shows on hover. The
 * data-fsz-swipe JSON tells swipe.js where to go and which first photo to fetch ahead. swipe.js turns a click into the
 * move without a page load; without it they are plain links.
 */
function fsz_swipe_nav( $product_id ) {
	if ( ! fsz_swipe_on() ) {
		return '';
	}
	$nb = fsz_neighbours( $product_id );
	if ( ! $nb ) {
		return '';
	}
	$data  = array();
	$links = '';
	foreach ( array( 'prev', 'next' ) as $dir ) {
		list( $link, $data[ $dir ] ) = fsz_nb_link( $nb[ $dir ], $dir );
		$links .= $link;
	}
	// 2.8.0 (Dan, 2026-11-18): on PC the side cards (and the edge tabs elsewhere) first showed at the window's mid-height
	// and jumped to the card's mid-height once swipe.js ran. This small script, right after the bar, puts them in their
	// final spot before the first paint, the same way swipe.js place() does (the card above it is already laid out);
	// swipe.js keeps them there afterwards. codex.css keeps the scrollbar's room from the start on PC, so the width
	// measured here is the final one.
	// 2.20.0: it follows place() exactly: only a fixed card (the phone) sets the mid-height. A phone on its side and a
	// small computer window kept the card's mid-height here, then swipe.js moved the tabs to the window's mid-height.
	$js = <<<'JS'
(function(){var n=document.currentScript.previousElementSibling,w=document.querySelector('.fsz-wrap.fsz-at-gallery');if(!n||!w||!n.classList.contains('fsz-swipe')){return}var c=(w.querySelector('.fsz-device')||w).getBoundingClientRect(),g=getComputedStyle;if(!c.height){return}if('fixed'===g(w).position){n.style.setProperty('--fsz-swipe-y',Math.round(c.top+c.height/2)+'px');return}if(!(window.matchMedia&&matchMedia('(min-width: 1200px) and (hover: hover) and (pointer: fine)').matches)||'absolute'!==g(n).position){return}n.style.setProperty('--fsz-swipe-y','0px');n.style.setProperty('--fsz-swipe-x','0px');var o=n.getBoundingClientRect();n.style.setProperty('--fsz-swipe-y',Math.round(c.top+c.height/2-o.top)+'px');n.style.setProperty('--fsz-swipe-x',Math.round(-o.left)+'px');n.style.setProperty('--fsz-swipe-w',document.documentElement.clientWidth+'px')})()
JS;
	return '<nav class="fsz-swipe" aria-label="' . esc_attr__( 'Species', 'codex' ) . '" data-fsz-swipe="' . esc_attr( wp_json_encode( $data ) ) . '">' . $links . '</nav><script data-fsz-place>' . $js . '</script>';
}

// ==========================================================================
//  3. The slide between pages (page head)
// ==========================================================================

/**
 * 2.3.0: swipe.js normally changes species without a page load. When it cannot (an editor's page with the admin bar
 * and edit tools, an older theme, a failed fetch), it loads the next page the 2.2.0 way, and this slide is used:
 * Browsers that can (Chrome and Edge 126+, Safari 18.2+) slide the card from one species page into the next: both
 * pages opt in here (@view-transition), and the slide plays only when swipe.js marked the move (a swipe or an edge
 * arrow); every other move between two species pages (back button, a link) is a normal page change. The script reads
 * the mark the page before left (sessionStorage fsz-swipe: where it went, which way, when) and sets
 * html[data-fsz-swipe=next|prev] for codex.css; a page the browser prepared in advance reads it when it is shown.
 * Other browsers simply load the page.
 */
add_action( 'wp_head', 'fsz_swipe_head', 2 );
function fsz_swipe_head() {
	if ( ! fsz_swipe_on() || ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}
	$id = (int) get_queried_object_id();
	if ( ! $id || ! fsz_is_live( $id ) || ! fsz_neighbours( $id ) ) {
		return;
	}
	$js = <<<'JS'
(function(){var h=document.documentElement,mark=function(){var v=null;try{v=JSON.parse(sessionStorage.getItem('fsz-swipe')||'null');if(v){sessionStorage.removeItem('fsz-swipe')}}catch(e){}if(v&&v.u===location.href.split('#')[0]&&Date.now()-v.t<9000){h.setAttribute('data-fsz-swipe',v.d)}};if(!document.prerendering){mark()}document.addEventListener('prerenderingchange',mark);addEventListener('pageswap',function(e){if(e.viewTransition&&!h.hasAttribute('data-fsz-swipe')){e.viewTransition.skipTransition()}});addEventListener('pagereveal',function(e){var t=e.viewTransition;if(!h.hasAttribute('data-fsz-swipe')){mark()}if(!t){return}if(!h.hasAttribute('data-fsz-swipe')){t.skipTransition();return}t.finished.then(function(){h.removeAttribute('data-fsz-swipe')},function(){h.removeAttribute('data-fsz-swipe')})})})()
JS;
	echo '<style id="fsz-swipe-vt">@view-transition{navigation:auto}</style><script>' . trim( $js ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}

// ==========================================================================
//  4. Loading the swipe script
// ==========================================================================

add_action( 'wp_enqueue_scripts', function () {
	if ( ! fsz_swipe_on() || ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}
	$id = (int) get_queried_object_id();
	if ( $id && fsz_is_live( $id ) && fsz_neighbours( $id ) ) {
		wp_enqueue_script( 'codex-swipe', fsz_script_url( 'assets/swipe.js' ), array(), fsz_asset_ver( 'assets/swipe.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_localize_script( 'codex-swipe', 'fszSwipe', array( 'line' => esc_url_raw( rest_url( 'fsz/v1/line' ) ) ) ); // 2.7.0: section 5
	}
}, 20 );

// ==========================================================================
//  5. The filtered line (2.7.0)
// ==========================================================================

/**
 * 2.7.0 (Dan, 2026-11-17): a species opened from a filtered shop list (a group, a genus, a level: Ízeltláb theme 3.10.0
 * shop.js keeps it in sessionStorage izl-sf) swipes only inside that filter. swipe.js asks this address once:
 * fsz/v1/line?g=group-slug&s=genus-slug&l=1..3 and gets the species of the filter in Codex number order, each with its
 * side links ready (as previous, as next) and the data swipe.js fetches ahead. Pages stay fully cached: the filter is
 * only in the browser. A genus is the shop category right under the group (Porcellio under Ászkák).
 */
function fsz_genus_slug( $product_id, $group ) {
	if ( ! $group ) {
		return '';
	}
	$terms = get_the_terms( $product_id, 'product_cat' );
	foreach ( ( $terms && ! is_wp_error( $terms ) ) ? $terms : array() as $t ) {
		for ( $step = $t; $step && ! is_wp_error( $step ) && $step->parent; $step = get_term( $step->parent, 'product_cat' ) ) {
			if ( (int) $step->parent === (int) $group->term_id ) {
				return $step->slug;
			}
		}
	}
	return '';
}
function fsz_swipe_line( $g, $s, $l ) {
	if ( ! fsz_swipe_on() ) {
		return array();
	}
	fsz_codex_number( 0 ); // fills the list when it is not there yet
	$list = get_transient( 'fsz_numbers' );
	if ( ! is_array( $list ) ) {
		return array();
	}
	asort( $list );
	$out = array();
	foreach ( array_keys( $list ) as $id ) {
		$id    = (int) $id;
		$group = fsz_group_term( $id );
		if ( ( $g && ( ! $group || $group->slug !== $g ) ) || ( $s && fsz_genus_slug( $id, $group ) !== $s ) || ( $l && fsz_level( (int) get_post_meta( $id, '_fsz_difficulty', true ) ) !== $l ) ) {
			continue;
		}
		list( $prev, $data ) = fsz_nb_link( $id, 'prev' );
		list( $next )        = fsz_nb_link( $id, 'next' );
		$out[] = array( 'u' => get_permalink( $id ), 'prev' => $prev, 'next' => $next, 'd' => $data );
	}
	return $out;
}
add_action( 'rest_api_init', function () {
	register_rest_route( 'fsz/v1', '/line', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true', // the same species anyone sees in the shop
		'callback'            => function ( $req ) {
			$line = fsz_swipe_line( sanitize_title( (string) $req['g'] ), sanitize_title( (string) $req['s'] ), max( 0, min( 3, (int) $req['l'] ) ) );
			$res  = rest_ensure_response( array( 'line' => $line, 'label' => __( 'Species', 'codex' ) ) );
			$res->header( 'Cache-Control', 'public, max-age=300' );
			return $res;
		},
	) );
} );
