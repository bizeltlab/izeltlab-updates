<?php
// ==========================================================================
//  FILE: inc/text-format.php   (Codex plugin)
//  WHAT: Text on the card: coloured marks, the Leírás (description) text, the fun fact, Hungarian hyphenation.
//  SEEN: The Leírás page and the fun fact bubble of the card.
//  SECTIONS IN THIS FILE:
//    1. Text formatting (1.52.0)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Text formatting (1.52.0)
// ==========================================================================

/**
 * The colours a text can take, key => CSS class. Picked in the card editor; each is darkened in codex.css so it stays
 * readable on the screen. 'group' is a highlighter in the card's own deep colour (1.53.0).
 */
function fsz_mark_colors() {
	return array( 'blue', 'green', 'amber', 'red', 'group' );
}

/**
 * A formatted text as runs: array( array( text, bold, italic, underline, colour ) ). The marks: **bold**, [i]italic[/i],
 * [u]underline[/u], [red]colour[/red] (any key of fsz_mark_colors()). A mark left open ends with the text; a closing
 * mark with nothing open is dropped. Line breaks stay in the text.
 */
function fsz_mark_runs( $text ) {
	$colors = implode( '|', fsz_mark_colors() );
	$parts  = preg_split( '#(\*\*|\[/?(?:i|u|' . $colors . ')\])#', (string) $text, -1, PREG_SPLIT_DELIM_CAPTURE );
	$st     = array( 'b' => false, 'i' => false, 'u' => false, 'c' => '' );
	$runs   = array();
	foreach ( $parts as $k => $part ) {
		if ( 0 === $k % 2 ) {
			if ( '' !== $part ) {
				$runs[] = array( $part, $st['b'], $st['i'], $st['u'], $st['c'] );
			}
		} elseif ( '**' === $part ) {
			$st['b'] = ! $st['b'];
		} else {
			$close = '/' === $part[1];
			$tag   = trim( $part, '[]/' );
			if ( 'i' === $tag || 'u' === $tag ) {
				$st[ $tag ] = ! $close;
			} else {
				$st['c'] = $close ? ( $st['c'] === $tag ? '' : $st['c'] ) : $tag;
			}
		}
	}
	return $runs;
}

// The text without its marks: what the shopper reads (for counting and limits).
function fsz_plain( $text ) {
	return implode( '', array_column( fsz_mark_runs( $text ), 0 ) );
}

/**
 * Runs back to marks, with as few as needed (the colour outside, then bold, italic, underline), so the text reads
 * cleanly in the product box and in CSV. The card editor writes the same marks.
 */
function fsz_mark_text( $runs ) {
	$out  = '';
	$open = array( '', false, false, false ); // colour, b, i, u
	$tags = array( 1 => array( '**', '**' ), 2 => array( '[i]', '[/i]' ), 3 => array( '[u]', '[/u]' ) );
	foreach ( $runs as $r ) {
		$want = array( (string) $r[4], (bool) $r[1], (bool) $r[2], (bool) $r[3] );
		// Close from the inside out down to the first style that changes, then open what is wanted from there.
		for ( $lvl = 0; $lvl < 4 && $want[ $lvl ] === $open[ $lvl ]; $lvl++ ) {}
		for ( $j = 3; $j >= $lvl; $j-- ) {
			if ( $open[ $j ] ) {
				$out .= 0 === $j ? '[/' . $open[0] . ']' : $tags[ $j ][1];
			}
		}
		for ( $j = $lvl; $j < 4; $j++ ) {
			if ( $want[ $j ] ) {
				$out .= 0 === $j ? '[' . $want[0] . ']' : $tags[ $j ][0];
			}
		}
		$open = $want;
		$out .= $r[0];
	}
	for ( $j = 3; $j >= 0; $j-- ) {
		if ( $open[ $j ] ) {
			$out .= 0 === $j ? '[/' . $open[0] . ']' : $tags[ $j ][1];
		}
	}
	return $out;
}

// The first $max letters of a formatted text, its marks kept.
function fsz_mark_cut( $text, $max ) {
	$runs = array();
	foreach ( fsz_mark_runs( $text ) as $r ) {
		if ( $max <= 0 ) {
			break;
		}
		$r[0]   = mb_substr( $r[0], 0, $max );
		$max   -= mb_strlen( $r[0] );
		$runs[] = $r;
	}
	return fsz_mark_text( $runs );
}

/**
 * A formatted text as safe HTML for the card: <strong>, <em>, <u> and <span class="fsz-c-red">, nothing else. $hyphen
 * adds the soft hyphens (display only); $breaks writes line breaks as <br> (the card editor).
 */
function fsz_format( $text, $hyphen = true, $breaks = false ) {
	$html = '';
	foreach ( fsz_mark_runs( $text ) as $r ) {
		$t = esc_html( $hyphen ? fsz_hyphenate( $r[0] ) : $r[0] );
		if ( $breaks ) {
			$t = str_replace( "\n", '<br>', $t );
		}
		$t = $r[3] ? '<u>' . $t . '</u>' : $t;
		$t = $r[2] ? '<em>' . $t . '</em>' : $t;
		$t = $r[1] ? '<strong>' . $t . '</strong>' : $t;
		$t = '' !== $r[4] ? '<span class="fsz-c-' . esc_attr( $r[4] ) . '" data-c="' . esc_attr( $r[4] ) . '">' . $t . '</span>' : $t;
		$html .= $t;
	}
	return $html;
}

/**
 * 1.55.0: the story for shoppers in up to three paragraphs (<span class="fsz-para">): its own line breaks when it has
 * them, else its sentences shared out evenly. codex.css runs them on as one text on bigger screens and breaks them into
 * paragraphs on phones.
 */
function fsz_story_html( $story ) {
	$story = trim( (string) $story );
	if ( '' === $story ) {
		return '';
	}
	$paras = preg_split( '/\s*\n\s*/u', $story, -1, PREG_SPLIT_NO_EMPTY );
	if ( count( $paras ) < 2 ) {
		// A sentence ends with . ! or ? (a closing mark may follow), the next one starts with a capital letter.
		$sent = preg_split( '/(?<=[.!?…])((?:\*\*|\[\/(?:i|u|' . implode( '|', fsz_mark_colors() ) . ')\])*)\s+(?=(?:\*\*|\[(?:i|u|' . implode( '|', fsz_mark_colors() ) . ')\])*[\p{Lu}0-9„"])/u', $story, -1, PREG_SPLIT_DELIM_CAPTURE );
		$list = array();
		for ( $i = 0; $i < count( $sent ); $i += 2 ) {
			$list[] = $sent[ $i ] . ( isset( $sent[ $i + 1 ] ) ? $sent[ $i + 1 ] : '' );
		}
		$per   = max( 1, (int) ceil( count( $list ) / 3 ) );
		$paras = array();
		foreach ( array_chunk( $list, $per ) as $chunk ) {
			$paras[] = implode( ' ', $chunk );
		}
	}
	// A mark (bold, colour) still open at the end of a paragraph carries on into the next one.
	$out  = '';
	$done = '';
	foreach ( $paras as $para ) {
		$out  .= '<span class="fsz-para">' . fsz_format( fsz_mark_open( $done ) . $para, true ) . '</span>';
		$done .= $para . ' ';
	}
	return $out;
}

// The marks still open at the end of a text, written out again (colour, bold, italic, underline).
function fsz_mark_open( $text ) {
	$colors = implode( '|', fsz_mark_colors() );
	$st     = array( 'b' => false, 'i' => false, 'u' => false, 'c' => '' );
	preg_match_all( '#\*\*|\[/?(?:i|u|' . $colors . ')\]#', (string) $text, $m );
	foreach ( $m[0] as $mark ) {
		if ( '**' === $mark ) {
			$st['b'] = ! $st['b'];
			continue;
		}
		$close = '/' === $mark[1];
		$tag   = trim( $mark, '[]/' );
		if ( 'i' === $tag || 'u' === $tag ) {
			$st[ $tag ] = ! $close;
		} else {
			$st['c'] = $close ? ( $st['c'] === $tag ? '' : $st['c'] ) : $tag;
		}
	}
	return ( '' !== $st['c'] ? '[' . $st['c'] . ']' : '' ) . ( $st['b'] ? '**' : '' ) . ( $st['i'] ? '[i]' : '' ) . ( $st['u'] ? '[u]' : '' );
}

// 1.55.0: a badge's meaning; a short lead before a colon ("Takarítómester:") is bold.
function fsz_why_html( $why ) {
	if ( preg_match( '/^([^:]{2,32}):\s+(.+)$/su', (string) $why, $m ) ) {
		return '<b>' . esc_html( $m[1] ) . ':</b> ' . esc_html( $m[2] );
	}
	return esc_html( $why );
}

function fsz_hyphenate( $text ) {
	if ( ! apply_filters( 'fsz_hyphenate', 0 === strpos( determine_locale(), 'hu' ) ) || '' === $text ) {
		return $text;
	}
	return preg_replace_callback( '/\p{L}{5,}/u', 'fsz_hyphenate_word', $text );
}

function fsz_hyphenate_word( $m ) {
	$word  = $m[0];
	$lower = mb_strtolower( $word, 'UTF-8' );
	$len   = mb_strlen( $word, 'UTF-8' );
	$units = array(); // [ start, length, is vowel, is a doubled digraph ]
	for ( $i = 0; $i < $len; ) {
		$n = 1;
		$long = false;
		foreach ( array( 'ddzs' => true, 'dzs' => false, 'ccs' => true, 'ddz' => true, 'ggy' => true, 'lly' => true, 'nny' => true, 'ssz' => true, 'tty' => true, 'zzs' => true, 'cs' => false, 'dz' => false, 'gy' => false, 'ly' => false, 'ny' => false, 'sz' => false, 'ty' => false, 'zs' => false ) as $g => $doubled ) {
			if ( mb_substr( $lower, $i, strlen( $g ), 'UTF-8' ) === $g ) {
				$n    = strlen( $g );
				$long = $doubled;
				break;
			}
		}
		$c       = mb_substr( $lower, $i, 1, 'UTF-8' );
		$units[] = array( $i, $n, 1 === $n && false !== mb_strpos( 'aáeéiíoóöőuúüű', $c, 0, 'UTF-8' ), $long );
		$i      += $n;
	}
	$breaks = array();
	$last   = -1; // the previous vowel
	foreach ( $units as $k => $u ) {
		if ( ! $u[2] ) {
			continue;
		}
		if ( $last >= 0 ) {
			$at = $k - $last > 1 ? $k - 1 : $k; // before the last consonant, or between two vowels
			if ( ! $units[ $at ][3] ) {
				$breaks[] = $units[ $at ][0];
			}
		}
		$last = $k;
	}
	$out = '';
	$pos = 0;
	foreach ( $breaks as $b ) {
		if ( $b >= 2 && $len - $b >= 2 ) {
			$out .= mb_substr( $word, $pos, $b - $pos, 'UTF-8' ) . "\u{00AD}";
			$pos  = $b;
		}
	}
	return $out . mb_substr( $word, $pos, null, 'UTF-8' );
}
