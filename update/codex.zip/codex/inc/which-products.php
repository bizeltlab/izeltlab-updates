<?php
// ==========================================================================
//  FILE: inc/which-products.php   (Codex plugin)
//  WHAT: Decides which products get a Codex card (the chosen categories).
//  SEEN: Behind the scenes.
//  SECTIONS IN THIS FILE:
//    1. Which products
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Which products
// ==========================================================================

function fsz_category_ids() {
	$ids = array();
	foreach ( array_filter( array_map( 'trim', explode( ',', fsz_opt( 'categories' ) ) ) ) as $slug ) {
		$term = get_term_by( 'slug', sanitize_title( $slug ), 'product_cat' );
		if ( $term && ! is_wp_error( $term ) && fsz_is_setup_term( $term ) ) {
			$ids[]    = (int) $term->term_id;
			$children = get_term_children( $term->term_id, 'product_cat' );
			if ( ! is_wp_error( $children ) ) {
				$ids = array_merge( $ids, array_map( 'intval', $children ) );
			}
		}
	}
	return array_unique( $ids );
}

function fsz_is_live( $product_id ) {
	if ( 'yes' === get_post_meta( $product_id, '_fsz_hide', true ) ) {
		return false;
	}
	$ids = fsz_category_ids();
	return $ids && has_term( $ids, 'product_cat', $product_id );
}
