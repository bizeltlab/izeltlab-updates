<?php
// ==========================================================================
//  FILE: inc/assets.php   (Codex plugin)
//  WHAT: Loads Codex's stylesheet, fonts and script on the shop pages (the small built copies for shoppers).
//  SEEN: Every page that shows a Codex card.
//  SECTIONS IN THIS FILE:
//    1. Front end
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Front end
// ==========================================================================

/**
 * Keep the card's own colours under dark mode extensions such as Dark Reader, while the rest of the site goes dark.
 * Dark Reader rewrites the colours of every stylesheet rule it can read, but skips rules inside @scope.
 * So the same CSS is added once more inside @scope: same selectors, and a scoped rule wins over the rewritten copy.
 * Without an extension both copies say the same; browsers without @scope simply ignore the copy.
 */
/**
 * 1.48.0: shoppers get the built copies in assets/min (build/build.js): the stylesheet without comments and line
 * breaks, and its Dark Reader copy inside @scope as a file of its own that the browser caches (it was printed inline on
 * every page). A built copy is used only while it matches its source (assets/min/build.json holds each source's md5), so
 * an edit to a source shows at once: the source with the inline copy takes over until the build runs again.
 */
function fsz_built( $file ) {
	static $map = null;
	if ( null === $map ) {
		$json = is_readable( FSZ_DIR . 'assets/min/build.json' ) ? (string) file_get_contents( FSZ_DIR . 'assets/min/build.json' ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$map  = $json ? (array) json_decode( $json, true ) : array();
	}
	if ( ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) || empty( $map[ $file ]['md5'] ) ) {
		return '';
	}
	if ( ! fsz_source_untouched( $file, $map[ $file ] ) ) {
		return '';
	}
	return 'assets/min/' . preg_replace( '/\.(css|js)$/', '', basename( $file ) );
}

/**
 * Is this source still the file the build saw? 1.71.0: the everyday check is the source's size (free: the server
 * already knows it), not reading and hashing the whole file on every page.
 * 2.0.0: a hand edit can keep the size (one colour changed to another colour), so the file's change time is remembered
 * too: when it moves, the file is read and fingerprinted once, and the answer is kept (option fsz_min_seen) until the
 * file changes again. With WP_DEBUG on, the full md5 check runs every time, as before.
 */
function fsz_source_untouched( $file, $rec ) {
	static $seen = null, $save = false;
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		return md5_file( FSZ_DIR . $file ) === $rec['md5'];
	}
	if ( (int) @filesize( FSZ_DIR . $file ) !== (int) $rec['size'] ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
		return false;
	}
	if ( null === $seen ) {
		$seen = get_option( 'fsz_min_seen', array() );
		$seen = is_array( $seen ) ? $seen : array();
	}
	$time = (int) @filemtime( FSZ_DIR . $file ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	if ( ! isset( $seen[ $file ][2] ) || $seen[ $file ][0] !== $time || $seen[ $file ][1] !== $rec['md5'] ) {
		$seen[ $file ] = array( $time, $rec['md5'], md5_file( FSZ_DIR . $file ) === $rec['md5'] );
		if ( ! $save ) {
			$save = true;
			add_action( 'shutdown', function () use ( &$seen ) {
				update_option( 'fsz_min_seen', $seen, true );
			} );
		}
	}
	return (bool) $seen[ $file ][2];
}

// 2.0.0: the version in a Codex file's address. A source served as written (edited by hand since the build) carries
// its change time, so a browser that kept an older copy fetches the new one after every edit.
function fsz_asset_ver( $file ) {
	if ( fsz_built( $file ) ) {
		return FSZ_VERSION;
	}
	$time = (int) @filemtime( FSZ_DIR . $file ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	return $time && ! ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) && is_readable( FSZ_DIR . 'assets/min/build.json' ) ? FSZ_VERSION . '.' . $time : FSZ_VERSION;
}

/**
 * 2.0.0: shoppers no longer get the stylesheet twice. The second copy (the same rules inside @scope, made for Dark
 * Reader) also decided ties: where a Codex rule and another stylesheet's rule were equally strong, the copy won
 * whatever the order. The card's look relied on that (for example the bar icons keep overflow:visible against
 * Storefront's svg rule). Now Codex's stylesheets are printed LAST in the page head instead (fsz_print_late_styles()),
 * where an equally strong rule wins by order: the same result, one download less (about 60 KB of CSS per page).
 * The dashboard keeps the copy (nothing is printed last there). To get the copy back on the shop too:
 * add_filter( 'fsz_dark_reader_copy', '__return_true' );
 */
function fsz_dark_copy() {
	return (bool) apply_filters( 'fsz_dark_reader_copy', is_admin() );
}

// The handles fsz_style() loaded without the copy: these are printed last in the head.
function fsz_late_handles( $add = null ) {
	static $handles = array();
	if ( null !== $add && ! in_array( $add, $handles, true ) ) {
		$handles[] = $add;
	}
	return $handles;
}

// A Codex stylesheet: the built file when it is current, else the source. With the Dark Reader copy where it is on.
function fsz_style( $handle, $file, $deps = array() ) {
	$min = fsz_built( $file );
	if ( ! fsz_dark_copy() ) {
		fsz_late_handles( $handle );
	}
	if ( $min ) {
		wp_enqueue_style( $handle, FSZ_URL . $min . '.min.css', $deps, FSZ_VERSION );
		if ( fsz_dark_copy() ) {
			wp_enqueue_style( $handle . '-scope', FSZ_URL . $min . '.scope.min.css', array( $handle ), FSZ_VERSION );
		}
		return;
	}
	wp_enqueue_style( $handle, FSZ_URL . $file, $deps, fsz_asset_ver( $file ) );
	if ( fsz_dark_copy() ) {
		fsz_keep_colours( $handle, $file );
	}
}

// 2.0.0: Codex's stylesheets leave the normal queue just before WordPress prints it …
add_action( 'wp_print_styles', function () {
	if ( is_admin() || doing_action( 'wp_footer' ) || did_action( 'wp_footer' ) ) {
		return; // loaded late (the [codex] shortcode): WordPress prints them at the page end, which is last anyway
	}
	foreach ( fsz_late_handles() as $h ) {
		wp_dequeue_style( $h );
	}
}, 100 );

// … and are printed as the very last thing in the page head, after every other stylesheet and <style> block.
add_action( 'wp_head', 'fsz_print_late_styles', PHP_INT_MAX );
function fsz_print_late_styles() {
	$handles = array_values( array_filter( fsz_late_handles(), function ( $h ) {
		return wp_style_is( $h, 'registered' ) && ! wp_style_is( $h, 'done' );
	} ) );
	if ( $handles ) {
		wp_print_styles( $handles );
	}
}

// 1.71.0: a Codex script: its minified copy from assets/min (build/build.js) while it is current, else the source.
function fsz_script_url( $file ) {
	$min = fsz_built( $file );
	return FSZ_URL . ( $min ? $min . '.min.js' : $file );
}

function fsz_keep_colours( $handle, $file ) {
	$css = (string) file_get_contents( FSZ_DIR . $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	if ( '' !== $css ) {
		wp_add_inline_style( $handle, '@scope (:root){' . $css . '}' );
	}
}

add_action( 'wp_enqueue_scripts', function () {
	if ( ! function_exists( 'is_product' ) ) {
		return;
	}
	// 1.65.0: only where a card shows: a product page with a card. The shop and category pages load it only for the
	// difficulty dropdown of other themes (the Ízeltláb theme draws its own tiles and pills there; filter
	// fsz_assets_on_lists). The [codex] shortcode loads it wherever it is used. Before, every shop page and every
	// supplies page carried the card's 120 KB of styles and its script without showing a card.
	if ( is_product() ? fsz_is_live( get_queried_object_id() ) : ( ( is_shop() || is_product_taxonomy() ) && apply_filters( 'fsz_assets_on_lists', ! function_exists( 'izl_has_codex' ) ) ) ) {
		fsz_enqueue_front();
	}
} );

function fsz_enqueue_front() {
	fsz_style( 'codex', 'assets/codex.css' );
	fsz_skin_style( fsz_skin() );
	wp_enqueue_style( 'codex-font', FSZ_URL . 'assets/fonts/ibm-plex-mono/font.css', array(), FSZ_VERSION ); // IBM Plex Mono, bundled (no Google Fonts)
	wp_enqueue_script( 'codex', fsz_script_url( 'assets/codex.js' ), array(), fsz_asset_ver( 'assets/codex.js' ), true );

	// Quick edit: only for people who may edit this product.
	if ( function_exists( 'is_product' ) && is_product() ) {
		$id = get_queried_object_id();
		if ( fsz_is_live( $id ) && fsz_can_quick_edit( $id ) ) {
			wp_enqueue_media( array( 'post' => $id ) );
			fsz_style( 'codex-edit', 'assets/codex-edit.css', array( 'codex' ) );
			wp_enqueue_script( 'codex-edit', FSZ_URL . 'assets/codex-edit.js', array( 'codex' ), FSZ_VERSION, true );
			wp_localize_script(
				'codex-edit',
				'CodexEdit',
				array(
					'ajax'         => admin_url( 'admin-ajax.php' ),
					'nonce'        => wp_create_nonce( 'fsz_quick_edit' ),
					'defaultColor' => fsz_group_color( $id ),
					'screen'       => fsz_opt( 'screen' ),
					'screenLight'  => FSZ_SCREEN_LIGHT,
					'ink'          => fsz_opt( 'ink' ),
					'editUrl'      => admin_url( 'post.php?post=' . (int) $id . '&action=edit' ),
				)
			);
		}
	}
}
