<?php
// ==========================================================================
//  FILE: inc/admin-fields.php   (Codex plugin)
//  WHAT: DASHBOARD. The Codex box on the product edit page, the group colour fields on categories, the list of all Codex fields, and saving them.
//  SEEN: Products → edit a product; Products → Categories.
//  SECTIONS IN THIS FILE:
//    1. Admin: product fields
//    2. Admin: group colours
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Admin: product fields
// ==========================================================================

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'fsz_box', 'Codex data', 'fsz_meta_box', 'product', 'normal', 'high' );
} );

add_action( 'admin_enqueue_scripts', function () {
	$screen = get_current_screen();
	if ( $screen && 'product' === $screen->post_type ) {
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
		wp_add_inline_script( 'wp-color-picker', 'jQuery(function($){$(".fsz-color").wpColorPicker({palettes:' . wp_json_encode( array_keys( fsz_themes() ) ) . '});});' );
		wp_enqueue_media();
		wp_add_inline_script( 'wp-color-picker', 'jQuery(function($){var f;$("#fsz-image-pick").on("click",function(e){e.preventDefault();if(!f){f=wp.media({title:"Codex image",button:{text:"Use this image"},library:{type:"image"},multiple:false});f.on("select",function(){var a=f.state().get("selection").first().toJSON(),u=(a.sizes&&a.sizes.medium?a.sizes.medium.url:a.url);$("#fsz_image").val(a.id);$("#fsz-image-preview").html($("<img>").attr("src",u));$("#fsz-image-remove").show();});}f.open();});$("#fsz-image-remove").on("click",function(e){e.preventDefault();$("#fsz_image").val("");$("#fsz-image-preview").empty();$(this).hide();});});' );
		wp_add_inline_style( 'wp-color-picker', '.fsz-admin th{width:170px;text-align:left;font-weight:600;padding:6px 10px 6px 0;vertical-align:top}.fsz-admin td{padding:4px 0}.fsz-admin input.regular-text{width:100%;max-width:420px}.fsz-admin h4{margin:18px 0 6px}.fsz-admin .description{color:#646970}#fsz-image-preview img{display:block;max-width:160px;height:auto;margin:0 0 6px;border:1px solid #dcdcde}' );
	}
} );

// ==========================================================================
//  Admin: group colours
// ==========================================================================

add_action( 'admin_enqueue_scripts', function () {
	$screen = get_current_screen();
	if ( $screen && 'product_cat' === $screen->taxonomy ) {
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
		// The add form is sent by AJAX and then cleared: the picker is cleared with it.
		wp_add_inline_script( 'wp-color-picker', 'jQuery(function($){$(".fsz-color").wpColorPicker({palettes:' . wp_json_encode( array_keys( fsz_themes() ) ) . '});$(document).ajaxComplete(function(e,x,o){if(o&&o.data&&String(o.data).indexOf("action=add-tag")>-1&&!$("#ajax-response .error").length){$("#addtag .fsz-color").wpColorPicker("color","").val("");}});});' );
		wp_add_inline_style( 'wp-color-picker', '.fsz-swatch-cell{display:inline-block;width:22px;height:22px;border-radius:5px;border:3px solid;box-sizing:border-box;vertical-align:middle}.column-fsz_color{width:90px}' );
	}
} );

function fsz_group_color_swatch( $hex ) {
	return '<span class="fsz-swatch-cell" style="background:' . esc_attr( $hex ) . ';border-color:' . esc_attr( fsz_theme_dark( $hex ) ) . '"></span>';
}

add_action( 'product_cat_add_form_fields', function () {
	wp_nonce_field( 'fsz_group_color', 'fsz_group_nonce' );
	?>
	<div class="form-field">
		<label for="fsz-group-color">Codex colour</label>
		<input type="text" class="fsz-color" id="fsz-group-color" name="fsz_group_color" value="">
		<p class="description">Only for top categories (groups such as Isopoda): every Codex card in the group, subcategories too, takes this colour. Empty = the default theme.</p>
	</div>
	<?php
} );

add_action( 'product_cat_edit_form_fields', function ( $term ) {
	?>
	<tr class="form-field">
		<th scope="row"><label for="fsz-group-color">Codex colour</label></th>
		<td>
			<?php if ( $term->parent ) : ?>
				<?php
				$top = $term;
				while ( $top->parent ) {
					$up = get_term( $top->parent, 'product_cat' );
					if ( ! $up || is_wp_error( $up ) ) {
						break;
					}
					$top = $up;
				}
				$c = sanitize_hex_color( (string) get_term_meta( $top->term_id, 'fsz_color', true ) );
				$c = $c ? $c : (string) sanitize_hex_color( fsz_opt( 'device' ) );
				?>
				<?php echo fsz_group_color_swatch( $c ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<p class="description">Follows its group: <a href="<?php echo esc_url( get_edit_term_link( $top->term_id, 'product_cat', 'product' ) ); ?>"><?php echo esc_html( $top->name ); ?></a>. Change the colour there.</p>
			<?php else : ?>
				<?php wp_nonce_field( 'fsz_group_color', 'fsz_group_nonce' ); ?>
				<input type="text" class="fsz-color" id="fsz-group-color" name="fsz_group_color" value="<?php echo esc_attr( (string) get_term_meta( $term->term_id, 'fsz_color', true ) ); ?>" data-default-color="<?php echo esc_attr( fsz_opt( 'device' ) ); ?>">
				<p class="description">Every Codex card in this group, subcategories too, takes this colour. A colour picked for one product still wins. Empty = the default theme.</p>
			<?php endif; ?>
		</td>
	</tr>
	<?php
} );

function fsz_save_group_color( $term_id ) {
	if ( ! isset( $_POST['fsz_group_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fsz_group_nonce'] ) ), 'fsz_group_color' ) || ! current_user_can( 'manage_product_terms' ) ) {
		return;
	}
	$term = get_term( $term_id, 'product_cat' );
	if ( ! $term || is_wp_error( $term ) || $term->parent ) {
		return;
	}
	$color = sanitize_hex_color( isset( $_POST['fsz_group_color'] ) ? trim( wp_unslash( $_POST['fsz_group_color'] ) ) : '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	if ( $color ) {
		update_term_meta( $term_id, 'fsz_color', $color );
	} else {
		delete_term_meta( $term_id, 'fsz_color' );
	}
}
add_action( 'edited_product_cat', 'fsz_save_group_color' );
add_action( 'created_product_cat', function ( $term_id ) {
	fsz_save_group_color( $term_id );
	fsz_seed_group_colors( array( $term_id ) ); // a new Isopoda, Blattodea… without a colour gets its starting colour
}, 20 );

// A colour column in the category list: groups show theirs, subcategories nothing.
add_filter( 'manage_edit-product_cat_columns', function ( $cols ) {
	$out = array();
	foreach ( $cols as $k => $v ) {
		$out[ $k ] = $v;
		if ( 'name' === $k ) {
			$out['fsz_color'] = 'Codex colour';
		}
	}
	return $out;
} );
add_filter( 'manage_product_cat_custom_column', function ( $content, $column, $term_id ) {
	if ( 'fsz_color' !== $column ) {
		return $content;
	}
	$term = get_term( $term_id, 'product_cat' );
	if ( ! $term || is_wp_error( $term ) || $term->parent ) {
		return $content;
	}
	$c = sanitize_hex_color( (string) get_term_meta( $term_id, 'fsz_color', true ) );
	return $c ? fsz_group_color_swatch( $c ) : '<span aria-hidden="true">—</span><span class="screen-reader-text">Default theme</span>';
}, 10, 3 );

function fsz_meta_box( $post ) {
	wp_nonce_field( 'fsz_save', 'fsz_nonce' );
	$v = function ( $key ) use ( $post ) {
		return (string) get_post_meta( $post->ID, '_fsz_' . $key, true );
	};
	$live = fsz_is_live( $post->ID );
	echo '<div class="fsz-admin">';
	if ( ! $live ) {
		echo '<p class="description"><b>This product does not show the Codex card right now.</b> Put it in a ticked category of a set-up group (Isopoda, Blattodea, Collembola, Arachnida) and untick "Hide" if it is ticked.</p>';
	}
	echo '<table><tbody>';
	$text = function ( $key, $label, $ph = '', $desc = '' ) use ( $v ) {
		echo '<tr><th><label for="fsz_' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td><input type="text" class="regular-text" id="fsz_' . esc_attr( $key ) . '" name="fsz[' . esc_attr( $key ) . ']" value="' . esc_attr( $v( $key ) ) . '" placeholder="' . esc_attr( $ph ) . '">';
		if ( $desc ) {
			echo '<br><span class="description">' . esc_html( $desc ) . '</span>';
		}
		echo '</td></tr>';
	};
	$img     = $v( 'image' );
	$preview = '';
	if ( ctype_digit( $img ) ) {
		$preview = wp_get_attachment_image( (int) $img, 'medium' );
	} elseif ( '' !== $img ) {
		$preview = '<img src="' . esc_url( $img ) . '" alt="">';
	}
	echo '<tr><th>Codex image</th><td><div id="fsz-image-preview">' . $preview . '</div><input type="hidden" id="fsz_image" name="fsz[image]" value="' . esc_attr( $img ) . '"><button type="button" class="button" id="fsz-image-pick">Choose image</button> <button type="button" class="button-link" id="fsz-image-remove"' . ( '' === $img ? ' style="display:none"' : '' ) . '>Remove</button><br><span class="description">Shown on the Codex screen only, separate from the product gallery. Leave empty to use the featured image.</span></td></tr>';
	echo '<tr><th>Codex number</th><td><b>' . esc_html( fsz_codex_number( $post->ID ) ) . '</b><br><span class="description">Automatic: the order the Codex products were published in.</span></td></tr>';
	$names = fsz_names( $post->ID );
	$text( 'name', 'Nickname', $names['from_title']['nick'], 'Big in the name bar. Empty: the part in quotes of a product name like Porcellio laevis – „Boci”, else the whole product name.' );
	$text( 'trade', 'English name', 'Dairy Cow', 'In the strip under the nickname.' );
	$text( 'latin', 'Latin name', '' !== $names['from_title']['latin'] ? $names['from_title']['latin'] : 'Porcellio laevis', 'On the detail page. Empty: the part before the dash in the product name.' );

	$d = (int) $v( 'difficulty' );
	echo '<tr><th><label for="fsz_difficulty">Difficulty</label></th><td><select id="fsz_difficulty" name="fsz[difficulty]"><option value="0">–</option>';
	foreach ( fsz_levels() as $i => $l ) {
		// A value saved before 1.47.0 (2 or 4) shows as its level and is saved as that level's value.
		echo '<option value="' . (int) $l['save'] . '"' . selected( fsz_level( $d ), $i, false ) . '>' . esc_html( $l['word'] ) . '</option>';
	}
	echo '</select></td></tr>';
	$text( 'tags', 'Tags', '', 'Comma separated. Shown as links next to the price (not on the card); they are also the product\'s WooCommerce tags.' );
	$badge = $v( 'badge' );
	echo '<tr><th><label for="fsz_badge">Badge</label></th><td><select id="fsz_badge" name="fsz[badge]"><option value="">None</option>';
	foreach ( array( 'new' => 'New', 'sale' => 'Sale', 'rare' => 'Rare' ) as $key => $label ) {
		echo '<option value="' . esc_attr( $key ) . '"' . selected( $badge, $key, false ) . '>' . esc_html( $label ) . '</option>';
	}
	echo '</select><br><span class="description">The sticker on the photo\'s corner. With None, the sale badge shows by itself while the product has a sale price.</span></td></tr>';
	$picked = fsz_trait_keys( $post->ID );
	echo '<tr><th>Badges</th><td><input type="hidden" name="fsz[traits][]" value="">';
	foreach ( array( 'cleanup' => 'Cleanup crew', 'ball' => 'Rolls into a ball', 'feeder' => 'Feeder' ) as $key => $label ) {
		echo '<label style="margin-right:14px"><input type="checkbox" name="fsz[traits][]" value="' . esc_attr( $key ) . '"' . checked( in_array( $key, $picked, true ), true, false ) . '> ' . esc_html( $label ) . '</label>';
	}
	echo '<br><span class="description">Animated badges over the power bar names; the detail page explains each one.</span></td></tr>';
	echo '</tbody></table>';

	echo '<h4>Power bars (1–5)</h4><table><tbody>';
	foreach ( fsz_bars() as $key => $label ) {
		$cur = (int) $v( 'bar_' . $key );
		echo '<tr><th><label for="fsz_bar_' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td><select id="fsz_bar_' . esc_attr( $key ) . '" name="fsz[bar_' . esc_attr( $key ) . ']"><option value="0">– (not shown)</option>';
		for ( $i = 1; $i <= 5; $i++ ) {
			echo '<option value="' . (int) $i . '"' . selected( $cur, $i, false ) . '>' . (int) $i . '</option>';
		}
		echo '</select></td></tr>';
	}
	echo '</tbody></table>';

	echo '<h4>Detail page</h4><table><tbody>';
	echo '<tr><th><label for="fsz_story">Description</label></th><td><textarea class="large-text" rows="5" id="fsz_story" name="fsz[story]">' . esc_textarea( $v( 'story' ) ) . '</textarea><br><span class="description">One text behind the Description button. About ' . (int) FSZ_STORY_WORDS . ' words fit above the four tiles. Formatting: **bold**, [i]italic[/i], [u]underline[/u], colours [blue] [green] [amber] [red] [group] … [/red] (or select words on the card in quick edit).</span></td></tr>';
	foreach ( fsz_stats() as $key => $st ) {
		$text( 'stat_' . $key, $st[0], '', '' );
	}
	echo '</tbody></table>';

	echo '<h4>Other</h4><table><tbody>';
	$text( 'fun', 'Fun fact', 'Sajnos nem ad tejet.', 'Optional joke in the bubble at the bottom of the card, up to ' . FSZ_FUN_MAX . ' characters (two lines; formatting marks like **bold** do not count).' );
	echo '<tr><th><label for="fsz_color">Colour theme</label></th><td><input type="text" class="fsz-color" id="fsz_color" name="fsz[color]" value="' . esc_attr( $v( 'color' ) ) . '" data-default-color="' . esc_attr( fsz_opt( 'device' ) ) . '"><br><span class="description">The screen frame follows in a darker shade. Leave empty to use the group colour (Products › Categories).</span></td></tr>';
	echo '<tr><th>Running low</th><td><label><input type="checkbox" name="fsz[low]" value="yes"' . checked( $v( 'low' ), 'yes', false ) . '> Few left: the yellow light on the card blinks (while it is in stock)</label></td></tr>';
	echo '<tr><th>Hide</th><td><label><input type="checkbox" name="fsz[hide]" value="yes"' . checked( $v( 'hide' ), 'yes', false ) . '> Do not show the Codex card on this product</label></td></tr>';
	echo '</tbody></table>';
	if ( $live ) {
		echo '<p class="description">Save, then check the product page to see the result.</p>';
	}
	echo '</div>';
}

add_action( 'save_post_product', function ( $post_id ) {
	if ( ! isset( $_POST['fsz_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fsz_nonce'] ) ), 'fsz_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$in = isset( $_POST['fsz'] ) && is_array( $_POST['fsz'] ) ? wp_unslash( $_POST['fsz'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	// The box sends every field; one that is missing counts as emptied.
	foreach ( fsz_field_keys() as $k ) {
		if ( ! isset( $in[ $k ] ) ) {
			$in[ $k ] = '';
		}
	}
	fsz_save_fields( $post_id, $in );
	isset( $in['hide'] ) && 'yes' === $in['hide'] ? update_post_meta( $post_id, '_fsz_hide', 'yes' ) : delete_post_meta( $post_id, '_fsz_hide' );
} );

/**
 * The Codex fields by type. The bars follow the list in the settings.
 */
function fsz_field_keys( $type = 'all' ) {
	$keys = array(
		'text'  => array( 'name', 'latin', 'trade', 'tags', 'fun' ), // 1.41.0: ability and weak point are off the card; their values stay saved
		'int'   => array( 'difficulty' ),
		'link'  => array( 'image' ),
		'multi' => array( 'story' ),
		'color' => array( 'color' ),
		'pick'  => array( 'badge', 'traits' ),
		'flag'  => array( 'low' ), // 1.54.0: yes or nothing
	);
	foreach ( array_keys( fsz_bars() ) as $k ) {
		$keys['int'][] = 'bar_' . $k;
	}
	foreach ( array_keys( fsz_stats() ) as $k ) {
		$keys['text'][] = 'stat_' . $k;
	}
	return 'all' === $type ? array_merge( ...array_values( $keys ) ) : $keys[ $type ];
}

// 2.0.0: which card fields a shop search reads, and in which group. Other plugins (Bolt's search index) ask here
// instead of keeping their own list: a new field added to fsz_field_keys() above is put into ONE group below
// (or left out on purpose), and the search knows about it.
//   names  = rank first (a match here beats a match anywhere else)
//   text   = everything else the card says; ability and weak point are off the card but their saved values still count
//   level  = the difficulty number, searched as words ("kezdő", "beginner")
//   traits = the badges, searched by their labels
function fsz_search_fields() {
	$text = array( 'tags', 'fun', 'story', 'ability', 'weak' );
	foreach ( array_keys( fsz_stats() ) as $k ) {
		$text[] = 'stat_' . $k;
	}
	return array(
		'names'  => array( 'name', 'latin', 'trade' ),
		'text'   => $text,
		'level'  => 'difficulty',
		'traits' => 'traits',
	);
}

/**
 * Save Codex fields from $in (key => value). Keys not in $in are left alone. An empty value
 * deletes the field, so that line is not shown.
 */
function fsz_save_fields( $post_id, $in ) {
	$put = function ( $key, $val, $keep ) use ( $post_id ) {
		$keep ? update_post_meta( $post_id, '_fsz_' . $key, $val ) : delete_post_meta( $post_id, '_fsz_' . $key );
	};
	foreach ( fsz_field_keys( 'text' ) as $k ) {
		if ( array_key_exists( $k, $in ) ) {
			$val = str_replace( "\u{00AD}", '', sanitize_text_field( $in[ $k ] ) ); // soft hyphens pasted from the card
			if ( 'fun' === $k && mb_strlen( fsz_plain( $val ) ) > FSZ_FUN_MAX ) {
				$val = trim( fsz_mark_cut( $val, FSZ_FUN_MAX ) ); // the limit counts the letters, not the marks
			}
			$put( $k, $val, '' !== $val );
		}
	}
	foreach ( fsz_field_keys( 'multi' ) as $k ) {
		if ( array_key_exists( $k, $in ) ) {
			// Browsers send line breaks as \r\n; keep plain \n like the CSV import.
			$val = trim( str_replace( array( "\r\n", "\r", "\u{00AD}" ), array( "\n", "\n", '' ), sanitize_textarea_field( $in[ $k ] ) ) );
			$put( $k, $val, '' !== $val );
		}
	}
	foreach ( fsz_field_keys( 'int' ) as $k ) {
		if ( array_key_exists( $k, $in ) ) {
			$val = max( 0, min( 5, (int) $in[ $k ] ) );
			$put( $k, $val, $val > 0 );
		}
	}
	// A media library ID, or a URL.
	foreach ( fsz_field_keys( 'link' ) as $k ) {
		if ( array_key_exists( $k, $in ) ) {
			$val = trim( (string) $in[ $k ] );
			$val = ctype_digit( $val ) ? (string) absint( $val ) : esc_url_raw( $val );
			$put( $k, $val, (bool) $val );
		}
	}
	if ( array_key_exists( 'color', $in ) ) {
		$val = (string) sanitize_hex_color( $in['color'] );
		$put( 'color', $val, '' !== $val );
	}
	if ( array_key_exists( 'badge', $in ) ) {
		$val = sanitize_key( (string) $in['badge'] );
		$put( 'badge', $val, isset( fsz_badges()[ $val ] ) );
	}
	foreach ( fsz_field_keys( 'flag' ) as $k ) {
		if ( array_key_exists( $k, $in ) ) {
			$put( $k, 'yes', in_array( strtolower( trim( (string) $in[ $k ] ) ), array( '1', 'yes', 'on', 'true', 'igen' ), true ) );
		}
	}
	if ( array_key_exists( 'traits', $in ) ) {
		$val = implode( ',', fsz_trait_keys( 0, is_array( $in['traits'] ) ? implode( ',', $in['traits'] ) : $in['traits'] ) );
		$put( 'traits', $val, '' !== $val );
	}
}
