<?php
// ==========================================================================
//  FILE: inc/traits.php   (Codex plugin)
//  WHAT: The trait badges (the three small icons), the group stamp and the in-stock check.
//  SEEN: The badge bubble on the card.
//  SECTIONS IN THIS FILE:
//    1. Trait badges
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Trait badges
// ==========================================================================

/**
 * The trait badges (meta _fsz_traits = comma list of keys): small animated badges over the power bar names on the card,
 * and on the detail page each one again with its sentence. Always in this order: cleanup crew, rolls into a ball, feeder.
 */
function fsz_traits() {
	return array(
		'cleanup' => array(
			'label' => __( 'Cleanup crew', 'codex' ),
			'why'   => __( 'A true cleaning expert: recommended for bioactive terrariums, for example alongside reptiles and amphibians!', 'codex' ),
		),
		'ball'    => array(
			'label' => __( 'Rolls into a ball', 'codex' ),
			'why'   => __( 'When in danger it curls up; that is how it defends itself against predators.', 'codex' ),
		),
		'feeder'  => array(
			'label' => __( 'Feeder', 'codex' ),
			'why'   => __( 'A real treat for reptiles, amphibians and spiders!', 'codex' ),
		),
	);
}

// The product's trait keys, in the badges' fixed order. Takes a saved value (comma list) or reads the product.
function fsz_trait_keys( $product_id, $raw = null ) {
	$raw  = null === $raw ? (string) get_post_meta( $product_id, '_fsz_traits', true ) : (string) $raw;
	$have = array_map( 'sanitize_key', array_map( 'trim', explode( ',', $raw ) ) );
	return array_values( array_intersect( array_keys( fsz_traits() ), $have ) );
}

/**
 * One trait badge as plain SVG (no filters, so animating it costs next to nothing): a shape with a thickness edge and
 * a soft shadow, a gradient face, a white icon with a thin dark outline (a wider dark copy under it), and a shine that
 * codex.css sweeps across from the top left. viewBox 40×42; the antennae of the ball badge reach past the coin.
 */
function fsz_trait_svg( $key ) {
	static $n = 0;
	$id     = 'fszt' . ( ++$n );
	$looks  = array(
		'cleanup' => array( 'diamond', '#5cbf55', '#2a7a2f', '#a6e89a', 1.08, 1.3, -0.9 ),
		'ball'    => array( 'coin', '#5a85f2', '#2a4bb0', '#a9c0ff', 1.15, 0, 0 ),
		'feeder'  => array( 'square', '#ee7d3e', '#a6461a', '#ffbc8f', 1.02, 0, 0 ),
	);
	$shapes = array(
		'coin'    => '<circle cx="20" cy="19" r="17.5"/>',
		'square'  => '<rect x="2.5" y="1.5" width="35" height="35" rx="8"/>',
		'diamond' => '<path d="M20 .6Q21.2 .6 22.2 1.6L37.4 16.8Q39.6 19 37.4 21.2L22.2 36.4Q20 38.6 17.8 36.4L2.6 21.2Q.4 19 2.6 16.8L17.8 1.6Q18.8 .6 20 .6Z"/>',
	);
	list( $shape, $c, $d, $l, $sc, $dx, $dy ) = $looks[ $key ];
	$s   = $shapes[ $shape ];
	$ink = 'color-mix(in srgb,' . $d . ' 75%,#000)';
	$ol  = round( 0.75 / $sc, 3 );
	// $top: the white icon; otherwise the outline pass (dark, every part a little wider).
	$icon = function ( $top ) use ( $key, $d, $ink, $ol ) {
		$w    = $top ? '#fff' : $ink;
		$o    = $top ? 0 : $ol;
		$fill = function ( $path ) use ( $w, $o ) {
			return '<path d="' . $path . '" fill="' . $w . '"' . ( $o ? ' stroke="' . $w . '" stroke-width="' . ( 2 * $o ) . '" stroke-linejoin="round"' : '' ) . '/>';
		};
		$line = function ( $path, $width ) use ( $w, $o ) {
			return '<path d="' . $path . '" fill="none" stroke="' . $w . '" stroke-width="' . ( $width + 2 * $o ) . '" stroke-linecap="round" stroke-linejoin="round"/>';
		};
		$detail = function ( $path, $width ) use ( $top, $d ) {
			return $top ? '<path d="' . $path . '" fill="none" stroke="' . $d . '" stroke-width="' . $width . '" stroke-linecap="round"/>' : '';
		};
		$disc = function ( $cx, $cy, $r ) use ( $w, $o ) {
			return '<circle cx="' . $cx . '" cy="' . $cy . '" r="' . ( $r + $o ) . '" fill="' . $w . '"/>';
		};
		if ( 'cleanup' === $key ) {
			return '<g class="fsz-t-sweep">' . $line( 'M20.8 2.2 13.4 13', 3.6 ) . $fill( 'M8.6 10.6 16.8 16.4 13.8 23C10.4 23.4 4.6 19.6 2 16.2z' ) . $detail( 'M6.6 18 9.4 14.4M10.2 20.6 13 16.9', 1.7 ) . '</g>'
				. ( $top ? '<g class="fsz-t-dust" fill="#fff"><circle cx="3" cy="22" r="1.3"/><circle cx="6" cy="23.6" r="1"/><circle cx="1" cy="19.6" r=".9"/></g>' : '' );
		}
		if ( 'ball' === $key ) {
			return $disc( 12, 12, 10.2 ) . $detail( 'M5.6 5.4Q9.2 12 5.6 18.6M9.2 2.6Q12.8 12 9.2 21.4M13 2Q16.6 12 13 22M16.8 3.2Q20.2 12 16.8 20.8', 1.5 );
		}
		return $disc( 12, 12.4, 7.6 ) . ( $top ? '<circle cx="12" cy="12.4" r="4.6" fill="none" stroke="' . $d . '" stroke-width="1.3"/>' : '' )
			. '<g class="fsz-t-fork">' . $line( 'M1.4 2.4v4.2M-.4 2.4v3.8Q-.4 8 1.4 8Q3.2 8 3.2 5.6V2.4M1.4 8V22', 1.9 ) . '</g>'
			. '<g class="fsz-t-knife">' . $fill( 'M21.8 1.8C25 3 25.4 8.4 23.4 10.2V21.4Q23.4 22.4 22.5 22.4Q21.6 22.4 21.6 21.4Z' ) . '</g>';
	};
	$off = 12 * $sc;
	$art = '<g transform="translate(' . round( 20 - $off + $dx, 2 ) . ' ' . round( 19.2 - $off + $dy, 2 ) . ') scale(' . $sc . ')">' . $icon( false ) . $icon( true ) . '</g>';
	if ( 'ball' === $key ) {
		$ant = 'M29.2 12.6Q34.4 7.4 41.2 6.6M30.4 15.6Q37.2 13.2 42.6 15.4';
		$art = '<g class="fsz-t-spin">' . $art . '<path d="' . $ant . '" fill="none" stroke="' . $ink . '" stroke-width="3.4" stroke-linecap="round"/><path d="' . $ant . '" fill="none" stroke="#fff" stroke-width="1.9" stroke-linecap="round"/></g>';
	}
	return '<svg class="fsz-tsvg" viewBox="0 0 40 42" aria-hidden="true" focusable="false"><defs>'
		. '<radialGradient id="' . $id . 'g" cx="34%" cy="26%" r="80%"><stop offset="0" stop-color="' . $l . '"/><stop offset=".48" stop-color="' . $c . '"/><stop offset="1" stop-color="' . $d . '"/></radialGradient>'
		. '<linearGradient id="' . $id . 's" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".7"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>'
		. '<clipPath id="' . $id . 'c">' . $s . '</clipPath></defs>'
		. '<g transform="translate(0 4)" fill="#000" opacity=".18">' . $s . '</g>'
		. '<g transform="translate(0 2.6)" fill="' . $d . '" stroke="' . $d . '">' . $s . '</g>'
		. '<g fill="url(#' . $id . 'g)" stroke="' . $ink . '" stroke-width="1.7">' . $s . '</g>'
		. '<g fill="none" stroke="#fff" stroke-opacity=".33" stroke-width="1.1" transform="translate(20 19) scale(.86) translate(-20 -19)">' . $s . '</g>'
		. $art
		. '<g clip-path="url(#' . $id . 'c)"><g transform="rotate(45)"><rect class="fsz-t-shine" x="-14" y="-45" width="9" height="90" fill="url(#' . $id . 's)"/></g></g></svg>';
}

/**
 * The badges' box over the power bar names. In edit mode all three are there (the ones not picked hidden) and the box
 * opens the picker; with none picked it reads "+ Badges".
 */
/**
 * The animal pressed into an empty badge box, picked from the product's group (the top category the card's top right
 * shows): Isopoda = isopod, Blattodea = roach, Collembola = springtail, Arachnida = spider. Matched on the category
 * name or slug, Latin, English or Hungarian; another group gets no animal. Filter: fsz_stamp_kind.
 */
function fsz_stamp_kind( $product_id ) {
	$term = fsz_group_term( $product_id );
	return (string) apply_filters( 'fsz_stamp_kind', $term ? fsz_term_kind( $term ) : '', $product_id );
}

// Which set-up group a top category is (isopoda, blattodea, collembola, arachnida), by its name or slug; '' for any other.
function fsz_term_kind( $term ) {
	$kind = '';
	if ( $term ) {
		$text  = mb_strtolower( $term->name . ' ' . $term->slug );
		$kinds = array(
			'isopoda'    => array( 'isopod', 'ászk', 'aszk' ),
			'blattodea'  => array( 'blatt', 'roach', 'csótány', 'csotany' ),
			'collembola' => array( 'collemb', 'springtail', 'ugróvillás', 'ugrovillas' ),
			'arachnida'  => array( 'arachn', 'spider', 'tarantul', 'pók', 'madarpok' ),
		);
		foreach ( $kinds as $key => $words ) {
			foreach ( $words as $word ) {
				if ( false !== strpos( $text, $word ) ) {
					$kind = $key;
					break 2;
				}
			}
		}
	}
	return (string) apply_filters( 'fsz_group_kind', $kind, $term );
}

/**
 * 1.51.0: only the set-up groups (the four with an animal stamp) can show the card. A category of any other group
 * (supplies, a future group not set up yet) never does, even when it is ticked in the settings.
 */
function fsz_is_setup_term( $term ) {
	while ( $term && ! is_wp_error( $term ) && $term->parent ) {
		$term = get_term( $term->parent, 'product_cat' );
	}
	return $term && ! is_wp_error( $term ) && '' !== fsz_term_kind( $term );
}

/**
 * The stamp itself: a silhouette facing right (viewBox 64×26), legs and antennae as lines, and the body segments as
 * grooves; codex.css colours it so it looks pressed into the box.
 */
function fsz_stamp_svg( $kind ) {
	// Each: filled body parts, lines (legs, antennae), grooves (segments) and holes (eyes) cut in the box colour.
	$shapes = array(
		'isopoda' => array( '<path d="M5.6 13L9 10.8L8.48 9.01L11 9.8L10.48 8.01L13 8.8L12.48 7.01L15 7.8L13.7 4.17L19.75 4.38L18.7 3.22L24.75 4.09L23.7 2.92L29.75 4.05L28.7 2.88L34.75 4.09L33.7 2.92L39.75 4.38L38.7 3.22L44.75 5.33L43.7 4.17L45.3 4.68L48.11 4.97L50.07 5.8L51.59 7.12L52.7 8.84L53.37 10.85L53.6 13L53.37 15.15L52.7 17.16L51.59 18.88L50.07 20.2L48.11 21.03L45.3 21.32L43.7 21.83L44.75 20.67L38.7 22.78L39.75 21.62L33.7 23.08L34.75 21.91L28.7 23.12L29.75 21.95L23.7 23.08L24.75 21.91L18.7 22.78L19.75 21.62L13.7 21.83L15 18.2L12.48 18.99L13 17.2L10.48 17.99L11 16.2L8.48 16.99L9 15.2Z"/>', 'M52.6 10.6L56 9.4L57.4 6.4L60.2 3.5999999999999996M52.6 15.4L56 16.6L57.4 19.6L60.2 22.4M9.6 11L3.4 8.7M9.6 15L3.4 17.3', 'M20 5.23Q18.7 13 20 20.77M25 4.94Q23.7 13 25 21.06M30 4.9Q28.7 13 30 21.1M35 4.94Q33.7 13 35 21.06M40 5.23Q38.7 13 40 20.77M45 6.18Q43.7 13 45 19.82M15 8.2Q14 13 15 17.8', '<ellipse cx="50.4" cy="7.8" rx="1" ry=".8"/><ellipse cx="50.4" cy="18.2" rx="1" ry=".8"/>' ),
		'blattodea' => array( '<path d="M6 13C6 8 14 5.5 30 5.5C38 5.5 42 7 44 8.5L44 17.5C42 19 38 20.5 30 20.5C14 20.5 6 18 6 13Z"/><path d="M43 6.8C49.5 6 54.5 8.6 55 13C54.5 17.4 49.5 20 43 19.2Z"/><ellipse cx="57" cy="13" rx="2.4" ry="3"/>', 'M58.5 11.5Q63 7 62 2.5Q60 .5 52 1.5M58.5 14.5Q63 19 62 23.5Q60 25.5 52 24.5M40 7L43 3.2L48.5 2.4M41 4.6L42.4 4.2M30 6L29.5 2L24.5 .8M29.6 3.6L28.4 3M20 6.2L15 2.5L9.5 2.2M17 3.8L16 4.8M40 19L43 22.8L48.5 23.6M30 20L29.5 24L24.5 25.2M20 19.8L15 23.5L9.5 23.8M6.5 11.5L2 10M6.5 14.5L2 16', 'M8 13H43M43 8.4Q24 8.8 8.4 12.4M43 17.6Q24 17.2 8.4 13.6M46.5 9.5Q49 13 46.5 16.5', '' ),
		'collembola' => array( '<path d="M8 13L8.28 10.99L9.13 10.35L10.51 9.84L12.39 9.38L14.74 8.95L17.48 8.58L20.56 8.25L23.89 8.01L27.4 7.85L31 7.8L34.6 7.85L38.11 8.01L41.44 8.25L44.52 8.58L47.26 8.95L49.61 9.38L51.49 9.84L52.87 10.35L53.72 10.99L54 13L53.72 15.01L52.87 15.65L51.49 16.16L49.61 16.62L47.26 17.05L44.52 17.42L41.44 17.75L38.11 17.99L34.6 18.15L31 18.2L27.4 18.15L23.89 17.99L20.56 17.75L17.48 17.42L14.74 17.05L12.39 16.62L10.51 16.16L9.13 15.65L8.28 15.01L8 13Z"/>', 'M53.4 11.6L56.4 9.2L58.8 6L62.8 3.4M53.4 14.4L56.4 16.8L58.8 20L62.8 22.6M44 8.2L45.6 5.4L47.6 4.8M39.4 8L40 4.8M34.6 8L33.6 4.8M44 17.8L45.6 20.6L47.6 21.2M39.4 18L40 21.2M34.6 18L33.6 21.2', 'M44 9.17Q43.2 13 44 16.83M38 8.91Q37.2 13 38 17.09M33 8.81Q32.2 13 33 17.19M28 8.82Q27.2 13 28 17.18M23 8.94Q22.2 13 23 17.06M18 9.17Q17.2 13 18 16.83', '' ),
		'arachnida' => array( '<ellipse cx="21" cy="13" rx="8" ry="6.4"/><ellipse cx="32.6" cy="13" rx="4.2" ry="3.8"/><path d="M28.4 13L29.4 12V14Z"/>', 'M35 10.4L39.6 3.8L50.4 1.2M36.2 11.8L44.6 7.4L58.4 8.6M36.2 14.2L44.6 18.6L58.4 17.4M35 15.6L39.6 22.2L50.4 24.8M31 10L28.4 3L19.4 .4M30 10.8L24.6 6.2L12.4 5.6M31 16L28.4 23L19.4 25.6M30 15.2L24.6 19.8L12.4 20.4M36.6 12.4L39 12M36.6 13.6L39 14', 'M17 10.4Q21 13 17 15.6M21 9.6Q25 13 21 16.4M25 10.4Q27.4 13 25 15.6', '' ),
	);
	if ( ! isset( $shapes[ $kind ] ) ) {
		return '';
	}
	list( $fill, $lines, $grooves, $holes ) = $shapes[ $kind ];
	return '<span class="fsz-stamp is-' . $kind . '"><svg viewBox="-1 -1 66 28" aria-hidden="true" focusable="false">' . $fill . '<path class="fsz-stamp-l" d="' . $lines . '"/>' . ( $grooves ? '<path class="fsz-stamp-g" d="' . $grooves . '"/>' : '' ) . ( $holes ? '<g class="fsz-stamp-e">' . $holes . '</g>' : '' ) . '</svg></span>';
}

function fsz_traits_box( $keys, $edit, $stamp = '' ) {
	$out = '';
	foreach ( fsz_traits() as $key => $t ) {
		$on = in_array( $key, $keys, true );
		if ( ! $on && ! $edit ) {
			continue;
		}
		$out .= '<span class="fsz-trait is-' . $key . ( $on ? '' : ' is-off' ) . '" data-trait="' . $key . '">' . fsz_trait_svg( $key ) . '</span>';
	}
	if ( $edit ) {
		return '<span class="fsz-traits' . ( $keys ? '' : ' is-empty' ) . '" data-fsz-open="traits" title="Badges">' . $stamp . $out . '<span class="fsz-traits-add">+ Badges</span></span>';
	}
	if ( ! $keys ) {
		// No badges: the box stays, with only the group's animal pressed into it (with badges it sits behind them).
		return '<span class="fsz-traits is-stamp" aria-hidden="true">' . $stamp . '</span>';
	}
	$names = array();
	foreach ( $keys as $key ) {
		$names[] = fsz_traits()[ $key ]['label'];
	}
	return '<span class="fsz-traits" role="img" aria-label="' . esc_attr( implode( ', ', $names ) ) . '">' . $stamp . $out . '</span>';
}

/**
 * In stock: a product with packs (variations) counts as in stock while any of its packs is, read from the packs
 * themselves, so the light agrees with the buy box even when the product's own saved status is out of date.
 */
function fsz_in_stock( $product ) {
	if ( ! $product instanceof WC_Product ) {
		return true;
	}
	if ( $product->is_type( 'variable' ) && $product->get_children() ) {
		return $product->child_is_in_stock();
	}
	return $product->is_in_stock();
}

/**
 * Hungarian hyphenation for the fun fact: soft hyphens at the syllable breaks, so a long word can break at the end of
 * line 1 instead of leaving it half empty. Between two vowels the last consonant starts the next syllable (cs, dz, dzs,
 * gy, ly, ny, sz, ty, zs count as one); never inside a doubled one like ssz (that break would change the spelling), and
 * never one letter from either end of a word. Only for display: the saved text has no soft hyphens.
 */
