<?php
// ==========================================================================
//  FILE: inc/product-page.php   (Codex plugin)
//  WHAT: Puts the card on the product page in place of the photo gallery, with the small scripts that size it before the first paint and the early photo download.
//  SEEN: Product pages of species.
//  SECTIONS IN THIS FILE:
//    1. The card on the product page
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  The card on the product page
// ==========================================================================

function fsz_output_on_product() {
	global $product;
	if ( ! $product instanceof WC_Product || ! fsz_is_live( $product->get_id() ) ) {
		return;
	}
	$id   = $product->get_id();
	$edit = fsz_can_quick_edit( $id );
	echo '<div class="fsz-wrap fsz-at-gallery"' . ( $edit ? ' data-fsz-edit="' . (int) $id . '"' : '' ) . '>' . fsz_render_card( $id ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	echo fsz_sleep_script(); // phpcs:ignore WordPress.Security.EscapeOutput
	echo fsz_fit_script(); // phpcs:ignore WordPress.Security.EscapeOutput
	echo fsz_swipe_nav( $id ); // phpcs:ignore WordPress.Security.EscapeOutput -- 2.2.0: the edge arrows (inc/card-swipe.php)
	if ( $edit ) {
		// Used by codex-edit.js when "Edit card" is clicked.
		echo '<template id="fsz-edit-' . (int) $id . '">' . fsz_render_card( $id, true ) . ( function_exists( 'fsz_render_edit_dialog' ) ? fsz_render_edit_dialog( $id ) : '' ) . '</template>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

// 1.54.0: the card waits for its wake-up (codex.js wake()) with empty bars, set before the first paint so nothing jumps.
// Not for visitors who turned off animations; and if codex.js never takes over, the bars come back after 4 s.
function fsz_sleep_script() {
	// 1.67.2: power-on (Dan's pick A): the product page card's screen starts switched off (.fsz-pwr, a dark layer made
	// here, before the first paint), then a line opens up and the picture flickers on (codex.css), and the layer is
	// removed. 1.68.0: it starts once the photo has loaded AND the page has finished loading (at most 1.5 s), two frames
	// later, so it no longer shares the phone's busiest moment with the page setting itself up; the card's wake-up
	// (codex.js) waits for its end ('fsz-pwr-done'). The full effect plays on the first product page of a visit; later
	// ones get a 0.2 s fade (sessionStorage 'fsz-pwr'). Skipped for reduced motion and without JavaScript.
	// 2.2.0 card swipe (inc/card-swipe.php): a card reached by a swipe or an edge arrow slides in already switched on
	// (html[data-fsz-swipe]), so the power-on is left out. A neighbour's page that the browser prepared in advance (PC
	// Chrome) decides only when it is shown: power-on as usual, or none after a swipe.
	$js = <<<'JS'
(function(){var d=document.currentScript.previousElementSibling;d=d&&d.querySelector('.fsz-device[data-tilt]');if(!d||(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches)){return}d.classList.add('is-asleep');setTimeout(function(){if(!d.fszWake){d.classList.remove('is-asleep')}},4000);var s=d.querySelector('.fsz-screen');if(!s){return}var h=document.documentElement,pwr=function(){var q=false;try{q=!!sessionStorage.getItem('fsz-pwr');sessionStorage.setItem('fsz-pwr','1')}catch(e){}var o=document.createElement('i');o.className='fsz-pwr'+(q?' is-quick':'');o.setAttribute('aria-hidden','true');o.innerHTML='<b></b>';s.appendChild(o);d.fszPwr=true;var done=false,img=s.querySelector('.fsz-slides img'),end=function(){if(o.parentNode){o.parentNode.removeChild(o)}d.fszPwr=false;try{d.dispatchEvent(new Event('fsz-pwr-done'))}catch(e){}},go=function(){if(done){return}done=true;requestAnimationFrame(function(){requestAnimationFrame(function(){o.classList.add('is-on');setTimeout(end,q?240:950)})})},check=function(){if((!img||img.complete)&&document.readyState==='complete'){go()}};if(img&&!img.complete){img.addEventListener('load',check);img.addEventListener('error',function(){img=null;check()})}window.addEventListener('load',check);setTimeout(go,1500);check()};if(document.prerendering){d.fszPwr=true;document.addEventListener('prerenderingchange',function(){if(h.hasAttribute('data-fsz-swipe')){d.fszPwr=false;try{d.dispatchEvent(new Event('fsz-pwr-done'))}catch(e){}}else{pwr()}},{once:true});return}if(!h.hasAttribute('data-fsz-swipe')){pwr()}})()
JS;
	return '<script>' . $js . '</script>';
}

// 1.68.0: the product page card's first photo is asked for in the page head, before the fonts and styles, with top
// priority, so it is there sooner (the power-on waits for it). Same file and sizes as the card's own <img>.
add_action( 'wp_head', 'fsz_preload_card_photo', 1 );
function fsz_preload_card_photo() {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}
	$id = (int) get_queried_object_id();
	if ( ! $id || ! fsz_is_live( $id ) ) {
		return;
	}
	$photo = fsz_first_photo( $id );
	if ( ! $photo ) {
		return;
	}
	echo '<link rel="preload" as="image" href="' . esc_url( $photo['src'] ) . '"' . ( $photo['srcset'] ? ' imagesrcset="' . esc_attr( $photo['srcset'] ) . '"' . ( $photo['sizes'] ? ' imagesizes="' . esc_attr( $photo['sizes'] ) . '"' : '' ) : '' ) . ' fetchpriority="high">' . "\n";
}

// 2.2.0: the card's first photo as the browser will ask for it: the file, its sizes (srcset) and how wide it is drawn
// (sizes). Used by the head preload above and by the card swipe (inc/card-swipe.php), which fetches a neighbour's
// first photo ahead. Empty when the card has no photo.
function fsz_first_photo( $id ) {
	$img = trim( (string) get_post_meta( $id, '_fsz_image', true ) );
	if ( '' !== $img && ! ctype_digit( $img ) ) {
		return array( 'src' => $img, 'srcset' => '', 'sizes' => '' );
	}
	$ids   = fsz_card_image_ids( $id );
	$first = $ids ? (int) reset( $ids ) : 0;
	$src   = $first ? wp_get_attachment_image_src( $first, 'woocommerce_single' ) : false;
	if ( ! $src ) {
		return array();
	}
	$set   = fsz_with_lean_srcset( function () use ( $first ) {
		return wp_get_attachment_image_srcset( $first, 'woocommerce_single' );
	} );
	$sizes = $set ? fsz_card_photo_sizes( $first, fsz_frame( fsz_frames( $id ), $first ) ) : '';
	return array( 'src' => $src[0], 'srcset' => (string) $set, 'sizes' => (string) $sizes );
}

// Fit to the screen: when the theme sets --fsz-fit-bottom on the product page card (the room to keep free under it), the
// card shrinks so its bottom stays that far above the bottom of the screen. It may be negative: an admin's extra bars
// above the card can be given back, so the card has the size a customer sees. Runs right after the card, before the first
// paint, so the card never jumps; codex.js runs it again on resize, after the fonts load and after the edit bar appears.
function fsz_fit_script() {
	static $done = false;
	if ( $done ) {
		return '<script>window.fszFit&&fszFit()</script>';
	}
	$done = true;
	// 1.55.0 screen mode (--fsz-fit-mode: screen, used by the Ízeltláb phone product page): the card is as wide as the
	// screen allows (screen width - 46px, at most 344px), but zoomed out just enough that its SCREEN (the device sides
	// may go under the bars) fits between --fsz-fit-top and --fsz-fit-bottom (px from the top and the bottom of the
	// visible window); never under 280px wide, so it stays readable. Spare room goes above it, up to --fsz-fit-cap
	// (half of it when none is set), so the card sits lower on big phones. The wrap gets --fsz-fit-y (the card's top),
	// --fsz-fit-w (its width) and data-fsz-spare, and a "fsz:fit" event.
	// 1.56.0: --fsz-fit-scale (e.g. .86) makes the card that much narrower than the screen allows; --fsz-fit-center: card
	// centres the WHOLE card between top and bottom (+6px for the float), but never so low that its screen comes within
	// 4px of --fsz-fit-low (px from the bottom: the drawer with its free-shipping line).
	$js = <<<'JS'
window.fszFit=function(){var w=document.querySelectorAll('.fsz-wrap.fsz-at-gallery');for(var i=0;i<w.length;i++){var d=w[i].querySelector('.fsz-device');if(!d){continue}var cs=getComputedStyle(w[i]);if(cs.getPropertyValue('--fsz-fit-mode').trim()==='screen'){fszFitScreen(w[i],d,cs);continue}d.style.removeProperty('--fsz-u');if(!cs.getPropertyValue('--fsz-fit-bottom').trim()){continue}var p=document.createElement('div');p.style.cssText='position:absolute;visibility:hidden;pointer-events:none;height:calc(var(--fsz-fit-bottom) + 10000px);width:calc(var(--fsz-u) * 1000)';d.appendChild(p);var u0=p.offsetWidth/1000,room=innerHeight-(p.offsetHeight-10000)-(w[i].getBoundingClientRect().top+scrollY);d.removeChild(p);var u=u0;for(var n=0;n<3;n++){var h=d.offsetHeight;if(!h||h<=room+1){break}u=Math.max(u0*.55,u*room/h);d.style.setProperty('--fsz-u',u.toFixed(3)+'px')}}};
function fszFitScreen(wr,d,cs){var num=function(k){var v=parseFloat(cs.getPropertyValue(k));return isNaN(v)?null:v},top=num('--fsz-fit-top')||0,bot=num('--fsz-fit-bottom')||0,cap=num('--fsz-fit-cap'),W=document.documentElement.clientWidth,H=num('--fsz-fit-h')||window.innerHeight,lo=top+6,hi=H-bot-6,max=Math.min(W-46,344)*(num('--fsz-fit-scale')||1),w=max,sT=.17,span=.76,R=.54,sc=d.querySelector('.fsz-screen');for(var n=0;n<4;n++){d.style.setProperty('--fsz-u',(w/440).toFixed(4)+'px');var dw=d.offsetWidth,dh=d.offsetHeight;if(!dw||!dh||!sc){return}var t=0,e=sc;while(e&&e!==d){t+=e.offsetTop;e=e.offsetParent}sT=t/dh;span=sc.offsetHeight/dh;R=dw/dh;var nw=Math.max(Math.min(280,max),Math.min(max,(hi-lo)/span*R));if(Math.abs(nw-w)<.5){w=nw;break}w=nw}d.style.setProperty('--fsz-u',(w/440).toFixed(4)+'px');var ch=w/R,spare=(hi-lo)-span*ch,up=Math.max(0,spare/2);if(cap!==null){up=Math.min(cap,up)}var y=lo-sT*ch+up;if(cs.getPropertyValue('--fsz-fit-center').trim()==='card'){var low=num('--fsz-fit-low');low=low===null?bot:low;y=Math.max(lo-sT*ch,Math.min(top+(H-bot-top-ch)/2+6,H-low-4-(sT+span)*ch))}wr.style.setProperty('--fsz-fit-y',Math.round(y)+'px');wr.style.setProperty('--fsz-fit-w',Math.round(w)+'px');wr.setAttribute('data-fsz-spare',String(Math.round(spare)));wr.dispatchEvent(new CustomEvent('fsz:fit',{bubbles:true,detail:{width:w,height:ch,spare:spare}}))}
fszFit()
JS;
	return '<script>' . str_replace( "\n", '', $js ) . '</script>';
}

add_action( 'wp', function () {
	if ( ! function_exists( 'is_product' ) ) {
		return; // WooCommerce is not active
	}
	$live = is_product() && fsz_is_live( get_queried_object_id() );
	if ( $live && '1' === fsz_opt( 'hide_wc' ) ) {
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
		remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
	}
	// The card always takes the product photos' place: left, with the title, price and cart on the right.
	if ( $live ) {
		remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );
		remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_images', 20 );
		add_action( 'woocommerce_before_single_product_summary', 'fsz_output_on_product', 20 );
		// 2.0.0: the card took the gallery's place, so WooCommerce's gallery tools have nothing to work on here: its zoom,
		// slider and lightbox scripts (four files), their two stylesheets and the lightbox's hidden frame are not loaded
		// on a card's product page. Other products keep them. Filter fsz_drop_gallery_tools to keep them here too.
		if ( apply_filters( 'fsz_drop_gallery_tools', true ) ) {
			remove_theme_support( 'wc-product-gallery-zoom' );
			remove_theme_support( 'wc-product-gallery-lightbox' );
			remove_theme_support( 'wc-product-gallery-slider' );
		}
	}
} );

add_shortcode( 'codex', function ( $atts ) {
	$atts = shortcode_atts( array( 'id' => 0 ), $atts );
	$id   = (int) $atts['id'] ? (int) $atts['id'] : get_the_ID();
	if ( ! $id || 'product' !== get_post_type( $id ) ) {
		return '';
	}
	fsz_enqueue_front();
	return '<div class="fsz-wrap">' . fsz_render_card( $id ) . '</div>';
} );
