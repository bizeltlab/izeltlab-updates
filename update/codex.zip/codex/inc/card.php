<?php
// ==========================================================================
//  FILE: inc/card.php   (Codex plugin)
//  WHAT: Builds the whole Codex card: the main page and the Leírás page behind the round arrow.
//  SEEN: Every Codex card: product pages, the front page, phone and PC.
//  SECTIONS IN THIS FILE:
//    1. The card itself (its HTML)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  The card itself (its HTML)
// ==========================================================================

/**
 * The card: the main page, and the detail page behind the round arrow (codex.js switches them).
 * With $edit (quick edit, see codex-edit.js) every line is shown, also the empty ones,
 * and the fields are marked with data-fsz-field / data-fsz-rating.
 */
function fsz_render_card( $product_id, $edit = false ) {
	$m = function ( $key ) use ( $product_id ) {
		return trim( (string) get_post_meta( $product_id, '_fsz_' . $key, true ) );
	};
	// Attributes of an editable text in edit mode.
	$f = function ( $key, $label, $placeholder = '—', $multi = false ) use ( $edit ) {
		return $edit ? ' data-fsz-field="' . esc_attr( $key ) . '" data-placeholder="' . esc_attr( $placeholder ) . '" aria-label="' . esc_attr( $label ) . '"' . ( $multi ? ' data-multiline' : '' ) : '';
	};
	$row = $edit ? ' data-fsz-row' : '';

	$names  = fsz_names( $product_id );
	$diff   = max( 0, min( 5, (int) $m( 'difficulty' ) ) );
	$slides = '1' === fsz_opt( 'show_photo' ) ? fsz_card_images( $product_id, $names['nick'] ) : array();
	if ( $edit ) {
		$slides = array_slice( $slides, 0, 1 ); // edit mode shows the first photo; clicking it opens the photo list
	}
	$story = $m( 'story' );
	// The four tiles show together (an empty one with a dash), or not at all when none is filled in.
	$stats = $edit ? fsz_stats() : array();
	foreach ( fsz_stats() as $key => $st ) {
		if ( '' !== $m( 'stat_' . $key ) ) {
			$stats = fsz_stats();
		}
	}
	// The detail page also holds the Latin name and the badge meanings, so it is there when any of them is.
	$traits   = $edit ? fsz_trait_keys( $product_id, $m( 'traits' ) ) : fsz_trait_keys( $product_id );
	$has_more = '' !== $story || $stats || '' !== $names['latin'] || $traits || $edit;
	$more_id  = 'fsz-more-' . (int) $product_id . ( $edit ? '-edit' : '' );
	$badge    = $edit ? (string) $m( 'badge' ) : fsz_badge( $product_id );
	$badges   = fsz_badges();
	$badge    = isset( $badges[ $badge ] ) ? $badge : '';
	$has_en   = true; // the English strip always takes its place, so every card is the same size
	// Difficulty level 1-3 (Beginner, Intermediate, Expert): the needle and the level colour. Same as level() in codex-edit.js.
	$level  = (string) ( fsz_level( $diff ) ?: '' );
	$levels = fsz_levels();
	$word   = $level ? $levels[ (int) $level ]['word'] : __( 'DIFFICULTY', 'codex' );
	// 1.55.0: the bubble is as wide as the longest level word (not "DIFFICULTY"), so it hugs the word; in edit mode and
	// on a card without a level "DIFFICULTY" can show too, so it counts then.
	$sizer = $edit || ! $level ? array( __( 'DIFFICULTY', 'codex' ) ) : array();
	foreach ( $levels as $l ) {
		$sizer[] = $l['word'];
	}
	usort( $sizer, function ( $a, $b ) {
		return mb_strlen( $b ) - mb_strlen( $a );
	} );
	$sizer = $sizer[0];
	// The green light on the device: lit while the product is in stock, grey when it is sold out.
	$product  = wc_get_product( $product_id );
	$in_stock = fsz_in_stock( $product );
	// 1.54.0: the yellow light blinks while the product is running low (the "Running low" switch) and still in stock.
	// In quick edit it is the switch itself.
	$low      = 'yes' === get_post_meta( $product_id, '_fsz_low', true );
	if ( $edit ) {
		$led_a = '<span class="fsz-led fsz-led-a' . ( $low ? ' is-low' : '' ) . '" data-fsz-toggle="low" role="switch" tabindex="0" aria-checked="' . ( $low ? 'true' : 'false' ) . '" aria-label="' . esc_attr__( 'Running low', 'codex' ) . '" title="' . esc_attr__( 'Running low: click to switch the blinking on or off', 'codex' ) . '"></span>';
	} elseif ( $low && $in_stock ) {
		$led_a = '<span class="fsz-led fsz-led-a is-low" role="img" aria-label="' . esc_attr__( 'Running low', 'codex' ) . '" title="' . esc_attr__( 'Running low', 'codex' ) . '"></span>';
	} else {
		$led_a = '<span class="fsz-led fsz-led-a"></span>';
	}
	$label    = fsz_device_label( $product_id );
	$link     = $edit ? '' : fsz_device_link( $product_id );

	ob_start();
	?>
	<div class="fsz-device<?php echo $edit ? ' is-editing' : ''; ?>"<?php echo $level ? ' data-level="' . esc_attr( $level ) . '"' : ''; ?><?php echo 'default' !== fsz_skin() ? ' data-fsz-skin="' . esc_attr( fsz_skin() ) . '"' : ''; ?> <?php echo $edit ? 'data-fsz-id="' . (int) $product_id . '"' : 'data-tilt="' . (int) fsz_opt( 'tilt' ) . '"'; ?> style="<?php echo esc_attr( fsz_css_vars( $product_id ) ); ?>">
		<div class="fsz-top">
			<?php echo $led_a; // phpcs:ignore WordPress.Security.EscapeOutput ?><span class="fsz-led fsz-led-b<?php echo $in_stock ? ' is-lit' : ''; ?>" role="img" aria-label="<?php echo esc_attr( $in_stock ? __( 'In stock', 'codex' ) : __( 'Out of stock', 'codex' ) ); ?>"></span>
			<?php if ( $link && '' !== $label ) : ?>
				<a class="fsz-label" href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $label ); ?></a>
			<?php else : ?>
				<span class="fsz-label"><?php echo esc_html( $label ); ?></span>
			<?php endif; ?>
		</div>
		<div class="fsz-bezel">
			<div class="fsz-screen">
				<div class="fsz-page fsz-page-main">
					<div class="fsz-deco" aria-hidden="true"></div><?php // group drawing slot (empty until --fsz-deco is set), under the power-bar plate ?>
					<?php // The name bar: the Codex number, the nickname and the difficulty gauge; the English name in the strip under it. ?>
					<div class="fsz-namebar<?php echo $has_en ? ' has-en' : ''; ?>">
						<b class="fsz-num"><?php echo esc_html( fsz_codex_number( $product_id ) ); ?></b>
						<span class="fsz-name fsz-nick"<?php echo $f( 'name', 'Nickname', $names['from_title']['nick'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $edit ? $m( 'name' ) : $names['nick'] ); ?></span>
						<?php if ( $diff > 0 || $edit ) : ?>
							<span class="fsz-diff"<?php echo $edit ? $row . ' data-words="' . esc_attr( wp_json_encode( array( __( 'DIFFICULTY', 'codex' ), $levels[1]['word'], $levels[2]['word'], $levels[3]['word'] ) ) ) . '"' : ' role="img" aria-label="' . esc_attr( __( 'DIFFICULTY', 'codex' ) . ': ' . $word ) . '"'; // phpcs:ignore WordPress.Security.EscapeOutput ?>><span class="fsz-diff-label" aria-hidden="true" data-size="<?php echo esc_attr( $sizer ); ?>"><span class="fsz-diff-word"><?php echo esc_html( $word ); ?></span></span><?php echo fsz_gauge( $diff, $edit ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
						<?php endif; ?>
					</div>
					<?php if ( $has_en ) : ?>
						<div class="fsz-en"><span<?php echo $f( 'trade', 'English name', 'English name' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $names['english'] ); ?></span></div>
					<?php endif; ?>

					<?php
					if ( $slides || ( $edit && '1' === fsz_opt( 'show_photo' ) ) ) {
						// Several photos: they change every 10 seconds or on a click (codex.js); the dots show which one is on.
						$count = count( $slides );
						$dots  = $count > 1 ? '<span class="fsz-strip-dots"><i class="is-on"></i>' . str_repeat( '<i></i>', $count - 1 ) . '</span>' : '';
						// The sticker on the photo's corner (NEW!, SALE!, RARE!); in edit mode it is always there, to pick one.
						if ( $edit ) {
							$sticker = '<span class="fsz-badge ' . ( $badge ? 'is-' . $badge : 'is-empty' ) . '" data-fsz-open="badge" title="Badge">' . esc_html( $badge ? $badges[ $badge ] : '+ Badge' ) . '</span>';
						} else {
							$sticker = $badge ? '<span class="fsz-badge is-' . $badge . '">' . esc_html( $badges[ $badge ] ) . '</span>' : '';
						}
						if ( $edit ) {
							echo '<div class="fsz-photo has-bar' . ( $slides ? '' : ' is-empty' ) . '" data-fsz-open="photos" title="Photos: add, remove, change the order">' . ( $slides ? '<div class="fsz-slides">' . $slides[0] . '</div>' : '<span class="fsz-photo-empty">No photo yet</span>' ) . $sticker . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
						} else {
							$attr = $count > 1 ? ' role="button" tabindex="0" aria-label="' . esc_attr__( 'Next photo', 'codex' ) . '"' : '';
							echo '<div class="fsz-photo has-bar"' . $attr . '><div class="fsz-slides">' . implode( '', $slides ) . '<span class="fsz-crt" aria-hidden="true"></span></div>' . $sticker . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
						}
						// The image bar under the photo: vent on the left, photo dots on the right.
						echo '<div class="fsz-strip" aria-hidden="true"><span class="fsz-strip-vents"></span>' . $dots . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
					}

					$bar_html = '';
					foreach ( fsz_bars() as $key => $label ) {
						$val = max( 0, min( 5, (int) $m( 'bar_' . $key ) ) ); // a bar without a value shows grey, so every card is the same size
						$cells_attr = $edit
							? ' data-fsz-rating="bar_' . esc_attr( $key ) . '" data-value="' . $val . '" aria-label="' . esc_attr( $label ) . '"'
							: ' role="img" aria-label="' . esc_attr( $label . ': ' . $val . '/5' ) . '"';
						$icon       = fsz_bar_icon( fsz_bar_kind( $key, $label ) );
						$bar_html  .= '<div class="fsz-bar"' . $row . '><span class="fsz-bar-label' . ( $icon ? ' has-icon' : '' ) . '">' . $icon . '<span class="fsz-bar-name">' . esc_html( $label ) . '</span></span><span class="fsz-cells"' . $cells_attr . '>';
						for ( $i = 1; $i <= 5; $i++ ) {
							$bar_html .= '<i class="fsz-cell fsz-c' . $i . ( $i <= $val ? ' is-on' : '' ) . '"></i>';
						}
						$bar_html .= '</span></div>';
					}
					if ( $bar_html || $traits || $edit ) {
						// One shared scale over all the bars (fuller = more); the trait badges sit over the bar names.
						$stamp  = fsz_stamp_svg( fsz_stamp_kind( $product_id ) );
						$box    = $traits || $edit || $stamp ? fsz_traits_box( $traits, $edit, $stamp ) : '';
						$scale  = $bar_html ? '<span class="fsz-legend-scale" aria-hidden="true"><span>−</span><i></i><span>+</span></span>' : '';
						$legend = '<div class="fsz-bar fsz-legend' . ( $box ? ' has-traits' : '' ) . '"><span class="fsz-bar-label">' . $box . '</span>' . $scale . '</div>';
						echo '<div class="fsz-bars">' . $legend . $bar_html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
					}

					// The bottom: the optional fun fact bubble, and the Description button centred between the line and the screen's edge.
					// It always takes the same height (room for a two-line fun fact), so every card is the same size.
					$fun = $m( 'fun' );
					echo '<div class="fsz-rule"></div><div class="fsz-screen-foot">';
					if ( '' !== $fun || $edit ) {
						$quote = explode( '|', _x( '“|”', 'quote marks around the fun fact', 'codex' ) . '|' );
						// The quote marks come from codex.css (data-q1/q2), the same in edit mode, so the lines break the same way.
						echo '<div class="fsz-fun' . ( '' === $fun ? ' is-empty' : '' ) . '"' . $row . '><b>' . esc_html__( 'Fun fact', 'codex' ) . '</b><span class="fsz-fun-text" data-q1="' . esc_attr( $quote[0] ) . '" data-q2="' . esc_attr( $quote[1] ) . '"' . $f( 'fun', 'Fun fact', 'Fun fact (optional)' ) . ( $edit ? ' data-fsz-max="' . (int) FSZ_FUN_MAX . '"' : '' ) . ' data-fsz-rich>' . fsz_format( $fun, ! $edit ) . '</span>' . ( $edit ? '<small class="fsz-fun-count" aria-hidden="true">' . (int) mb_strlen( fsz_plain( $fun ) ) . '/' . (int) FSZ_FUN_MAX . '</small>' : '' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
					}
					if ( $has_more ) {
						echo '<button type="button" class="fsz-more" aria-controls="' . esc_attr( $more_id ) . '" aria-expanded="false"><span class="fsz-more-text">' . esc_html__( 'Description', 'codex' ) . '</span><span class="fsz-more-btn" aria-hidden="true"></span></button>';
					}
					echo '</div>';
					?>
				</div>
				<?php if ( $has_more ) : ?>
					<div class="fsz-page fsz-page-more" id="<?php echo esc_attr( $more_id ); ?>" role="region" aria-label="<?php esc_attr_e( 'Detailed description', 'codex' ); ?>" tabindex="-1" hidden>
						<div class="fsz-head">
							<b class="fsz-num"><?php echo esc_html( fsz_codex_number( $product_id ) ); ?></b>
							<span class="fsz-pill"><span class="fsz-diff-label"><?php esc_html_e( 'Detailed description', 'codex' ); ?></span></span>
						</div>
						<?php if ( '' !== $names['latin'] || $edit ) : ?>
							<?php // The scientific name, quiet: a small temple pill, then the name in grey italics. ?>
							<div class="fsz-latin"<?php echo '' === $names['from_title']['latin'] ? $row : ''; // phpcs:ignore WordPress.Security.EscapeOutput -- with a Latin name in the product name the line always shows ?>><span class="fsz-temple" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M12 2 22.5 8H1.5z"/><rect x="2" y="8.8" width="20" height="1.8"/><rect x="3.8" y="11.4" width="2.6" height="8"/><rect x="10.7" y="11.4" width="2.6" height="8"/><rect x="17.6" y="11.4" width="2.6" height="8"/><rect x="2" y="20" width="20" height="1.7"/><rect x="1" y="22.2" width="22" height="1.5"/></svg></span><i lang="la"<?php echo $f( 'latin', 'Latin name', '' !== $names['from_title']['latin'] ? $names['from_title']['latin'] : 'Latin name' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $edit ? $m( 'latin' ) : $names['latin'] ); ?></i></div>
						<?php endif; ?>
						<?php if ( $traits || $edit ) : ?>
							<?php // Each badge on the card again, with what it means (in edit mode all three, the ones not picked hidden). ?>
							<div class="fsz-whys">
								<?php foreach ( fsz_traits() as $key => $t ) : ?>
									<?php $on = in_array( $key, $traits, true ); ?>
									<?php if ( $on || $edit ) : ?>
										<div class="fsz-why is-<?php echo esc_attr( $key ) . ( $on ? '' : ' is-off' ); ?>" data-trait="<?php echo esc_attr( $key ); ?>"><span class="fsz-trait"><?php echo fsz_trait_svg( $key ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span><p><?php echo fsz_why_html( $t['why'] ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside ?></p></div>
									<?php endif; ?>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
						<div class="fsz-rule"></div>
						<div class="fsz-more-body">
							<?php if ( '' !== $story || $edit ) : ?>
								<?php // One text, no heading. In edit mode a word counter: about FSZ_STORY_WORDS fit above the tiles. ?>
								<div class="fsz-story-wrap"<?php echo $row; // phpcs:ignore WordPress.Security.EscapeOutput ?>><div class="fsz-story"<?php echo $f( 'story', 'Description', 'Description', true ) . ( $edit ? ' data-fsz-words="' . (int) FSZ_STORY_WORDS . '"' : '' ); // phpcs:ignore WordPress.Security.EscapeOutput ?> data-fsz-rich><?php echo $edit ? fsz_format( $story, false, true ) : fsz_story_html( $story ); // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped text ?></div><?php if ( $edit ) : ?><?php $n = fsz_word_count( fsz_plain( $story ) ); ?><small class="fsz-story-count<?php echo $n > FSZ_STORY_WORDS ? ' is-full' : ''; ?>" aria-hidden="true"><?php echo (int) $n . '/' . (int) FSZ_STORY_WORDS; ?></small><?php endif; ?></div>
							<?php endif; ?>
							<?php if ( $stats ) : ?>
								<?php // Four tiles, two by two: icon, label, short value. An empty one shows a dash. ?>
								<div class="fsz-stats">
									<?php foreach ( $stats as $key => $st ) : ?>
										<?php $val = $m( 'stat_' . $key ); ?>
										<div class="fsz-stat"><span class="fsz-bar-ic" aria-hidden="true"><svg viewBox="0 0 16 16" focusable="false"><?php echo $st[1]; // phpcs:ignore WordPress.Security.EscapeOutput ?></svg></span><span class="fsz-stat-t"><span class="fsz-stat-l"><?php echo esc_html( $st[0] ); ?></span><span class="fsz-stat-v"<?php echo $f( 'stat_' . $key, $st[0], '—' ); // phpcs:ignore WordPress.Security.EscapeOutput ?> data-fsz-rich><?php echo '' === $val && ! $edit ? '—' : fsz_format( $val, false ); // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped text ?></span></span></div>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>
						</div>
						<div class="fsz-more-foot"><button type="button" class="fsz-back"><span class="fsz-back-btn" aria-hidden="true"></span><span class="fsz-more-text"><?php esc_html_e( 'Back', 'codex' ); ?></span></button></div>
					</div>
				<?php endif; ?>
				<span class="fsz-crt" aria-hidden="true"></span>
			</div>
		</div>
		<div class="fsz-foot" aria-hidden="true">
			<span class="fsz-foot-vents" aria-hidden="true"></span>
		</div>
	</div>
	<?php
	return ob_get_clean();
}
