<?php
// ==========================================================================
//  FILE: inc/edit-dialog.php   (Codex plugin)
//  WHAT: EDITORS ONLY. The pop-ups of "Edit card" on the product page: photos, badge, colour theme.
//  SEEN: Only by logged-in editors, after pressing Edit card.
//  SECTIONS IN THIS FILE:
//    1. Quick edit pop-ups (photos, badge, colours)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Quick edit pop-ups (photos, badge, colours)
// ==========================================================================

/**
 * Quick edit pop-ups: photos (click the photo), badge (click the photo's corner), colour theme (click the device).
 * 1.51.0: the tags are no longer on the card; they are set in the product's Codex box.
 */
function fsz_render_edit_dialog( $product_id ) {
	$color   = sanitize_hex_color( trim( (string) get_post_meta( $product_id, '_fsz_color', true ) ) );
	$default = fsz_group_color( $product_id );
	$uid     = 'fsz-d' . (int) $product_id;
	// The group colour comes first (no own colour, follows the group); the same colour is not listed twice.
	$themes = array( '' => 'Group colour' );
	foreach ( fsz_themes() as $hex => $name ) {
		if ( 0 !== strcasecmp( $hex, $default ) ) {
			$themes[ $hex ] = $name;
		}
	}
	$picked = $color ? 'custom' : '';
	foreach ( array_keys( $themes ) as $hex ) {
		if ( $color && 0 === strcasecmp( $hex, $color ) ) {
			$picked = $hex;
		}
	}
	$own = $color ? $color : $default;

	ob_start();
	?>
	<dialog class="fsz-dialog" aria-labelledby="<?php echo esc_attr( $uid ); ?>-title">
		<form method="dialog">
			<h2 id="<?php echo esc_attr( $uid ); ?>-title"></h2>
			<div class="fsz-dfield" data-fsz-section="photos" data-title="Photos" hidden>
				<ol class="fsz-pics">
					<?php
					// A Codex image given as a link (not in the media library) is shown first on the card, so it is listed first too.
					$linked = trim( (string) get_post_meta( $product_id, '_fsz_image', true ) );
					$frames = fsz_frames( $product_id );
					if ( '' !== $linked && ! ctype_digit( $linked ) ) :
						?>
						<li class="fsz-pic is-linked" data-id="url" data-full="<?php echo esc_url( $linked ); ?>" data-frame="<?php echo esc_attr( implode( ',', fsz_frame( $frames, 'url' ) ) ); ?>" title="Linked Codex image: always shown first">
							<img src="<?php echo esc_url( $linked ); ?>" alt="">
						</li>
					<?php endif; ?>
					<?php foreach ( fsz_card_image_ids( $product_id ) as $id ) : ?>
						<li class="fsz-pic" data-id="<?php echo (int) $id; ?>" data-full="<?php echo esc_url( (string) wp_get_attachment_image_url( $id, 'woocommerce_single' ) ); ?>" data-frame="<?php echo esc_attr( implode( ',', fsz_frame( $frames, $id ) ) ); ?>" draggable="true">
							<img src="<?php echo esc_url( (string) wp_get_attachment_image_url( $id, 'thumbnail' ) ); ?>" alt="">
						</li>
					<?php endforeach; ?>
				</ol>
				<p class="fsz-pics-empty" hidden>No photos yet.</p>
				<div class="fsz-dimage-btns"><button type="button" class="fsz-btn" data-fsz-add-photos>Add photos…</button></div>
				<span class="fsz-dhint">Click a photo to choose which part shows on the card. Drag to change the order, or use the arrows. The first photo is also the product's main image. These are the product's own photos (the album below the card too).</span>
			</div>
			<div class="fsz-dfield" data-fsz-section="color" data-title="Colour theme" hidden>
				<div class="fsz-themes">
					<?php foreach ( $themes as $hex => $name ) : $a = '' === $hex ? $default : $hex; ?>
						<button type="button" class="fsz-theme" data-hex="<?php echo esc_attr( $hex ); ?>" aria-pressed="<?php echo $picked === $hex ? 'true' : 'false'; ?>">
							<span class="fsz-swatch" style="background-color:<?php echo esc_attr( $a ); ?> !important"><span style="background-color:<?php echo esc_attr( fsz_theme_dark( $a ) ); ?> !important"></span></span>
							<span class="fsz-theme-name"><?php echo esc_html( $name ); ?></span>
						</button>
					<?php endforeach; ?>
					<label class="fsz-theme is-custom<?php echo 'custom' === $picked ? ' is-on' : ''; ?>">
						<span class="fsz-swatch" style="background-color:<?php echo esc_attr( $own ); ?> !important"><span style="background-color:<?php echo esc_attr( fsz_theme_dark( $own ) ); ?> !important"></span></span>
						<span class="fsz-theme-name">Own colour</span>
						<input type="color" name="color" value="<?php echo esc_attr( $own ); ?>" data-picked="<?php echo esc_attr( 'custom' === $picked ? $color : '' ); ?>">
					</label>
				</div>
				<span class="fsz-dhint">The outside takes the colour, the screen frame the same colour, darker.</span>
				<?php if ( current_user_can( 'manage_woocommerce' ) ) : ?>
					<div class="fsz-motion">
						<h3>Motion <span>All cards</span></h3>
						<?php
						$sliders = array(
							'float' => array( 'Levitation', 0, 20, '' ),
							'turn'  => array( 'Turn right', -15, 15, '°' ),
							'lean'  => array( 'Tilt down', -15, 15, '°' ),
						);
						foreach ( $sliders as $key => $sl ) :
							$val = (int) fsz_opt( $key );
							?>
							<label class="fsz-slider"><span class="fsz-slider-name"><?php echo esc_html( $sl[0] ); ?></span><input type="range" name="<?php echo esc_attr( $key ); ?>" min="<?php echo (int) $sl[1]; ?>" max="<?php echo (int) $sl[2]; ?>" step="1" value="<?php echo $val; // phpcs:ignore WordPress.Security.EscapeOutput ?>" data-unit="<?php echo esc_attr( $sl[3] ); ?>"><output><?php echo esc_html( $val . $sl[3] ); ?></output></label>
						<?php endforeach; ?>
						<span class="fsz-dhint">Levitation 0 = still. A minus angle turns left / tips up. Saved for every card with Save.</span>
					</div>
				<?php endif; ?>
			</div>
			<div class="fsz-dfield" data-fsz-section="badge" data-title="Badge" hidden>
				<div class="fsz-badges">
					<?php
					$picked_badge = (string) get_post_meta( $product_id, '_fsz_badge', true );
					$picked_badge = isset( fsz_badges()[ $picked_badge ] ) ? $picked_badge : '';
					?>
					<button type="button" class="fsz-badge-pick" data-badge="" aria-pressed="<?php echo '' === $picked_badge ? 'true' : 'false'; ?>"><span class="fsz-badge-none">None</span></button>
					<?php foreach ( fsz_badges() as $key => $text ) : ?>
						<button type="button" class="fsz-badge-pick" data-badge="<?php echo esc_attr( $key ); ?>" aria-pressed="<?php echo $picked_badge === $key ? 'true' : 'false'; ?>"><span class="fsz-badge is-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $text ); ?></span></button>
					<?php endforeach; ?>
				</div>
				<span class="fsz-dhint">The sticker on the photo's corner. With no badge picked, <?php echo esc_html( fsz_badges()['sale'] ); ?> shows by itself while the product has a sale price.</span>
			</div>
			<div class="fsz-dfield" data-fsz-section="traits" data-title="Badges" hidden>
				<div class="fsz-traitpicks">
					<?php $picked_traits = fsz_trait_keys( $product_id ); ?>
					<?php foreach ( fsz_traits() as $key => $t ) : ?>
						<button type="button" class="fsz-trait-pick" data-trait="<?php echo esc_attr( $key ); ?>" aria-pressed="<?php echo in_array( $key, $picked_traits, true ) ? 'true' : 'false'; ?>"><span class="fsz-trait"><?php echo fsz_trait_svg( $key ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span><span class="fsz-trait-name"><?php echo esc_html( array( 'cleanup' => 'Cleanup crew', 'ball' => 'Rolls into a ball', 'feeder' => 'Feeder' )[ $key ] ); ?></span></button>
					<?php endforeach; ?>
				</div>
				<span class="fsz-dhint">Click to switch each badge on or off. They show over the power bar names; the detail page lists them again with what they mean.</span>
			</div>
			<div class="fsz-dactions"><button class="fsz-btn is-primary" value="done">Done</button></div>
		</form>
	</dialog>
	<?php
	return ob_get_clean();
}
