<?php
// ==========================================================================
//  FILE: inc/quick-edit-save.php   (Codex plugin)
//  WHAT: EDITORS ONLY. Saves what "Edit card" on the product page changed.
//  SEEN: Behind the scenes, when an editor presses Save on a card.
//  SECTIONS IN THIS FILE:
//    1. Quick edit: saving
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Quick edit: saving
// ==========================================================================

add_action( 'wp_ajax_fsz_quick_edit_save', function () {
	check_ajax_referer( 'fsz_quick_edit', 'nonce' );
	$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
	if ( ! $id || 'product' !== get_post_type( $id ) || ! current_user_can( 'edit_post', $id ) ) {
		wp_send_json_error( array( 'message' => 'You are not allowed to edit this product.' ), 403 );
	}
	$in = isset( $_POST['fields'] ) && is_array( $_POST['fields'] ) ? wp_unslash( $_POST['fields'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	fsz_save_fields( $id, array_intersect_key( $in, array_flip( fsz_field_keys() ) ) );
	// Photos (only sent when they were changed): the first is the product image, the rest the gallery.
	$res = array();
	if ( isset( $_POST['photos'] ) && function_exists( 'wc_get_product' ) ) {
		$sent = explode( ',', sanitize_text_field( wp_unslash( $_POST['photos'] ) ) );
		$ids  = array_values( array_unique( array_filter( array_map( 'absint', $sent ), 'wp_attachment_is_image' ) ) );
		// The Codex image field: an uploaded one is now part of the photo list; a linked one stays only if it was kept.
		$img = trim( (string) get_post_meta( $id, '_fsz_image', true ) );
		if ( '' !== $img && ( ctype_digit( $img ) || ! in_array( 'url', $sent, true ) ) ) {
			delete_post_meta( $id, '_fsz_image' );
		}
		$product = wc_get_product( $id );
		if ( $product ) {
			try {
				$product->set_image_id( $ids ? $ids[0] : '' );
				$product->set_gallery_image_ids( array_slice( $ids, 1 ) );
				$product->save();
			} catch ( Exception $e ) {
				wp_send_json_error( array( 'message' => 'The photos could not be saved: ' . $e->getMessage() ) );
			}
		}
		// Written once more straight into the product, like the product editor does, so nothing older can win.
		if ( $ids ) {
			set_post_thumbnail( $id, $ids[0] );
		} else {
			delete_post_thumbnail( $id );
		}
		update_post_meta( $id, '_product_image_gallery', implode( ',', array_slice( $ids, 1 ) ) );
		clean_post_cache( $id );
		wp_cache_delete( $id, 'post_meta' );
		// What the card shows now, so the edit card can check it before reloading.
		$res['photos'] = array_map( 'strval', fsz_card_image_ids( $id ) );
		$res['wanted'] = array_map( 'strval', $ids );
	}
	// How each photo sits in the card's frame (only sent when changed): {id: [x, y, zoom]}.
	if ( isset( $_POST['frames'] ) ) {
		$in     = json_decode( wp_unslash( $_POST['frames'] ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$frames = array();
		foreach ( is_array( $in ) ? $in : array() as $key => $f ) {
			if ( ( 'url' !== $key && ! ctype_digit( (string) $key ) ) || ! is_array( $f ) || 3 !== count( $f ) ) {
				continue;
			}
			$f = array_map( 'floatval', array_values( $f ) );
			$f = array( round( max( 0, min( 100, $f[0] ) ), 1 ), round( max( 0, min( 100, $f[1] ) ), 1 ), round( max( 1, min( 3, $f[2] ) ), 3 ) );
			if ( array( 50.0, 50.0, 1.0 ) !== $f ) {
				$frames[ (string) $key ] = $f; // centred and not zoomed is the default, not stored
			}
		}
		if ( $frames ) {
			update_post_meta( $id, '_fsz_frames', $frames );
		} else {
			delete_post_meta( $id, '_fsz_frames' );
		}
	}
	// Motion (only sent when changed): one setting for every card, for shop managers.
	if ( isset( $_POST['motion'] ) && is_array( $_POST['motion'] ) && current_user_can( 'manage_woocommerce' ) ) {
		$motion = array_intersect_key( wp_unslash( $_POST['motion'] ), array_flip( array( 'float', 'turn', 'lean' ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		update_option( FSZ_OPT, array_merge( fsz_opt(), array_map( 'intval', $motion ) ) );
	}
	if ( function_exists( 'wc_delete_product_transients' ) ) {
		wc_delete_product_transients( $id );
	}
	wp_send_json_success( $res );
} );
