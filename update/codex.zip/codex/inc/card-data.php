<?php
// ==========================================================================
//  FILE: inc/card-data.php   (Codex plugin)
//  WHAT: Small facts of one card: its Codex number (#001), the two names, the tags and the corner badge.
//  SEEN: The top of every Codex card.
//  SECTIONS IN THIS FILE:
//    1. Card data: Codex number, names, tags, badge
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Card data: Codex number, names, tags, badge
// ==========================================================================

/**
 * The Codex number: the product's place among the published Codex products, oldest first (#001, #002 …).
 * A product that is not published yet gets the next free number.
 */
function fsz_codex_number( $product_id ) {
	$list = get_transient( 'fsz_numbers' );
	if ( ! is_array( $list ) ) {
		$list = array();
		$ids  = fsz_category_ids();
		if ( $ids ) {
			$posts = get_posts(
				array(
					'post_type'      => 'product',
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'fields'         => 'ids',
					'orderby'        => array( 'date' => 'ASC', 'ID' => 'ASC' ),
					'no_found_rows'  => true,
					'tax_query'      => array( array( 'taxonomy' => 'product_cat', 'terms' => $ids ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
					'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
						'relation' => 'OR',
						array( 'key' => '_fsz_hide', 'compare' => 'NOT EXISTS' ),
						array( 'key' => '_fsz_hide', 'value' => 'yes', 'compare' => '!=' ),
					),
				)
			);
			foreach ( $posts as $i => $id ) {
				$list[ (int) $id ] = $i + 1;
			}
		}
		set_transient( 'fsz_numbers', $list, DAY_IN_SECONDS );
	}
	$n = isset( $list[ (int) $product_id ] ) ? $list[ (int) $product_id ] : count( $list ) + 1;
	return '#' . str_pad( (string) $n, 3, '0', STR_PAD_LEFT );
}

// New, deleted, moved or hidden products renumber the others.
function fsz_forget_numbers() {
	delete_transient( 'fsz_numbers' );
}
add_action( 'save_post_product', 'fsz_forget_numbers' );
add_action( 'deleted_post', 'fsz_forget_numbers' );
add_action( 'trashed_post', 'fsz_forget_numbers' );
add_action( 'untrashed_post', 'fsz_forget_numbers' );
add_action( 'transition_post_status', 'fsz_forget_numbers' );
add_action( 'set_object_terms', 'fsz_forget_numbers' );
add_action( 'update_option_' . FSZ_OPT, 'fsz_forget_numbers' );

// A name without the quotes around it: „Boci” -> Boci.
function fsz_unquote( $text ) {
	return trim( preg_replace( '/^["\'„“”‚‘’«»]+|["\'„“”‚‘’«»]+$/u', '', trim( (string) $text ) ) );
}

// "Latin – „Nickname”" → latin + nickname (any dash, a space on at least one side, plain or no-break spaces).
function fsz_split_name( $name ) {
	if ( preg_match( '/^(.+?)(?:[\s\x{00A0}]+[–—-][\s\x{00A0}]*|[\s\x{00A0}]*[–—-][\s\x{00A0}]+)(.+)$/u', $name, $m ) ) {
		return array(
			'latin' => trim( $m[1] ),
			'nick'  => fsz_unquote( $m[2] ),
		);
	}
	return array(
		'latin' => '',
		'nick'  => $name,
	);
}

/**
 * The names on the card: the nickname (big, in the name bar), the English name (the strip under it) and the Latin name
 * (on the detail page). An empty nickname or Latin name comes from the product name when it reads "Latin – „Nickname”";
 * otherwise the nickname is the whole product name. The from_title values are what an empty field falls back to.
 */
function fsz_names( $product_id ) {
	$meta = function ( $key ) use ( $product_id ) {
		return trim( (string) get_post_meta( $product_id, '_fsz_' . $key, true ) );
	};
	// The title comes texturized (&#8211; and the like); decode it to read the dash and the quotes.
	$title = html_entity_decode( get_the_title( $product_id ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	$from  = fsz_split_name( $title );
	$nick  = $meta( 'name' );
	$latin = $meta( 'latin' );
	// 1.38.1: a nickname still holding the whole old card name ("Latin – „Nickname”") shows only the nickname.
	$own = fsz_split_name( $nick );
	if ( '' !== $own['latin'] ) {
		$nick  = $own['nick'];
		$latin = '' !== $latin ? $latin : $own['latin'];
	}
	return array(
		'nick'       => '' !== $nick ? $nick : $from['nick'],
		'english'    => fsz_unquote( $meta( 'trade' ) ),
		'latin'      => '' !== $latin ? $latin : $from['latin'],
		'from_title' => $from,
	);
}

function fsz_tags( $product_id ) {
	return array_values( array_filter( array_map( 'trim', explode( ',', (string) get_post_meta( $product_id, '_fsz_tags', true ) ) ) ) );
}

// The stickers for the photo's corner (meta _fsz_badge holds the key), in the site language.
function fsz_badges() {
	return array(
		'new'  => __( 'NEW!', 'codex' ),
		'sale' => __( 'SALE!', 'codex' ),
		'rare' => __( 'RARE!', 'codex' ),
	);
}

// The sticker the card shows: the one picked for the product, else the sale one while the product has a sale price.
function fsz_badge( $product_id ) {
	$own = (string) get_post_meta( $product_id, '_fsz_badge', true );
	if ( isset( fsz_badges()[ $own ] ) ) {
		return $own;
	}
	$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;
	return $product && $product->is_on_sale() ? 'sale' : '';
}
