<?php
// ==========================================================================
//  FILE: inc/colours.php   (Codex plugin)
//  WHAT: The card's colour themes (device colour, darker frame, screen tint) and the colour maths behind them. Also who may quick-edit a card.
//  SEEN: The colours of every Codex card.
//  SECTIONS IN THIS FILE:
//    1. Who may quick-edit a card; colour themes and colour maths
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Who may quick-edit a card; colour themes and colour maths
// ==========================================================================

function fsz_can_quick_edit( $product_id ) {
	return is_user_logged_in() && current_user_can( 'edit_post', $product_id );
}

/**
 * Colour themes: the chosen colour is the device, the screen frame is the same colour, darker.
 */
function fsz_themes() {
	return array(
		'#1F8A8A' => 'Teal',
		'#2F6DB5' => 'Blue',
		'#6E4BA8' => 'Purple',
		'#B8487E' => 'Pink',
		'#B83A3A' => 'Red',
		'#C8692A' => 'Orange',
		'#B8902A' => 'Amber',
		'#3B8A3F' => 'Green',
		'#5A6068' => 'Graphite',
	);
}

function fsz_theme_dark( $hex ) {
	$hex = ltrim( (string) sanitize_hex_color( $hex ), '#' );
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	if ( 6 !== strlen( $hex ) ) {
		return '';
	}
	$out = '#';
	foreach ( str_split( $hex, 2 ) as $c ) {
		$out .= sprintf( '%02X', (int) round( hexdec( $c ) * 0.7 ) ); // same as codex-edit.js dark()
	}
	return $out;
}

/**
 * The screen colours in a theme: the hue of the theme colour, the lightness of the settings colour
 * (so text and screen keep the same contrast), and never more saturated than either.
 * Same as tint() in codex-edit.js.
 */
function fsz_theme_tint( $base, $theme, $min_light = 0 ) {
	$b = fsz_hex_hsl( $base );
	$t = fsz_hex_hsl( $theme );
	if ( ! $b || ! $t ) {
		return $base;
	}
	return fsz_hsl_hex( $t[0], min( $b[1], $t[1] ), max( $b[2], $min_light ) );
}

// The screen is at least this light (0-1), whatever the theme.
define( 'FSZ_SCREEN_LIGHT', 0.88 );

function fsz_hex_hsl( $hex ) {
	$hex = ltrim( (string) sanitize_hex_color( $hex ), '#' );
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	if ( 6 !== strlen( $hex ) ) {
		return null;
	}
	list( $r, $g, $b ) = array_map( function ( $c ) {
		return hexdec( $c ) / 255;
	}, str_split( $hex, 2 ) );
	$max = max( $r, $g, $b );
	$min = min( $r, $g, $b );
	$l   = ( $max + $min ) / 2;
	$d   = $max - $min;
	if ( 0.0 === (float) $d ) {
		return array( 0, 0, $l );
	}
	$s = $d / ( 1 - abs( 2 * $l - 1 ) );
	if ( $max === $r ) {
		$h = fmod( ( $g - $b ) / $d + 6, 6 );
	} elseif ( $max === $g ) {
		$h = ( $b - $r ) / $d + 2;
	} else {
		$h = ( $r - $g ) / $d + 4;
	}
	return array( $h * 60, $s, $l );
}

function fsz_hsl_hex( $h, $s, $l ) {
	$c   = ( 1 - abs( 2 * $l - 1 ) ) * $s;
	$x   = $c * ( 1 - abs( fmod( $h / 60, 2 ) - 1 ) );
	$m   = $l - $c / 2;
	$rgb = array( array( $c, $x, 0 ), array( $x, $c, 0 ), array( 0, $c, $x ), array( 0, $x, $c ), array( $x, 0, $c ), array( $c, 0, $x ) );
	$out = '#';
	foreach ( $rgb[ (int) floor( $h / 60 ) % 6 ] as $v ) {
		$out .= sprintf( '%02X', (int) round( ( $v + $m ) * 255 ) );
	}
	return $out;
}
