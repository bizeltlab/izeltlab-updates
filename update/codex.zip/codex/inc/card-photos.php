<?php
// ==========================================================================
//  FILE: inc/card-photos.php   (Codex plugin)
//  WHAT: The photos on the card's screen: which photos, how each is framed (zoom and position), and which file size each screen gets.
//  SEEN: The photo on every Codex card.
//  SECTIONS IN THIS FILE:
//    1. Card photos: which photos, their framing and sizes
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Card photos: which photos, their framing and sizes
// ==========================================================================

/**
 * The photo IDs on the screen: the product's own Codex image (from the media library) or the
 * featured image first, then the product gallery.
 */
function fsz_card_image_ids( $product_id ) {
	$ids = array();
	$img = trim( (string) get_post_meta( $product_id, '_fsz_image', true ) );
	if ( ctype_digit( $img ) && wp_attachment_is_image( (int) $img ) ) {
		$ids[] = (int) $img;
	}
	// The product's own photos, read the same way WooCommerce reads them for the gallery under the card.
	$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;
	if ( $product ) {
		$ids[] = (int) $product->get_image_id();
		$ids   = array_merge( $ids, array_map( 'intval', $product->get_gallery_image_ids() ) );
	} else {
		$ids[] = (int) get_post_thumbnail_id( $product_id );
	}
	return array_values( array_unique( array_filter( $ids ) ) );
}

/**
 * How each photo sits in the fixed 4:3 frame on this product's card: [x %, y %, zoom] by photo ID
 * ('url' for a linked Codex image). Photos without one are centred and not zoomed.
 */
function fsz_frames( $product_id ) {
	$frames = get_post_meta( $product_id, '_fsz_frames', true );
	return is_array( $frames ) ? $frames : array();
}

function fsz_frame( $frames, $key ) {
	$f = isset( $frames[ $key ] ) && is_array( $frames[ $key ] ) ? array_values( $frames[ $key ] ) : array();
	return 3 === count( $f ) ? array( (float) $f[0], (float) $f[1], (float) $f[2] ) : array( 50, 50, 1 );
}

// The frame as CSS variables (codex.css: object-position, transform-origin and scale of .fsz-slides img).
function fsz_frame_style( $frame ) {
	return '--fsz-fx:' . round( $frame[0], 1 ) . '%;--fsz-fy:' . round( $frame[1], 1 ) . '%;--fsz-fz:' . round( $frame[2], 3 );
}

/**
 * 1.71.0: how wide the card's photo is really drawn, for the browser's choice among the photo's sizes (the sizes
 * attribute). WordPress said "416px, or the whole screen on a phone", so a phone with a sharp screen fetched the 1536px
 * file for a photo it draws about 240px wide. The card's screen is about 61% of a narrow phone, 233px on larger phones
 * and small tablets, and 300px (a fifth of a very wide window) on PC. A photo wider than the screen's 4:3 is drawn wider
 * than the box to fill it, and a zoomed frame (the third frame number) larger still, so both count.
 * $frame: array( x, y, zoom ). Filter: fsz_card_photo_sizes.
 */
function fsz_card_photo_sizes( $attachment_id, $frame ) {
	$meta = wp_get_attachment_metadata( $attachment_id );
	$k    = 1;
	if ( is_array( $meta ) && ! empty( $meta['width'] ) && ! empty( $meta['height'] ) ) {
		$k = max( 1, ( (int) $meta['width'] / (int) $meta['height'] ) / 1.3 );
	}
	$k    *= max( 1, isset( $frame[2] ) ? (float) $frame[2] : 1 );
	$n     = function ( $v ) use ( $k ) {
		return (string) round( $v * $k, 1 );
	};
	$sizes = '(min-width: 1500px) ' . $n( 20.3 ) . 'vw, (min-width: 1024px) ' . $n( 300 ) . 'px, (min-width: 414px) ' . $n( 233 ) . 'px, ' . $n( 61 ) . 'vw';
	return (string) apply_filters( 'fsz_card_photo_sizes', fsz_sizes_dpr_cap( $sizes ), $attachment_id, $frame );
}

/**
 * 2.21.0 (Dan's M1, 2026-11-28: the right-sized card photo for phones): a phone with a very sharp screen (2.6 to 3.5
 * dots per pixel: most Androids, every iPhone) fetched the photo for all its dots, e.g. the 1024px file (32-42 KB) for a
 * card drawn 350px wide, while two dots per pixel already look as sharp to the eye on a phone held in the hand, more so
 * under the card screen's glass and lines. Phones and tablets (narrower than 1024px) are now asked for at most about
 * 2.1 dots per pixel: the same card takes the 768px file (about 22 KB). Computers and screens of 2 dots or fewer are
 * unchanged. Works through the browser's own choice (sizes), so the preload in the page head and the card swipe's photo
 * ahead follow it. Filter: fsz_photo_dpr_cap (false switches it off).
 * $sizes: a sizes list such as "(min-width: 1024px) 300px, (min-width: 414px) 233px, 61vw".
 */
function fsz_sizes_dpr_cap( $sizes ) {
	if ( ! apply_filters( 'fsz_photo_dpr_cap', true ) ) {
		return $sizes;
	}
	// screens from this sharpness up are drawn as if they had ~2.1 dots per pixel
	$bands = array( array( '3.4', 0.6 ), array( '2.9', 0.7 ), array( '2.4', 0.8 ) );
	$out   = array();
	foreach ( array_map( 'trim', explode( ',', (string) $sizes ) ) as $part ) {
		if ( ! preg_match( '/^(\((?:[^()]|\([^()]*\))*\)(?:\s+and\s+\([^()]*\))*)?\s*([\d.]+)(px|vw)$/', $part, $m ) ) {
			return $sizes; // a shape this does not know (calc(), auto…): left as it is
		}
		$cond = trim( (string) $m[1] );
		if ( preg_match( '/min-width:\s*(\d+)px/', $cond, $w ) && (int) $w[1] >= 1024 ) {
			$out[] = $part; // a computer's window: unchanged
			continue;
		}
		foreach ( $bands as $b ) {
			$out[] = ( '' !== $cond ? $cond . ' and ' : '' ) . '(min-resolution: ' . $b[0] . 'dppx) ' . round( (float) $m[2] * $b[1], 1 ) . $m[3];
		}
		$out[] = $part;
	}
	return implode( ', ', $out );
}

/**
 * 1.71.0: a photo's list of sizes without the pointless ones: a file that is heavier than a WIDER file of the same
 * photo is never the better pick (it happens when the original was saved more tightly than the sizes WordPress made
 * from it). So a browser that needs fewer dots never downloads more bytes than one that needs more.
 * $cap: also leave out what is wider than this (0 = no limit); the narrowest wider file stays when nothing under the
 * limit comes close to it.
 * Reads the file sizes from the uploads folder; if one cannot be read (photos on another server) the list stays as it is.
 * Used through WordPress's wp_calculate_image_srcset filter, see fsz_with_lean_srcset().
 */
function fsz_srcset_lean( $sources, $meta, $cap = 0 ) {
	if ( ! is_array( $sources ) || count( $sources ) < 2 || empty( $meta['file'] ) ) {
		return $sources;
	}
	$up    = wp_get_upload_dir();
	$sub   = dirname( (string) $meta['file'] );
	$dir   = trailingslashit( $up['basedir'] ) . ( '.' === $sub ? '' : trailingslashit( $sub ) );
	$bytes = array();
	foreach ( $sources as $w => $src ) {
		$b = isset( $src['url'] ) ? (int) @filesize( $dir . wp_basename( rawurldecode( (string) strtok( (string) $src['url'], '?' ) ) ) ) : 0; // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( $b <= 0 ) {
			return $sources;
		}
		$bytes[ (int) $w ] = $b;
	}
	krsort( $bytes, SORT_NUMERIC ); // widest first
	foreach ( $bytes as $w => $b ) {
		foreach ( $bytes as $wider => $lighter ) {
			// "wider" only up to twice as wide: a phone should not have to unpack a far bigger picture to save a few KB
			if ( $wider > $w && $wider <= 2 * $w && $lighter <= $b ) {
				unset( $sources[ $w ], $bytes[ $w ] );
				break;
			}
		}
	}
	if ( $cap > 0 ) {
		// Widest first. Above the limit only the narrowest file may stay, and only when nothing under the limit comes
		// close to it (nine tenths of it): otherwise a sharp screen would be left with a file too small for it.
		$under = 0;
		foreach ( array_keys( $bytes ) as $w ) {
			$under = $w <= $cap ? max( $under, $w ) : $under;
		}
		$over = array_reverse( array_filter( array_keys( $bytes ), function ( $w ) use ( $cap ) {
			return $w > $cap;
		} ) ); // narrowest first
		foreach ( $over as $i => $w ) {
			if ( $i > 0 || $under >= 0.9 * $cap ) {
				unset( $sources[ $w ] );
			}
		}
	}
	return $sources;
}

// Runs $make (something that builds an <img> or a srcset) with fsz_srcset_lean() switched on, and returns its result.
function fsz_with_lean_srcset( $make, $cap = 0 ) {
	$lean = function ( $sources, $size, $src, $meta ) use ( $cap ) {
		return fsz_srcset_lean( $sources, $meta, $cap );
	};
	add_filter( 'wp_calculate_image_srcset', $lean, 99, 4 );
	$out = $make();
	remove_filter( 'wp_calculate_image_srcset', $lean, 99 );
	return $out;
}

// The photos on the screen as <img> tags: a linked Codex image (URL) first, then fsz_card_image_ids().
function fsz_card_images( $product_id, $alt ) {
	// 1.67.0: the first photo of the first cards on a page (the product page's card, the front page's three) loads at
	// once instead of lazily, and the very first one before anything else (fetchpriority), so the card that opens the
	// page shows its photo straight away. The other photos still load when needed. Filter: fsz_eager_cards (3).
	// 2.1.0: how many of those first photos get top priority is a filter too (fsz_high_cards, 1): the theme's front
	// page sets it to its three hero cards, so the three photos arrive together and the cards can appear together.
	static $cards = 0;
	$cards++;
	$eager  = $cards <= (int) apply_filters( 'fsz_eager_cards', 3 );
	$high   = $cards <= (int) apply_filters( 'fsz_high_cards', 1 );
	$out    = array();
	$frames = fsz_frames( $product_id );
	$img    = trim( (string) get_post_meta( $product_id, '_fsz_image', true ) );
	$load   = function () use ( &$out, $eager, $high ) {
		if ( $out ) {
			// 2.21.0: the card's other photos (shown after a swipe or a dot) wait behind everything the first screen needs;
			// they lie on the screen, so the browser fetched them at once and as urgently as the first photo
			return array( 'loading' => 'lazy', 'fetchpriority' => 'low' );
		}
		if ( ! $eager ) {
			return array( 'loading' => 'lazy' );
		}
		return $high ? array( 'loading' => 'eager', 'fetchpriority' => 'high' ) : array( 'loading' => 'eager' );
	};
	if ( '' !== $img && ! ctype_digit( $img ) ) {
		$a = '';
		foreach ( $load() as $k => $v ) {
			$a .= ' ' . $k . '="' . esc_attr( $v ) . '"';
		}
		$out[] = '<img src="' . esc_url( $img ) . '" alt="' . esc_attr( $alt ) . '"' . $a . ' style="' . esc_attr( fsz_frame_style( fsz_frame( $frames, 'url' ) ) ) . '">';
	}
	foreach ( fsz_card_image_ids( $product_id ) as $id ) {
		// The photo's own alt text, or the species name.
		$frame = fsz_frame( $frames, $id );
		$attr  = array_merge( $load(), array( 'style' => fsz_frame_style( $frame ), 'sizes' => fsz_card_photo_sizes( $id, $frame ) ) );
		if ( '' === trim( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) ) ) {
			$attr['alt'] = $alt;
		}
		// 2.21.0: WordPress puts "auto" before the sizes of a lazy photo, and the browser then asks for every dot of a sharp
		// phone screen again; the card's own sizes (fsz_card_photo_sizes()) already know how wide the photo is drawn
		add_filter( 'wp_img_tag_add_auto_sizes', '__return_false' );
		$html = fsz_with_lean_srcset( function () use ( $id, $attr ) {
			return wp_get_attachment_image( $id, 'woocommerce_single', false, $attr );
		} );
		remove_filter( 'wp_img_tag_add_auto_sizes', '__return_false' );
		if ( $html ) {
			$out[] = $html;
		}
	}
	return $out;
}
