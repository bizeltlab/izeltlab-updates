// ==========================================================================
//  FILE: assets/swipe.js   (Codex plugin)
//  WHAT: Moving between species on their product pages without a page load (2.3.0). Phones and touch screens: a
//        sideways swipe anywhere on the page (also beside the card) brings the next species from the right or the
//        previous one from the left; the new card is already visible while the finger moves and comes forward from
//        behind ("Depth"). PC: no swipe; the small side cards (or the arrow keys) do the same move. The next and
//        previous pages are fetched in the background, then the page content is swapped in place and the address
//        bar follows (the back button works). Anything unusual: a normal page load instead. 2.4.0: the swap happens
//        while the cards are still moving and the real card takes over in mid-move (no jump when it lands); the
//        finger is followed with touch events (iPhone).
//        The neighbours and the side cards: inc/card-swipe.php; the look: codex.css section 7.
//  SEEN: Product pages of species (only where a Codex card shows).
//  SECTIONS IN THIS FILE:
//    1. The page now: card, side cards, neighbours
//    2. Fetching the neighbours ahead
//    3. The incoming card (a still picture of the next card)
//    4. The move and the swap
//    5. The swipe (finger only)
//    6. Side cards, arrows, the back button
//    7. PC: first-visit hints on the side cards
//    8. Where the phone tabs sit
//    9. Start
// ==========================================================================
( function () {
	'use strict';
	var html = document.documentElement, body = document.body;
	if ( ! document.querySelector( '.fsz-swipe' ) || ! document.querySelector( '.fsz-wrap.fsz-at-gallery' ) || ! window.matchMedia ) {
		return;
	}
	var mm = function ( q ) {
		return window.matchMedia( q ).matches;
	};
	var reduce = mm( '(prefers-reduced-motion: reduce)' );
	var GAP = 24, DUR = 540, EASE = 'cubic-bezier(.45,.05,.25,1)'; // the "Depth" move (Dan's pick, 2026-11-14)

	// ==========================================================================
	//  1. The page now: card, side cards, neighbours
	// ==========================================================================

	var nav, wrap, data, links, going = false, step = 0;
	function bind() {
		nav = document.querySelector( '.fsz-swipe' );
		wrap = document.querySelector( '.fsz-wrap.fsz-at-gallery:not(.fsz-incoming)' );
		data = {};
		try {
			data = JSON.parse( ( nav && nav.getAttribute( 'data-fsz-swipe' ) ) || '{}' ) || {};
		} catch ( e ) {}
		links = { prev: nav && nav.querySelector( '.fsz-nb-prev' ), next: nav && nav.querySelector( '.fsz-nb-next' ) };
	}
	function url( dir ) {
		return links[ dir ] ? links[ dir ].href.split( '#' )[ 0 ] : '';
	}

	// The page can be swapped in place only with the shop theme's product page helper (Ízeltláb theme 3.4.0+) and
	// Codex's card helper, for shoppers: an editor's page (admin bar, edit tools) changes with a normal page load.
	function canSwap() {
		return !! ( window.fetch && window.DOMParser && window.history && window.history.pushState && window.Codex && window.Codex.setup && window.izlProductPage && ! body.classList.contains( 'admin-bar' ) && ! document.querySelector( '.fsz-device.is-editing' ) );
	}

	// A normal page load (the 2.2.0 way): the next page reads the mark and slides its card in where the browser can.
	function load( dir, u ) {
		try {
			window.sessionStorage.setItem( 'fsz-swipe', JSON.stringify( { u: u, d: dir, t: Date.now() } ) );
		} catch ( e ) {}
		html.setAttribute( 'data-fsz-swipe', dir );
		window.location.href = u;
	}

	// ==========================================================================
	//  2. Fetching the neighbours ahead
	// ==========================================================================

	/* Each neighbour's page is fetched once the page is idle (never on Save-Data or a slow connection: then only when
	   a swipe starts), read into a document that is not shown, and kept until the next move. Scripts and styles that
	   page needs and this one does not have yet (for example the pack choice of a species sold in packs) are loaded
	   then, so the swap itself waits for nothing. The neighbour's first photo is fetched too (as the page will ask for
	   it), so the incoming card shows its picture at once. */
	var docs = {};
	function slow() {
		var c = navigator.connection;
		return !! ( c && ( c.saveData || /(^|-)(2g|3g)$/.test( c.effectiveType || '' ) ) ) || mm( '(prefers-reduced-data: reduce)' );
	}
	function have( sel ) {
		try {
			return !! document.querySelector( sel );
		} catch ( e ) {
			return true;
		}
	}
	function runInline( s ) {
		var n = document.createElement( 'script' );
		n.text = s.text;
		body.appendChild( n );
		body.removeChild( n );
	}
	// What the new page has outside its content that this one lacks: stylesheets, script templates, script files
	// (each with its settings, in page order).
	function needs( d ) {
		d.querySelectorAll( 'link[rel=stylesheet][href]' ).forEach( function ( l ) {
			if ( ! have( 'link[rel=stylesheet][href="' + l.getAttribute( 'href' ) + '"]' ) && ! ( l.id && document.getElementById( l.id ) ) ) {
				document.head.appendChild( document.importNode( l, true ) );
			}
		} );
		var chain = Promise.resolve();
		d.querySelectorAll( 'script' ).forEach( function ( s ) {
			if ( s.closest( '#content' ) ) {
				return;
			}
			if ( /text\/template/.test( s.type || '' ) ) {
				if ( s.id && ! document.getElementById( s.id ) ) {
					body.appendChild( document.importNode( s, true ) );
				}
				return;
			}
			var src = s.getAttribute( 'src' );
			if ( ! src || have( 'script[src="' + src + '"]' ) || ( s.id && document.getElementById( s.id ) ) ) {
				return;
			}
			var base = ( s.id || '' ).replace( /-js$/, '' );
			chain = chain.then( function () {
				return new Promise( function ( done ) {
					[ '-js-extra', '-js-before' ].forEach( function ( k ) {
						var x = base && d.getElementById( base + k );
						if ( x && ! document.getElementById( base + k ) ) {
							runInline( x );
						}
					} );
					var n = document.createElement( 'script' );
					n.src = src;
					if ( s.id ) {
						n.id = s.id;
					}
					n.async = false;
					n.onload = n.onerror = function () {
						var a = base && d.getElementById( base + '-js-after' );
						if ( a ) {
							runInline( a );
						}
						done();
					};
					body.appendChild( n );
				} );
			} );
		} );
		return chain;
	}
	function fetchDoc( u ) {
		if ( ! docs[ u ] ) {
			docs[ u ] = window.fetch( u, { credentials: 'same-origin' } ).then( function ( r ) {
				if ( ! r.ok ) {
					throw new Error( 'status ' + r.status );
				}
				return r.text();
			} ).then( function ( t ) {
				var d = new window.DOMParser().parseFromString( t, 'text/html' );
				if ( ! d.getElementById( 'content' ) || ! d.querySelector( '#content .fsz-wrap.fsz-at-gallery .fsz-device' ) ) {
					throw new Error( 'not a species page' );
				}
				return needs( d ).then( function () {
					return d;
				} );
			} );
			docs[ u ].catch( function () {
				delete docs[ u ];
			} );
		}
		return docs[ u ];
	}
	function photoAhead( dir ) {
		var m = data[ dir ] && data[ dir ].img;
		if ( ! m || ! m[ 0 ] ) {
			return;
		}
		var im = new window.Image(); // never put on the page, so never drawn
		im.decoding = 'async';
		if ( m[ 2 ] ) {
			im.sizes = m[ 2 ];
		}
		if ( m[ 1 ] ) {
			im.srcset = m[ 1 ];
		}
		im.src = m[ 0 ];
	}
	function ahead() {
		if ( slow() || ! canSwap() ) {
			return;
		}
		[ 'next', 'prev' ].forEach( function ( dir ) {
			var u = url( dir );
			if ( u && u !== window.location.href.split( '#' )[ 0 ] ) {
				fetchDoc( u );
				photoAhead( dir );
			}
		} );
	}
	function idle( wait ) {
		window.setTimeout( function () {
			( window.requestIdleCallback || function ( f ) {
				return window.setTimeout( f, 1 );
			} )( ahead, { timeout: 4000 } );
		}, wait );
	}

	// ==========================================================================
	//  3. The incoming card (a still picture of the next card)
	// ==========================================================================

	/* The next species' card, taken from its fetched page, laid exactly over this card (same size and place) and moved
	   to the side it comes from. It is dressed once (Codex.still: names, depth, plate) and has no life of its own; after
	   the swap the real card takes its place in the same spot, so nothing jumps. */
	// This card's place and size before it moves (taken when a swipe starts, or when a move starts without one).
	var base = null;
	function makeGhost( d ) {
		var src = d.querySelector( '#content .fsz-wrap.fsz-at-gallery' );
		if ( ! src || ! wrap ) {
			return null;
		}
		var g = document.importNode( src, true );
		g.querySelectorAll( 'script' ).forEach( function ( s ) {
			s.parentNode.removeChild( s );
		} );
		var r = base || wrap.getBoundingClientRect(), dev = wrap.querySelector( '.fsz-device' ), gd = g.querySelector( '.fsz-device' );
		g.classList.add( 'fsz-incoming' );
		g.setAttribute( 'aria-hidden', 'true' );
		g.setAttribute( 'inert', '' );
		g.style.cssText = wrap.style.cssText;
		[ [ 'position', 'fixed' ], [ 'left', r.left + 'px' ], [ 'top', r.top + 'px' ], [ 'right', 'auto' ], [ 'bottom', 'auto' ], [ 'width', r.width + 'px' ], [ 'height', r.height + 'px' ], [ 'margin', '0' ], [ 'z-index', '4' ], [ 'pointer-events', 'none' ], [ 'translate', 'none' ], [ 'transform', 'none' ], [ 'opacity', '0' ] ].forEach( function ( p ) {
			g.style.setProperty( p[ 0 ], p[ 1 ] );
		} );
		if ( dev && gd ) {
			var u = dev.style.getPropertyValue( '--fsz-u' );
			if ( u ) {
				gd.style.setProperty( '--fsz-u', u );
			}
		}
		wrap.parentNode.insertBefore( g, wrap.nextSibling );
		try {
			window.Codex.still( gd );
		} catch ( e ) {}
		return g;
	}

	// Where the cards are for a finger at dx (the "Depth" move): the outgoing card follows the finger and steps back,
	// the incoming one comes from its side, growing from behind and getting clearer.
	var W = 360;
	// (2.4.0: without an element, it gives the values only)
	function pose( el, x ) {
		var f = Math.min( 1, Math.abs( x ) / W );
		var v = { translate: Math.round( x ) + 'px 0px', scale: String( Math.round( ( 1 - 0.2 * f ) * 1000 ) / 1000 ), opacity: String( Math.round( ( 1 - 0.55 * f ) * 100 ) / 100 ) };
		if ( el ) {
			el.style.translate = v.translate;
			el.style.scale = v.scale;
			el.style.opacity = v.opacity;
		}
		return v;
	}
	function clear( el ) {
		[ 'transition', 'translate', 'scale', 'opacity' ].forEach( function ( k ) {
			el.style.removeProperty( k );
		} );
	}

	// ==========================================================================
	//  4. The move and the swap
	// ==========================================================================

	var ghost = null, gdir = '', gdoc = null, land = null;
	// the real card's last stretch of a move (2.4.0): stopped when a new move starts
	function stopLand() {
		if ( land ) {
			try {
				land.cancel();
			} catch ( e ) {}
			land = null;
		}
	}
	function dropGhost() {
		if ( ghost && ghost.parentNode ) {
			ghost.parentNode.removeChild( ghost );
		}
		ghost = null;
		gdir = '';
		gdoc = null;
	}
	function side( dir ) {
		return 'next' === dir ? 1 : -1; // the next species comes from the right
	}
	function ease( dur, how ) {
		how = how || EASE;
		return reduce ? 'opacity .15s' : 'translate ' + dur + 'ms ' + how + ',scale ' + dur + 'ms ' + how + ',opacity ' + dur + 'ms ease';
	}
	function after( ms, f ) {
		window.setTimeout( f, ms + 30 );
	}
	// After the next frame is on screen: the moves started now are already running on their own by then (the browser
	// draws them without this page's script), so the heavy work that follows cannot hold them up.
	function soon( f ) {
		window.requestAnimationFrame( function () {
			window.setTimeout( f, 0 );
		} );
	}
	var now = function () {
		return window.performance && window.performance.now ? window.performance.now() : Date.now();
	};

	/* 2.4.0: the outgoing card keeps its spot on the screen by itself (fixed, its own size), whatever happens to the page
	   around it: the swap takes the drawer down and puts the next species' page in while it is still leaving. Set from
	   its resting place (r), with the turning point moved so that a card that is already moving (or shrinking) goes on
	   exactly as it was. */
	function pin( el, r ) {
		var cs = window.getComputedStyle( el ), m = /matrix\(([^)]+)\)/.exec( cs.transform || '' ), ox = 0, oy = 0;
		var o = ( cs.transformOrigin || '' ).split( ' ' ).map( parseFloat );
		if ( m ) {
			var v = m[ 1 ].split( ',' ).map( parseFloat );
			ox = v[ 4 ] || 0;
			oy = v[ 5 ] || 0;
		}
		[ [ 'position', 'fixed' ], [ 'left', r.left + 'px' ], [ 'top', r.top + 'px' ], [ 'right', 'auto' ], [ 'bottom', 'auto' ], [ 'width', r.width + 'px' ], [ 'height', r.height + 'px' ], [ 'margin', '0' ], [ 'transform', 'none' ], [ 'z-index', '3' ], [ 'pointer-events', 'none' ] ].forEach( function ( p ) {
			el.style.setProperty( p[ 0 ], p[ 1 ] );
		} );
		if ( o.length > 1 && ! isNaN( o[ 0 ] ) && ! isNaN( o[ 1 ] ) ) {
			el.style.setProperty( 'transform-origin', ( o[ 0 ] - ox ) + 'px ' + ( o[ 1 ] - oy ) + 'px' );
		}
	}

	/* Go to a neighbour: the outgoing card leaves to one side and steps back while the incoming one comes forward from
	   the other. 2.4.0: the page content is swapped while the cards are still moving (the drawer, the buy box and the
	   rest change at once, the backdrop stays), the new card is laid out unseen, and the incoming picture hands over to
	   it in mid-move, so the move ends on the real card in its real spot: nothing jumps or loads after it lands.
	   dx: where the finger let go (0 for a tap or a click). pop: the back or forward button (the address is already
	   there). */
	function go( dir, dx, pop, to ) {
		var u = to || url( dir );
		if ( going || ! u ) {
			return;
		}
		if ( ! canSwap() ) {
			load( dir, u );
			return;
		}
		going = true;
		stopLand();
		W = window.innerWidth || 360;
		if ( ! dx || ! base ) {
			base = wrap.getBoundingClientRect(); // a tap or a click: the card has not moved yet
		}
		var s = side( dir ), off = s * ( W + GAP ), p = Math.min( 1, Math.abs( dx ) / W );
		var dur = Math.round( DUR * ( 1 - 0.4 * p ) );
		try {
			window.localStorage.setItem( 'fsz-nb-hint', '1' ); // they know how to move on: no hints
		} catch ( e ) {}
		hintsOff();
		// the outgoing card leaves now; the incoming one follows as soon as its page is here (usually already)
		var out = wrap, t0 = now();
		if ( ! reduce && out.animate && window.document.timeline ) {
			// 2.4.0: with a start time set here, like the incoming picture (below): it moves on even while the page is busy
			out.style.transition = 'none';
			var oa = out.animate( [ { translate: out.style.translate || '0px', scale: out.style.scale || '1', opacity: out.style.opacity || '1' }, pose( null, -off ) ], { duration: dur, easing: EASE, fill: 'forwards' } );
			try {
				oa.startTime = window.document.timeline.currentTime;
			} catch ( e ) {}
			pose( out, -off );
		} else {
			out.style.transition = ease( dur );
			void out.offsetWidth;
			if ( reduce ) {
				out.style.opacity = '0';
			} else {
				pose( out, -off );
			}
		}
		fetchDoc( u ).then( function ( d ) {
			if ( ! ghost || gdir !== dir || gdoc !== d ) {
				dropGhost();
				ghost = makeGhost( d );
				gdir = dir;
				gdoc = d;
				if ( ghost && ! reduce ) {
					pose( ghost, off + dx );
				}
			}
			if ( ! ghost ) {
				throw new Error( 'no card' );
			}
			var mv = { out: out, outEnd: t0 + dur, end: now() + dur, anim: null };
			void ghost.offsetWidth;
			if ( reduce ) {
				ghost.style.transition = ease( dur );
				void ghost.offsetWidth;
				ghost.style.opacity = '1';
			} else if ( ghost.animate && window.document.timeline ) {
				// 2.4.0: the incoming picture's move runs with a start time set here, so the page knows at every moment where
				// it is on the screen (a plain transition starts "some time soon", and while the page is busy it reads as
				// not moved yet): the real card takes over from exactly that spot
				ghost.style.transition = 'none';
				mv.anim = ghost.animate( [ { translate: ghost.style.translate || '0px', scale: ghost.style.scale || '1', opacity: ghost.style.opacity || '1' }, { translate: '0px 0px', scale: '1', opacity: '1' } ], { duration: dur, easing: EASE, fill: 'forwards' } );
				try {
					mv.anim.startTime = window.document.timeline.currentTime;
				} catch ( e ) {}
				pose( ghost, 0 );
				ghost.style.opacity = '1';
			} else {
				ghost.style.transition = ease( dur );
				void ghost.offsetWidth;
				pose( ghost, 0 );
				ghost.style.opacity = '1';
			}
			soon( function () {
				try {
					swap( d, u, pop, mv );
				} catch ( err ) {
					if ( window.console ) {
						window.console.error( err );
					}
					window.location.href = u;
				}
			} );
		} ).catch( function () {
			load( dir, u );
		} );
	}

	// The body's classes that came from the server (the rest were added by scripts and stay).
	var srvClass = body.className.split( /\s+/ ).filter( Boolean );

	/* 2.4.0: the old content, emptied down to the outgoing card (and the incoming picture), stays on the page, out of the
	   way, until the card has left: the boxes around the card stay, so it keeps its looks. */
	function keepOut( cur, out, r ) {
		pin( out, r );
		for ( var n = out; n && n !== cur && n.parentNode; n = n.parentNode ) {
			Array.prototype.slice.call( n.parentNode.children ).forEach( function ( k ) {
				if ( k !== n && ! k.classList.contains( 'fsz-incoming' ) ) {
					k.parentNode.removeChild( k );
				}
			} );
		}
		cur.removeAttribute( 'id' );
		cur.classList.add( 'fsz-leaving' );
		cur.setAttribute( 'aria-hidden', 'true' );
		cur.setAttribute( 'inert', '' );
		[ [ 'position', 'absolute' ], [ 'left', '0' ], [ 'top', '0' ], [ 'width', '100%' ], [ 'height', '0' ], [ 'margin', '0' ], [ 'padding', '0' ], [ 'overflow', 'visible' ], [ 'pointer-events', 'none' ] ].forEach( function ( p ) {
			cur.style.setProperty( p[ 0 ], p[ 1 ] );
		} );
	}

	function swap( d, u, pop, mv ) {
		var cur = document.getElementById( 'content' ), nu = document.importNode( d.getElementById( 'content' ), true );
		var g = ghost, out = mv.out, r0 = base || out.getBoundingClientRect();
		ghost = null;
		gdoc = null;
		// the new content's scripts: the card's sleep script is left out (the card arrives switched on), the others
		// run when the content is put in (the card fit)
		nu.querySelectorAll( 'script' ).forEach( function ( s ) {
			if ( s.type && ! /javascript|ecmascript/i.test( s.type ) ) {
				return;
			}
			if ( s.hasAttribute( 'data-fsz-sleep' ) ) {
				s.parentNode.removeChild( s );
				return;
			}
			var n = document.createElement( 'script' );
			n.text = s.text;
			s.parentNode.replaceChild( n, s );
		} );
		var nwrap = nu.querySelector( '.fsz-wrap.fsz-at-gallery' ), ndev = nwrap && nwrap.querySelector( '.fsz-device' );
		if ( ! ndev ) {
			throw new Error( 'no card' );
		}
		ndev.setAttribute( 'data-fsz-calm', '' );
		nwrap.style.visibility = 'hidden';
		document.dispatchEvent( new window.CustomEvent( 'fsz:swap', { detail: { url: u } } ) );
		// the outgoing card first keeps its own spot (the drawer coming down would move it), then the phone drawer puts
		// its parts back, then the old content is emptied down to the moving cards and the new content goes in before it
		pin( out, r0 );
		// 2.4.0: the backdrop (the leaves behind the card) stays exactly as it is while the drawer is taken down and
		// built again (codex.css: html.fsz-hold)
		var held = body.classList.contains( 'izl-roomy' );
		if ( held ) {
			html.classList.add( 'fsz-hold' );
		}
		window.izlProductPage.down();
		keepOut( cur, out, r0 );
		cur.parentNode.insertBefore( nu, cur );

		// the page around the content: body classes, title, head tags, the footer's sticky buy bar, page settings
		var was = srvClass, cls = ( d.body.className || '' ).replace( /\bwoocommerce-no-js\b/, 'woocommerce-js' ).split( /\s+/ ).filter( Boolean );
		was.forEach( function ( c ) {
			if ( cls.indexOf( c ) < 0 ) {
				body.classList.remove( c );
			}
		} );
		cls.forEach( function ( c ) {
			body.classList.add( c );
		} );
		srvClass = cls;
		document.title = d.title;
		[ 'link[rel=canonical]', 'link[rel=shortlink]', 'meta[name=description]', 'meta[property^="og:"]', 'meta[property^="product:"]', 'meta[name^="twitter:"]' ].forEach( function ( sel ) {
			var old = document.head.querySelectorAll( sel ), fresh = d.head.querySelectorAll( sel ), at = old.length ? old[ old.length - 1 ].nextSibling : null;
			old.forEach( function ( n ) {
				n.parentNode.removeChild( n );
			} );
			fresh.forEach( function ( n ) {
				document.head.insertBefore( document.importNode( n, true ), at );
			} );
		} );
		var sticky = document.querySelector( '.storefront-sticky-add-to-cart' ), sticky2 = d.querySelector( '.storefront-sticky-add-to-cart' );
		if ( sticky && sticky2 ) {
			sticky.parentNode.replaceChild( document.importNode( sticky2, true ), sticky );
		}
		d.querySelectorAll( 'script[id$="-js-extra"],script[id$="-js-before"]' ).forEach( function ( s ) {
			var mine = document.getElementById( s.id );
			if ( s.closest( '#content' ) || ( mine && mine.text === s.text ) ) {
				return;
			}
			runInline( s );
			if ( mine ) {
				mine.text = s.text;
			}
		} );
		if ( ! pop ) {
			step++;
			window.history.pushState( { fsz: step }, '', u );
		}

		// start the page again: WooCommerce's pack choice and tabs, the theme's buy box and drawer, the card
		var $ = window.jQuery;
		if ( $ ) {
			if ( $.fn.wc_variation_form ) {
				$( '.variations_form' ).each( function () {
					$( this ).wc_variation_form();
				} );
			}
			$( '.wc-tabs-wrapper, .woocommerce-tabs, #rating' ).trigger( 'init' );
		}
		window.izlProductPage.up();
		if ( held ) {
			soon( function () {
				html.classList.remove( 'fsz-hold' );
			} );
		}
		window.Codex.setup( ndev );
		if ( window.fszFit ) {
			window.fszFit();
		}
		bind();
		place();
		watch();
		hintsLater();
		// keep only the new neighbours' pages
		var keep = {};
		[ url( 'next' ), url( 'prev' ) ].forEach( function ( k ) {
			if ( docs[ k ] ) {
				keep[ k ] = docs[ k ];
			}
		} );
		docs = keep;
		// the old content goes once the outgoing card has left and the incoming picture has handed over
		var left = 0;
		function gone() {
			if ( ++left > 1 && cur.parentNode ) {
				cur.parentNode.removeChild( cur );
			}
		}
		window.setTimeout( gone, Math.max( 0, mv.outEnd - now() ) + 30 );
		// 2.4.0: the real card takes over from the incoming picture as soon as it has its size and place (the same for
		// two frames in a row, at most ~0.7 s): in mid-move, exactly where the picture is on the screen at that moment and
		// at its size; it then finishes the move by itself into its own spot (a species whose card sits a little higher or
		// lower, another fit, simply ends there). If the picture has already landed (a slow phone), the card glides the
		// last few pixels instead.
		base = null;
		var last = '', same = 0, n = 0;
		( function settle() {
			var r = nwrap.getBoundingClientRect(), r2 = ndev.getBoundingClientRect();
			var k = [ r.left, r.top, r.width, r.height, r2.width, r2.height ].map( Math.round ).join( ',' );
			same = k === last ? same + 1 : 0;
			last = k;
			if ( ( same < 1 || n < 1 ) && n < 40 ) {
				n++;
				window.requestAnimationFrame( settle );
				return;
			}
			var rest = mv.end - now(), ms = 0;
			if ( mv.anim ) {
				var ct = mv.anim.currentTime;
				rest = null === ct ? 0 : mv.anim.effect.getTiming().duration - ct;
			}
			if ( g && ! reduce && r.width ) {
				var a = g.getBoundingClientRect(), op = parseFloat( window.getComputedStyle( g ).opacity );
				nwrap.style.transition = 'none';
				nwrap.style.translate = '0px 0px';
				nwrap.style.scale = String( Math.round( ( a.width / r.width ) * 10000 ) / 10000 );
				var b = nwrap.getBoundingClientRect();
				var mx = ( a.left + a.width / 2 ) - ( b.left + b.width / 2 ), my = ( a.top + a.height / 2 ) - ( b.top + b.height / 2 );
				var from = { translate: Math.round( mx * 10 ) / 10 + 'px ' + Math.round( my * 10 ) / 10 + 'px', scale: nwrap.style.scale, opacity: String( isNaN( op ) ? 1 : op ) };
				if ( rest > 40 ) {
					ms = Math.round( rest ); // in mid-move: the same move goes on, slowing down into the spot
				} else if ( Math.abs( mx ) > 0.5 || Math.abs( my ) > 0.5 || Math.abs( a.width / r.width - 1 ) > 0.002 || op < 1 ) {
					ms = 220; // landed already: the last few pixels
				}
				clear( nwrap );
				if ( ms ) {
					var how = rest > 40 ? 'cubic-bezier(.2,.6,.35,1)' : EASE;
					if ( nwrap.animate && window.document.timeline ) {
						land = nwrap.animate( [ from, { translate: '0px 0px', scale: '1', opacity: '1' } ], { duration: ms, easing: how } );
						try {
							land.startTime = window.document.timeline.currentTime;
						} catch ( e ) {}
					} else {
						nwrap.style.translate = from.translate;
						nwrap.style.scale = from.scale;
						nwrap.style.opacity = from.opacity;
						void nwrap.offsetWidth;
						nwrap.style.transition = ease( ms, how );
						nwrap.style.translate = '0px 0px';
						nwrap.style.scale = '1';
						nwrap.style.opacity = '1';
					}
				}
			} else if ( g && reduce ) {
				nwrap.style.opacity = window.getComputedStyle( g ).opacity;
				void nwrap.offsetWidth;
				nwrap.style.transition = 'opacity .15s';
				nwrap.style.opacity = '1';
				ms = 160;
			}
			nwrap.style.visibility = '';
			if ( g && g.parentNode ) {
				g.parentNode.removeChild( g );
			}
			gone();
			going = false;
			after( ms, function () {
				if ( wrap === nwrap && ! going && ! html.classList.contains( 'fsz-dragging' ) ) {
					clear( nwrap );
				}
			} );
			idle( 300 + ms );
		} )();
	}

	// ==========================================================================
	//  5. The swipe (finger only)
	// ==========================================================================

	/* Phones and touch screens only (a mouse never swipes; PC has the side cards). Anywhere on the page except the top
	   bar, the open drawer, fields, a card being edited, the photo when the card has several (a swipe there changes the
	   photo) and the photo pop-out. Only a clear sideways move counts: the first 10 px decide, mostly up or down stays the
	   page's (the drawer). Only translate, scale and opacity change while the card moves. */
	var g = null, raf = 0, block = false;
	// a row that scrolls sideways itself (a tablet's product rows) keeps its own swipe
	function sideScroller( t ) {
		for ( var el = t; el && el !== body && el.nodeType === 1; el = el.parentNode ) {
			if ( el.scrollWidth > el.clientWidth + 1 && /auto|scroll/.test( window.getComputedStyle( el ).overflowX ) ) {
				return true;
			}
		}
		return false;
	}
	function skip( t ) {
		return ! t.closest || sideScroller( t ) || !! ( body.classList.contains( 'izl-open' ) || body.classList.contains( 'izl-popon' ) || document.querySelector( '.fsz-device.is-editing' ) || t.closest( '.site-header,#wpadminbar,.izl-drawer,.izl-pop,.fsz-incoming,input,textarea,select,[contenteditable],.fsz-photo[role=button]' ) );
	}
	function paint() {
		raf = 0;
		if ( ! g || ! g.on ) {
			return;
		}
		pose( wrap, g.dx );
		var dir = g.dx < 0 ? 'next' : 'prev';
		if ( ghost && gdir !== dir ) {
			dropGhost();
		}
		if ( ! ghost && g.docs[ dir ] ) {
			ghost = makeGhost( g.docs[ dir ] );
			gdir = dir;
			gdoc = g.docs[ dir ];
		}
		if ( ghost ) {
			pose( ghost, side( dir ) * ( W + GAP ) + g.dx );
		}
	}
	// p: one finger's place, from a touch or a pointer event: { id, x, y, t }
	function move( p, e ) {
		if ( ! g || p.id !== g.id ) {
			return;
		}
		var dx = p.x - g.x, dy = p.y - g.y;
		if ( ! g.on ) {
			if ( Math.abs( dx ) < 10 && Math.abs( dy ) < 10 ) {
				// 2.4.0: still deciding; a finger that so far goes more sideways than up or down keeps the page still
				// (iPhone: once the page starts to scroll, the finger is the browser's for the rest of the touch)
				if ( e && e.cancelable && Math.abs( dx ) > Math.abs( dy ) * 2 && Math.abs( dx ) > 2 ) {
					e.preventDefault();
				}
				return;
			}
			if ( Math.abs( dx ) < Math.abs( dy ) * 1.5 || ! wrap || ( e && 'cancelable' in e && ! e.cancelable ) ) {
				g = null; // up or down (or the page is already scrolling): not a swipe
				return;
			}
			g.on = true;
			stopLand();
			W = window.innerWidth || 360;
			base = wrap.getBoundingClientRect();
			html.classList.add( 'fsz-dragging' );
			wrap.style.transition = 'none';
			// both neighbours' pages (usually fetched already): the incoming card appears as soon as one is here
			var gs = g;
			[ 'next', 'prev' ].forEach( function ( dir ) {
				var u = url( dir );
				if ( u ) {
					fetchDoc( u ).then( function ( d ) {
						gs.docs[ dir ] = d;
						if ( g === gs && ! raf ) {
							raf = window.requestAnimationFrame( paint );
						}
					}, function () {} );
				}
			} );
		}
		if ( e && e.cancelable ) {
			e.preventDefault(); // the finger is ours now: the page does not scroll under it
		}
		g.dx = dx;
		g.hist.push( [ p.t, p.x ] );
		if ( g.hist.length > 5 ) {
			g.hist.shift();
		}
		if ( ! raf ) {
			raf = window.requestAnimationFrame( paint );
		}
	}
	function end( p, cancel ) {
		if ( ! g || p.id !== g.id ) {
			return;
		}
		var was = g;
		g = null;
		if ( ! was.on ) {
			return;
		}
		html.classList.remove( 'fsz-dragging' );
		if ( raf ) {
			window.cancelAnimationFrame( raf );
			raf = 0;
		}
		var h = was.hist, v = 0, dx = was.dx;
		if ( h.length > 1 ) {
			v = ( h[ h.length - 1 ][ 1 ] - h[ 0 ][ 1 ] ) / Math.max( 1, h[ h.length - 1 ][ 0 ] - h[ 0 ][ 0 ] ); // px per ms, the last moves
		}
		block = true; // the click a finger sends after the drag (on Leírás, a badge …) is not a click
		window.setTimeout( function () {
			block = false;
		}, 350 );
		if ( ! cancel && ( Math.abs( dx ) > Math.min( 110, W * 0.3 ) || ( Math.abs( dx ) > 36 && Math.abs( v ) > 0.45 && ( v < 0 ) === ( dx < 0 ) ) ) ) {
			go( dx < 0 ? 'next' : 'prev', dx );
			return;
		}
		// not far or fast enough: both cards back to their places
		wrap.style.transition = ease( 300 );
		pose( wrap, 0 );
		var gh = ghost;
		if ( gh ) {
			gh.style.transition = ease( 300 );
			pose( gh, side( gdir ) * ( W + GAP ) );
		}
		after( 300, function () {
			if ( ! g && ! going ) {
				clear( wrap );
				if ( gh === ghost ) {
					dropGhost();
				}
			}
		} );
	}
	function begin( p, t ) {
		if ( going || ( g && g.on ) || ! wrap || skip( t ) ) {
			return;
		}
		g = { id: p.id, x: p.x, y: p.y, dx: 0, on: false, hist: [ [ p.t, p.x ] ], docs: {} };
	}
	/* 2.4.0: a finger is followed with touch events where the browser has them (iPhone: with pointer events Safari took
	   the finger back after a few pixels, pointercancel, and the card stopped); a pen (or a touch screen without touch
	   events) with pointer events. */
	var TOUCH = 'ontouchstart' in window;
	function tp( e ) {
		var k = e.changedTouches && e.changedTouches[ 0 ];
		return k ? { id: k.identifier, x: k.clientX, y: k.clientY, t: e.timeStamp } : null;
	}
	if ( TOUCH ) {
		document.addEventListener( 'touchstart', function ( e ) {
			var p = tp( e );
			if ( ! p || e.touches.length > 1 ) {
				g = null; // two fingers: a pinch, not a swipe
				return;
			}
			begin( p, e.target );
		}, { passive: true } );
		document.addEventListener( 'touchmove', function ( e ) {
			if ( ! g ) {
				return;
			}
			for ( var i = 0; i < e.changedTouches.length; i++ ) {
				var k = e.changedTouches[ i ];
				if ( k.identifier === g.id ) {
					move( { id: k.identifier, x: k.clientX, y: k.clientY, t: e.timeStamp }, e );
					return;
				}
			}
		}, { passive: false } );
		var tEnd = function ( e ) {
			if ( ! g ) {
				return;
			}
			for ( var i = 0; i < e.changedTouches.length; i++ ) {
				var k = e.changedTouches[ i ];
				if ( k.identifier === g.id ) {
					end( { id: k.identifier }, 'touchcancel' === e.type );
					return;
				}
			}
		};
		document.addEventListener( 'touchend', tEnd );
		document.addEventListener( 'touchcancel', tEnd );
	}
	var pp = function ( e ) {
		return { id: 'p' + e.pointerId, x: e.clientX, y: e.clientY, t: e.timeStamp };
	};
	document.addEventListener( 'pointerdown', function ( e ) {
		if ( ! e.isPrimary || 'mouse' === e.pointerType || ( TOUCH && 'touch' === e.pointerType ) ) {
			return;
		}
		begin( pp( e ), e.target );
	}, { passive: true } );
	document.addEventListener( 'pointermove', function ( e ) {
		if ( g && 'string' === typeof g.id ) {
			move( pp( e ), null );
		}
	}, { passive: true } );
	[ 'pointerup', 'pointercancel' ].forEach( function ( k ) {
		document.addEventListener( k, function ( e ) {
			if ( g && 'string' === typeof g.id ) {
				end( pp( e ), 'pointercancel' === e.type );
			}
		} );
	} );
	document.addEventListener( 'click', function ( e ) {
		if ( block ) {
			e.preventDefault();
			e.stopPropagation();
		}
	}, true );
	// A finger moving sideways is ours; up and down stay the browser's (the drawer, the page).
	html.classList.add( 'fsz-swipe-on' );

	// ==========================================================================
	//  6. Side cards, arrows, the back button
	// ==========================================================================

	// The side cards (PC) and the edge tabs (phone) are plain links: a click moves in place (a new tab or window stays
	// a normal link).
	document.addEventListener( 'click', function ( e ) {
		var a = e.target.closest && e.target.closest( '.fsz-nb' );
		if ( ! a || e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey ) {
			return;
		}
		e.preventDefault();
		go( a.classList.contains( 'fsz-nb-prev' ) ? 'prev' : 'next', 0 );
	} );
	// 2.4.0: a pointer over a side card or a tab fetches that species' page right away (if it is not here yet), so the
	// incoming card is ready when the click comes
	document.addEventListener( 'pointerover', function ( e ) {
		var a = e.target.closest && e.target.closest( '.fsz-nb' );
		if ( a && ! going && canSwap() ) {
			var u = url( a.classList.contains( 'fsz-nb-prev' ) ? 'prev' : 'next' );
			if ( u ) {
				fetchDoc( u ).catch( function () {} );
			}
		}
	}, { passive: true } );
	// PC: the arrow keys (not while typing, not with the photo pop-out open)
	document.addEventListener( 'keydown', function ( e ) {
		if ( ( 'ArrowLeft' !== e.key && 'ArrowRight' !== e.key ) || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey || e.defaultPrevented ) {
			return;
		}
		var t = e.target;
		if ( ! mm( '(hover: hover) and (pointer: fine)' ) || ( t && t.closest && t.closest( 'input,textarea,select,[contenteditable],.izl-pop,.fsz-photo' ) ) || body.classList.contains( 'izl-popon' ) || ! nav || ! window.getComputedStyle( nav ).display || 'none' === window.getComputedStyle( nav ).display ) {
			return;
		}
		go( 'ArrowRight' === e.key ? 'next' : 'prev', 0 );
	} );
	// Back and forward between swapped species: the same move, the way back from the left.
	window.addEventListener( 'popstate', function ( e ) {
		var st = e.state;
		if ( ! st || 'number' !== typeof st.fsz ) {
			return;
		}
		if ( going ) {
			window.location.reload();
			return;
		}
		var dir = st.fsz < step ? 'prev' : 'next';
		step = st.fsz;
		go( dir, 0, true, window.location.href.split( '#' )[ 0 ] );
	} );
	try {
		window.history.replaceState( Object.assign( {}, window.history.state || {}, { fsz: step } ), '' );
	} catch ( e ) {}
	// Back to this page from the browser's memory: everything in its place.
	window.addEventListener( 'pageshow', function ( e ) {
		if ( e.persisted ) {
			going = false;
			g = null;
			dropGhost();
			if ( wrap ) {
				clear( wrap );
			}
			html.removeAttribute( 'data-fsz-swipe' );
			html.classList.remove( 'fsz-dragging' );
		}
	} );

	// ==========================================================================
	//  7. PC: first-visit hints on the side cards
	// ==========================================================================

	/* A new visitor on PC (side cards showing) who has not used them: after 12 seconds on the page (counted only while the
	   tab is in front), faint "előző" and "következő" labels fade in next to the side cards for a few seconds, and from
	   then the side cards nudge inwards every 9 seconds until one is hovered or used. Once per visitor (localStorage
	   fsz-nb-hint). The look: codex.css section 7 (.is-hint, .is-nudge). */
	var HINT_AT = 12000, NUDGE_EVERY = 9000;
	var seen = 0, tick = 0, nudgeT = 0, hinted = false, lastT = 0;
	function told() {
		try {
			return !! window.localStorage.getItem( 'fsz-nb-hint' );
		} catch ( e ) {
			return true; // storage blocked: never nag
		}
	}
	function peeks() {
		return mm( '(min-width: 1200px) and (hover: hover) and (pointer: fine)' ) && nav && ! nav.classList.contains( 'is-away' );
	}
	function nudge() {
		if ( ! nav || ! hinted ) {
			return;
		}
		nav.classList.remove( 'is-nudge' );
		void nav.offsetWidth;
		nav.classList.add( 'is-nudge' );
		nudgeT = window.setTimeout( nudge, NUDGE_EVERY );
	}
	function hintsOff() {
		window.clearInterval( tick );
		window.clearTimeout( nudgeT );
		tick = 0;
		hinted = false;
		if ( nav ) {
			nav.classList.remove( 'is-hint', 'is-nudge' );
		}
	}
	function hintsLater() {
		if ( reduce || told() || tick || hinted ) {
			return;
		}
		lastT = Date.now();
		tick = window.setInterval( function () {
			var now = Date.now();
			if ( ! document.hidden && peeks() ) {
				seen += now - lastT;
			}
			lastT = now;
			if ( seen < HINT_AT ) {
				return;
			}
			window.clearInterval( tick );
			tick = 0;
			try {
				window.localStorage.setItem( 'fsz-nb-hint', '1' );
			} catch ( e ) {}
			hinted = true;
			nav.classList.add( 'is-hint' );
			nudge();
		}, 250 );
	}
	document.addEventListener( 'pointerover', function ( e ) {
		if ( hinted && e.target.closest && e.target.closest( '.fsz-nb' ) ) {
			window.clearTimeout( nudgeT );
			hinted = false;
			nav.classList.remove( 'is-nudge' );
		}
	} );

	// ==========================================================================
	//  8. Where the phone tabs sit
	// ==========================================================================

	// Phone (the card stays still on the screen): at the card's mid-height, so the tabs are never under the buy drawer.
	// Elsewhere at the window's mid-height, faded out while the card is mostly scrolled away.
	function place() {
		if ( ! nav || ! wrap ) {
			return;
		}
		if ( 'fixed' !== window.getComputedStyle( wrap ).position ) {
			nav.style.removeProperty( '--fsz-swipe-y' );
			return;
		}
		var d = wrap.querySelector( '.fsz-device' ), r = ( d || wrap ).getBoundingClientRect();
		if ( r.height ) {
			nav.style.setProperty( '--fsz-swipe-y', Math.round( r.top + r.height / 2 ) + 'px' );
		}
	}
	document.addEventListener( 'fsz:fit', function ( e ) {
		if ( ! e.target || ! e.target.classList || ! e.target.classList.contains( 'fsz-incoming' ) ) {
			place();
		}
	} );
	window.addEventListener( 'resize', function () {
		window.requestAnimationFrame( place );
	} );
	var io = null;
	function watch() {
		if ( ! ( 'IntersectionObserver' in window ) || ! wrap ) {
			return;
		}
		if ( io ) {
			io.disconnect();
		}
		io = new window.IntersectionObserver( function ( en ) {
			if ( nav ) {
				nav.classList.toggle( 'is-away', en[ en.length - 1 ].intersectionRatio < 0.3 );
			}
		}, { threshold: [ 0, 0.3 ] } );
		io.observe( wrap );
	}

	// ==========================================================================
	//  9. Start
	// ==========================================================================

	function start() {
		bind();
		place();
		watch();
		hintsLater();
		if ( 'complete' === document.readyState ) {
			idle( 2000 );
		} else {
			window.addEventListener( 'load', function () {
				idle( 2000 );
			} );
		}
		// The slide mark of a normal page load has done its job once the page is on screen.
		window.setTimeout( function () {
			if ( ! going ) {
				html.removeAttribute( 'data-fsz-swipe' );
			}
		}, 1500 );
	}
	if ( document.prerendering ) {
		document.addEventListener( 'prerenderingchange', start, { once: true } );
	} else {
		start();
	}
} )();
