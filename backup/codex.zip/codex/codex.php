<?php
/**
 * Plugin Name: Codex
 * Description: Handheld-scanner style species card on live animal product pages. Fill in the data on the product edit page or by CSV import; the look is set in one place, in the settings.
 * Version: 1.67.2
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Dan
 * Text Domain: codex
 * Domain Path: /languages
 * WC requires at least: 7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'FSZ_VERSION', '1.67.2' );

// 1.66.0: updates from the shop's GitHub repository (Settings → Ízeltláb updates), shared with the theme and Bolt.
require_once __DIR__ . '/updater.php';
IZL_Updater::add( 'codex', 'plugin', plugin_basename( __FILE__ ), 'Codex', FSZ_VERSION );
define( 'FSZ_FUN_MAX', 35 ); // fun fact: two lines in the bubble next to the Description button
define( 'FSZ_STORY_WORDS', 60 ); // the detail page text: about this many words fit above the four tiles (a guide, not a limit)
define( 'FSZ_URL', plugin_dir_url( __FILE__ ) );
define( 'FSZ_DIR', plugin_dir_path( __FILE__ ) );
define( 'FSZ_OPT', 'fsz_settings' );

add_action( 'init', function () {
	load_plugin_textdomain( 'codex', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}, 1 );

/* ------------------------------------------------------------------ settings */

function fsz_defaults() {
	return array(
		'categories'   => 'live-animals, isopods, springtails',
		'bars'         => "Size\nCourage\nAppetite\nbreeding | Fertility",
		'show_photo'   => '1',
		'device'       => '#1F8A8A',
		'screen'       => '#C9DBA5',
		'ink'          => '#2F3B1E',
		'filter'       => '1',
		'hide_wc'      => '0',
		'tilt'         => '10',
		'float'        => '8', // levitation strength, 0-20 (0 = still)
		'turn'         => '6', // resting angle: turned to the right, degrees (-15 to 15)
		'lean'         => '5', // resting angle: tipped down, degrees (-15 to 15)
		'skin'         => 'default', // 1.62.0: the card's look, see fsz_skins()
	);
}

/**
 * 1.62.0 skins: one look for every card, chosen in the settings (Look > Skin). A skin is one stylesheet that loads after
 * codex.css and only restyles the card (colours, fonts, borders, radii, shadows, effects), never moves anything; the
 * rules and the knobs it can set are at the top of assets/codex.css. 'file' is relative to the plugin folder; another
 * plugin or the theme can add its own skin with the fsz_skins filter and an absolute 'url' instead of 'file'.
 */
function fsz_skins() {
	$skins = array(
		'default' => array( 'label' => 'Default', 'file' => '' ),
		'swiss'   => array( 'label' => 'Swiss (test skin)', 'file' => 'assets/skins/swiss.css' ),
	);
	return (array) apply_filters( 'fsz_skins', $skins );
}

// The chosen skin's slug, 'default' when none or when the saved one is gone.
function fsz_skin() {
	$slug  = (string) fsz_opt( 'skin' );
	$skins = fsz_skins();
	return isset( $skins[ $slug ] ) ? $slug : 'default';
}

// Loads one skin's stylesheet (with its Dark Reader copy) after the card's.
function fsz_skin_style( $slug ) {
	$skins = fsz_skins();
	if ( 'default' === $slug || empty( $skins[ $slug ] ) ) {
		return;
	}
	$sk = $skins[ $slug ];
	if ( ! empty( $sk['file'] ) && is_readable( FSZ_DIR . $sk['file'] ) ) {
		fsz_style( 'codex-skin-' . $slug, $sk['file'], array( 'codex' ) );
	} elseif ( ! empty( $sk['url'] ) ) {
		wp_enqueue_style( 'codex-skin-' . $slug, $sk['url'], array( 'codex' ), FSZ_VERSION );
	}
}

/**
 * Default power bar and detail page labels, translatable. A label typed in the settings
 * that matches one of these is shown in the site language on the card.
 */
function fsz_default_labels() {
	return array(
		'Breeding'        => __( 'Breeding', 'codex' ),
		'Size'            => __( 'Size', 'codex' ),
		'Humidity'        => __( 'Humidity', 'codex' ),
		'Activity'        => __( 'Activity', 'codex' ),
		'Appetite'        => __( 'Appetite', 'codex' ),
		'Courage'         => __( 'Courage', 'codex' ),
		'Fertility'       => __( 'Fertility', 'codex' ),
		'Origin'          => __( 'Origin', 'codex' ),
		'Housing'         => __( 'Housing', 'codex' ),
		'Feeding'         => __( 'Feeding', 'codex' ),
		'Good to know'    => __( 'Good to know', 'codex' ),
	);
}

function fsz_label( $label ) {
	$t = fsz_default_labels();
	return isset( $t[ $label ] ) ? $t[ $label ] : $label;
}

// A list key from a label: "Good to know" -> good_to_know.
function fsz_key( $label ) {
	return str_replace( '-', '_', sanitize_title( $label ) );
}

/* ------------------------------------------------------------------ upgrades */

add_action( 'init', function () {
	if ( FSZ_VERSION === get_option( 'fsz_version' ) ) {
		return;
	}
	$version = (string) get_option( 'fsz_version', '' );
	// A new install: the known groups start with their colour (after WooCommerce has registered the categories).
	// 1.48.0: the steps for updates from before 1.40.0 are gone; every install is past them.
	if ( '' === $version ) {
		add_action( 'init', function () {
			fsz_seed_group_colors();
		}, 20 );
	}
	// 1.51.0: the detail page sections become one text; each product's sections are put into it once.
	if ( '' !== $version && version_compare( $version, '1.51.0', '<' ) ) {
		fsz_merge_sections();
	}
	// 1.48.0: the star colour and the facts list are no longer settings.
	$saved = get_option( FSZ_OPT );
	if ( is_array( $saved ) && ( isset( $saved['star'] ) || isset( $saved['facts'] ) ) ) {
		unset( $saved['star'], $saved['facts'] );
		update_option( FSZ_OPT, $saved );
	}
	update_option( 'fsz_version', FSZ_VERSION );
}, 5 );

/**
 * 1.51.0: the old detail sections (Origin, Housing ...) of each product go into its one text, as "Heading: text" lines in
 * the old order, headings in the shop language. Only where that text is still empty. The old values stay saved, so
 * they can be checked and then deleted under Clean up old data.
 */
function fsz_merge_sections() {
	global $wpdb;
	$saved = get_option( FSZ_OPT );
	$list  = is_array( $saved ) && isset( $saved['more'] ) ? $saved['more'] : "Origin\nHousing\nFeeding\nBreeding\nGood to know";
	$rows  = fsz_list_rows( $list );
	// Headings in the shop language, also when an admin with another language runs the update.
	$mo   = new MO();
	$file = FSZ_DIR . 'languages/codex-' . get_locale() . '.mo';
	$mo   = is_readable( $file ) && $mo->import_from_file( $file ) ? $mo : null;
	$ids  = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key LIKE %s AND meta_value <> ''", $wpdb->esc_like( '_fsz_more_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	foreach ( $ids as $id ) {
		if ( '' !== trim( (string) get_post_meta( $id, '_fsz_story', true ) ) ) {
			continue;
		}
		$keys  = array_keys( $rows );
		$lines = array();
		foreach ( get_post_meta( $id ) as $k => $v ) {
			if ( 0 === strpos( $k, '_fsz_more_' ) && ! in_array( substr( $k, 10 ), $keys, true ) ) {
				$keys[] = substr( $k, 10 ); // a section no longer in the list: last
			}
		}
		foreach ( $keys as $key ) {
			$text = trim( (string) get_post_meta( $id, '_fsz_more_' . $key, true ) );
			if ( '' === $text ) {
				continue;
			}
			$label   = isset( $rows[ $key ] ) ? $rows[ $key ] : fsz_key_label( $key );
			$label   = $mo ? $mo->translate( $label ) : $label;
			$lines[] = $label . ': ' . $text;
		}
		if ( $lines ) {
			update_post_meta( $id, '_fsz_story', implode( "\n", $lines ) );
		}
	}
	if ( is_array( $saved ) && isset( $saved['more'] ) ) {
		unset( $saved['more'] );
		update_option( FSZ_OPT, $saved );
	}
}

function fsz_opt( $key = null ) {
	$opts = wp_parse_args( (array) get_option( FSZ_OPT, array() ), fsz_defaults() );
	return null === $key ? $opts : ( isset( $opts[ $key ] ) ? $opts[ $key ] : '' );
}

/**
 * Rows of a "one per line" list as [key, label], labels as typed. A line is either "Label" or "key | Label".
 * The key stays stable when you reorder or rename lines, so saved values never move to another bar.
 */
function fsz_list_rows( $text ) {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		if ( false !== strpos( $line, '|' ) ) {
			list( $key, $label ) = array_map( 'trim', explode( '|', $line, 2 ) );
		} else {
			$key   = $line;
			$label = $line;
		}
		$key = fsz_key( $key );
		if ( '' !== $key && '' !== $label ) {
			$out[ $key ] = $label;
		}
	}
	return $out;
}

// The list with its labels in the site language (default labels are translated).
function fsz_parse_list( $text ) {
	return array_map( 'fsz_label', fsz_list_rows( $text ) );
}

function fsz_bars() {
	return fsz_parse_list( fsz_opt( 'bars' ) );
}

/**
 * The four standard power bars: default label, and the keys or labels (English or Hungarian,
 * as a key) that count as the same bar. Used for the bar icons and the 1.40.0 upgrade.
 */
function fsz_bar_kinds() {
	return array(
		'size'     => array( 'Size', array( 'size', 'meret', 'termet' ) ),
		'courage'  => array( 'Courage', array( 'courage', 'batorsag' ) ),
		'appetite' => array( 'Appetite', array( 'appetite', 'etvagy', 'falanksag' ) ),
		'breeding' => array( 'Fertility', array( 'breeding', 'fertility', 'breeding_rate', 'szaporodas', 'szaporasag' ) ),
	);
}

// Which standard bar a list row is, from its key or its label; '' for a bar you added yourself.
function fsz_bar_kind( $key, $label = '' ) {
	foreach ( fsz_bar_kinds() as $kind => $def ) {
		if ( in_array( $key, $def[1], true ) || ( '' !== $label && in_array( fsz_key( $label ), $def[1], true ) ) ) {
			return $kind;
		}
	}
	return '';
}

// The small icon in front of a standard bar's name (16 px grid; .fsz-kf / .fsz-ks are cut-outs in the tile colour).
function fsz_bar_icon( $kind ) {
	$icons = array(
		'size'     => '<path d="M8 13V3.2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M4 7 8 3l4 4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 15h10" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
		'courage'  => '<path d="M8 .8 14.4 3v4.2c0 4-2.8 6.8-6.4 8-3.6-1.2-6.4-4-6.4-8V3z" fill="currentColor"/><path d="M8 3 9.1 4.4V9.6H6.9V4.4z" class="fsz-kf"/><path d="M5 10h6M8 10v2.6" class="fsz-ks" stroke-width="1.4" stroke-linecap="round"/>',
		'appetite' => '<path d="M2.5 13.5C2.5 6 6.5 2 14 2 14 9.5 10 13.5 2.5 13.5Z" fill="currentColor"/><path d="M1.2 14.8 3.6 12.4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><circle cx="12.1" cy="9.3" r="2.2" class="fsz-kf"/><circle cx="8.9" cy="12.3" r="1.9" class="fsz-kf"/><path d="M3.6 12.4 12.6 3.4" class="fsz-ks" stroke-width="1" stroke-linecap="round"/>',
		'breeding' => '<text x="8" y="12.6" text-anchor="middle" font-size="11.5" fill="currentColor">×2</text>',
	);
	return isset( $icons[ $kind ] ) ? '<span class="fsz-bar-ic" aria-hidden="true"><svg viewBox="0 0 16 16" focusable="false">' . $icons[ $kind ] . '</svg></span>' : '';
}

/**
 * 1.51.0: the four tiles under the detail page text, key => array( label, icon ). Short free text each ("70-80%", "5 cm").
 * The icons are drawn like the power bar icons.
 */
function fsz_stats() {
	return array(
		'humidity'  => array( _x( 'Humidity', 'detail page tile', 'codex' ), '<path d="M8 1.2C8 1.2 3 7 3 10.2a5 5 0 0 0 10 0C13 7 8 1.2 8 1.2Z" fill="currentColor"/><path d="M5.6 10.3a2.4 2.4 0 0 0 2.1 2.3" class="fsz-ks" stroke-width="1.3" stroke-linecap="round"/>' ),
		'substrate' => array( _x( 'Substrate depth', 'detail page tile', 'codex' ), '<path d="M8 5.2V2.6M8 3.4C6.9 1.9 5.5 2 5.2 2.4M8 3.4c1.1-1.5 2.5-1.4 2.8-1" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/><rect x="1.5" y="5.4" width="13" height="2.8" rx="1" fill="currentColor"/><rect x="1.5" y="9" width="13" height="2.6" rx="1" fill="currentColor" opacity=".7"/><rect x="1.5" y="12.4" width="13" height="2.4" rx="1" fill="currentColor" opacity=".45"/>' ),
		'protein'   => array( _x( 'Protein', 'detail page tile', 'codex' ), '<path d="M1.2 8c2.1-3.5 6.8-4.5 10.4 0-3.6 4.5-8.3 3.5-10.4 0Z" fill="currentColor"/><path d="M11.4 8 15 5v6Z" fill="currentColor"/><circle cx="4.5" cy="7.3" r="1" class="fsz-kf"/>' ),
		'offspring' => array( _x( 'Offspring', 'detail page tile', 'codex' ), '<ellipse cx="5.8" cy="8.4" rx="4.6" ry="3.3" fill="currentColor"/><path d="M4 5.4v6M6.5 5.2v6.4" class="fsz-ks" stroke-width="1" stroke-linecap="round"/><circle cx="12.6" cy="5.6" r="1.8" fill="currentColor"/><circle cx="13" cy="10.9" r="1.5" fill="currentColor"/>' ),
	);
}

// Words in a text, as the edit counter counts them.
function fsz_word_count( $text ) {
	return count( preg_split( '/\s+/u', trim( (string) $text ), -1, PREG_SPLIT_NO_EMPTY ) );
}

/* ------------------------------------------------------------------ which products */

function fsz_category_ids() {
	$ids = array();
	foreach ( array_filter( array_map( 'trim', explode( ',', fsz_opt( 'categories' ) ) ) ) as $slug ) {
		$term = get_term_by( 'slug', sanitize_title( $slug ), 'product_cat' );
		if ( $term && ! is_wp_error( $term ) && fsz_is_setup_term( $term ) ) {
			$ids[]    = (int) $term->term_id;
			$children = get_term_children( $term->term_id, 'product_cat' );
			if ( ! is_wp_error( $children ) ) {
				$ids = array_merge( $ids, array_map( 'intval', $children ) );
			}
		}
	}
	return array_unique( $ids );
}

function fsz_is_live( $product_id ) {
	if ( 'yes' === get_post_meta( $product_id, '_fsz_hide', true ) ) {
		return false;
	}
	$ids = fsz_category_ids();
	return $ids && has_term( $ids, 'product_cat', $product_id );
}

/* ------------------------------------------------------------------ front end */

/**
 * Keep the card's own colours under dark mode extensions such as Dark Reader, while the rest of the site goes dark.
 * Dark Reader rewrites the colours of every stylesheet rule it can read, but skips rules inside @scope.
 * So the same CSS is added once more inside @scope: same selectors, and a scoped rule wins over the rewritten copy.
 * Without an extension both copies say the same; browsers without @scope simply ignore the copy.
 */
/**
 * 1.48.0: shoppers get the built copies in assets/min (tools/build-css.py): the stylesheet without comments and line
 * breaks, and its Dark Reader copy inside @scope as a file of its own that the browser caches (it was printed inline on
 * every page). A built copy is used only while it matches its source (assets/min/build.json holds each source's md5), so
 * an edit to a source shows at once: the source with the inline copy takes over until the build runs again.
 */
function fsz_built( $file ) {
	static $map = null;
	if ( null === $map ) {
		$json = is_readable( FSZ_DIR . 'assets/min/build.json' ) ? (string) file_get_contents( FSZ_DIR . 'assets/min/build.json' ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$map  = $json ? (array) json_decode( $json, true ) : array();
	}
	if ( ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) || empty( $map[ $file ] ) || md5_file( FSZ_DIR . $file ) !== $map[ $file ] ) {
		return '';
	}
	return 'assets/min/' . basename( $file, '.css' );
}

// A Codex stylesheet with its Dark Reader copy: the built files when they are current, else the source + inline copy.
function fsz_style( $handle, $file, $deps = array() ) {
	$min = fsz_built( $file );
	if ( $min ) {
		wp_enqueue_style( $handle, FSZ_URL . $min . '.min.css', $deps, FSZ_VERSION );
		wp_enqueue_style( $handle . '-scope', FSZ_URL . $min . '.scope.min.css', array( $handle ), FSZ_VERSION );
		return;
	}
	wp_enqueue_style( $handle, FSZ_URL . $file, $deps, FSZ_VERSION );
	fsz_keep_colours( $handle, $file );
}

function fsz_keep_colours( $handle, $file ) {
	$css = (string) file_get_contents( FSZ_DIR . $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	if ( '' !== $css ) {
		wp_add_inline_style( $handle, '@scope (:root){' . $css . '}' );
	}
}

add_action( 'wp_enqueue_scripts', function () {
	if ( ! function_exists( 'is_product' ) ) {
		return;
	}
	// 1.65.0: only where a card shows: a product page with a card. The shop and category pages load it only for the
	// difficulty dropdown of other themes (the Ízeltláb theme draws its own tiles and pills there; filter
	// fsz_assets_on_lists). The [codex] shortcode loads it wherever it is used. Before, every shop page and every
	// supplies page carried the card's 120 KB of styles and its script without showing a card.
	if ( is_product() ? fsz_is_live( get_queried_object_id() ) : ( ( is_shop() || is_product_taxonomy() ) && apply_filters( 'fsz_assets_on_lists', ! function_exists( 'izl_has_codex' ) ) ) ) {
		fsz_enqueue_front();
	}
} );

function fsz_enqueue_front() {
	fsz_style( 'codex', 'assets/codex.css' );
	fsz_skin_style( fsz_skin() );
	wp_enqueue_style( 'codex-font', FSZ_URL . 'assets/fonts/ibm-plex-mono/font.css', array(), FSZ_VERSION ); // IBM Plex Mono, bundled (no Google Fonts)
	wp_enqueue_script( 'codex', FSZ_URL . 'assets/codex.js', array(), FSZ_VERSION, true );

	// Quick edit: only for people who may edit this product.
	if ( function_exists( 'is_product' ) && is_product() ) {
		$id = get_queried_object_id();
		if ( fsz_is_live( $id ) && fsz_can_quick_edit( $id ) ) {
			wp_enqueue_media( array( 'post' => $id ) );
			fsz_style( 'codex-edit', 'assets/codex-edit.css', array( 'codex' ) );
			wp_enqueue_script( 'codex-edit', FSZ_URL . 'assets/codex-edit.js', array( 'codex' ), FSZ_VERSION, true );
			wp_localize_script(
				'codex-edit',
				'CodexEdit',
				array(
					'ajax'         => admin_url( 'admin-ajax.php' ),
					'nonce'        => wp_create_nonce( 'fsz_quick_edit' ),
					'defaultColor' => fsz_group_color( $id ),
					'screen'       => fsz_opt( 'screen' ),
					'screenLight'  => FSZ_SCREEN_LIGHT,
					'ink'          => fsz_opt( 'ink' ),
					'editUrl'      => admin_url( 'post.php?post=' . (int) $id . '&action=edit' ),
				)
			);
		}
	}
}

function fsz_can_quick_edit( $product_id ) {
	return is_user_logged_in() && current_user_can( 'edit_post', $product_id );
}

/**
 * Colour themes: the chosen colour is the device, the screen frame is the same colour, darker.
 */
function fsz_themes() {
	return array(
		'#1F8A8A' => 'Teal',
		'#2F6DB5' => 'Blue',
		'#6E4BA8' => 'Purple',
		'#B8487E' => 'Pink',
		'#B83A3A' => 'Red',
		'#C8692A' => 'Orange',
		'#B8902A' => 'Amber',
		'#3B8A3F' => 'Green',
		'#5A6068' => 'Graphite',
	);
}

function fsz_theme_dark( $hex ) {
	$hex = ltrim( (string) sanitize_hex_color( $hex ), '#' );
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	if ( 6 !== strlen( $hex ) ) {
		return '';
	}
	$out = '#';
	foreach ( str_split( $hex, 2 ) as $c ) {
		$out .= sprintf( '%02X', (int) round( hexdec( $c ) * 0.7 ) ); // same as codex-edit.js dark()
	}
	return $out;
}

/**
 * The screen colours in a theme: the hue of the theme colour, the lightness of the settings colour
 * (so text and screen keep the same contrast), and never more saturated than either.
 * Same as tint() in codex-edit.js.
 */
function fsz_theme_tint( $base, $theme, $min_light = 0 ) {
	$b = fsz_hex_hsl( $base );
	$t = fsz_hex_hsl( $theme );
	if ( ! $b || ! $t ) {
		return $base;
	}
	return fsz_hsl_hex( $t[0], min( $b[1], $t[1] ), max( $b[2], $min_light ) );
}

// The screen is at least this light (0-1), whatever the theme.
define( 'FSZ_SCREEN_LIGHT', 0.88 );

function fsz_hex_hsl( $hex ) {
	$hex = ltrim( (string) sanitize_hex_color( $hex ), '#' );
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	if ( 6 !== strlen( $hex ) ) {
		return null;
	}
	list( $r, $g, $b ) = array_map( function ( $c ) {
		return hexdec( $c ) / 255;
	}, str_split( $hex, 2 ) );
	$max = max( $r, $g, $b );
	$min = min( $r, $g, $b );
	$l   = ( $max + $min ) / 2;
	$d   = $max - $min;
	if ( 0.0 === (float) $d ) {
		return array( 0, 0, $l );
	}
	$s = $d / ( 1 - abs( 2 * $l - 1 ) );
	if ( $max === $r ) {
		$h = fmod( ( $g - $b ) / $d + 6, 6 );
	} elseif ( $max === $g ) {
		$h = ( $b - $r ) / $d + 2;
	} else {
		$h = ( $r - $g ) / $d + 4;
	}
	return array( $h * 60, $s, $l );
}

function fsz_hsl_hex( $h, $s, $l ) {
	$c   = ( 1 - abs( 2 * $l - 1 ) ) * $s;
	$x   = $c * ( 1 - abs( fmod( $h / 60, 2 ) - 1 ) );
	$m   = $l - $c / 2;
	$rgb = array( array( $c, $x, 0 ), array( $x, $c, 0 ), array( 0, $c, $x ), array( 0, $x, $c ), array( $x, 0, $c ), array( $c, 0, $x ) );
	$out = '#';
	foreach ( $rgb[ (int) floor( $h / 60 ) % 6 ] as $v ) {
		$out .= sprintf( '%02X', (int) round( ( $v + $m ) * 255 ) );
	}
	return $out;
}

/**
 * The Codex number: the product's place among the published Codex products, oldest first (#001, #002 …).
 * A product that is not published yet gets the next free number.
 */
function fsz_codex_number( $product_id ) {
	$list = get_transient( 'fsz_numbers' );
	if ( ! is_array( $list ) ) {
		$list = array();
		$ids  = fsz_category_ids();
		if ( $ids ) {
			$posts = get_posts(
				array(
					'post_type'      => 'product',
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'fields'         => 'ids',
					'orderby'        => array( 'date' => 'ASC', 'ID' => 'ASC' ),
					'no_found_rows'  => true,
					'tax_query'      => array( array( 'taxonomy' => 'product_cat', 'terms' => $ids ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
					'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
						'relation' => 'OR',
						array( 'key' => '_fsz_hide', 'compare' => 'NOT EXISTS' ),
						array( 'key' => '_fsz_hide', 'value' => 'yes', 'compare' => '!=' ),
					),
				)
			);
			foreach ( $posts as $i => $id ) {
				$list[ (int) $id ] = $i + 1;
			}
		}
		set_transient( 'fsz_numbers', $list, DAY_IN_SECONDS );
	}
	$n = isset( $list[ (int) $product_id ] ) ? $list[ (int) $product_id ] : count( $list ) + 1;
	return '#' . str_pad( (string) $n, 3, '0', STR_PAD_LEFT );
}

// New, deleted, moved or hidden products renumber the others.
function fsz_forget_numbers() {
	delete_transient( 'fsz_numbers' );
}
add_action( 'save_post_product', 'fsz_forget_numbers' );
add_action( 'deleted_post', 'fsz_forget_numbers' );
add_action( 'trashed_post', 'fsz_forget_numbers' );
add_action( 'untrashed_post', 'fsz_forget_numbers' );
add_action( 'transition_post_status', 'fsz_forget_numbers' );
add_action( 'set_object_terms', 'fsz_forget_numbers' );
add_action( 'update_option_' . FSZ_OPT, 'fsz_forget_numbers' );

// A name without the quotes around it: „Boci” -> Boci.
function fsz_unquote( $text ) {
	return trim( preg_replace( '/^["\'„“”‚‘’«»]+|["\'„“”‚‘’«»]+$/u', '', trim( (string) $text ) ) );
}

// "Latin – „Nickname”" → latin + nickname (any dash, a space on at least one side, plain or no-break spaces).
function fsz_split_name( $name ) {
	if ( preg_match( '/^(.+?)(?:[\s\x{00A0}]+[–—-][\s\x{00A0}]*|[\s\x{00A0}]*[–—-][\s\x{00A0}]+)(.+)$/u', $name, $m ) ) {
		return array(
			'latin' => trim( $m[1] ),
			'nick'  => fsz_unquote( $m[2] ),
		);
	}
	return array(
		'latin' => '',
		'nick'  => $name,
	);
}

/**
 * The names on the card: the nickname (big, in the name bar), the English name (the strip under it) and the Latin name
 * (on the detail page). An empty nickname or Latin name comes from the product name when it reads "Latin – „Nickname”";
 * otherwise the nickname is the whole product name. The from_title values are what an empty field falls back to.
 */
function fsz_names( $product_id ) {
	$meta = function ( $key ) use ( $product_id ) {
		return trim( (string) get_post_meta( $product_id, '_fsz_' . $key, true ) );
	};
	// The title comes texturized (&#8211; and the like); decode it to read the dash and the quotes.
	$title = html_entity_decode( get_the_title( $product_id ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	$from  = fsz_split_name( $title );
	$nick  = $meta( 'name' );
	$latin = $meta( 'latin' );
	// 1.38.1: a nickname still holding the whole old card name ("Latin – „Nickname”") shows only the nickname.
	$own = fsz_split_name( $nick );
	if ( '' !== $own['latin'] ) {
		$nick  = $own['nick'];
		$latin = '' !== $latin ? $latin : $own['latin'];
	}
	return array(
		'nick'       => '' !== $nick ? $nick : $from['nick'],
		'english'    => fsz_unquote( $meta( 'trade' ) ),
		'latin'      => '' !== $latin ? $latin : $from['latin'],
		'from_title' => $from,
	);
}

function fsz_tags( $product_id ) {
	return array_values( array_filter( array_map( 'trim', explode( ',', (string) get_post_meta( $product_id, '_fsz_tags', true ) ) ) ) );
}

// The stickers for the photo's corner (meta _fsz_badge holds the key), in the site language.
function fsz_badges() {
	return array(
		'new'  => __( 'NEW!', 'codex' ),
		'sale' => __( 'SALE!', 'codex' ),
		'rare' => __( 'RARE!', 'codex' ),
	);
}

// The sticker the card shows: the one picked for the product, else the sale one while the product has a sale price.
function fsz_badge( $product_id ) {
	$own = (string) get_post_meta( $product_id, '_fsz_badge', true );
	if ( isset( fsz_badges()[ $own ] ) ) {
		return $own;
	}
	$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;
	return $product && $product->is_on_sale() ? 'sale' : '';
}

/* ------------------------------------------------------------------ trait badges */

/**
 * The trait badges (meta _fsz_traits = comma list of keys): small animated badges over the power bar names on the card,
 * and on the detail page each one again with its sentence. Always in this order: cleanup crew, rolls into a ball, feeder.
 */
function fsz_traits() {
	return array(
		'cleanup' => array(
			'label' => __( 'Cleanup crew', 'codex' ),
			'why'   => __( 'A true cleaning expert: recommended for bioactive terrariums, for example alongside reptiles and amphibians!', 'codex' ),
		),
		'ball'    => array(
			'label' => __( 'Rolls into a ball', 'codex' ),
			'why'   => __( 'When in danger it curls up; that is how it defends itself against predators.', 'codex' ),
		),
		'feeder'  => array(
			'label' => __( 'Feeder', 'codex' ),
			'why'   => __( 'A real treat for reptiles, amphibians and spiders!', 'codex' ),
		),
	);
}

// The product's trait keys, in the badges' fixed order. Takes a saved value (comma list) or reads the product.
function fsz_trait_keys( $product_id, $raw = null ) {
	$raw  = null === $raw ? (string) get_post_meta( $product_id, '_fsz_traits', true ) : (string) $raw;
	$have = array_map( 'sanitize_key', array_map( 'trim', explode( ',', $raw ) ) );
	return array_values( array_intersect( array_keys( fsz_traits() ), $have ) );
}

/**
 * One trait badge as plain SVG (no filters, so animating it costs next to nothing): a shape with a thickness edge and
 * a soft shadow, a gradient face, a white icon with a thin dark outline (a wider dark copy under it), and a shine that
 * codex.css sweeps across from the top left. viewBox 40×42; the antennae of the ball badge reach past the coin.
 */
function fsz_trait_svg( $key ) {
	static $n = 0;
	$id     = 'fszt' . ( ++$n );
	$looks  = array(
		'cleanup' => array( 'diamond', '#5cbf55', '#2a7a2f', '#a6e89a', 1.08, 1.3, -0.9 ),
		'ball'    => array( 'coin', '#5a85f2', '#2a4bb0', '#a9c0ff', 1.15, 0, 0 ),
		'feeder'  => array( 'square', '#ee7d3e', '#a6461a', '#ffbc8f', 1.02, 0, 0 ),
	);
	$shapes = array(
		'coin'    => '<circle cx="20" cy="19" r="17.5"/>',
		'square'  => '<rect x="2.5" y="1.5" width="35" height="35" rx="8"/>',
		'diamond' => '<path d="M20 .6Q21.2 .6 22.2 1.6L37.4 16.8Q39.6 19 37.4 21.2L22.2 36.4Q20 38.6 17.8 36.4L2.6 21.2Q.4 19 2.6 16.8L17.8 1.6Q18.8 .6 20 .6Z"/>',
	);
	list( $shape, $c, $d, $l, $sc, $dx, $dy ) = $looks[ $key ];
	$s   = $shapes[ $shape ];
	$ink = 'color-mix(in srgb,' . $d . ' 75%,#000)';
	$ol  = round( 0.75 / $sc, 3 );
	// $top: the white icon; otherwise the outline pass (dark, every part a little wider).
	$icon = function ( $top ) use ( $key, $d, $ink, $ol ) {
		$w    = $top ? '#fff' : $ink;
		$o    = $top ? 0 : $ol;
		$fill = function ( $path ) use ( $w, $o ) {
			return '<path d="' . $path . '" fill="' . $w . '"' . ( $o ? ' stroke="' . $w . '" stroke-width="' . ( 2 * $o ) . '" stroke-linejoin="round"' : '' ) . '/>';
		};
		$line = function ( $path, $width ) use ( $w, $o ) {
			return '<path d="' . $path . '" fill="none" stroke="' . $w . '" stroke-width="' . ( $width + 2 * $o ) . '" stroke-linecap="round" stroke-linejoin="round"/>';
		};
		$detail = function ( $path, $width ) use ( $top, $d ) {
			return $top ? '<path d="' . $path . '" fill="none" stroke="' . $d . '" stroke-width="' . $width . '" stroke-linecap="round"/>' : '';
		};
		$disc = function ( $cx, $cy, $r ) use ( $w, $o ) {
			return '<circle cx="' . $cx . '" cy="' . $cy . '" r="' . ( $r + $o ) . '" fill="' . $w . '"/>';
		};
		if ( 'cleanup' === $key ) {
			return '<g class="fsz-t-sweep">' . $line( 'M20.8 2.2 13.4 13', 3.6 ) . $fill( 'M8.6 10.6 16.8 16.4 13.8 23C10.4 23.4 4.6 19.6 2 16.2z' ) . $detail( 'M6.6 18 9.4 14.4M10.2 20.6 13 16.9', 1.7 ) . '</g>'
				. ( $top ? '<g class="fsz-t-dust" fill="#fff"><circle cx="3" cy="22" r="1.3"/><circle cx="6" cy="23.6" r="1"/><circle cx="1" cy="19.6" r=".9"/></g>' : '' );
		}
		if ( 'ball' === $key ) {
			return $disc( 12, 12, 10.2 ) . $detail( 'M5.6 5.4Q9.2 12 5.6 18.6M9.2 2.6Q12.8 12 9.2 21.4M13 2Q16.6 12 13 22M16.8 3.2Q20.2 12 16.8 20.8', 1.5 );
		}
		return $disc( 12, 12.4, 7.6 ) . ( $top ? '<circle cx="12" cy="12.4" r="4.6" fill="none" stroke="' . $d . '" stroke-width="1.3"/>' : '' )
			. '<g class="fsz-t-fork">' . $line( 'M1.4 2.4v4.2M-.4 2.4v3.8Q-.4 8 1.4 8Q3.2 8 3.2 5.6V2.4M1.4 8V22', 1.9 ) . '</g>'
			. '<g class="fsz-t-knife">' . $fill( 'M21.8 1.8C25 3 25.4 8.4 23.4 10.2V21.4Q23.4 22.4 22.5 22.4Q21.6 22.4 21.6 21.4Z' ) . '</g>';
	};
	$off = 12 * $sc;
	$art = '<g transform="translate(' . round( 20 - $off + $dx, 2 ) . ' ' . round( 19.2 - $off + $dy, 2 ) . ') scale(' . $sc . ')">' . $icon( false ) . $icon( true ) . '</g>';
	if ( 'ball' === $key ) {
		$ant = 'M29.2 12.6Q34.4 7.4 41.2 6.6M30.4 15.6Q37.2 13.2 42.6 15.4';
		$art = '<g class="fsz-t-spin">' . $art . '<path d="' . $ant . '" fill="none" stroke="' . $ink . '" stroke-width="3.4" stroke-linecap="round"/><path d="' . $ant . '" fill="none" stroke="#fff" stroke-width="1.9" stroke-linecap="round"/></g>';
	}
	return '<svg class="fsz-tsvg" viewBox="0 0 40 42" aria-hidden="true" focusable="false"><defs>'
		. '<radialGradient id="' . $id . 'g" cx="34%" cy="26%" r="80%"><stop offset="0" stop-color="' . $l . '"/><stop offset=".48" stop-color="' . $c . '"/><stop offset="1" stop-color="' . $d . '"/></radialGradient>'
		. '<linearGradient id="' . $id . 's" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".7"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>'
		. '<clipPath id="' . $id . 'c">' . $s . '</clipPath></defs>'
		. '<g transform="translate(0 4)" fill="#000" opacity=".18">' . $s . '</g>'
		. '<g transform="translate(0 2.6)" fill="' . $d . '" stroke="' . $d . '">' . $s . '</g>'
		. '<g fill="url(#' . $id . 'g)" stroke="' . $ink . '" stroke-width="1.7">' . $s . '</g>'
		. '<g fill="none" stroke="#fff" stroke-opacity=".33" stroke-width="1.1" transform="translate(20 19) scale(.86) translate(-20 -19)">' . $s . '</g>'
		. $art
		. '<g clip-path="url(#' . $id . 'c)"><g transform="rotate(45)"><rect class="fsz-t-shine" x="-14" y="-45" width="9" height="90" fill="url(#' . $id . 's)"/></g></g></svg>';
}

/**
 * The badges' box over the power bar names. In edit mode all three are there (the ones not picked hidden) and the box
 * opens the picker; with none picked it reads "+ Badges".
 */
/**
 * The animal pressed into an empty badge box, picked from the product's group (the top category the card's top right
 * shows): Isopoda = isopod, Blattodea = roach, Collembola = springtail, Arachnida = spider. Matched on the category
 * name or slug, Latin, English or Hungarian; another group gets no animal. Filter: fsz_stamp_kind.
 */
function fsz_stamp_kind( $product_id ) {
	$term = fsz_group_term( $product_id );
	return (string) apply_filters( 'fsz_stamp_kind', $term ? fsz_term_kind( $term ) : '', $product_id );
}

// Which set-up group a top category is (isopoda, blattodea, collembola, arachnida), by its name or slug; '' for any other.
function fsz_term_kind( $term ) {
	$kind = '';
	if ( $term ) {
		$text  = mb_strtolower( $term->name . ' ' . $term->slug );
		$kinds = array(
			'isopoda'    => array( 'isopod', 'ászk', 'aszk' ),
			'blattodea'  => array( 'blatt', 'roach', 'csótány', 'csotany' ),
			'collembola' => array( 'collemb', 'springtail', 'ugróvillás', 'ugrovillas' ),
			'arachnida'  => array( 'arachn', 'spider', 'tarantul', 'pók', 'madarpok' ),
		);
		foreach ( $kinds as $key => $words ) {
			foreach ( $words as $word ) {
				if ( false !== strpos( $text, $word ) ) {
					$kind = $key;
					break 2;
				}
			}
		}
	}
	return (string) apply_filters( 'fsz_group_kind', $kind, $term );
}

/**
 * 1.51.0: only the set-up groups (the four with an animal stamp) can show the card. A category of any other group
 * (supplies, a future group not set up yet) never does, even when it is ticked in the settings.
 */
function fsz_is_setup_term( $term ) {
	while ( $term && ! is_wp_error( $term ) && $term->parent ) {
		$term = get_term( $term->parent, 'product_cat' );
	}
	return $term && ! is_wp_error( $term ) && '' !== fsz_term_kind( $term );
}

/**
 * The stamp itself: a silhouette facing right (viewBox 64×26), legs and antennae as lines, and the body segments as
 * grooves; codex.css colours it so it looks pressed into the box.
 */
function fsz_stamp_svg( $kind ) {
	// Each: filled body parts, lines (legs, antennae), grooves (segments) and holes (eyes) cut in the box colour.
	$shapes = array(
		'isopoda' => array( '<path d="M5.6 13L9 10.8L8.48 9.01L11 9.8L10.48 8.01L13 8.8L12.48 7.01L15 7.8L13.7 4.17L19.75 4.38L18.7 3.22L24.75 4.09L23.7 2.92L29.75 4.05L28.7 2.88L34.75 4.09L33.7 2.92L39.75 4.38L38.7 3.22L44.75 5.33L43.7 4.17L45.3 4.68L48.11 4.97L50.07 5.8L51.59 7.12L52.7 8.84L53.37 10.85L53.6 13L53.37 15.15L52.7 17.16L51.59 18.88L50.07 20.2L48.11 21.03L45.3 21.32L43.7 21.83L44.75 20.67L38.7 22.78L39.75 21.62L33.7 23.08L34.75 21.91L28.7 23.12L29.75 21.95L23.7 23.08L24.75 21.91L18.7 22.78L19.75 21.62L13.7 21.83L15 18.2L12.48 18.99L13 17.2L10.48 17.99L11 16.2L8.48 16.99L9 15.2Z"/>', 'M52.6 10.6L56 9.4L57.4 6.4L60.2 3.5999999999999996M52.6 15.4L56 16.6L57.4 19.6L60.2 22.4M9.6 11L3.4 8.7M9.6 15L3.4 17.3', 'M20 5.23Q18.7 13 20 20.77M25 4.94Q23.7 13 25 21.06M30 4.9Q28.7 13 30 21.1M35 4.94Q33.7 13 35 21.06M40 5.23Q38.7 13 40 20.77M45 6.18Q43.7 13 45 19.82M15 8.2Q14 13 15 17.8', '<ellipse cx="50.4" cy="7.8" rx="1" ry=".8"/><ellipse cx="50.4" cy="18.2" rx="1" ry=".8"/>' ),
		'blattodea' => array( '<path d="M6 13C6 8 14 5.5 30 5.5C38 5.5 42 7 44 8.5L44 17.5C42 19 38 20.5 30 20.5C14 20.5 6 18 6 13Z"/><path d="M43 6.8C49.5 6 54.5 8.6 55 13C54.5 17.4 49.5 20 43 19.2Z"/><ellipse cx="57" cy="13" rx="2.4" ry="3"/>', 'M58.5 11.5Q63 7 62 2.5Q60 .5 52 1.5M58.5 14.5Q63 19 62 23.5Q60 25.5 52 24.5M40 7L43 3.2L48.5 2.4M41 4.6L42.4 4.2M30 6L29.5 2L24.5 .8M29.6 3.6L28.4 3M20 6.2L15 2.5L9.5 2.2M17 3.8L16 4.8M40 19L43 22.8L48.5 23.6M30 20L29.5 24L24.5 25.2M20 19.8L15 23.5L9.5 23.8M6.5 11.5L2 10M6.5 14.5L2 16', 'M8 13H43M43 8.4Q24 8.8 8.4 12.4M43 17.6Q24 17.2 8.4 13.6M46.5 9.5Q49 13 46.5 16.5', '' ),
		'collembola' => array( '<path d="M8 13L8.28 10.99L9.13 10.35L10.51 9.84L12.39 9.38L14.74 8.95L17.48 8.58L20.56 8.25L23.89 8.01L27.4 7.85L31 7.8L34.6 7.85L38.11 8.01L41.44 8.25L44.52 8.58L47.26 8.95L49.61 9.38L51.49 9.84L52.87 10.35L53.72 10.99L54 13L53.72 15.01L52.87 15.65L51.49 16.16L49.61 16.62L47.26 17.05L44.52 17.42L41.44 17.75L38.11 17.99L34.6 18.15L31 18.2L27.4 18.15L23.89 17.99L20.56 17.75L17.48 17.42L14.74 17.05L12.39 16.62L10.51 16.16L9.13 15.65L8.28 15.01L8 13Z"/>', 'M53.4 11.6L56.4 9.2L58.8 6L62.8 3.4M53.4 14.4L56.4 16.8L58.8 20L62.8 22.6M44 8.2L45.6 5.4L47.6 4.8M39.4 8L40 4.8M34.6 8L33.6 4.8M44 17.8L45.6 20.6L47.6 21.2M39.4 18L40 21.2M34.6 18L33.6 21.2', 'M44 9.17Q43.2 13 44 16.83M38 8.91Q37.2 13 38 17.09M33 8.81Q32.2 13 33 17.19M28 8.82Q27.2 13 28 17.18M23 8.94Q22.2 13 23 17.06M18 9.17Q17.2 13 18 16.83', '' ),
		'arachnida' => array( '<ellipse cx="21" cy="13" rx="8" ry="6.4"/><ellipse cx="32.6" cy="13" rx="4.2" ry="3.8"/><path d="M28.4 13L29.4 12V14Z"/>', 'M35 10.4L39.6 3.8L50.4 1.2M36.2 11.8L44.6 7.4L58.4 8.6M36.2 14.2L44.6 18.6L58.4 17.4M35 15.6L39.6 22.2L50.4 24.8M31 10L28.4 3L19.4 .4M30 10.8L24.6 6.2L12.4 5.6M31 16L28.4 23L19.4 25.6M30 15.2L24.6 19.8L12.4 20.4M36.6 12.4L39 12M36.6 13.6L39 14', 'M17 10.4Q21 13 17 15.6M21 9.6Q25 13 21 16.4M25 10.4Q27.4 13 25 15.6', '' ),
	);
	if ( ! isset( $shapes[ $kind ] ) ) {
		return '';
	}
	list( $fill, $lines, $grooves, $holes ) = $shapes[ $kind ];
	return '<span class="fsz-stamp is-' . $kind . '"><svg viewBox="-1 -1 66 28" aria-hidden="true" focusable="false">' . $fill . '<path class="fsz-stamp-l" d="' . $lines . '"/>' . ( $grooves ? '<path class="fsz-stamp-g" d="' . $grooves . '"/>' : '' ) . ( $holes ? '<g class="fsz-stamp-e">' . $holes . '</g>' : '' ) . '</svg></span>';
}

function fsz_traits_box( $keys, $edit, $stamp = '' ) {
	$out = '';
	foreach ( fsz_traits() as $key => $t ) {
		$on = in_array( $key, $keys, true );
		if ( ! $on && ! $edit ) {
			continue;
		}
		$out .= '<span class="fsz-trait is-' . $key . ( $on ? '' : ' is-off' ) . '" data-trait="' . $key . '">' . fsz_trait_svg( $key ) . '</span>';
	}
	if ( $edit ) {
		return '<span class="fsz-traits' . ( $keys ? '' : ' is-empty' ) . '" data-fsz-open="traits" title="Badges">' . $stamp . $out . '<span class="fsz-traits-add">+ Badges</span></span>';
	}
	if ( ! $keys ) {
		// No badges: the box stays, with only the group's animal pressed into it (with badges it sits behind them).
		return '<span class="fsz-traits is-stamp" aria-hidden="true">' . $stamp . '</span>';
	}
	$names = array();
	foreach ( $keys as $key ) {
		$names[] = fsz_traits()[ $key ]['label'];
	}
	return '<span class="fsz-traits" role="img" aria-label="' . esc_attr( implode( ', ', $names ) ) . '">' . $stamp . $out . '</span>';
}

/**
 * In stock: a product with packs (variations) counts as in stock while any of its packs is, read from the packs
 * themselves, so the light agrees with the buy box even when the product's own saved status is out of date.
 */
function fsz_in_stock( $product ) {
	if ( ! $product instanceof WC_Product ) {
		return true;
	}
	if ( $product->is_type( 'variable' ) && $product->get_children() ) {
		return $product->child_is_in_stock();
	}
	return $product->is_in_stock();
}

/**
 * Hungarian hyphenation for the fun fact: soft hyphens at the syllable breaks, so a long word can break at the end of
 * line 1 instead of leaving it half empty. Between two vowels the last consonant starts the next syllable (cs, dz, dzs,
 * gy, ly, ny, sz, ty, zs count as one); never inside a doubled one like ssz (that break would change the spelling), and
 * never one letter from either end of a word. Only for display: the saved text has no soft hyphens.
 */
/* ------------------------------------------------------------------ text formatting (1.52.0) */

/**
 * The colours a text can take, key => CSS class. Picked in the card editor; each is darkened in codex.css so it stays
 * readable on the screen. 'group' is a highlighter in the card's own deep colour (1.53.0).
 */
function fsz_mark_colors() {
	return array( 'blue', 'green', 'amber', 'red', 'group' );
}

/**
 * A formatted text as runs: array( array( text, bold, italic, underline, colour ) ). The marks: **bold**, [i]italic[/i],
 * [u]underline[/u], [red]colour[/red] (any key of fsz_mark_colors()). A mark left open ends with the text; a closing
 * mark with nothing open is dropped. Line breaks stay in the text.
 */
function fsz_mark_runs( $text ) {
	$colors = implode( '|', fsz_mark_colors() );
	$parts  = preg_split( '#(\*\*|\[/?(?:i|u|' . $colors . ')\])#', (string) $text, -1, PREG_SPLIT_DELIM_CAPTURE );
	$st     = array( 'b' => false, 'i' => false, 'u' => false, 'c' => '' );
	$runs   = array();
	foreach ( $parts as $k => $part ) {
		if ( 0 === $k % 2 ) {
			if ( '' !== $part ) {
				$runs[] = array( $part, $st['b'], $st['i'], $st['u'], $st['c'] );
			}
		} elseif ( '**' === $part ) {
			$st['b'] = ! $st['b'];
		} else {
			$close = '/' === $part[1];
			$tag   = trim( $part, '[]/' );
			if ( 'i' === $tag || 'u' === $tag ) {
				$st[ $tag ] = ! $close;
			} else {
				$st['c'] = $close ? ( $st['c'] === $tag ? '' : $st['c'] ) : $tag;
			}
		}
	}
	return $runs;
}

// The text without its marks: what the shopper reads (for counting and limits).
function fsz_plain( $text ) {
	return implode( '', array_column( fsz_mark_runs( $text ), 0 ) );
}

/**
 * Runs back to marks, with as few as needed (the colour outside, then bold, italic, underline), so the text reads
 * cleanly in the product box and in CSV. The card editor writes the same marks.
 */
function fsz_mark_text( $runs ) {
	$out  = '';
	$open = array( '', false, false, false ); // colour, b, i, u
	$tags = array( 1 => array( '**', '**' ), 2 => array( '[i]', '[/i]' ), 3 => array( '[u]', '[/u]' ) );
	foreach ( $runs as $r ) {
		$want = array( (string) $r[4], (bool) $r[1], (bool) $r[2], (bool) $r[3] );
		// Close from the inside out down to the first style that changes, then open what is wanted from there.
		for ( $lvl = 0; $lvl < 4 && $want[ $lvl ] === $open[ $lvl ]; $lvl++ ) {}
		for ( $j = 3; $j >= $lvl; $j-- ) {
			if ( $open[ $j ] ) {
				$out .= 0 === $j ? '[/' . $open[0] . ']' : $tags[ $j ][1];
			}
		}
		for ( $j = $lvl; $j < 4; $j++ ) {
			if ( $want[ $j ] ) {
				$out .= 0 === $j ? '[' . $want[0] . ']' : $tags[ $j ][0];
			}
		}
		$open = $want;
		$out .= $r[0];
	}
	for ( $j = 3; $j >= 0; $j-- ) {
		if ( $open[ $j ] ) {
			$out .= 0 === $j ? '[/' . $open[0] . ']' : $tags[ $j ][1];
		}
	}
	return $out;
}

// The first $max letters of a formatted text, its marks kept.
function fsz_mark_cut( $text, $max ) {
	$runs = array();
	foreach ( fsz_mark_runs( $text ) as $r ) {
		if ( $max <= 0 ) {
			break;
		}
		$r[0]   = mb_substr( $r[0], 0, $max );
		$max   -= mb_strlen( $r[0] );
		$runs[] = $r;
	}
	return fsz_mark_text( $runs );
}

/**
 * A formatted text as safe HTML for the card: <strong>, <em>, <u> and <span class="fsz-c-red">, nothing else. $hyphen
 * adds the soft hyphens (display only); $breaks writes line breaks as <br> (the card editor).
 */
function fsz_format( $text, $hyphen = true, $breaks = false ) {
	$html = '';
	foreach ( fsz_mark_runs( $text ) as $r ) {
		$t = esc_html( $hyphen ? fsz_hyphenate( $r[0] ) : $r[0] );
		if ( $breaks ) {
			$t = str_replace( "\n", '<br>', $t );
		}
		$t = $r[3] ? '<u>' . $t . '</u>' : $t;
		$t = $r[2] ? '<em>' . $t . '</em>' : $t;
		$t = $r[1] ? '<strong>' . $t . '</strong>' : $t;
		$t = '' !== $r[4] ? '<span class="fsz-c-' . esc_attr( $r[4] ) . '" data-c="' . esc_attr( $r[4] ) . '">' . $t . '</span>' : $t;
		$html .= $t;
	}
	return $html;
}

/**
 * 1.55.0: the story for shoppers in up to three paragraphs (<span class="fsz-para">): its own line breaks when it has
 * them, else its sentences shared out evenly. codex.css runs them on as one text on bigger screens and breaks them into
 * paragraphs on phones.
 */
function fsz_story_html( $story ) {
	$story = trim( (string) $story );
	if ( '' === $story ) {
		return '';
	}
	$paras = preg_split( '/\s*\n\s*/u', $story, -1, PREG_SPLIT_NO_EMPTY );
	if ( count( $paras ) < 2 ) {
		// A sentence ends with . ! or ? (a closing mark may follow), the next one starts with a capital letter.
		$sent = preg_split( '/(?<=[.!?…])((?:\*\*|\[\/(?:i|u|' . implode( '|', fsz_mark_colors() ) . ')\])*)\s+(?=(?:\*\*|\[(?:i|u|' . implode( '|', fsz_mark_colors() ) . ')\])*[\p{Lu}0-9„"])/u', $story, -1, PREG_SPLIT_DELIM_CAPTURE );
		$list = array();
		for ( $i = 0; $i < count( $sent ); $i += 2 ) {
			$list[] = $sent[ $i ] . ( isset( $sent[ $i + 1 ] ) ? $sent[ $i + 1 ] : '' );
		}
		$per   = max( 1, (int) ceil( count( $list ) / 3 ) );
		$paras = array();
		foreach ( array_chunk( $list, $per ) as $chunk ) {
			$paras[] = implode( ' ', $chunk );
		}
	}
	// A mark (bold, colour) still open at the end of a paragraph carries on into the next one.
	$out  = '';
	$done = '';
	foreach ( $paras as $para ) {
		$out  .= '<span class="fsz-para">' . fsz_format( fsz_mark_open( $done ) . $para, true ) . '</span>';
		$done .= $para . ' ';
	}
	return $out;
}

// The marks still open at the end of a text, written out again (colour, bold, italic, underline).
function fsz_mark_open( $text ) {
	$colors = implode( '|', fsz_mark_colors() );
	$st     = array( 'b' => false, 'i' => false, 'u' => false, 'c' => '' );
	preg_match_all( '#\*\*|\[/?(?:i|u|' . $colors . ')\]#', (string) $text, $m );
	foreach ( $m[0] as $mark ) {
		if ( '**' === $mark ) {
			$st['b'] = ! $st['b'];
			continue;
		}
		$close = '/' === $mark[1];
		$tag   = trim( $mark, '[]/' );
		if ( 'i' === $tag || 'u' === $tag ) {
			$st[ $tag ] = ! $close;
		} else {
			$st['c'] = $close ? ( $st['c'] === $tag ? '' : $st['c'] ) : $tag;
		}
	}
	return ( '' !== $st['c'] ? '[' . $st['c'] . ']' : '' ) . ( $st['b'] ? '**' : '' ) . ( $st['i'] ? '[i]' : '' ) . ( $st['u'] ? '[u]' : '' );
}

// 1.55.0: a badge's meaning; a short lead before a colon ("Takarítómester:") is bold.
function fsz_why_html( $why ) {
	if ( preg_match( '/^([^:]{2,32}):\s+(.+)$/su', (string) $why, $m ) ) {
		return '<b>' . esc_html( $m[1] ) . ':</b> ' . esc_html( $m[2] );
	}
	return esc_html( $why );
}

function fsz_hyphenate( $text ) {
	if ( ! apply_filters( 'fsz_hyphenate', 0 === strpos( determine_locale(), 'hu' ) ) || '' === $text ) {
		return $text;
	}
	return preg_replace_callback( '/\p{L}{5,}/u', 'fsz_hyphenate_word', $text );
}

function fsz_hyphenate_word( $m ) {
	$word  = $m[0];
	$lower = mb_strtolower( $word, 'UTF-8' );
	$len   = mb_strlen( $word, 'UTF-8' );
	$units = array(); // [ start, length, is vowel, is a doubled digraph ]
	for ( $i = 0; $i < $len; ) {
		$n = 1;
		$long = false;
		foreach ( array( 'ddzs' => true, 'dzs' => false, 'ccs' => true, 'ddz' => true, 'ggy' => true, 'lly' => true, 'nny' => true, 'ssz' => true, 'tty' => true, 'zzs' => true, 'cs' => false, 'dz' => false, 'gy' => false, 'ly' => false, 'ny' => false, 'sz' => false, 'ty' => false, 'zs' => false ) as $g => $doubled ) {
			if ( mb_substr( $lower, $i, strlen( $g ), 'UTF-8' ) === $g ) {
				$n    = strlen( $g );
				$long = $doubled;
				break;
			}
		}
		$c       = mb_substr( $lower, $i, 1, 'UTF-8' );
		$units[] = array( $i, $n, 1 === $n && false !== mb_strpos( 'aáeéiíoóöőuúüű', $c, 0, 'UTF-8' ), $long );
		$i      += $n;
	}
	$breaks = array();
	$last   = -1; // the previous vowel
	foreach ( $units as $k => $u ) {
		if ( ! $u[2] ) {
			continue;
		}
		if ( $last >= 0 ) {
			$at = $k - $last > 1 ? $k - 1 : $k; // before the last consonant, or between two vowels
			if ( ! $units[ $at ][3] ) {
				$breaks[] = $units[ $at ][0];
			}
		}
		$last = $k;
	}
	$out = '';
	$pos = 0;
	foreach ( $breaks as $b ) {
		if ( $b >= 2 && $len - $b >= 2 ) {
			$out .= mb_substr( $word, $pos, $b - $pos, 'UTF-8' ) . "\u{00AD}";
			$pos  = $b;
		}
	}
	return $out . mb_substr( $word, $pos, null, 'UTF-8' );
}

/**
 * The three difficulty levels on the card. Saved values stay 1-5, which the shop filter counts: 1-2 is Beginner,
 * 3-4 Intermediate, 5 Expert. The editors save 1, 3 and 5, so values saved before 1.47.0 keep working.
 */
function fsz_levels() {
	return array(
		1 => array( 'save' => 1, 'word' => __( 'Beginner', 'codex' ) ),
		2 => array( 'save' => 3, 'word' => __( 'Intermediate', 'codex' ) ),
		3 => array( 'save' => 5, 'word' => __( 'Expert', 'codex' ) ),
	);
}

// The level (1-3) of a saved difficulty (1-5); 0 when none is set. Same as levelOf() in codex-edit.js.
function fsz_level( $diff ) {
	$diff = (int) $diff;
	return $diff < 1 ? 0 : ( $diff <= 2 ? 1 : ( $diff <= 4 ? 2 : 3 ) );
}

/**
 * The difficulty gauge: a half dial in three zones (the power bars' green, yellow and red) with a dark rim, and a
 * needle that codex.css turns to the level (data-level on the card). In edit mode the zones are the rating: click one
 * to set the level.
 */
function fsz_gauge( $diff, $edit ) {
	$point = function ( $a ) {
		return sprintf( '%.2f %.2f', 15 + 13 * cos( M_PI * ( 1 - $a ) ), 16 - 13 * sin( M_PI * ( 1 - $a ) ) );
	};
	$arc = function ( $a0, $a1 ) use ( $point ) {
		return 'M' . $point( $a0 ) . 'A13 13 0 0 1 ' . $point( $a1 );
	};
	$level = fsz_level( $diff );
	$segs  = '';
	foreach ( fsz_levels() as $i => $l ) {
		$segs .= '<path class="fsz-seg fsz-z' . $i . ( $i === $level ? ' is-on' : '' ) . '" data-save="' . (int) $l['save'] . '" d="' . $arc( ( $i - 1 ) / 3 + .012, $i / 3 - .012 ) . '"/>';
	}
	$rating = $edit ? ' data-fsz-rating="difficulty" data-value="' . (int) $diff . '" aria-label="' . esc_attr__( 'DIFFICULTY', 'codex' ) . '"' : '';
	return '<span class="fsz-dial"><svg class="fsz-gauge" viewBox="0 0 30 18"' . ( $edit ? '' : ' aria-hidden="true" focusable="false"' ) . '><path class="fsz-gauge-rim" d="' . $arc( 0, 1 ) . '"/><g class="fsz-segs"' . $rating . '>' . $segs . '</g><line class="fsz-needle" x1="15" y1="16" x2="5" y2="16"/><circle class="fsz-hub" cx="15" cy="16" r="2.6"/></svg></span>';
}

function fsz_css_vars( $product_id ) {
	$o      = fsz_opt();
	$device = fsz_product_color( $product_id );
	$vars   = array(
		'--fsz-device'      => $device,
		'--fsz-device-dark' => fsz_theme_dark( $device ),
		// Every theme (the default too) tints the screen: bright like a lit display, dark text in the same hue.
		'--fsz-screen'      => fsz_theme_tint( $o['screen'], $device, FSZ_SCREEN_LIGHT ),
		'--fsz-ink'         => fsz_theme_tint( $o['ink'], $device ),
	);
	$css = '';
	foreach ( $vars as $k => $v ) {
		$v = sanitize_hex_color( $v );
		if ( $v ) {
			$css .= $k . ':' . $v . ';';
		}
	}
	// Motion, the same for every card: levitation strength and the resting angle (codex.css).
	return $css . '--fsz-float:' . (int) $o['float'] . ';--fsz-turn:' . (int) $o['turn'] . 'deg;--fsz-lean:' . (int) $o['lean'] . 'deg;';
}

/**
 * The label on the device: the name of the product's main (top-level) category.
 * Categories under the card categories in the settings come first; Uncategorized is skipped
 * when the product has other categories.
 */
function fsz_device_label( $product_id ) {
	$term = fsz_group_term( $product_id );
	if ( ! $term ) {
		return '';
	}
	return function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $term->name, 'UTF-8' ) : strtoupper( $term->name );
}

// The device label's link: the group's shop page, so a shopper can browse the rest of the group.
function fsz_device_link( $product_id ) {
	$term = fsz_group_term( $product_id );
	$link = $term ? get_term_link( $term ) : '';
	return is_wp_error( $link ) ? '' : (string) $link;
}

/**
 * The product's group: its main (top-level) category, the one named on the device label.
 */
function fsz_group_term( $product_id ) {
	$terms = get_the_terms( $product_id, 'product_cat' );
	if ( ! $terms || is_wp_error( $terms ) ) {
		return null;
	}
	$default = (int) get_option( 'default_product_cat' );
	if ( count( $terms ) > 1 ) {
		$terms = array_values( array_filter( $terms, function ( $t ) use ( $default ) {
			return (int) $t->term_id !== $default;
		} ) );
	}
	$card_ids = fsz_category_ids();
	usort( $terms, function ( $a, $b ) use ( $card_ids ) {
		$ia = in_array( (int) $a->term_id, $card_ids, true ) ? 0 : 1;
		$ib = in_array( (int) $b->term_id, $card_ids, true ) ? 0 : 1;
		return $ia - $ib;
	} );
	$term = $terms[0];
	while ( $term->parent ) {
		$parent = get_term( $term->parent, 'product_cat' );
		if ( ! $parent || is_wp_error( $parent ) ) {
			break;
		}
		$term = $parent;
	}
	return $term;
}

/**
 * Group colours: a top category can have a Codex colour (term meta fsz_color); every card in it,
 * subcategories too, takes it. A colour picked for one product wins; no colour at all = the default theme.
 */
function fsz_group_color( $product_id ) {
	$term  = fsz_group_term( $product_id );
	$color = $term ? sanitize_hex_color( (string) get_term_meta( $term->term_id, 'fsz_color', true ) ) : '';
	return $color ? $color : (string) sanitize_hex_color( fsz_opt( 'device' ) );
}

function fsz_product_color( $product_id ) {
	$own = sanitize_hex_color( trim( (string) get_post_meta( $product_id, '_fsz_color', true ) ) );
	return $own ? $own : fsz_group_color( $product_id );
}

// Starting colours for the known groups (top categories, by name or slug); a colour already set stays.
function fsz_group_presets() {
	return array(
		'isopoda'    => '#1F8A8A', // teal
		'blattodea'  => '#C8692A', // copper orange
		'collembola' => '#3B8A3F', // green
		'arachnida'  => '#6E4BA8', // purple
	);
}

function fsz_seed_group_colors( $term_ids = null ) {
	if ( ! taxonomy_exists( 'product_cat' ) ) {
		return;
	}
	$terms = null === $term_ids
		? get_terms( array( 'taxonomy' => 'product_cat', 'parent' => 0, 'hide_empty' => false ) )
		: array_filter( array_map( function ( $id ) {
			return get_term( $id, 'product_cat' );
		}, (array) $term_ids ) );
	if ( is_wp_error( $terms ) ) {
		return;
	}
	$presets = fsz_group_presets();
	foreach ( $terms as $t ) {
		if ( ! $t || is_wp_error( $t ) || $t->parent || '' !== (string) get_term_meta( $t->term_id, 'fsz_color', true ) ) {
			continue;
		}
		foreach ( array( sanitize_title( $t->name ), $t->slug ) as $k ) {
			if ( isset( $presets[ $k ] ) ) {
				update_term_meta( $t->term_id, 'fsz_color', $presets[ $k ] );
				break;
			}
		}
	}
}

/**
 * The photo IDs on the screen: the product's own Codex image (from the media library) or the
 * featured image first, then the product gallery.
 */
function fsz_card_image_ids( $product_id ) {
	$ids = array();
	$img = trim( (string) get_post_meta( $product_id, '_fsz_image', true ) );
	if ( ctype_digit( $img ) && wp_attachment_is_image( (int) $img ) ) {
		$ids[] = (int) $img;
	}
	// The product's own photos, read the same way WooCommerce reads them for the gallery under the card.
	$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;
	if ( $product ) {
		$ids[] = (int) $product->get_image_id();
		$ids   = array_merge( $ids, array_map( 'intval', $product->get_gallery_image_ids() ) );
	} else {
		$ids[] = (int) get_post_thumbnail_id( $product_id );
	}
	return array_values( array_unique( array_filter( $ids ) ) );
}

/**
 * How each photo sits in the fixed 4:3 frame on this product's card: [x %, y %, zoom] by photo ID
 * ('url' for a linked Codex image). Photos without one are centred and not zoomed.
 */
function fsz_frames( $product_id ) {
	$frames = get_post_meta( $product_id, '_fsz_frames', true );
	return is_array( $frames ) ? $frames : array();
}

function fsz_frame( $frames, $key ) {
	$f = isset( $frames[ $key ] ) && is_array( $frames[ $key ] ) ? array_values( $frames[ $key ] ) : array();
	return 3 === count( $f ) ? array( (float) $f[0], (float) $f[1], (float) $f[2] ) : array( 50, 50, 1 );
}

// The frame as CSS variables (codex.css: object-position, transform-origin and scale of .fsz-slides img).
function fsz_frame_style( $frame ) {
	return '--fsz-fx:' . round( $frame[0], 1 ) . '%;--fsz-fy:' . round( $frame[1], 1 ) . '%;--fsz-fz:' . round( $frame[2], 3 );
}

// The photos on the screen as <img> tags: a linked Codex image (URL) first, then fsz_card_image_ids().
function fsz_card_images( $product_id, $alt ) {
	// 1.67.0: the first photo of the first cards on a page (the product page's card, the front page's three) loads at
	// once instead of lazily, and the very first one before anything else (fetchpriority), so the card that opens the
	// page shows its photo straight away. The other photos still load when needed. Filter: fsz_eager_cards (3).
	static $cards = 0;
	$cards++;
	$eager  = $cards <= (int) apply_filters( 'fsz_eager_cards', 3 );
	$out    = array();
	$frames = fsz_frames( $product_id );
	$img    = trim( (string) get_post_meta( $product_id, '_fsz_image', true ) );
	$load   = function () use ( &$out, $eager, $cards ) {
		if ( $out || ! $eager ) {
			return array( 'loading' => 'lazy' );
		}
		return 1 === $cards ? array( 'loading' => 'eager', 'fetchpriority' => 'high' ) : array( 'loading' => 'eager' );
	};
	if ( '' !== $img && ! ctype_digit( $img ) ) {
		$a = '';
		foreach ( $load() as $k => $v ) {
			$a .= ' ' . $k . '="' . esc_attr( $v ) . '"';
		}
		$out[] = '<img src="' . esc_url( $img ) . '" alt="' . esc_attr( $alt ) . '"' . $a . ' style="' . esc_attr( fsz_frame_style( fsz_frame( $frames, 'url' ) ) ) . '">';
	}
	foreach ( fsz_card_image_ids( $product_id ) as $id ) {
		// The photo's own alt text, or the species name.
		$attr = array_merge( $load(), array( 'style' => fsz_frame_style( fsz_frame( $frames, $id ) ) ) );
		if ( '' === trim( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) ) ) {
			$attr['alt'] = $alt;
		}
		$html = wp_get_attachment_image( $id, 'woocommerce_single', false, $attr );
		if ( $html ) {
			$out[] = $html;
		}
	}
	return $out;
}

/**
 * The card: the main page, and the detail page behind the round arrow (codex.js switches them).
 * With $edit (quick edit, see codex-edit.js) every line is shown, also the empty ones,
 * and the fields are marked with data-fsz-field / data-fsz-rating.
 */
function fsz_render_card( $product_id, $edit = false ) {
	$m = function ( $key ) use ( $product_id ) {
		return trim( (string) get_post_meta( $product_id, '_fsz_' . $key, true ) );
	};
	// Attributes of an editable text in edit mode.
	$f = function ( $key, $label, $placeholder = '—', $multi = false ) use ( $edit ) {
		return $edit ? ' data-fsz-field="' . esc_attr( $key ) . '" data-placeholder="' . esc_attr( $placeholder ) . '" aria-label="' . esc_attr( $label ) . '"' . ( $multi ? ' data-multiline' : '' ) : '';
	};
	$row = $edit ? ' data-fsz-row' : '';

	$names  = fsz_names( $product_id );
	$diff   = max( 0, min( 5, (int) $m( 'difficulty' ) ) );
	$slides = '1' === fsz_opt( 'show_photo' ) ? fsz_card_images( $product_id, $names['nick'] ) : array();
	if ( $edit ) {
		$slides = array_slice( $slides, 0, 1 ); // edit mode shows the first photo; clicking it opens the photo list
	}
	$story = $m( 'story' );
	// The four tiles show together (an empty one with a dash), or not at all when none is filled in.
	$stats = $edit ? fsz_stats() : array();
	foreach ( fsz_stats() as $key => $st ) {
		if ( '' !== $m( 'stat_' . $key ) ) {
			$stats = fsz_stats();
		}
	}
	// The detail page also holds the Latin name and the badge meanings, so it is there when any of them is.
	$traits   = $edit ? fsz_trait_keys( $product_id, $m( 'traits' ) ) : fsz_trait_keys( $product_id );
	$has_more = '' !== $story || $stats || '' !== $names['latin'] || $traits || $edit;
	$more_id  = 'fsz-more-' . (int) $product_id . ( $edit ? '-edit' : '' );
	$badge    = $edit ? (string) $m( 'badge' ) : fsz_badge( $product_id );
	$badges   = fsz_badges();
	$badge    = isset( $badges[ $badge ] ) ? $badge : '';
	$has_en   = true; // the English strip always takes its place, so every card is the same size
	// Difficulty level 1-3 (Beginner, Intermediate, Expert): the needle and the level colour. Same as level() in codex-edit.js.
	$level  = (string) ( fsz_level( $diff ) ?: '' );
	$levels = fsz_levels();
	$word   = $level ? $levels[ (int) $level ]['word'] : __( 'DIFFICULTY', 'codex' );
	// 1.55.0: the bubble is as wide as the longest level word (not "DIFFICULTY"), so it hugs the word; in edit mode and
	// on a card without a level "DIFFICULTY" can show too, so it counts then.
	$sizer = $edit || ! $level ? array( __( 'DIFFICULTY', 'codex' ) ) : array();
	foreach ( $levels as $l ) {
		$sizer[] = $l['word'];
	}
	usort( $sizer, function ( $a, $b ) {
		return mb_strlen( $b ) - mb_strlen( $a );
	} );
	$sizer = $sizer[0];
	// The green light on the device: lit while the product is in stock, grey when it is sold out.
	$product  = wc_get_product( $product_id );
	$in_stock = fsz_in_stock( $product );
	// 1.54.0: the yellow light blinks while the product is running low (the "Running low" switch) and still in stock.
	// In quick edit it is the switch itself.
	$low      = 'yes' === get_post_meta( $product_id, '_fsz_low', true );
	if ( $edit ) {
		$led_a = '<span class="fsz-led fsz-led-a' . ( $low ? ' is-low' : '' ) . '" data-fsz-toggle="low" role="switch" tabindex="0" aria-checked="' . ( $low ? 'true' : 'false' ) . '" aria-label="' . esc_attr__( 'Running low', 'codex' ) . '" title="' . esc_attr__( 'Running low: click to switch the blinking on or off', 'codex' ) . '"></span>';
	} elseif ( $low && $in_stock ) {
		$led_a = '<span class="fsz-led fsz-led-a is-low" role="img" aria-label="' . esc_attr__( 'Running low', 'codex' ) . '" title="' . esc_attr__( 'Running low', 'codex' ) . '"></span>';
	} else {
		$led_a = '<span class="fsz-led fsz-led-a"></span>';
	}
	$label    = fsz_device_label( $product_id );
	$link     = $edit ? '' : fsz_device_link( $product_id );

	ob_start();
	?>
	<div class="fsz-device<?php echo $edit ? ' is-editing' : ''; ?>"<?php echo $level ? ' data-level="' . esc_attr( $level ) . '"' : ''; ?><?php echo 'default' !== fsz_skin() ? ' data-fsz-skin="' . esc_attr( fsz_skin() ) . '"' : ''; ?> <?php echo $edit ? 'data-fsz-id="' . (int) $product_id . '"' : 'data-tilt="' . (int) fsz_opt( 'tilt' ) . '"'; ?> style="<?php echo esc_attr( fsz_css_vars( $product_id ) ); ?>">
		<div class="fsz-top">
			<?php echo $led_a; // phpcs:ignore WordPress.Security.EscapeOutput ?><span class="fsz-led fsz-led-b<?php echo $in_stock ? ' is-lit' : ''; ?>" role="img" aria-label="<?php echo esc_attr( $in_stock ? __( 'In stock', 'codex' ) : __( 'Out of stock', 'codex' ) ); ?>"></span>
			<?php if ( $link && '' !== $label ) : ?>
				<a class="fsz-label" href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $label ); ?></a>
			<?php else : ?>
				<span class="fsz-label"><?php echo esc_html( $label ); ?></span>
			<?php endif; ?>
		</div>
		<div class="fsz-bezel">
			<div class="fsz-screen">
				<div class="fsz-page fsz-page-main">
					<div class="fsz-deco" aria-hidden="true"></div><?php // group drawing slot (empty until --fsz-deco is set), under the power-bar plate ?>
					<?php // The name bar: the Codex number, the nickname and the difficulty gauge; the English name in the strip under it. ?>
					<div class="fsz-namebar<?php echo $has_en ? ' has-en' : ''; ?>">
						<b class="fsz-num"><?php echo esc_html( fsz_codex_number( $product_id ) ); ?></b>
						<span class="fsz-name fsz-nick"<?php echo $f( 'name', 'Nickname', $names['from_title']['nick'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $edit ? $m( 'name' ) : $names['nick'] ); ?></span>
						<?php if ( $diff > 0 || $edit ) : ?>
							<span class="fsz-diff"<?php echo $edit ? $row . ' data-words="' . esc_attr( wp_json_encode( array( __( 'DIFFICULTY', 'codex' ), $levels[1]['word'], $levels[2]['word'], $levels[3]['word'] ) ) ) . '"' : ' role="img" aria-label="' . esc_attr( __( 'DIFFICULTY', 'codex' ) . ': ' . $word ) . '"'; // phpcs:ignore WordPress.Security.EscapeOutput ?>><span class="fsz-diff-label" aria-hidden="true" data-size="<?php echo esc_attr( $sizer ); ?>"><span class="fsz-diff-word"><?php echo esc_html( $word ); ?></span></span><?php echo fsz_gauge( $diff, $edit ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
						<?php endif; ?>
					</div>
					<?php if ( $has_en ) : ?>
						<div class="fsz-en"><span<?php echo $f( 'trade', 'English name', 'English name' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $names['english'] ); ?></span></div>
					<?php endif; ?>

					<?php
					if ( $slides || ( $edit && '1' === fsz_opt( 'show_photo' ) ) ) {
						// Several photos: they change every 10 seconds or on a click (codex.js); the dots show which one is on.
						$count = count( $slides );
						$dots  = $count > 1 ? '<span class="fsz-strip-dots"><i class="is-on"></i>' . str_repeat( '<i></i>', $count - 1 ) . '</span>' : '';
						// The sticker on the photo's corner (NEW!, SALE!, RARE!); in edit mode it is always there, to pick one.
						if ( $edit ) {
							$sticker = '<span class="fsz-badge ' . ( $badge ? 'is-' . $badge : 'is-empty' ) . '" data-fsz-open="badge" title="Badge">' . esc_html( $badge ? $badges[ $badge ] : '+ Badge' ) . '</span>';
						} else {
							$sticker = $badge ? '<span class="fsz-badge is-' . $badge . '">' . esc_html( $badges[ $badge ] ) . '</span>' : '';
						}
						if ( $edit ) {
							echo '<div class="fsz-photo has-bar' . ( $slides ? '' : ' is-empty' ) . '" data-fsz-open="photos" title="Photos: add, remove, change the order">' . ( $slides ? '<div class="fsz-slides">' . $slides[0] . '</div>' : '<span class="fsz-photo-empty">No photo yet</span>' ) . $sticker . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
						} else {
							$attr = $count > 1 ? ' role="button" tabindex="0" aria-label="' . esc_attr__( 'Next photo', 'codex' ) . '"' : '';
							echo '<div class="fsz-photo has-bar"' . $attr . '><div class="fsz-slides">' . implode( '', $slides ) . '<span class="fsz-crt" aria-hidden="true"></span></div>' . $sticker . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
						}
						// The image bar under the photo: vent on the left, photo dots on the right.
						echo '<div class="fsz-strip" aria-hidden="true"><span class="fsz-strip-vents"></span>' . $dots . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
					}

					$bar_html = '';
					foreach ( fsz_bars() as $key => $label ) {
						$val = max( 0, min( 5, (int) $m( 'bar_' . $key ) ) ); // a bar without a value shows grey, so every card is the same size
						$cells_attr = $edit
							? ' data-fsz-rating="bar_' . esc_attr( $key ) . '" data-value="' . $val . '" aria-label="' . esc_attr( $label ) . '"'
							: ' role="img" aria-label="' . esc_attr( $label . ': ' . $val . '/5' ) . '"';
						$icon       = fsz_bar_icon( fsz_bar_kind( $key, $label ) );
						$bar_html  .= '<div class="fsz-bar"' . $row . '><span class="fsz-bar-label' . ( $icon ? ' has-icon' : '' ) . '">' . $icon . '<span class="fsz-bar-name">' . esc_html( $label ) . '</span></span><span class="fsz-cells"' . $cells_attr . '>';
						for ( $i = 1; $i <= 5; $i++ ) {
							$bar_html .= '<i class="fsz-cell fsz-c' . $i . ( $i <= $val ? ' is-on' : '' ) . '"></i>';
						}
						$bar_html .= '</span></div>';
					}
					if ( $bar_html || $traits || $edit ) {
						// One shared scale over all the bars (fuller = more); the trait badges sit over the bar names.
						$stamp  = fsz_stamp_svg( fsz_stamp_kind( $product_id ) );
						$box    = $traits || $edit || $stamp ? fsz_traits_box( $traits, $edit, $stamp ) : '';
						$scale  = $bar_html ? '<span class="fsz-legend-scale" aria-hidden="true"><span>−</span><i></i><span>+</span></span>' : '';
						$legend = '<div class="fsz-bar fsz-legend' . ( $box ? ' has-traits' : '' ) . '"><span class="fsz-bar-label">' . $box . '</span>' . $scale . '</div>';
						echo '<div class="fsz-bars">' . $legend . $bar_html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
					}

					// The bottom: the optional fun fact bubble, and the Description button centred between the line and the screen's edge.
					// It always takes the same height (room for a two-line fun fact), so every card is the same size.
					$fun = $m( 'fun' );
					echo '<div class="fsz-rule"></div><div class="fsz-screen-foot">';
					if ( '' !== $fun || $edit ) {
						$quote = explode( '|', _x( '“|”', 'quote marks around the fun fact', 'codex' ) . '|' );
						// The quote marks come from codex.css (data-q1/q2), the same in edit mode, so the lines break the same way.
						echo '<div class="fsz-fun' . ( '' === $fun ? ' is-empty' : '' ) . '"' . $row . '><b>' . esc_html__( 'Fun fact', 'codex' ) . '</b><span class="fsz-fun-text" data-q1="' . esc_attr( $quote[0] ) . '" data-q2="' . esc_attr( $quote[1] ) . '"' . $f( 'fun', 'Fun fact', 'Fun fact (optional)' ) . ( $edit ? ' data-fsz-max="' . (int) FSZ_FUN_MAX . '"' : '' ) . ' data-fsz-rich>' . fsz_format( $fun, ! $edit ) . '</span>' . ( $edit ? '<small class="fsz-fun-count" aria-hidden="true">' . (int) mb_strlen( fsz_plain( $fun ) ) . '/' . (int) FSZ_FUN_MAX . '</small>' : '' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
					}
					if ( $has_more ) {
						echo '<button type="button" class="fsz-more" aria-controls="' . esc_attr( $more_id ) . '" aria-expanded="false"><span class="fsz-more-text">' . esc_html__( 'Description', 'codex' ) . '</span><span class="fsz-more-btn" aria-hidden="true"></span></button>';
					}
					echo '</div>';
					?>
				</div>
				<?php if ( $has_more ) : ?>
					<div class="fsz-page fsz-page-more" id="<?php echo esc_attr( $more_id ); ?>" role="region" aria-label="<?php esc_attr_e( 'Detailed description', 'codex' ); ?>" tabindex="-1" hidden>
						<div class="fsz-head">
							<b class="fsz-num"><?php echo esc_html( fsz_codex_number( $product_id ) ); ?></b>
							<span class="fsz-pill"><span class="fsz-diff-label"><?php esc_html_e( 'Detailed description', 'codex' ); ?></span></span>
						</div>
						<?php if ( '' !== $names['latin'] || $edit ) : ?>
							<?php // The scientific name, quiet: a small temple pill, then the name in grey italics. ?>
							<div class="fsz-latin"<?php echo '' === $names['from_title']['latin'] ? $row : ''; // phpcs:ignore WordPress.Security.EscapeOutput -- with a Latin name in the product name the line always shows ?>><span class="fsz-temple" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M12 2 22.5 8H1.5z"/><rect x="2" y="8.8" width="20" height="1.8"/><rect x="3.8" y="11.4" width="2.6" height="8"/><rect x="10.7" y="11.4" width="2.6" height="8"/><rect x="17.6" y="11.4" width="2.6" height="8"/><rect x="2" y="20" width="20" height="1.7"/><rect x="1" y="22.2" width="22" height="1.5"/></svg></span><i lang="la"<?php echo $f( 'latin', 'Latin name', '' !== $names['from_title']['latin'] ? $names['from_title']['latin'] : 'Latin name' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $edit ? $m( 'latin' ) : $names['latin'] ); ?></i></div>
						<?php endif; ?>
						<?php if ( $traits || $edit ) : ?>
							<?php // Each badge on the card again, with what it means (in edit mode all three, the ones not picked hidden). ?>
							<div class="fsz-whys">
								<?php foreach ( fsz_traits() as $key => $t ) : ?>
									<?php $on = in_array( $key, $traits, true ); ?>
									<?php if ( $on || $edit ) : ?>
										<div class="fsz-why is-<?php echo esc_attr( $key ) . ( $on ? '' : ' is-off' ); ?>" data-trait="<?php echo esc_attr( $key ); ?>"><span class="fsz-trait"><?php echo fsz_trait_svg( $key ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span><p><?php echo fsz_why_html( $t['why'] ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside ?></p></div>
									<?php endif; ?>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
						<div class="fsz-rule"></div>
						<div class="fsz-more-body">
							<?php if ( '' !== $story || $edit ) : ?>
								<?php // One text, no heading. In edit mode a word counter: about FSZ_STORY_WORDS fit above the tiles. ?>
								<div class="fsz-story-wrap"<?php echo $row; // phpcs:ignore WordPress.Security.EscapeOutput ?>><div class="fsz-story"<?php echo $f( 'story', 'Description', 'Description', true ) . ( $edit ? ' data-fsz-words="' . (int) FSZ_STORY_WORDS . '"' : '' ); // phpcs:ignore WordPress.Security.EscapeOutput ?> data-fsz-rich><?php echo $edit ? fsz_format( $story, false, true ) : fsz_story_html( $story ); // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped text ?></div><?php if ( $edit ) : ?><?php $n = fsz_word_count( fsz_plain( $story ) ); ?><small class="fsz-story-count<?php echo $n > FSZ_STORY_WORDS ? ' is-full' : ''; ?>" aria-hidden="true"><?php echo (int) $n . '/' . (int) FSZ_STORY_WORDS; ?></small><?php endif; ?></div>
							<?php endif; ?>
							<?php if ( $stats ) : ?>
								<?php // Four tiles, two by two: icon, label, short value. An empty one shows a dash. ?>
								<div class="fsz-stats">
									<?php foreach ( $stats as $key => $st ) : ?>
										<?php $val = $m( 'stat_' . $key ); ?>
										<div class="fsz-stat"><span class="fsz-bar-ic" aria-hidden="true"><svg viewBox="0 0 16 16" focusable="false"><?php echo $st[1]; // phpcs:ignore WordPress.Security.EscapeOutput ?></svg></span><span class="fsz-stat-t"><span class="fsz-stat-l"><?php echo esc_html( $st[0] ); ?></span><span class="fsz-stat-v"<?php echo $f( 'stat_' . $key, $st[0], '—' ); // phpcs:ignore WordPress.Security.EscapeOutput ?> data-fsz-rich><?php echo '' === $val && ! $edit ? '—' : fsz_format( $val, false ); // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped text ?></span></span></div>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>
						</div>
						<div class="fsz-more-foot"><button type="button" class="fsz-back"><span class="fsz-back-btn" aria-hidden="true"></span><span class="fsz-more-text"><?php esc_html_e( 'Back', 'codex' ); ?></span></button></div>
					</div>
				<?php endif; ?>
				<span class="fsz-crt" aria-hidden="true"></span>
			</div>
		</div>
		<div class="fsz-foot" aria-hidden="true">
			<span class="fsz-foot-vents" aria-hidden="true"></span>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Quick edit pop-ups: photos (click the photo), badge (click the photo's corner), colour theme (click the device).
 * 1.51.0: the tags are no longer on the card; they are set in the product's Codex box.
 */
function fsz_render_edit_dialog( $product_id ) {
	$color   = sanitize_hex_color( trim( (string) get_post_meta( $product_id, '_fsz_color', true ) ) );
	$default = fsz_group_color( $product_id );
	$uid     = 'fsz-d' . (int) $product_id;
	// The group colour comes first (no own colour, follows the group); the same colour is not listed twice.
	$themes = array( '' => 'Group colour' );
	foreach ( fsz_themes() as $hex => $name ) {
		if ( 0 !== strcasecmp( $hex, $default ) ) {
			$themes[ $hex ] = $name;
		}
	}
	$picked = $color ? 'custom' : '';
	foreach ( array_keys( $themes ) as $hex ) {
		if ( $color && 0 === strcasecmp( $hex, $color ) ) {
			$picked = $hex;
		}
	}
	$own = $color ? $color : $default;

	ob_start();
	?>
	<dialog class="fsz-dialog" aria-labelledby="<?php echo esc_attr( $uid ); ?>-title">
		<form method="dialog">
			<h2 id="<?php echo esc_attr( $uid ); ?>-title"></h2>
			<div class="fsz-dfield" data-fsz-section="photos" data-title="Photos" hidden>
				<ol class="fsz-pics">
					<?php
					// A Codex image given as a link (not in the media library) is shown first on the card, so it is listed first too.
					$linked = trim( (string) get_post_meta( $product_id, '_fsz_image', true ) );
					$frames = fsz_frames( $product_id );
					if ( '' !== $linked && ! ctype_digit( $linked ) ) :
						?>
						<li class="fsz-pic is-linked" data-id="url" data-full="<?php echo esc_url( $linked ); ?>" data-frame="<?php echo esc_attr( implode( ',', fsz_frame( $frames, 'url' ) ) ); ?>" title="Linked Codex image: always shown first">
							<img src="<?php echo esc_url( $linked ); ?>" alt="">
						</li>
					<?php endif; ?>
					<?php foreach ( fsz_card_image_ids( $product_id ) as $id ) : ?>
						<li class="fsz-pic" data-id="<?php echo (int) $id; ?>" data-full="<?php echo esc_url( (string) wp_get_attachment_image_url( $id, 'woocommerce_single' ) ); ?>" data-frame="<?php echo esc_attr( implode( ',', fsz_frame( $frames, $id ) ) ); ?>" draggable="true">
							<img src="<?php echo esc_url( (string) wp_get_attachment_image_url( $id, 'thumbnail' ) ); ?>" alt="">
						</li>
					<?php endforeach; ?>
				</ol>
				<p class="fsz-pics-empty" hidden>No photos yet.</p>
				<div class="fsz-dimage-btns"><button type="button" class="fsz-btn" data-fsz-add-photos>Add photos…</button></div>
				<span class="fsz-dhint">Click a photo to choose which part shows on the card. Drag to change the order, or use the arrows. The first photo is also the product's main image. These are the product's own photos (the album below the card too).</span>
			</div>
			<div class="fsz-dfield" data-fsz-section="color" data-title="Colour theme" hidden>
				<div class="fsz-themes">
					<?php foreach ( $themes as $hex => $name ) : $a = '' === $hex ? $default : $hex; ?>
						<button type="button" class="fsz-theme" data-hex="<?php echo esc_attr( $hex ); ?>" aria-pressed="<?php echo $picked === $hex ? 'true' : 'false'; ?>">
							<span class="fsz-swatch" style="background-color:<?php echo esc_attr( $a ); ?> !important"><span style="background-color:<?php echo esc_attr( fsz_theme_dark( $a ) ); ?> !important"></span></span>
							<span class="fsz-theme-name"><?php echo esc_html( $name ); ?></span>
						</button>
					<?php endforeach; ?>
					<label class="fsz-theme is-custom<?php echo 'custom' === $picked ? ' is-on' : ''; ?>">
						<span class="fsz-swatch" style="background-color:<?php echo esc_attr( $own ); ?> !important"><span style="background-color:<?php echo esc_attr( fsz_theme_dark( $own ) ); ?> !important"></span></span>
						<span class="fsz-theme-name">Own colour</span>
						<input type="color" name="color" value="<?php echo esc_attr( $own ); ?>" data-picked="<?php echo esc_attr( 'custom' === $picked ? $color : '' ); ?>">
					</label>
				</div>
				<span class="fsz-dhint">The outside takes the colour, the screen frame the same colour, darker.</span>
				<?php if ( current_user_can( 'manage_woocommerce' ) ) : ?>
					<div class="fsz-motion">
						<h3>Motion <span>All cards</span></h3>
						<?php
						$sliders = array(
							'float' => array( 'Levitation', 0, 20, '' ),
							'turn'  => array( 'Turn right', -15, 15, '°' ),
							'lean'  => array( 'Tilt down', -15, 15, '°' ),
						);
						foreach ( $sliders as $key => $sl ) :
							$val = (int) fsz_opt( $key );
							?>
							<label class="fsz-slider"><span class="fsz-slider-name"><?php echo esc_html( $sl[0] ); ?></span><input type="range" name="<?php echo esc_attr( $key ); ?>" min="<?php echo (int) $sl[1]; ?>" max="<?php echo (int) $sl[2]; ?>" step="1" value="<?php echo $val; // phpcs:ignore WordPress.Security.EscapeOutput ?>" data-unit="<?php echo esc_attr( $sl[3] ); ?>"><output><?php echo esc_html( $val . $sl[3] ); ?></output></label>
						<?php endforeach; ?>
						<span class="fsz-dhint">Levitation 0 = still. A minus angle turns left / tips up. Saved for every card with Save.</span>
					</div>
				<?php endif; ?>
			</div>
			<div class="fsz-dfield" data-fsz-section="badge" data-title="Badge" hidden>
				<div class="fsz-badges">
					<?php
					$picked_badge = (string) get_post_meta( $product_id, '_fsz_badge', true );
					$picked_badge = isset( fsz_badges()[ $picked_badge ] ) ? $picked_badge : '';
					?>
					<button type="button" class="fsz-badge-pick" data-badge="" aria-pressed="<?php echo '' === $picked_badge ? 'true' : 'false'; ?>"><span class="fsz-badge-none">None</span></button>
					<?php foreach ( fsz_badges() as $key => $text ) : ?>
						<button type="button" class="fsz-badge-pick" data-badge="<?php echo esc_attr( $key ); ?>" aria-pressed="<?php echo $picked_badge === $key ? 'true' : 'false'; ?>"><span class="fsz-badge is-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $text ); ?></span></button>
					<?php endforeach; ?>
				</div>
				<span class="fsz-dhint">The sticker on the photo's corner. With no badge picked, <?php echo esc_html( fsz_badges()['sale'] ); ?> shows by itself while the product has a sale price.</span>
			</div>
			<div class="fsz-dfield" data-fsz-section="traits" data-title="Badges" hidden>
				<div class="fsz-traitpicks">
					<?php $picked_traits = fsz_trait_keys( $product_id ); ?>
					<?php foreach ( fsz_traits() as $key => $t ) : ?>
						<button type="button" class="fsz-trait-pick" data-trait="<?php echo esc_attr( $key ); ?>" aria-pressed="<?php echo in_array( $key, $picked_traits, true ) ? 'true' : 'false'; ?>"><span class="fsz-trait"><?php echo fsz_trait_svg( $key ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span><span class="fsz-trait-name"><?php echo esc_html( array( 'cleanup' => 'Cleanup crew', 'ball' => 'Rolls into a ball', 'feeder' => 'Feeder' )[ $key ] ); ?></span></button>
					<?php endforeach; ?>
				</div>
				<span class="fsz-dhint">Click to switch each badge on or off. They show over the power bar names; the detail page lists them again with what they mean.</span>
			</div>
			<div class="fsz-dactions"><button class="fsz-btn is-primary" value="done">Done</button></div>
		</form>
	</dialog>
	<?php
	return ob_get_clean();
}

function fsz_output_on_product() {
	global $product;
	if ( ! $product instanceof WC_Product || ! fsz_is_live( $product->get_id() ) ) {
		return;
	}
	$id   = $product->get_id();
	$edit = fsz_can_quick_edit( $id );
	echo '<div class="fsz-wrap fsz-at-gallery"' . ( $edit ? ' data-fsz-edit="' . (int) $id . '"' : '' ) . '>' . fsz_render_card( $id ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	echo fsz_sleep_script(); // phpcs:ignore WordPress.Security.EscapeOutput
	echo fsz_fit_script(); // phpcs:ignore WordPress.Security.EscapeOutput
	if ( $edit ) {
		// Used by codex-edit.js when "Edit card" is clicked.
		echo '<template id="fsz-edit-' . (int) $id . '">' . fsz_render_card( $id, true ) . fsz_render_edit_dialog( $id ) . '</template>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

// 1.54.0: the card waits for its wake-up (codex.js wake()) with empty bars, set before the first paint so nothing jumps.
// Not for visitors who turned off animations; and if codex.js never takes over, the bars come back after 4 s.
function fsz_sleep_script() {
	// 1.67.2: power-on (Dan's pick A): the product page card's screen starts switched off (.fsz-pwr, a dark layer made
	// here, before the first paint); once the photo has loaded (at most 1.5 s), a thin line of the screen's own colour opens
	// up and the picture flickers on (codex.css), then the layer is removed. Only opacity and transform move. Once per
	// page open; skipped for reduced motion and without JavaScript (no dark screen then).
	$js = <<<'JS'
(function(){var d=document.currentScript.previousElementSibling;d=d&&d.querySelector('.fsz-device[data-tilt]');if(!d||(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches)){return}d.classList.add('is-asleep');setTimeout(function(){if(!d.fszWake){d.classList.remove('is-asleep')}},4000);var s=d.querySelector('.fsz-screen');if(!s){return}var o=document.createElement('i');o.className='fsz-pwr';o.setAttribute('aria-hidden','true');o.innerHTML='<b></b>';s.appendChild(o);var done=false,go=function(){if(done){return}done=true;requestAnimationFrame(function(){o.classList.add('is-on');setTimeout(function(){if(o.parentNode){o.parentNode.removeChild(o)}},900)})},img=s.querySelector('.fsz-slides img');if(img&&!img.complete){img.addEventListener('load',go);img.addEventListener('error',go);setTimeout(go,1500)}else{go()}})()
JS;
	return '<script>' . $js . '</script>';
}

// Fit to the screen: when the theme sets --fsz-fit-bottom on the product page card (the room to keep free under it), the
// card shrinks so its bottom stays that far above the bottom of the screen. It may be negative: an admin's extra bars
// above the card can be given back, so the card has the size a customer sees. Runs right after the card, before the first
// paint, so the card never jumps; codex.js runs it again on resize, after the fonts load and after the edit bar appears.
function fsz_fit_script() {
	static $done = false;
	if ( $done ) {
		return '<script>window.fszFit&&fszFit()</script>';
	}
	$done = true;
	// 1.55.0 screen mode (--fsz-fit-mode: screen, used by the Ízeltláb phone product page): the card is as wide as the
	// screen allows (screen width - 46px, at most 344px), but zoomed out just enough that its SCREEN (the device sides
	// may go under the bars) fits between --fsz-fit-top and --fsz-fit-bottom (px from the top and the bottom of the
	// visible window); never under 280px wide, so it stays readable. Spare room goes above it, up to --fsz-fit-cap
	// (half of it when none is set), so the card sits lower on big phones. The wrap gets --fsz-fit-y (the card's top),
	// --fsz-fit-w (its width) and data-fsz-spare, and a "fsz:fit" event.
	// 1.56.0: --fsz-fit-scale (e.g. .86) makes the card that much narrower than the screen allows; --fsz-fit-center: card
	// centres the WHOLE card between top and bottom (+6px for the float), but never so low that its screen comes within
	// 4px of --fsz-fit-low (px from the bottom: the drawer with its free-shipping line).
	$js = <<<'JS'
window.fszFit=function(){var w=document.querySelectorAll('.fsz-wrap.fsz-at-gallery');for(var i=0;i<w.length;i++){var d=w[i].querySelector('.fsz-device');if(!d){continue}var cs=getComputedStyle(w[i]);if(cs.getPropertyValue('--fsz-fit-mode').trim()==='screen'){fszFitScreen(w[i],d,cs);continue}d.style.removeProperty('--fsz-u');if(!cs.getPropertyValue('--fsz-fit-bottom').trim()){continue}var p=document.createElement('div');p.style.cssText='position:absolute;visibility:hidden;pointer-events:none;height:calc(var(--fsz-fit-bottom) + 10000px);width:calc(var(--fsz-u) * 1000)';d.appendChild(p);var u0=p.offsetWidth/1000,room=innerHeight-(p.offsetHeight-10000)-(w[i].getBoundingClientRect().top+scrollY);d.removeChild(p);var u=u0;for(var n=0;n<3;n++){var h=d.offsetHeight;if(!h||h<=room+1){break}u=Math.max(u0*.55,u*room/h);d.style.setProperty('--fsz-u',u.toFixed(3)+'px')}}};
function fszFitScreen(wr,d,cs){var num=function(k){var v=parseFloat(cs.getPropertyValue(k));return isNaN(v)?null:v},top=num('--fsz-fit-top')||0,bot=num('--fsz-fit-bottom')||0,cap=num('--fsz-fit-cap'),W=document.documentElement.clientWidth,H=num('--fsz-fit-h')||window.innerHeight,lo=top+6,hi=H-bot-6,max=Math.min(W-46,344)*(num('--fsz-fit-scale')||1),w=max,sT=.17,span=.76,R=.54,sc=d.querySelector('.fsz-screen');for(var n=0;n<4;n++){d.style.setProperty('--fsz-u',(w/440).toFixed(4)+'px');var dw=d.offsetWidth,dh=d.offsetHeight;if(!dw||!dh||!sc){return}var t=0,e=sc;while(e&&e!==d){t+=e.offsetTop;e=e.offsetParent}sT=t/dh;span=sc.offsetHeight/dh;R=dw/dh;var nw=Math.max(Math.min(280,max),Math.min(max,(hi-lo)/span*R));if(Math.abs(nw-w)<.5){w=nw;break}w=nw}d.style.setProperty('--fsz-u',(w/440).toFixed(4)+'px');var ch=w/R,spare=(hi-lo)-span*ch,up=Math.max(0,spare/2);if(cap!==null){up=Math.min(cap,up)}var y=lo-sT*ch+up;if(cs.getPropertyValue('--fsz-fit-center').trim()==='card'){var low=num('--fsz-fit-low');low=low===null?bot:low;y=Math.max(lo-sT*ch,Math.min(top+(H-bot-top-ch)/2+6,H-low-4-(sT+span)*ch))}wr.style.setProperty('--fsz-fit-y',Math.round(y)+'px');wr.style.setProperty('--fsz-fit-w',Math.round(w)+'px');wr.setAttribute('data-fsz-spare',String(Math.round(spare)));wr.dispatchEvent(new CustomEvent('fsz:fit',{bubbles:true,detail:{width:w,height:ch,spare:spare}}))}
fszFit()
JS;
	return '<script>' . str_replace( "\n", '', $js ) . '</script>';
}

add_action( 'wp', function () {
	if ( ! function_exists( 'is_product' ) ) {
		return; // WooCommerce is not active
	}
	$live = is_product() && fsz_is_live( get_queried_object_id() );
	if ( $live && '1' === fsz_opt( 'hide_wc' ) ) {
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
		remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
	}
	// The card always takes the product photos' place: left, with the title, price and cart on the right.
	if ( $live ) {
		remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );
		remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_images', 20 );
		add_action( 'woocommerce_before_single_product_summary', 'fsz_output_on_product', 20 );
	}
} );

add_shortcode( 'codex', function ( $atts ) {
	$atts = shortcode_atts( array( 'id' => 0 ), $atts );
	$id   = (int) $atts['id'] ? (int) $atts['id'] : get_the_ID();
	if ( ! $id || 'product' !== get_post_type( $id ) ) {
		return '';
	}
	fsz_enqueue_front();
	return '<div class="fsz-wrap">' . fsz_render_card( $id ) . '</div>';
} );

/* ------------------------------------------------------------------ shop filter: difficulty */

add_action( 'woocommerce_before_shop_loop', function () {
	// 1.48.0: not printed under the Ízeltláb theme, whose difficulty pills do the same job (it only hid the dropdown).
	// Another theme can turn it off with the fsz_filter_dropdown filter.
	if ( '1' !== fsz_opt( 'filter' ) || ! apply_filters( 'fsz_filter_dropdown', ! function_exists( 'izl_has_codex' ) ) ) {
		return;
	}
	$ids = fsz_category_ids();
	if ( is_product_category() ) {
		$cur = get_queried_object();
		if ( ! $cur || ! in_array( (int) $cur->term_id, $ids, true ) ) {
			return;
		}
	} elseif ( ! is_shop() ) {
		return;
	}
	$sel = isset( $_GET['max_difficulty'] ) ? (int) $_GET['max_difficulty'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	echo '<form class="fsz-filter" method="get"><label for="fsz-max-difficulty">' . esc_html__( 'Difficulty:', 'codex' ) . '</label> <select id="fsz-max-difficulty" name="max_difficulty" onchange="this.form.submit()">';
	echo '<option value="0">' . esc_html__( 'All', 'codex' ) . '</option>';
	// Up to a level: Beginner (saved 1-2), Beginner and Intermediate (1-4). Expert and up is every species, so "All".
	$levels = fsz_levels();
	$ups    = array(
		2 => $levels[1]['word'],
		/* translators: 1: Beginner, 2: Intermediate */
		4 => sprintf( __( '%1$s + %2$s', 'codex' ), $levels[1]['word'], $levels[2]['word'] ),
	);
	foreach ( $ups as $i => $text ) {
		echo '<option value="' . (int) $i . '"' . selected( $sel, $i, false ) . '>' . esc_html( $text ) . '</option>';
	}
	echo '</select>';
	foreach ( $_GET as $k => $v ) { // phpcs:ignore WordPress.Security.NonceVerification
		if ( 'max_difficulty' !== $k && is_scalar( $v ) ) {
			echo '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( wp_unslash( $v ) ) . '">';
		}
	}
	echo '<noscript><button type="submit">' . esc_html__( 'Filter', 'codex' ) . '</button></noscript></form>';
}, 25 );

add_action( 'woocommerce_product_query', function ( $q ) {
	if ( '1' !== fsz_opt( 'filter' ) ) {
		return;
	}
	$sel = isset( $_GET['max_difficulty'] ) ? (int) $_GET['max_difficulty'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	if ( $sel < 1 || $sel > 5 ) {
		return;
	}
	$mq   = (array) $q->get( 'meta_query' );
	$mq[] = array(
		'key'     => '_fsz_difficulty',
		'value'   => array( 1, $sel ),
		'type'    => 'NUMERIC',
		'compare' => 'BETWEEN',
	);
	$q->set( 'meta_query', $mq );
} );

/* ------------------------------------------------------------------ admin: product fields */

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'fsz_box', 'Codex data', 'fsz_meta_box', 'product', 'normal', 'high' );
} );

add_action( 'admin_enqueue_scripts', function () {
	$screen = get_current_screen();
	if ( $screen && 'product' === $screen->post_type ) {
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
		wp_add_inline_script( 'wp-color-picker', 'jQuery(function($){$(".fsz-color").wpColorPicker({palettes:' . wp_json_encode( array_keys( fsz_themes() ) ) . '});});' );
		wp_enqueue_media();
		wp_add_inline_script( 'wp-color-picker', 'jQuery(function($){var f;$("#fsz-image-pick").on("click",function(e){e.preventDefault();if(!f){f=wp.media({title:"Codex image",button:{text:"Use this image"},library:{type:"image"},multiple:false});f.on("select",function(){var a=f.state().get("selection").first().toJSON(),u=(a.sizes&&a.sizes.medium?a.sizes.medium.url:a.url);$("#fsz_image").val(a.id);$("#fsz-image-preview").html($("<img>").attr("src",u));$("#fsz-image-remove").show();});}f.open();});$("#fsz-image-remove").on("click",function(e){e.preventDefault();$("#fsz_image").val("");$("#fsz-image-preview").empty();$(this).hide();});});' );
		wp_add_inline_style( 'wp-color-picker', '.fsz-admin th{width:170px;text-align:left;font-weight:600;padding:6px 10px 6px 0;vertical-align:top}.fsz-admin td{padding:4px 0}.fsz-admin input.regular-text{width:100%;max-width:420px}.fsz-admin h4{margin:18px 0 6px}.fsz-admin .description{color:#646970}#fsz-image-preview img{display:block;max-width:160px;height:auto;margin:0 0 6px;border:1px solid #dcdcde}' );
	}
} );

/* ------------------------------------------------------------------ admin: group colours */

add_action( 'admin_enqueue_scripts', function () {
	$screen = get_current_screen();
	if ( $screen && 'product_cat' === $screen->taxonomy ) {
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
		// The add form is sent by AJAX and then cleared: the picker is cleared with it.
		wp_add_inline_script( 'wp-color-picker', 'jQuery(function($){$(".fsz-color").wpColorPicker({palettes:' . wp_json_encode( array_keys( fsz_themes() ) ) . '});$(document).ajaxComplete(function(e,x,o){if(o&&o.data&&String(o.data).indexOf("action=add-tag")>-1&&!$("#ajax-response .error").length){$("#addtag .fsz-color").wpColorPicker("color","").val("");}});});' );
		wp_add_inline_style( 'wp-color-picker', '.fsz-swatch-cell{display:inline-block;width:22px;height:22px;border-radius:5px;border:3px solid;box-sizing:border-box;vertical-align:middle}.column-fsz_color{width:90px}' );
	}
} );

function fsz_group_color_swatch( $hex ) {
	return '<span class="fsz-swatch-cell" style="background:' . esc_attr( $hex ) . ';border-color:' . esc_attr( fsz_theme_dark( $hex ) ) . '"></span>';
}

add_action( 'product_cat_add_form_fields', function () {
	wp_nonce_field( 'fsz_group_color', 'fsz_group_nonce' );
	?>
	<div class="form-field">
		<label for="fsz-group-color">Codex colour</label>
		<input type="text" class="fsz-color" id="fsz-group-color" name="fsz_group_color" value="">
		<p class="description">Only for top categories (groups such as Isopoda): every Codex card in the group, subcategories too, takes this colour. Empty = the default theme.</p>
	</div>
	<?php
} );

add_action( 'product_cat_edit_form_fields', function ( $term ) {
	?>
	<tr class="form-field">
		<th scope="row"><label for="fsz-group-color">Codex colour</label></th>
		<td>
			<?php if ( $term->parent ) : ?>
				<?php
				$top = $term;
				while ( $top->parent ) {
					$up = get_term( $top->parent, 'product_cat' );
					if ( ! $up || is_wp_error( $up ) ) {
						break;
					}
					$top = $up;
				}
				$c = sanitize_hex_color( (string) get_term_meta( $top->term_id, 'fsz_color', true ) );
				$c = $c ? $c : (string) sanitize_hex_color( fsz_opt( 'device' ) );
				?>
				<?php echo fsz_group_color_swatch( $c ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<p class="description">Follows its group: <a href="<?php echo esc_url( get_edit_term_link( $top->term_id, 'product_cat', 'product' ) ); ?>"><?php echo esc_html( $top->name ); ?></a>. Change the colour there.</p>
			<?php else : ?>
				<?php wp_nonce_field( 'fsz_group_color', 'fsz_group_nonce' ); ?>
				<input type="text" class="fsz-color" id="fsz-group-color" name="fsz_group_color" value="<?php echo esc_attr( (string) get_term_meta( $term->term_id, 'fsz_color', true ) ); ?>" data-default-color="<?php echo esc_attr( fsz_opt( 'device' ) ); ?>">
				<p class="description">Every Codex card in this group, subcategories too, takes this colour. A colour picked for one product still wins. Empty = the default theme.</p>
			<?php endif; ?>
		</td>
	</tr>
	<?php
} );

function fsz_save_group_color( $term_id ) {
	if ( ! isset( $_POST['fsz_group_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fsz_group_nonce'] ) ), 'fsz_group_color' ) || ! current_user_can( 'manage_product_terms' ) ) {
		return;
	}
	$term = get_term( $term_id, 'product_cat' );
	if ( ! $term || is_wp_error( $term ) || $term->parent ) {
		return;
	}
	$color = sanitize_hex_color( isset( $_POST['fsz_group_color'] ) ? trim( wp_unslash( $_POST['fsz_group_color'] ) ) : '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	if ( $color ) {
		update_term_meta( $term_id, 'fsz_color', $color );
	} else {
		delete_term_meta( $term_id, 'fsz_color' );
	}
}
add_action( 'edited_product_cat', 'fsz_save_group_color' );
add_action( 'created_product_cat', function ( $term_id ) {
	fsz_save_group_color( $term_id );
	fsz_seed_group_colors( array( $term_id ) ); // a new Isopoda, Blattodea… without a colour gets its starting colour
}, 20 );

// A colour column in the category list: groups show theirs, subcategories nothing.
add_filter( 'manage_edit-product_cat_columns', function ( $cols ) {
	$out = array();
	foreach ( $cols as $k => $v ) {
		$out[ $k ] = $v;
		if ( 'name' === $k ) {
			$out['fsz_color'] = 'Codex colour';
		}
	}
	return $out;
} );
add_filter( 'manage_product_cat_custom_column', function ( $content, $column, $term_id ) {
	if ( 'fsz_color' !== $column ) {
		return $content;
	}
	$term = get_term( $term_id, 'product_cat' );
	if ( ! $term || is_wp_error( $term ) || $term->parent ) {
		return $content;
	}
	$c = sanitize_hex_color( (string) get_term_meta( $term_id, 'fsz_color', true ) );
	return $c ? fsz_group_color_swatch( $c ) : '<span aria-hidden="true">—</span><span class="screen-reader-text">Default theme</span>';
}, 10, 3 );

function fsz_meta_box( $post ) {
	wp_nonce_field( 'fsz_save', 'fsz_nonce' );
	$v = function ( $key ) use ( $post ) {
		return (string) get_post_meta( $post->ID, '_fsz_' . $key, true );
	};
	$live = fsz_is_live( $post->ID );
	echo '<div class="fsz-admin">';
	if ( ! $live ) {
		echo '<p class="description"><b>This product does not show the Codex card right now.</b> Put it in a ticked category of a set-up group (Isopoda, Blattodea, Collembola, Arachnida) and untick "Hide" if it is ticked.</p>';
	}
	echo '<table><tbody>';
	$text = function ( $key, $label, $ph = '', $desc = '' ) use ( $v ) {
		echo '<tr><th><label for="fsz_' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td><input type="text" class="regular-text" id="fsz_' . esc_attr( $key ) . '" name="fsz[' . esc_attr( $key ) . ']" value="' . esc_attr( $v( $key ) ) . '" placeholder="' . esc_attr( $ph ) . '">';
		if ( $desc ) {
			echo '<br><span class="description">' . esc_html( $desc ) . '</span>';
		}
		echo '</td></tr>';
	};
	$img     = $v( 'image' );
	$preview = '';
	if ( ctype_digit( $img ) ) {
		$preview = wp_get_attachment_image( (int) $img, 'medium' );
	} elseif ( '' !== $img ) {
		$preview = '<img src="' . esc_url( $img ) . '" alt="">';
	}
	echo '<tr><th>Codex image</th><td><div id="fsz-image-preview">' . $preview . '</div><input type="hidden" id="fsz_image" name="fsz[image]" value="' . esc_attr( $img ) . '"><button type="button" class="button" id="fsz-image-pick">Choose image</button> <button type="button" class="button-link" id="fsz-image-remove"' . ( '' === $img ? ' style="display:none"' : '' ) . '>Remove</button><br><span class="description">Shown on the Codex screen only, separate from the product gallery. Leave empty to use the featured image.</span></td></tr>';
	echo '<tr><th>Codex number</th><td><b>' . esc_html( fsz_codex_number( $post->ID ) ) . '</b><br><span class="description">Automatic: the order the Codex products were published in.</span></td></tr>';
	$names = fsz_names( $post->ID );
	$text( 'name', 'Nickname', $names['from_title']['nick'], 'Big in the name bar. Empty: the part in quotes of a product name like Porcellio laevis – „Boci”, else the whole product name.' );
	$text( 'trade', 'English name', 'Dairy Cow', 'In the strip under the nickname.' );
	$text( 'latin', 'Latin name', '' !== $names['from_title']['latin'] ? $names['from_title']['latin'] : 'Porcellio laevis', 'On the detail page. Empty: the part before the dash in the product name.' );

	$d = (int) $v( 'difficulty' );
	echo '<tr><th><label for="fsz_difficulty">Difficulty</label></th><td><select id="fsz_difficulty" name="fsz[difficulty]"><option value="0">–</option>';
	foreach ( fsz_levels() as $i => $l ) {
		// A value saved before 1.47.0 (2 or 4) shows as its level and is saved as that level's value.
		echo '<option value="' . (int) $l['save'] . '"' . selected( fsz_level( $d ), $i, false ) . '>' . esc_html( $l['word'] ) . '</option>';
	}
	echo '</select></td></tr>';
	$text( 'tags', 'Tags', '', 'Comma separated. Shown as links next to the price (not on the card); they are also the product\'s WooCommerce tags.' );
	$badge = $v( 'badge' );
	echo '<tr><th><label for="fsz_badge">Badge</label></th><td><select id="fsz_badge" name="fsz[badge]"><option value="">None</option>';
	foreach ( array( 'new' => 'New', 'sale' => 'Sale', 'rare' => 'Rare' ) as $key => $label ) {
		echo '<option value="' . esc_attr( $key ) . '"' . selected( $badge, $key, false ) . '>' . esc_html( $label ) . '</option>';
	}
	echo '</select><br><span class="description">The sticker on the photo\'s corner. With None, the sale badge shows by itself while the product has a sale price.</span></td></tr>';
	$picked = fsz_trait_keys( $post->ID );
	echo '<tr><th>Badges</th><td><input type="hidden" name="fsz[traits][]" value="">';
	foreach ( array( 'cleanup' => 'Cleanup crew', 'ball' => 'Rolls into a ball', 'feeder' => 'Feeder' ) as $key => $label ) {
		echo '<label style="margin-right:14px"><input type="checkbox" name="fsz[traits][]" value="' . esc_attr( $key ) . '"' . checked( in_array( $key, $picked, true ), true, false ) . '> ' . esc_html( $label ) . '</label>';
	}
	echo '<br><span class="description">Animated badges over the power bar names; the detail page explains each one.</span></td></tr>';
	echo '</tbody></table>';

	echo '<h4>Power bars (1–5)</h4><table><tbody>';
	foreach ( fsz_bars() as $key => $label ) {
		$cur = (int) $v( 'bar_' . $key );
		echo '<tr><th><label for="fsz_bar_' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td><select id="fsz_bar_' . esc_attr( $key ) . '" name="fsz[bar_' . esc_attr( $key ) . ']"><option value="0">– (not shown)</option>';
		for ( $i = 1; $i <= 5; $i++ ) {
			echo '<option value="' . (int) $i . '"' . selected( $cur, $i, false ) . '>' . (int) $i . '</option>';
		}
		echo '</select></td></tr>';
	}
	echo '</tbody></table>';

	echo '<h4>Detail page</h4><table><tbody>';
	echo '<tr><th><label for="fsz_story">Description</label></th><td><textarea class="large-text" rows="5" id="fsz_story" name="fsz[story]">' . esc_textarea( $v( 'story' ) ) . '</textarea><br><span class="description">One text behind the Description button. About ' . (int) FSZ_STORY_WORDS . ' words fit above the four tiles. Formatting: **bold**, [i]italic[/i], [u]underline[/u], colours [blue] [green] [amber] [red] [group] … [/red] (or select words on the card in quick edit).</span></td></tr>';
	foreach ( fsz_stats() as $key => $st ) {
		$text( 'stat_' . $key, $st[0], '', '' );
	}
	echo '</tbody></table>';

	echo '<h4>Other</h4><table><tbody>';
	$text( 'fun', 'Fun fact', 'Sajnos nem ad tejet.', 'Optional joke in the bubble at the bottom of the card, up to ' . FSZ_FUN_MAX . ' characters (two lines; formatting marks like **bold** do not count).' );
	echo '<tr><th><label for="fsz_color">Colour theme</label></th><td><input type="text" class="fsz-color" id="fsz_color" name="fsz[color]" value="' . esc_attr( $v( 'color' ) ) . '" data-default-color="' . esc_attr( fsz_opt( 'device' ) ) . '"><br><span class="description">The screen frame follows in a darker shade. Leave empty to use the group colour (Products › Categories).</span></td></tr>';
	echo '<tr><th>Running low</th><td><label><input type="checkbox" name="fsz[low]" value="yes"' . checked( $v( 'low' ), 'yes', false ) . '> Few left: the yellow light on the card blinks (while it is in stock)</label></td></tr>';
	echo '<tr><th>Hide</th><td><label><input type="checkbox" name="fsz[hide]" value="yes"' . checked( $v( 'hide' ), 'yes', false ) . '> Do not show the Codex card on this product</label></td></tr>';
	echo '</tbody></table>';
	if ( $live ) {
		echo '<p class="description">Save, then check the product page to see the result.</p>';
	}
	echo '</div>';
}

add_action( 'save_post_product', function ( $post_id ) {
	if ( ! isset( $_POST['fsz_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fsz_nonce'] ) ), 'fsz_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$in = isset( $_POST['fsz'] ) && is_array( $_POST['fsz'] ) ? wp_unslash( $_POST['fsz'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	// The box sends every field; one that is missing counts as emptied.
	foreach ( fsz_field_keys() as $k ) {
		if ( ! isset( $in[ $k ] ) ) {
			$in[ $k ] = '';
		}
	}
	fsz_save_fields( $post_id, $in );
	isset( $in['hide'] ) && 'yes' === $in['hide'] ? update_post_meta( $post_id, '_fsz_hide', 'yes' ) : delete_post_meta( $post_id, '_fsz_hide' );
} );

/**
 * The Codex fields by type. The bars follow the list in the settings.
 */
function fsz_field_keys( $type = 'all' ) {
	$keys = array(
		'text'  => array( 'name', 'latin', 'trade', 'tags', 'fun' ), // 1.41.0: ability and weak point are off the card; their values stay saved
		'int'   => array( 'difficulty' ),
		'link'  => array( 'image' ),
		'multi' => array( 'story' ),
		'color' => array( 'color' ),
		'pick'  => array( 'badge', 'traits' ),
		'flag'  => array( 'low' ), // 1.54.0: yes or nothing
	);
	foreach ( array_keys( fsz_bars() ) as $k ) {
		$keys['int'][] = 'bar_' . $k;
	}
	foreach ( array_keys( fsz_stats() ) as $k ) {
		$keys['text'][] = 'stat_' . $k;
	}
	return 'all' === $type ? array_merge( ...array_values( $keys ) ) : $keys[ $type ];
}

/**
 * Save Codex fields from $in (key => value). Keys not in $in are left alone. An empty value
 * deletes the field, so that line is not shown.
 */
function fsz_save_fields( $post_id, $in ) {
	$put = function ( $key, $val, $keep ) use ( $post_id ) {
		$keep ? update_post_meta( $post_id, '_fsz_' . $key, $val ) : delete_post_meta( $post_id, '_fsz_' . $key );
	};
	foreach ( fsz_field_keys( 'text' ) as $k ) {
		if ( array_key_exists( $k, $in ) ) {
			$val = str_replace( "\u{00AD}", '', sanitize_text_field( $in[ $k ] ) ); // soft hyphens pasted from the card
			if ( 'fun' === $k && mb_strlen( fsz_plain( $val ) ) > FSZ_FUN_MAX ) {
				$val = trim( fsz_mark_cut( $val, FSZ_FUN_MAX ) ); // the limit counts the letters, not the marks
			}
			$put( $k, $val, '' !== $val );
		}
	}
	foreach ( fsz_field_keys( 'multi' ) as $k ) {
		if ( array_key_exists( $k, $in ) ) {
			// Browsers send line breaks as \r\n; keep plain \n like the CSV import.
			$val = trim( str_replace( array( "\r\n", "\r", "\u{00AD}" ), array( "\n", "\n", '' ), sanitize_textarea_field( $in[ $k ] ) ) );
			$put( $k, $val, '' !== $val );
		}
	}
	foreach ( fsz_field_keys( 'int' ) as $k ) {
		if ( array_key_exists( $k, $in ) ) {
			$val = max( 0, min( 5, (int) $in[ $k ] ) );
			$put( $k, $val, $val > 0 );
		}
	}
	// A media library ID, or a URL.
	foreach ( fsz_field_keys( 'link' ) as $k ) {
		if ( array_key_exists( $k, $in ) ) {
			$val = trim( (string) $in[ $k ] );
			$val = ctype_digit( $val ) ? (string) absint( $val ) : esc_url_raw( $val );
			$put( $k, $val, (bool) $val );
		}
	}
	if ( array_key_exists( 'color', $in ) ) {
		$val = (string) sanitize_hex_color( $in['color'] );
		$put( 'color', $val, '' !== $val );
	}
	if ( array_key_exists( 'badge', $in ) ) {
		$val = sanitize_key( (string) $in['badge'] );
		$put( 'badge', $val, isset( fsz_badges()[ $val ] ) );
	}
	foreach ( fsz_field_keys( 'flag' ) as $k ) {
		if ( array_key_exists( $k, $in ) ) {
			$put( $k, 'yes', in_array( strtolower( trim( (string) $in[ $k ] ) ), array( '1', 'yes', 'on', 'true', 'igen' ), true ) );
		}
	}
	if ( array_key_exists( 'traits', $in ) ) {
		$val = implode( ',', fsz_trait_keys( 0, is_array( $in['traits'] ) ? implode( ',', $in['traits'] ) : $in['traits'] ) );
		$put( 'traits', $val, '' !== $val );
	}
}

/* ------------------------------------------------------------------ tags = WooCommerce product tags */

/**
 * The Codex tags are also the product's WooCommerce tags, so each one has its own shop page (the theme links them next
 * to the price). Runs whenever _fsz_tags changes: the product box, quick edit and the CSV import alike. Tags added to
 * the product another way stay; a tag taken out of the Codex tags is taken off the product too.
 */
function fsz_sync_tags( $product_id ) {
	if ( ! taxonomy_exists( 'product_tag' ) || 'product' !== get_post_type( $product_id ) || ! empty( $GLOBALS['fsz_deleting'][ $product_id ] ) ) {
		return;
	}
	$tags = fsz_tags( $product_id );
	$old  = get_post_meta( $product_id, '_fsz_tags_synced', true );
	$old  = is_array( $old ) ? $old : array();
	$cur  = wp_get_object_terms( $product_id, 'product_tag', array( 'fields' => 'names' ) );
	if ( is_wp_error( $cur ) ) {
		return;
	}
	$cur  = array_map( 'wp_specialchars_decode', $cur );
	$keep = array_diff( $cur, array_diff( $old, $tags ) );
	wp_set_object_terms( $product_id, array_values( array_unique( array_merge( $keep, $tags ) ) ), 'product_tag' );
	if ( $tags ) {
		update_post_meta( $product_id, '_fsz_tags_synced', $tags );
	} else {
		delete_post_meta( $product_id, '_fsz_tags_synced' );
	}
}

foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $fsz_hook ) {
	add_action( $fsz_hook, function ( $meta_id, $object_id, $meta_key ) {
		if ( '_fsz_tags' === $meta_key ) {
			fsz_sync_tags( (int) $object_id );
		}
	}, 10, 3 );
}
unset( $fsz_hook );

// A product being deleted loses its terms first, then its meta: its tags must not be put back on the way out.
add_action( 'before_delete_post', function ( $post_id ) {
	$GLOBALS['fsz_deleting'][ (int) $post_id ] = true;
} );

/* ------------------------------------------------------------------ quick edit: saving */

add_action( 'wp_ajax_fsz_quick_edit_save', function () {
	check_ajax_referer( 'fsz_quick_edit', 'nonce' );
	$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
	if ( ! $id || 'product' !== get_post_type( $id ) || ! current_user_can( 'edit_post', $id ) ) {
		wp_send_json_error( array( 'message' => 'You are not allowed to edit this product.' ), 403 );
	}
	$in = isset( $_POST['fields'] ) && is_array( $_POST['fields'] ) ? wp_unslash( $_POST['fields'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	fsz_save_fields( $id, array_intersect_key( $in, array_flip( fsz_field_keys() ) ) );
	// Photos (only sent when they were changed): the first is the product image, the rest the gallery.
	$res = array();
	if ( isset( $_POST['photos'] ) && function_exists( 'wc_get_product' ) ) {
		$sent = explode( ',', sanitize_text_field( wp_unslash( $_POST['photos'] ) ) );
		$ids  = array_values( array_unique( array_filter( array_map( 'absint', $sent ), 'wp_attachment_is_image' ) ) );
		// The Codex image field: an uploaded one is now part of the photo list; a linked one stays only if it was kept.
		$img = trim( (string) get_post_meta( $id, '_fsz_image', true ) );
		if ( '' !== $img && ( ctype_digit( $img ) || ! in_array( 'url', $sent, true ) ) ) {
			delete_post_meta( $id, '_fsz_image' );
		}
		$product = wc_get_product( $id );
		if ( $product ) {
			try {
				$product->set_image_id( $ids ? $ids[0] : '' );
				$product->set_gallery_image_ids( array_slice( $ids, 1 ) );
				$product->save();
			} catch ( Exception $e ) {
				wp_send_json_error( array( 'message' => 'The photos could not be saved: ' . $e->getMessage() ) );
			}
		}
		// Written once more straight into the product, like the product editor does, so nothing older can win.
		if ( $ids ) {
			set_post_thumbnail( $id, $ids[0] );
		} else {
			delete_post_thumbnail( $id );
		}
		update_post_meta( $id, '_product_image_gallery', implode( ',', array_slice( $ids, 1 ) ) );
		clean_post_cache( $id );
		wp_cache_delete( $id, 'post_meta' );
		// What the card shows now, so the edit card can check it before reloading.
		$res['photos'] = array_map( 'strval', fsz_card_image_ids( $id ) );
		$res['wanted'] = array_map( 'strval', $ids );
	}
	// How each photo sits in the card's frame (only sent when changed): {id: [x, y, zoom]}.
	if ( isset( $_POST['frames'] ) ) {
		$in     = json_decode( wp_unslash( $_POST['frames'] ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$frames = array();
		foreach ( is_array( $in ) ? $in : array() as $key => $f ) {
			if ( ( 'url' !== $key && ! ctype_digit( (string) $key ) ) || ! is_array( $f ) || 3 !== count( $f ) ) {
				continue;
			}
			$f = array_map( 'floatval', array_values( $f ) );
			$f = array( round( max( 0, min( 100, $f[0] ) ), 1 ), round( max( 0, min( 100, $f[1] ) ), 1 ), round( max( 1, min( 3, $f[2] ) ), 3 ) );
			if ( array( 50.0, 50.0, 1.0 ) !== $f ) {
				$frames[ (string) $key ] = $f; // centred and not zoomed is the default, not stored
			}
		}
		if ( $frames ) {
			update_post_meta( $id, '_fsz_frames', $frames );
		} else {
			delete_post_meta( $id, '_fsz_frames' );
		}
	}
	// Motion (only sent when changed): one setting for every card, for shop managers.
	if ( isset( $_POST['motion'] ) && is_array( $_POST['motion'] ) && current_user_can( 'manage_woocommerce' ) ) {
		$motion = array_intersect_key( wp_unslash( $_POST['motion'] ), array_flip( array( 'float', 'turn', 'lean' ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		update_option( FSZ_OPT, array_merge( fsz_opt(), array_map( 'intval', $motion ) ) );
	}
	if ( function_exists( 'wc_delete_product_transients' ) ) {
		wc_delete_product_transients( $id );
	}
	wp_send_json_success( $res );
} );

/* ------------------------------------------------------------------ admin: settings page */

add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'Codex', 'Codex', 'manage_woocommerce', 'codex', 'fsz_settings_page' );
}, 60 );

add_action( 'admin_init', function () {
	register_setting( 'fsz_group', FSZ_OPT, array( 'sanitize_callback' => 'fsz_sanitize_settings' ) );
} );

/**
 * A list from the settings page (rows of key + label, in the order shown) as "one per line" text.
 * A row without a key is new: its key comes from its label. Plain text (older saves, upgrades) is kept as it is.
 */
function fsz_rows_text( $v ) {
	if ( ! is_array( $v ) ) {
		return sanitize_textarea_field( (string) $v );
	}
	$lines = array();
	$used  = array();
	foreach ( $v as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$label = trim( str_replace( '|', '/', sanitize_text_field( isset( $row['label'] ) ? $row['label'] : '' ) ) );
		$key   = isset( $row['key'] ) ? trim( (string) $row['key'] ) : '';
		$key   = fsz_key( '' === $key ? $label : $key );
		if ( '' === $label || '' === $key ) {
			continue;
		}
		// Two rows with the same name still get their own values.
		$base = $key;
		for ( $n = 2; isset( $used[ $key ] ); $n++ ) {
			$key = $base . '_' . $n;
		}
		$used[ $key ] = true;
		$lines[]      = fsz_key( $label ) === $key ? $label : $key . ' | ' . $label;
	}
	return implode( "\n", $lines );
}

function fsz_sanitize_settings( $in ) {
	$def   = fsz_defaults();
	$saved = (array) get_option( FSZ_OPT, array() );
	$out   = array();
	foreach ( $def as $k => $d ) {
		$v = isset( $in[ $k ] ) ? $in[ $k ] : '';
		if ( in_array( $k, array( 'float', 'turn', 'lean' ), true ) ) {
			// Set in the edit card (motion), not on the settings page: keep what is saved when it is not sent.
			$v         = isset( $in[ $k ] ) ? $v : ( isset( $saved[ $k ] ) ? $saved[ $k ] : $d );
			$out[ $k ] = 'float' === $k ? (string) max( 0, min( 20, (int) $v ) ) : (string) max( -15, min( 15, (int) $v ) );
		} elseif ( 'bars' === $k ) {
			$out[ $k ] = fsz_rows_text( $v );
		} elseif ( 'skin' === $k ) {
			$v         = sanitize_key( $v );
			$out[ $k ] = array_key_exists( $v, fsz_skins() ) ? $v : 'default';
		} elseif ( 'tilt' === $k ) {
			$out[ $k ] = (string) max( 0, min( 20, (int) $v ) );
		} elseif ( in_array( $k, array( 'show_photo', 'filter', 'hide_wc' ), true ) ) {
			$out[ $k ] = '1' === $v ? '1' : '0';
		} elseif ( 'categories' === $k ) {
			// Ticked boxes send slugs; older saves are comma separated text.
			$out[ $k ] = is_array( $v ) ? implode( ', ', array_filter( array_map( 'sanitize_title', $v ) ) ) : sanitize_text_field( $v );
		} else {
			$c         = sanitize_hex_color( $v );
			$out[ $k ] = $c ? $c : $d;
		}
	}
	return $out;
}

// Products with a saved value per field key, for one kind of field ('bar').
function fsz_saved_counts( $prefix ) {
	global $wpdb;
	$meta = '_fsz_' . $prefix . '_';
	$rows = $wpdb->get_results( $wpdb->prepare( "SELECT m.meta_key, COUNT(DISTINCT m.post_id) AS n FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE p.post_type = 'product' AND p.post_status <> 'trash' AND m.meta_key LIKE %s AND m.meta_value <> '' AND m.meta_value <> '0' GROUP BY m.meta_key", $wpdb->esc_like( $meta ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$out  = array();
	foreach ( $rows as $r ) {
		$out[ substr( $r->meta_key, strlen( $meta ) ) ] = (int) $r->n;
	}
	return $out;
}

// A readable name for a saved key that is not in a list any more.
function fsz_key_label( $key ) {
	foreach ( array_keys( fsz_default_labels() ) as $label ) {
		if ( fsz_key( $label ) === $key ) {
			return $label;
		}
	}
	return ucfirst( str_replace( '_', ' ', $key ) );
}

function fsz_products_text( $n ) {
	return $n ? sprintf( 1 === $n ? '%d product' : '%d products', $n ) : 'Not filled in yet';
}

function fsz_list_row( $name, $i, $key, $label, $n ) {
	$field = $name . '[' . $i . ']';
	echo '<li class="fsz-row">';
	echo '<span class="fsz-handle" title="Drag to change the order" aria-hidden="true"></span>';
	echo '<input type="hidden" class="fsz-row-key" name="' . esc_attr( $field . '[key]' ) . '" value="' . esc_attr( $key ) . '">';
	echo '<input type="text" class="fsz-row-label" name="' . esc_attr( $field . '[label]' ) . '" value="' . esc_attr( $label ) . '" aria-label="Name" placeholder="Name">';
	echo '<span class="fsz-row-count' . ( $n ? '' : ' is-empty' ) . '">' . esc_html( fsz_products_text( $n ) ) . '</span>';
	echo '<button type="button" class="fsz-row-remove" title="Remove from the card. Values already filled in are kept." aria-label="Remove"></button>';
	echo '</li>';
}

/**
 * A list on the settings page: drag to sort, rename in place (the hidden key keeps the values), add, remove.
 * Saved values whose row was removed or renamed the old way are offered back below the list.
 */
function fsz_list_editor( $list, $prefix, $add ) {
	$name   = FSZ_OPT . '[' . $list . ']';
	$rows   = fsz_list_rows( fsz_opt( $list ) );
	$counts = fsz_saved_counts( $prefix );
	echo '<div class="fsz-list" data-name="' . esc_attr( $name ) . '"><ol class="fsz-rows">';
	$i = 0;
	foreach ( $rows as $key => $label ) {
		fsz_list_row( $name, $i++, $key, $label, isset( $counts[ $key ] ) ? $counts[ $key ] : 0 );
	}
	echo '</ol>';
	echo '<button type="button" class="button fsz-add"><span aria-hidden="true">+</span> ' . esc_html( $add ) . '</button>';
	$lost = array_diff_key( $counts, $rows );
	if ( $lost ) {
		echo '<div class="fsz-lost"><p><b>Values not on the card.</b> These were filled in earlier, but their line was removed or renamed. Click one to bring it back with its values, then rename it.</p><div class="fsz-lost-chips">';
		foreach ( $lost as $key => $n ) {
			echo '<button type="button" class="fsz-chip" data-key="' . esc_attr( $key ) . '" data-label="' . esc_attr( fsz_key_label( $key ) ) . '" data-count="' . esc_attr( fsz_products_text( $n ) ) . '">+ ' . esc_html( fsz_key_label( $key ) ) . ' <span>' . esc_html( fsz_products_text( $n ) ) . '</span></button>';
		}
		echo '</div></div>';
	}
	echo '<template class="fsz-row-tpl">';
	fsz_list_row( $name, '__i__', '', '', 0 );
	echo '</template></div>';
}

// Product categories as a tree of checkboxes; a ticked category includes its subcategories.
function fsz_category_tree( $terms, $parent, $chosen, $setup = null ) {
	$kids = array_filter( $terms, function ( $t ) use ( $parent ) {
		return (int) $t->parent === (int) $parent;
	} );
	if ( ! $kids ) {
		return;
	}
	echo '<ul' . ( $parent ? '' : ' class="fsz-cats"' ) . '>';
	foreach ( $kids as $t ) {
		// A group that is not set up (and everything in it) cannot be ticked.
		$ok = null === $setup ? '' !== fsz_term_kind( $t ) : $setup;
		echo '<li><label class="fsz-cat' . ( $ok ? '' : ' is-off' ) . '"><input type="checkbox" name="' . esc_attr( FSZ_OPT ) . '[categories][]" value="' . esc_attr( $t->slug ) . '"' . checked( $ok && in_array( $t->slug, $chosen, true ), true, false ) . disabled( ! $ok, true, false ) . '> <span class="fsz-cat-name">' . esc_html( $t->name ) . '</span> <span class="fsz-cat-count">' . (int) $t->count . '</span>' . ( ! $ok && null === $setup ? ' <span class="fsz-cat-note">no card: not a set-up group</span>' : '' ) . '</label>';
		fsz_category_tree( $terms, $t->term_id, $chosen, $ok );
		echo '</li>';
	}
	echo '</ul>';
}

// Published products that show the card, for the preview.
function fsz_preview_products() {
	$ids = fsz_category_ids();
	if ( ! $ids ) {
		return array();
	}
	$posts = get_posts( array(
		'post_type'   => 'product',
		'post_status' => 'publish',
		'numberposts' => 100,
		'orderby'     => 'date',
		'order'       => 'ASC',
		'tax_query'   => array( array( 'taxonomy' => 'product_cat', 'terms' => $ids ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
	) );
	return array_values( array_filter( $posts, function ( $p ) {
		return fsz_is_live( $p->ID );
	} ) );
}

function fsz_preview_html( $product_id ) {
	return $product_id ? '<div class="fsz-wrap">' . fsz_render_card( $product_id ) . '</div>' : '';
}

// The preview with the settings as they are on the page, not saved yet.
add_action( 'wp_ajax_fsz_preview', function () {
	check_ajax_referer( 'fsz_preview', 'nonce' );
	$id = isset( $_POST['product'] ) ? absint( $_POST['product'] ) : 0;
	if ( ! current_user_can( 'manage_woocommerce' ) || ! $id || 'product' !== get_post_type( $id ) ) {
		wp_send_json_error( null, 403 );
	}
	$in       = isset( $_POST[ FSZ_OPT ] ) && is_array( $_POST[ FSZ_OPT ] ) ? wp_unslash( $_POST[ FSZ_OPT ] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$settings = fsz_sanitize_settings( $in );
	add_filter( 'pre_option_' . FSZ_OPT, function () use ( $settings ) {
		return $settings;
	} );
	wp_send_json_success( array( 'html' => fsz_preview_html( $id ) ) );
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( 'woocommerce_page_codex' !== $hook ) {
		return;
	}
	// The card itself, for the preview, with every skin (each one is scoped to its data-fsz-skin, so the preview can switch).
	fsz_style( 'codex', 'assets/codex.css' );
	foreach ( array_keys( fsz_skins() ) as $slug ) {
		fsz_skin_style( $slug );
	}
	wp_enqueue_style( 'codex-font', FSZ_URL . 'assets/fonts/ibm-plex-mono/font.css', array(), FSZ_VERSION );
	wp_enqueue_script( 'codex', FSZ_URL . 'assets/codex.js', array(), FSZ_VERSION, true );
	wp_enqueue_style( 'codex-admin', FSZ_URL . 'assets/codex-admin.css', array( 'wp-color-picker' ), FSZ_VERSION );
	wp_enqueue_script( 'codex-admin', FSZ_URL . 'assets/codex-admin.js', array( 'jquery', 'jquery-ui-sortable', 'wp-color-picker', 'codex' ), FSZ_VERSION, true );
	wp_localize_script( 'codex-admin', 'CodexAdmin', array(
		'ajax'     => admin_url( 'admin-ajax.php' ),
		'nonce'    => wp_create_nonce( 'fsz_preview' ),
		'palettes' => array_keys( fsz_themes() ),
		'empty'    => fsz_products_text( 0 ),
	) );
}, 20 );

function fsz_settings_page() {
	$o        = fsz_opt();
	$opt      = FSZ_OPT;
	$chosen   = array_filter( array_map( 'sanitize_title', explode( ',', $o['categories'] ) ) );
	$terms    = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
	$terms    = is_wp_error( $terms ) ? array() : $terms;
	$missing  = array_diff( $chosen, wp_list_pluck( $terms, 'slug' ) );
	$products = fsz_preview_products();
	$first    = $products ? $products[0]->ID : 0;
	$switch   = function ( $key, $title, $desc ) use ( $o, $opt ) {
		echo '<label class="fsz-switch"><input type="checkbox" role="switch" name="' . esc_attr( $opt ) . '[' . esc_attr( $key ) . ']" value="1"' . checked( $o[ $key ], '1', false ) . '><span class="fsz-switch-ui" aria-hidden="true"></span><span class="fsz-switch-text"><b>' . esc_html( $title ) . '</b><span>' . esc_html( $desc ) . '</span></span></label>';
	};
	?>
	<div class="wrap fsz-settings">
		<form method="post" action="options.php" id="fsz-settings-form">
			<?php settings_fields( 'fsz_group' ); ?>
			<header class="fsz-header">
				<div>
					<h1>Codex</h1>
					<p>The species card on your live animal product pages.</p>
				</div>
				<?php submit_button( 'Save changes', 'primary large', 'submit', false ); ?>
			</header>
			<?php settings_errors(); ?>
			<hr class="wp-header-end">

			<div class="fsz-layout">
				<div class="fsz-main">

					<section class="fsz-panel">
						<h2>Where the card shows</h2>
						<div class="fsz-field">
							<div class="fsz-field-head"><b>Categories</b><span>Products in a ticked category get the card. Its subcategories are included. Only the set-up groups (Isopoda, Blattodea, Collembola, Arachnida) can have it; every other group, such as supplies, never shows the card.</span></div>
							<?php if ( $terms ) : ?>
								<?php fsz_category_tree( $terms, 0, $chosen ); ?>
							<?php else : ?>
								<p class="fsz-note">No product categories yet. Add them under Products → Categories.</p>
							<?php endif; ?>
							<p class="fsz-note is-warning" id="fsz-cats-none"<?php echo $chosen ? ' hidden' : ''; ?>>No category ticked: the card is not shown on any product.</p>
							<?php if ( $missing ) : ?>
								<p class="fsz-note is-warning">Not found and removed when you save: <?php echo esc_html( implode( ', ', $missing ) ); ?></p>
							<?php endif; ?>
						</div>
					</section>

					<section class="fsz-panel">
						<h2>Product page and shop</h2>
						<?php
						$switch( 'show_photo', 'Photos on the screen', 'The product photos show on the Codex screen. They change every 10 seconds, on a click or a swipe.' );
						$switch( 'hide_wc', 'Hide WooCommerce details', 'On card products: no short description, categories/tags or Description/Reviews tabs. Title, price and cart button stay.' );
						$switch( 'filter', 'Difficulty filter in the shop', 'A dropdown above the product list to show species up to a difficulty.' );
						?>
					</section>

					<section class="fsz-panel">
						<h2>Power bars</h2>
						<p class="fsz-panel-desc">The rated lines on the card, in this order. Drag to reorder. Renaming keeps the values already filled in.</p>
						<?php fsz_list_editor( 'bars', 'bar', 'Add power bar' ); ?>
					</section>

					<section class="fsz-panel">
						<h2>Look</h2>
						<div class="fsz-field">
							<div class="fsz-field-head"><b><label for="fsz-skin">Skin</label></b><span>The style of every card. A skin changes colours, lines and effects only; everything stays in its place.</span></div>
							<select id="fsz-skin" name="<?php echo esc_attr( $opt ); ?>[skin]">
								<?php foreach ( fsz_skins() as $slug => $sk ) : ?>
									<option value="<?php echo esc_attr( $slug ); ?>"<?php selected( fsz_skin(), $slug ); ?>><?php echo esc_html( isset( $sk['label'] ) ? $sk['label'] : $slug ); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						<div class="fsz-field">
							<div class="fsz-field-head"><b><label for="fsz-tilt">3D tilt</label></b><span>How far the card turns toward the mouse. 0 = flat. Phones always get the still card.</span></div>
							<div class="fsz-range"><input type="range" id="fsz-tilt" min="0" max="20" step="1" name="<?php echo esc_attr( $opt ); ?>[tilt]" value="<?php echo esc_attr( $o['tilt'] ); ?>"><output for="fsz-tilt" id="fsz-tilt-val"><?php echo esc_html( $o['tilt'] ); ?></output></div>
						</div>
						<div class="fsz-colors">
							<?php
							$colors = array(
								'device' => array( 'Default theme', 'For groups without a colour. Each group (Products › Categories) and each species can have its own. The screen frame is a darker shade.' ),
								'screen' => array( 'Screen', 'How soft the screen is. The hue follows the theme.' ),
								'ink'    => array( 'Screen text', 'How dark the text is. The hue follows the theme.' ),
							);
							$def = fsz_defaults();
							foreach ( $colors as $k => $c ) {
								echo '<div class="fsz-color-field"><div class="fsz-field-head"><b>' . esc_html( $c[0] ) . '</b><span>' . esc_html( $c[1] ) . '</span></div><input type="text" class="fsz-color" name="' . esc_attr( $opt ) . '[' . esc_attr( $k ) . ']" value="' . esc_attr( $o[ $k ] ) . '" data-default-color="' . esc_attr( $def[ $k ] ) . '" aria-label="' . esc_attr( $c[0] ) . '"></div>';
							}
							?>
						</div>
					</section>

					<details class="fsz-panel fsz-csv">
						<summary><h2>CSV import columns</h2></summary>
						<p class="fsz-panel-desc">Products → Import, tick "Update existing products". Products are matched by SKU. _fsz_name is the nickname, _fsz_trade the English name; _fsz_badge is new, sale, rare or empty; _fsz_traits lists the badges over the power bars, comma separated: cleanup, ball, feeder.</p>
						<code><?php
						$cols = array( 'SKU', 'Meta: _fsz_name', 'Meta: _fsz_trade', 'Meta: _fsz_latin', 'Meta: _fsz_difficulty', 'Meta: _fsz_tags', 'Meta: _fsz_badge', 'Meta: _fsz_traits', 'Meta: _fsz_image' );
						foreach ( array_keys( fsz_bars() ) as $k ) {
							$cols[] = 'Meta: _fsz_bar_' . $k;
						}
						$cols = array_merge( $cols, array( 'Meta: _fsz_fun', 'Meta: _fsz_color' ) );
						$cols[] = 'Meta: _fsz_story';
						foreach ( array_keys( fsz_stats() ) as $k ) {
							$cols[] = 'Meta: _fsz_stat_' . $k;
						}
						echo esc_html( implode( ',', $cols ) );
						?></code>
					</details>

					<?php $old = fsz_old_data(); ?>
					<section class="fsz-panel fsz-cleanup">
						<h2>Clean up old data</h2>
						<?php if ( isset( $_GET['fsz_cleaned'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
							<p class="fsz-note"><?php echo esc_html( sprintf( 'Deleted %d old values.', absint( $_GET['fsz_cleaned'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification ?></p>
						<?php endif; ?>
						<?php if ( $old ) : ?>
							<p class="fsz-panel-desc">Values saved on products that no card line uses any more. Deleting them cannot be undone, and they can no longer be brought back under the lists above.</p>
							<ul class="fsz-old">
								<?php foreach ( $old as $row ) : ?>
									<li><b><?php echo esc_html( $row[0] ); ?></b> <span><?php echo esc_html( fsz_products_text( $row[1] ) ); ?></span></li>
								<?php endforeach; ?>
							</ul>
							<button type="submit" form="fsz-cleanup" class="button button-link-delete" onclick="return window.confirm( 'Delete these saved values from every product? This cannot be undone.' )">Delete old data</button>
						<?php else : ?>
							<p class="fsz-panel-desc">Nothing to clean up: the card uses every saved value.</p>
						<?php endif; ?>
					</section>

					<div class="fsz-save"><?php submit_button( 'Save changes', 'primary large', 'submit', false ); ?></div>
				</div>

				<aside class="fsz-side">
					<div class="fsz-panel fsz-preview-panel">
						<div class="fsz-preview-head">
							<h2>Live preview</h2>
							<?php if ( $products ) : ?>
								<select id="fsz-preview-product" aria-label="Product to preview">
									<?php foreach ( $products as $p ) : ?>
										<option value="<?php echo (int) $p->ID; ?>" data-url="<?php echo esc_url( get_permalink( $p ) ); ?>"><?php echo esc_html( html_entity_decode( get_the_title( $p ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ); ?></option>
									<?php endforeach; ?>
								</select>
							<?php endif; ?>
						</div>
						<?php if ( $products ) : ?>
							<div class="fsz-preview" id="fsz-preview" aria-live="polite"><?php echo fsz_preview_html( $first ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
							<p class="fsz-preview-foot"><span>Changes show here before you save.</span> <a id="fsz-preview-link" href="<?php echo esc_url( get_permalink( $first ) ); ?>" target="_blank" rel="noopener">Open product page ↗</a></p>
						<?php else : ?>
							<p class="fsz-note">No product shows the card yet. Tick a category with products, save, and a preview appears here.</p>
						<?php endif; ?>
					</div>
				</aside>
			</div>
		</form>
		<form id="fsz-cleanup" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="fsz_cleanup">
			<?php wp_nonce_field( 'fsz_cleanup' ); ?>
		</form>
	</div>
	<?php
}

/**
 * 1.48.0: values saved on products that no card line uses any more: the fields taken off the card (ability, weak point,
 * pack, the facts) and power bars or detail sections that are no longer in the lists. Meta key => array( label, products ).
 */
function fsz_old_data() {
	global $wpdb;
	$used = array();
	foreach ( fsz_field_keys() as $k ) {
		$used[] = '_fsz_' . $k;
	}
	$fixed = array(
		'_fsz_ability' => 'Ability',
		'_fsz_weak'    => 'Weak point',
		'_fsz_pack'    => 'Pack',
	);
	$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT meta_key, COUNT(DISTINCT post_id) AS n FROM {$wpdb->postmeta} WHERE meta_key LIKE %s GROUP BY meta_key", $wpdb->esc_like( '_fsz_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$out   = array();
	foreach ( $rows as $r ) {
		$k     = (string) $r->meta_key;
		$label = '';
		if ( isset( $fixed[ $k ] ) ) {
			$label = $fixed[ $k ];
		} elseif ( 0 === strpos( $k, '_fsz_fact_' ) ) {
			$label = 'Fact: ' . fsz_key_label( substr( $k, 10 ) );
		} elseif ( 0 === strpos( $k, '_fsz_bar_' ) && ! in_array( $k, $used, true ) ) {
			$label = 'Power bar: ' . fsz_key_label( substr( $k, 9 ) );
		} elseif ( 0 === strpos( $k, '_fsz_more_' ) && ! in_array( $k, $used, true ) ) {
			$label = 'Detail section: ' . fsz_key_label( substr( $k, 10 ) );
		}
		if ( '' !== $label ) {
			$out[ $k ] = array( $label, (int) $r->n );
		}
	}
	return $out;
}

add_action( 'admin_post_fsz_cleanup', function () {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( 'Sorry, you are not allowed to do this.' );
	}
	check_admin_referer( 'fsz_cleanup' );
	global $wpdb;
	$n = 0;
	foreach ( array_keys( fsz_old_data() ) as $key ) {
		$n += (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s", $key ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}
	wp_cache_flush();
	wp_safe_redirect( admin_url( 'admin.php?page=codex&fsz_cleaned=' . $n ) );
	exit;
} );

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=codex' ) ) . '">Settings</a>' );
	return $links;
} );

add_action( 'before_woocommerce_init', function () {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
} );
