/* Ízeltláb theme: build the minified copies shoppers get (2.8.0). Run from the theme folder:
     npm i terser@5   (once, anywhere on NODE_PATH)
     node tools/build-min.js
   CSS: comments and line breaks dropped only (the same careful method as Codex's tools/build-css.py, never inside a
   string), so every rule stays exactly as written. JS: terser (compress + shorter local names; names other files or
   the page use are kept). Each copy sits next to its source (style.min.css, assets/x.min.js); assets/min.json holds each
   source's md5, and functions.php izl_min() serves a copy only while its source still matches. */
'use strict';
const fs = require( 'fs' ), path = require( 'path' ), crypto = require( 'crypto' );
const { minify } = require( 'terser' );
const root = path.resolve( __dirname, '..' );
const CSS = [ 'style.css', 'assets/fonts.css', 'assets/launch.css' ];
const JS = fs.readdirSync( path.join( root, 'assets' ) ).filter( ( f ) => /\.js$/.test( f ) && ! /\.min\.js$/.test( f ) ).map( ( f ) => 'assets/' + f );

function minCss( css ) {
	let out = '', q = null;
	for ( let i = 0; i < css.length; i++ ) {
		const c = css[ i ];
		if ( q ) {
			out += c;
			if ( '\\' === c ) {
				out += css[ ++i ];
			} else if ( c === q ) {
				q = null;
			}
		} else if ( '"' === c || "'" === c ) {
			q = c;
			out += c;
		} else if ( '/' === c && '*' === css[ i + 1 ] ) {
			i = css.indexOf( '*/', i + 2 ) + 1;
		} else {
			out += c;
		}
	}
	return out.split( '\n' ).map( ( l ) => l.trim() ).filter( Boolean ).join( ' ' ).split( '} ' ).join( '}' ).split( '{ ' ).join( '{' ).split( '; ' ).join( ';' );
}

( async () => {
	const md5 = {};
	for ( const rel of CSS ) {
		const src = fs.readFileSync( path.join( root, rel ), 'utf8' );
		const out = minCss( src ) + '\n';
		fs.writeFileSync( path.join( root, rel.replace( /\.css$/, '.min.css' ) ), out );
		md5[ rel ] = crypto.createHash( 'md5' ).update( src ).digest( 'hex' );
		console.log( rel, src.length, '->', out.length );
	}
	for ( const rel of JS ) {
		const src = fs.readFileSync( path.join( root, rel ), 'utf8' );
		const res = await minify( src, { compress: { passes: 1 }, mangle: true, format: { comments: false } } );
		fs.writeFileSync( path.join( root, rel.replace( /\.js$/, '.min.js' ) ), res.code + '\n' );
		md5[ rel ] = crypto.createHash( 'md5' ).update( src ).digest( 'hex' );
		console.log( rel, src.length, '->', res.code.length );
	}
	fs.writeFileSync( path.join( root, 'assets/min.json' ), JSON.stringify( md5, null, 1 ) + '\n' );
} )();
