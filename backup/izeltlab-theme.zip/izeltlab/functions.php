<?php
/**
 * Ízeltláb: Storefront child theme in the "Retro Handheld" look of the Codex card.
 * Storefront does the shop work (cart, checkout, account, mobile); this theme changes the look, the header,
 * the product tiles and the front page. With the Codex plugin active, the tiles show the Codex number,
 * difficulty and colour of each species.
 *
 * Order: setup · helpers · site-wide look (colours, logo, styles, layout, header, footer, titles) · shop pages (pills,
 * tiles, new products) · front page · product page (layout, texts, buy ticket, trust and questions, cart button,
 * script, Customizer, buy box editor, product row) · Edit photos · launch pages (inc/launch.php).
 * The shop's rules and data live in inc/shop-core.php (shared with the Ízeltláb Bolt plugin).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'IZL_VERSION', '2.10.0' );

/**
 * 2.8.0: shoppers get the minified copies of the theme's stylesheets and scripts (no comments, no spaces: about half the
 * size, the same rules and code), built by tools/build-min.js next to their sources (style.min.css, assets/*.min.js,
 * assets/*.min.css). A copy is used only while it was built from the source as it is now (assets/min.json holds each
 * source's md5), so a hand edit to a source is never hidden by an older copy. SCRIPT_DEBUG serves the sources.
 * $rel: the source's path in the theme (e.g. 'assets/product.js'). Returns the path to serve.
 */
function izl_min( $rel ) {
	static $map = null;
	if ( null === $map ) {
		$file = get_stylesheet_directory() . '/assets/min.json';
		$map  = is_readable( $file ) ? json_decode( (string) file_get_contents( $file ), true ) : array(); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$map  = is_array( $map ) ? $map : array();
	}
	if ( ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) || empty( $map[ $rel ] ) ) {
		return $rel;
	}
	$dir = get_stylesheet_directory() . '/';
	$min = preg_replace( '/\.(js|css)$/', '.min.$1', $rel );
	if ( ! is_readable( $dir . $min ) || md5_file( $dir . $rel ) !== $map[ $rel ] ) {
		return $rel;
	}
	return $min;
}

// The theme's own style.css (loaded by Storefront as storefront-child-style): its minified copy on the shop side.
add_filter( 'stylesheet_uri', function ( $uri ) {
	if ( is_admin() ) {
		return $uri;
	}
	$min = izl_min( 'style.css' );
	return 'style.css' === $min ? $uri : get_stylesheet_directory_uri() . '/' . $min;
} );

// 2.1.1: the shop's rules and data (ship days, holidays, packs, free shipping, whole forints, photo frames). The same
// file is in the Ízeltláb Bolt plugin; whichever loads first runs, so the shop works with or without the plugin.
if ( ! defined( 'IZL_CORE' ) ) { // the Ízeltláb Bolt plugin already loaded its copy
	require_once __DIR__ . '/inc/shop-core.php';
}

add_action( 'after_setup_theme', function () {
	load_child_theme_textdomain( 'izeltlab', get_stylesheet_directory() . '/languages' );
	register_nav_menus( array( 'izeltlab-main' => 'Main menu (Ízeltláb header)' ) );
} );

/* ------------------------------------------------------------------ helpers: colours, the isopod pages, the Codex levels (izl_is_codex() etc. are in inc/shop-core.php) */

// The Codex default colour theme, so the whole shop follows it.
function izl_teal() {
	$c = izl_has_codex() ? sanitize_hex_color( fsz_opt( 'device' ) ) : '';
	return $c ? $c : '#1F8A8A';
}

function izl_dark( $hex ) {
	if ( function_exists( 'fsz_theme_dark' ) ) {
		$d = fsz_theme_dark( $hex );
		if ( $d ) {
			return $d;
		}
	}
	$hex = ltrim( (string) sanitize_hex_color( $hex ), '#' );
	if ( 6 !== strlen( $hex ) ) {
		return '#14605F';
	}
	$out = '#';
	foreach ( str_split( $hex, 2 ) as $c ) {
		$out .= sprintf( '%02X', (int) round( hexdec( $c ) * 0.7 ) );
	}
	return $out;
}

// The "Isopods" page: the one isopod category, or the shop showing only the isopod categories (?izl_view=isopods).
function izl_isopods_url() {
	$terms = izl_isopod_terms();
	if ( ! $terms || ! function_exists( 'wc_get_page_permalink' ) ) {
		return '';
	}
	if ( 1 === count( $terms ) ) {
		$link = get_term_link( $terms[0] );
		return is_wp_error( $link ) ? '' : $link;
	}
	return add_query_arg( 'izl_view', 'isopods', get_post_type_archive_link( 'product' ) );
}

// Every product (the shop page), for the "All products" button on the front page.
function izl_all_products_url() {
	return function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
}

// 1.7.1: the isopod on the front page "Isopods" button: rolled into a ball, it unrolls when the button is pointed at
// (style.css, "rolling isopod"). Seven back plates swing from a ring into an arch; the ball fades as they open.
// The isopod on the "Isopods" button (1.7.6): a rolled-up ball; pointed at, it unrolls (seen from above, facing right)
// and walks in place; it rolls up again after. Without a mouse (phones) it stays open and still.
function izl_bug_icon() {
	echo '<svg class="izl-bug" viewBox="0 0 30 24" aria-hidden="true" focusable="false"><g class="izl-bug-walk">'
		. '<path class="izl-bug-leg is-a is-top" d="M9.0 8.2l-1.1 -1.5"/><path class="izl-bug-leg is-b is-bottom" d="M9.0 15.8l-1.1 1.5"/><path class="izl-bug-leg is-b is-top" d="M11.0 7.5l-1.1 -1.5"/><path class="izl-bug-leg is-a is-bottom" d="M11.0 16.5l-1.1 1.5"/><path class="izl-bug-leg is-a is-top" d="M13.0 7.2l-1.1 -1.5"/><path class="izl-bug-leg is-b is-bottom" d="M13.0 16.8l-1.1 1.5"/><path class="izl-bug-leg is-b is-top" d="M15.0 7.2l-1.1 -1.5"/><path class="izl-bug-leg is-a is-bottom" d="M15.0 16.8l-1.1 1.5"/><path class="izl-bug-leg is-a is-top" d="M17.0 7.5l-1.1 -1.5"/><path class="izl-bug-leg is-b is-bottom" d="M17.0 16.5l-1.1 1.5"/><path class="izl-bug-leg is-b is-top" d="M18.8 8.1l-1.1 -1.5"/><path class="izl-bug-leg is-a is-bottom" d="M18.8 15.9l-1.1 1.5"/><path class="izl-bug-leg is-a is-top" d="M20.4 9.0l-1.1 -1.5"/><path class="izl-bug-leg is-b is-bottom" d="M20.4 15.0l-1.1 1.5"/>'
		. '<path class="izl-bug-line" d="M5.8 11.3L3.2 10.1M5.8 12.7L3.2 13.9M23.6 10.2Q25.8 7.2 29.2 6.6M23.6 13.8Q25.8 16.8 29.2 17.4"/>'
		. '<ellipse class="izl-bug-body" cx="14" cy="12" rx="8.6" ry="5.4"/><path class="izl-bug-band" d="M8.0 8.5Q9.1 12 8.0 15.5M10.1 7.5Q11.2 12 10.1 16.5M12.2 7.1Q13.3 12 12.2 16.9M14.3 7.0Q15.4 12 14.3 17.0M16.4 7.2Q17.5 12 16.4 16.8M18.4 7.7Q19.5 12 18.4 16.3"/><ellipse class="izl-bug-head" cx="22.6" cy="12" rx="1.8" ry="3"/>'
		. '</g><g class="izl-bug-ball"><circle cx="14" cy="12" r="7.4"/><path class="izl-bug-band" d="M8.7 7.1Q11.2 12 8.7 16.9M11.3 5.4Q13.8 12 11.3 18.6M14 4.9Q16.5 12 14 19.1M16.7 5.4Q19.2 12 16.7 18.6M19.3 7.1Q21.8 12 19.3 16.9"/></g></svg>'; // phpcs:ignore WordPress.Security.EscapeOutput -- fixed markup
}

function izl_isopods_view() {
	return isset( $_GET['izl_view'] ) && 'isopods' === $_GET['izl_view'] && count( izl_isopod_terms() ) > 1; // phpcs:ignore WordPress.Security.NonceVerification
}

function izl_on_isopods_page() {
	if ( ! function_exists( 'is_product_category' ) ) {
		return false;
	}
	if ( is_product_category() ) {
		return in_array( get_queried_object()->slug, wp_list_pluck( izl_isopod_terms(), 'slug' ), true );
	}
	return is_shop() && izl_isopods_view();
}

// The shop with ?izl_view=isopods: only the isopod categories (and the ones under them).
add_action( 'woocommerce_product_query', function ( $q ) {
	if ( ! izl_isopods_view() || ! $q->is_main_query() ) {
		return;
	}
	$tax   = (array) $q->get( 'tax_query' );
	$tax[] = array(
		'taxonomy'         => 'product_cat',
		'field'            => 'term_id',
		'terms'            => wp_list_pluck( izl_isopod_terms(), 'term_id' ),
		'include_children' => true,
	);
	$q->set( 'tax_query', $tax );
} );

// The beginner level: species saved up to this difficulty (1-5). Codex 1.47+ shows three levels: 1-2 Beginner,
// 3-4 Intermediate, 5 Expert.
function izl_beginner_level() {
	return (int) apply_filters( 'izl_beginner_level', 2 );
}

// 1.7.14: the Codex level (1 Beginner, 2 Intermediate, 3 Expert) of a saved difficulty, 0 when none is set.
function izl_level( $diff ) {
	if ( function_exists( 'fsz_level' ) ) {
		return fsz_level( $diff );
	}
	$diff = (int) $diff;
	return $diff < 1 ? 0 : ( $diff <= 2 ? 1 : ( $diff <= 4 ? 2 : 3 ) );
}

// The level's word, the same as on the Codex card.
function izl_level_word( $level ) {
	if ( function_exists( 'fsz_levels' ) ) {
		$levels = fsz_levels();
		if ( isset( $levels[ $level ] ) ) {
			return $levels[ $level ]['word'];
		}
	}
	$words = array( 1 => __( 'Beginner', 'izeltlab' ), 2 => __( 'Intermediate', 'izeltlab' ), 3 => __( 'Expert', 'izeltlab' ) );
	return isset( $words[ $level ] ) ? $words[ $level ] : '';
}

/* ------------------------------------------------------------------ colours stay the shop's own */

// Dark Reader (and browsers that darken pages, like LibreWolf with it built in) would recolour the shop: dark mint
// background, brown buttons. The lock tag tells Dark Reader to leave the site alone, and color-scheme keeps form
// controls light, so every visitor sees the same teal, mint and yellow.
add_action( 'wp_head', function () {
	echo '<meta name="darkreader-lock">' . "\n" . '<meta name="color-scheme" content="light only">' . "\n";
}, 1 );

// The Firefox engine (Firefox, LibreWolf, other Gecko browsers; 1.7.8): html.izl-gecko, set before the page is drawn,
// so style.css can give the 3D Codex cards a lighter way to draw there (Firefox lagged on them). Chromium browsers say
// "like Gecko" without the slash and support neither check, so they never get the class and nothing changes for them.
add_action( 'wp_head', function () {
	echo "<script>if(/\\bGecko\\/\\d/.test(navigator.userAgent)||(window.CSS&&CSS.supports&&CSS.supports('-moz-orient','inline'))){document.documentElement.classList.add('izl-gecko')}</script>\n";
}, 2 );

/* ------------------------------------------------------------------ 2.4.0: which layout fits the window

   Upright phones (under 768px wide) get the phone layout; everything else gets the computer layout. A phone turned
   sideways is only 360-430px tall, too short for the phone layout's card and drawer, and 667-956px wide, where the
   computer layout is cramped (the product page's guarantee column ran under the card). So for a phone on its side
   (screen under 500px tall, under 1024px wide) this script tells the browser to lay every page out 1024px wide and
   fit it to the screen: the full computer layout, slightly zoomed out, the same on every page (theme and Codex).
   Turned upright again, the normal width comes back. It reads the SCREEN's size and turn, not the window's, so an
   on-screen keyboard (which makes the window shorter) never switches it. Runs in the head, before anything is drawn;
   window.izlVp() re-applies it (product.js calls it after it changes the tag). */
add_action( 'wp_head', function () {
	echo "<script id=\"izl-vp\">(function(w){var m=document.querySelector('meta[name=viewport]');if(!m||!w.screen)return;function squeezed(){var s=w.screen,lo=Math.min(s.width,s.height),hi=Math.max(s.width,s.height),o=s.orientation&&s.orientation.type,side=o?o.indexOf('landscape')===0:Math.abs(+w.orientation||0)===90;return side&&hi<1024&&lo<500}w.izlVp=function(){var c=m.getAttribute('content')||'',s=squeezed(),k=Math.max(w.screen.width,w.screen.height)/1024,p=c.split(',').map(function(x){return x.trim()}).filter(function(x){return x&&!/^(width|initial-scale|viewport-fit)=/.test(x)});if(s){p=p.filter(function(x){return!/^(maximum-scale|user-scalable)=/.test(x)})}p.unshift(s?'width=1024, initial-scale='+k.toFixed(3):'width=device-width, initial-scale=1');p.push('viewport-fit=cover');var n=p.join(', ');if(n!==c){m.setAttribute('content',n)}};w.izlVp();w.addEventListener('orientationchange',function(){setTimeout(w.izlVp,60)});w.addEventListener('resize',w.izlVp)})(window)</script>\n";
}, 1 );

/* ------------------------------------------------------------------ 1.7.19: logo and icons */

// The wordmark: "ízeltláb" in Space Mono Bold, white, with the 8-segment line under the letters (one segment under each
// letter, the two end ones shorter). A logo set in the Customizer still wins. Storefront lets a child theme replace this.
function storefront_site_title_or_logo( $echo = true ) {
	if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
		$logo = get_custom_logo();
		$html = is_home() ? '<h1 class="logo">' . $logo . '</h1>' : $logo;
	} else {
		$tag  = is_home() && ! is_front_page() ? 'h1' : 'div'; // 2.1.2: the front page's one H1 is the hero title
		$html = '<' . $tag . ' class="beta site-title izl-logo"><a href="' . esc_url( home_url( '/' ) ) . '" rel="home"><span class="screen-reader-text">' . esc_html( get_bloginfo( 'name' ) ) . '</span><span class="izl-logo-t" aria-hidden="true">ízeltláb</span><span class="izl-logo-seg" aria-hidden="true">' . str_repeat( '<b></b>', 8 ) . '</span></a></' . $tag . '>';
	}
	if ( ! $echo ) {
		return $html;
	}
	echo $html; // phpcs:ignore WordPress.Security.EscapeOutput
}

// The tab icon and the home-screen icon: "Három vastag sáv", the rolled-up isopod on a teal tile. A Site Icon set under
// Appearance → Customize → Site Identity still wins.
add_action( 'wp_head', function () {
	if ( function_exists( 'has_site_icon' ) && has_site_icon() ) {
		return;
	}
	$u = get_stylesheet_directory_uri() . '/assets/icons/';
	echo '<link rel="icon" href="' . esc_url( $u . 'favicon.svg' ) . '" type="image/svg+xml">' . "\n";
	echo '<link rel="icon" href="' . esc_url( $u . 'favicon-32.png' ) . '" sizes="32x32" type="image/png">' . "\n";
	echo '<link rel="apple-touch-icon" href="' . esc_url( $u . 'apple-touch-icon.png' ) . '">' . "\n";
	echo '<link rel="manifest" href="' . esc_url( $u . 'site.webmanifest' ) . '">' . "\n";
	// 2.0.0: no theme colour on product pages, so Safari keeps its own whiteish bars there (1.7.27 made them mint).
	if ( ! ( function_exists( 'is_product' ) && is_product() ) ) {
		echo '<meta name="theme-color" content="#1F8A8A">' . "\n";
	}
}, 3 );

/* ------------------------------------------------------------------ styles */

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'izeltlab-fonts', get_stylesheet_directory_uri() . '/' . izl_min( 'assets/fonts.css' ), array(), IZL_VERSION );
	// 2.1.2: Storefront's Google font (Source Sans Pro) is not shown anywhere (every text uses the bundled fonts), so its
	// request to Google (a slow, render-blocking third-party file, and a visitor's IP sent to Google) is dropped.
	wp_dequeue_style( 'storefront-fonts' );
	// 2.1.2: with Codex on, IBM Plex Mono 400/700 come from Codex's copy of the same files (byte for byte), so the
	// browser downloads them once instead of twice. Same font, same look; without Codex the theme's own files load.
	if ( defined( 'FSZ_URL' ) && is_readable( WP_PLUGIN_DIR . '/codex/assets/fonts/ibm-plex-mono/latin-400.woff2' ) ) {
		$f   = FSZ_URL . 'assets/fonts/ibm-plex-mono/';
		$ext = 'U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF';
		$lat = 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD';
		$css = '';
		foreach ( array( 400, 700 ) as $w ) {
			foreach ( array( 'latin-ext' => $ext, 'latin' => $lat ) as $sub => $range ) {
				$css .= "@font-face{font-family:'Izeltlab Mono';font-style:normal;font-weight:{$w};font-display:swap;src:url(" . esc_url( $f . $sub . '-' . $w . '.woff2' ) . ") format('woff2');unicode-range:{$range}}";
			}
		}
		wp_add_inline_style( 'izeltlab-fonts', $css );
	}
	// The Codex colour theme for the whole shop (style.css itself is loaded by Storefront).
	$teal = izl_teal();
	wp_add_inline_style( 'izeltlab-fonts', ':root{--izl-teal:' . $teal . ';--izl-teal-dark:' . izl_dark( $teal ) . '}' );
	// The front page shows the Codex cards, turning on a carousel when there are more than one.
	if ( is_front_page() && function_exists( 'fsz_enqueue_front' ) ) {
		fsz_enqueue_front();
		// Mirrored resting turn: the card faces the headline and the buttons, so the eye follows it to them.
		wp_add_inline_style( 'izeltlab-fonts', '.izl-hero-card .fsz-device{--fsz-turn:' . ( -1 * (int) fsz_opt( 'turn' ) ) . 'deg!important}' );
		// 1.7.10: the fake resting side stays at its resting size (style.css), the mirror of what Codex's codex.js sets
		// at rest: sideways 1 - turn / ref, down 1 - lean / ref (ref = tilt x 0.65, or 6.5 without tilt), kept 0-2.
		$ref = (float) fsz_opt( 'tilt' ) * 0.65;
		$ref = $ref > 0 ? $ref : 6.5;
		$kx  = max( 0, min( 2, 1 - (float) fsz_opt( 'turn' ) / $ref ) );
		$ky  = max( 0, min( 2, 1 - (float) fsz_opt( 'lean' ) / $ref ) );
		wp_add_inline_style( 'izeltlab-fonts', '.izl-hero-card .fsz-device{--izl-kx:' . round( $kx, 3 ) . ';--izl-ky:' . round( $ky, 3 ) . '}' );
		// The hero's scripts (hero-link.js, home-phone.js, carousel.js) are printed right under the hero since 2.5.0:
		// izl_hero_scripts(), called by front-page.php.
	}
}, 20 );

/**
 * 2.5.0: the hero's three scripts, printed inline right after the hero's markup (front-page.php), so they run before the
 * browser first draws the page: the three cards show up together at their places and sizes, with the title already
 * fitted. Before, they ran at the very end of the page: the front card showed alone for a moment, bigger, with the title
 * running off the screen, then everything jumped into place. In this order: 1.7.2 the card in front opens its product
 * page (before carousel.js, see the script); 2.4.0 phones: the title on one line, the cards at the product page's size;
 * the carousel (only with more than one card).
 */
function izl_hero_scripts() {
	$files = array( 'hero-link', 'home-phone' );
	if ( count( izl_hero_products() ) > 1 ) {
		$files[] = 'carousel';
	}
	foreach ( $files as $f ) {
		$js = (string) file_get_contents( get_stylesheet_directory() . '/' . izl_min( 'assets/' . $f . '.js' ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		echo '<script id="izeltlab-' . esc_attr( $f ) . '-js">' . str_replace( '</script', '<\\/script', $js ) . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

// 2.5.0: the front page's title font (Plex Mono bold) and the logo font are fetched with the page, so the title is fitted
// to its real letters straight away instead of shrinking a moment later.
add_action( 'wp_head', function () {
	if ( ! is_front_page() ) {
		return;
	}
	// 2.8.0: with Codex on, Izeltlab Mono comes from Codex's copy (see above), so that copy is the one fetched early;
	// the theme's own copy was preloaded and then never used (the same font downloaded twice on the front page).
	$theme = get_stylesheet_directory_uri() . '/assets/fonts/';
	$mono  = defined( 'FSZ_URL' ) && is_readable( WP_PLUGIN_DIR . '/codex/assets/fonts/ibm-plex-mono/latin-700.woff2' ) ? FSZ_URL . 'assets/fonts/ibm-plex-mono/' : '';
	$urls  = $mono ? array( $mono . 'latin-700.woff2', $mono . 'latin-ext-700.woff2' ) : array( $theme . 'plex-mono-latin-700.woff2', $theme . 'plex-mono-latin-ext-700.woff2' );
	$urls[] = $theme . 'space-mono-latin-700.woff2';
	foreach ( $urls as $u ) {
		printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( $u ) );
	}
}, 1 );

/* ------------------------------------------------------------------ layout: full width shop pages */

// No sidebar on the shop, product, cart, checkout and account pages and on the front page: the tiles get the room.
function izl_full_width() {
	return is_front_page() || ( function_exists( 'is_woocommerce' ) && ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) );
}

// 2.1.2: Storefront's sticky add-to-cart bar reads the global $product without checking it. When the product loop never
// ran (WooCommerce's "Coming soon" page shown to visitors before launch, a password-protected product) that global is
// still the URL's product slug, a string, and the page died with a fatal error before its footer and scripts. The bar
// is left out only then.
add_action( 'storefront_after_footer', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		remove_action( 'storefront_after_footer', 'storefront_sticky_single_add_to_cart', 999 );
	}
}, 1 );

add_action( 'wp', function () {
	if ( izl_full_width() ) {
		remove_action( 'storefront_sidebar', 'storefront_get_sidebar', 10 );
	}
} );

add_filter( 'body_class', function ( $classes ) {
	if ( izl_full_width() ) {
		$classes[] = 'storefront-full-width-content';
	}
	return $classes;
} );

add_filter( 'storefront_loop_columns', function () {
	return 4;
} );

add_filter( 'woocommerce_output_related_products_args', function ( $args ) {
	$args['posts_per_page'] = 6; // 1.7.0: the small-tile row under every product page
	$args['columns']        = 6;
	return $args;
} );

add_filter( 'woocommerce_upsell_display_args', function ( $args ) {
	$args['posts_per_page'] = 4;
	$args['columns']        = 4;
	return $args;
} );

/* ------------------------------------------------------------------ header: logo, menu, search / account / cart */

add_action( 'init', function () {
	remove_action( 'storefront_header', 'storefront_secondary_navigation', 30 );
	remove_action( 'storefront_header', 'storefront_product_search', 40 );
	remove_action( 'storefront_header', 'storefront_header_cart', 60 );
	remove_action( 'storefront_header', 'storefront_primary_navigation_wrapper', 42 );
	remove_action( 'storefront_header', 'storefront_primary_navigation', 50 );
	remove_action( 'storefront_header', 'storefront_primary_navigation_wrapper_close', 68 );
	add_action( 'storefront_header', 'izl_header_nav', 30 );
	add_action( 'storefront_header', 'izl_header_icons', 35 );
	// Sorting and count only above the products, not twice (the page numbers stay below).
	remove_action( 'woocommerce_after_shop_loop', 'woocommerce_catalog_ordering', 10 );
	remove_action( 'woocommerce_after_shop_loop', 'woocommerce_result_count', 20 );
	// Storefront's previous / next product photos, half hidden at the two screen edges: they look like a broken image.
	remove_action( 'woocommerce_after_single_product_summary', 'storefront_single_product_pagination', 30 );
} );

/**
 * The menu: a menu set under Appearance → Menus → "Main menu (Ízeltláb header)" if there is one,
 * otherwise Isopods, Supplies and For beginners, made from the shop's own categories.
 */
function izl_header_nav() {
	echo '<nav class="izl-nav" aria-label="' . esc_attr__( 'Main menu', 'izeltlab' ) . '">';
	if ( has_nav_menu( 'izeltlab-main' ) ) {
		wp_nav_menu( array( 'theme_location' => 'izeltlab-main', 'container' => false, 'depth' => 1, 'fallback_cb' => false ) );
	} else {
		echo '<ul class="menu">';
		foreach ( izl_menu_items() as $item ) {
			echo '<li' . ( $item[2] ? ' class="is-current"' : '' ) . '><a href="' . esc_url( $item[1] ) . '"' . ( $item[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $item[0] ) . '</a></li>';
		}
		echo '</ul>';
	}
	echo '</nav>';
}

// 2.6.0: on phones the top bar has no menu row (the same slim bar on every page); the list pages show the menu links
// under their title instead (style.css .izl-list-menu, hidden on computers, where the header keeps its menu).
add_action( 'woocommerce_archive_description', 'izl_list_menu', 1 );
function izl_list_menu() {
	$items = izl_menu_items();
	if ( ! $items ) {
		return;
	}
	echo '<nav aria-label="' . esc_attr__( 'Main menu', 'izeltlab' ) . '"><ul class="izl-list-menu">';
	foreach ( $items as $item ) {
		echo '<li' . ( $item[2] ? ' class="is-current"' : '' ) . '><a href="' . esc_url( $item[1] ) . '"' . ( $item[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $item[0] ) . '</a></li>';
	}
	echo '</ul></nav>';
}

function izl_menu_items() {
	$items    = array();
	$isopods  = izl_isopods_url();
	$supplies = izl_supplies_term();
	$level    = isset( $_GET['max_difficulty'] ) ? (int) $_GET['max_difficulty'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	$on       = izl_on_isopods_page();
	if ( $isopods ) {
		$items[] = array( __( 'Isopods', 'izeltlab' ), $isopods, $on && izl_beginner_level() !== $level );
	}
	if ( $supplies ) {
		$items[] = array( __( 'Supplies', 'izeltlab' ), get_term_link( $supplies ), function_exists( 'is_product_category' ) && is_product_category( IZL_SUPPLIES ) );
	}
	// Needs the Codex difficulty filter (WooCommerce → Codex → "Difficulty filter in the shop").
	if ( $isopods && izl_has_codex() && '1' === fsz_opt( 'filter' ) ) {
		$items[] = array( __( 'For beginners', 'izeltlab' ), add_query_arg( 'max_difficulty', izl_beginner_level(), $isopods ), $on && izl_beginner_level() === $level );
	}
	return $items;
}

function izl_icon( $name ) {
	$paths = array(
		'search' => '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
		'user'   => '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>',
		'cart'   => '<path d="M3 5h3l2.5 11h10L21 8H7"/><circle cx="10" cy="20" r="1.4"/><circle cx="17" cy="20" r="1.4"/>',
	);
	return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $paths[ $name ] . '</svg>';
}

// The count on the cart icon. 1.7.18: it carries the cart total too (data-total), so the free-shipping progress on the
// product page knows it right after an add to cart.
function izl_cart_count_html() {
	$n = function_exists( 'WC' ) && WC()->cart ? (int) WC()->cart->get_cart_contents_count() : 0;
	return '<span class="izl-cart-count' . ( $n ? '' : ' is-empty' ) . '" data-total="' . esc_attr( izl_cart_total() ) . '">' . (int) $n . '</span>';
}

function izl_header_icons() {
	if ( ! function_exists( 'wc_get_cart_url' ) ) {
		return;
	}
	echo '<div class="izl-icons">';
	// 2.6.0: opens the search panel under the top bar (inc/finder.php); a plain link to it without JavaScript
	echo '<a class="izl-icon izl-search-btn" href="#izl-sp" role="button" aria-controls="izl-sp" aria-expanded="false" aria-label="' . esc_attr__( 'Search', 'izeltlab' ) . '" title="' . esc_attr__( 'Search', 'izeltlab' ) . '">' . izl_icon( 'search' ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '<a class="izl-icon" href="' . esc_url( wc_get_page_permalink( 'myaccount' ) ) . '" aria-label="' . esc_attr__( 'My account', 'izeltlab' ) . '" title="' . esc_attr__( 'My account', 'izeltlab' ) . '">' . izl_icon( 'user' ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '<a class="izl-icon izl-cart" href="' . esc_url( wc_get_cart_url() ) . '" aria-label="' . esc_attr__( 'Cart', 'izeltlab' ) . '" title="' . esc_attr__( 'Cart', 'izeltlab' ) . '">' . izl_icon( 'cart' ) . izl_cart_count_html() . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	do_action( 'izl_after_cart_icon' ); // 2.1.0: the mini cart (inc/launch.php)
	echo '</div>';
}

// The count on the cart icon follows "add to cart" without a reload.
add_filter( 'woocommerce_add_to_cart_fragments', function ( $fragments ) {
	$fragments['span.izl-cart-count'] = izl_cart_count_html();
	return $fragments;
} );

/* ------------------------------------------------------------------ footer */

// No "Built with WooCommerce" line under the shop: only the copyright stays.
add_filter( 'storefront_credit_link', '__return_false' );

/* ------------------------------------------------------------------ page titles */

// The breadcrumb says "Isopods" there too, not "Shop".
add_filter( 'woocommerce_get_breadcrumb', function ( $crumbs ) {
	if ( $crumbs && izl_on_isopods_page() && is_shop() ) {
		$crumbs[ count( $crumbs ) - 1 ][0] = __( 'Isopods', 'izeltlab' );
	}
	return $crumbs;
} );

// 1.7.11: the breadcrumb is a strip under the header (style.css, woocommerce/global/breadcrumb.php), with a bold ›
// between the steps in place of Storefront's slash.
add_filter( 'woocommerce_breadcrumb_defaults', function ( $defaults ) {
	$defaults['delimiter'] = '<span class="izl-crumb-sep" aria-hidden="true">&#8250;</span>';
	return $defaults;
}, 20 );

add_filter( 'woocommerce_page_title', function ( $title ) {
	return izl_on_isopods_page() ? __( 'Isopods', 'izeltlab' ) : $title;
} );

/* ------------------------------------------------------------------ difficulty pills (in place of the Codex dropdown) */

add_action( 'woocommerce_before_shop_loop', function () {
	if ( ! izl_has_codex() || '1' !== fsz_opt( 'filter' ) ) {
		return;
	}
	// Same pages as the Codex filter: the shop and the isopod categories.
	if ( is_product_category() ) {
		if ( ! in_array( (int) get_queried_object_id(), fsz_category_ids(), true ) ) {
			return;
		}
	} elseif ( ! is_shop() ) {
		return;
	}
	// 1.7.14: the Codex levels instead of stars: All · Beginner (max 2) · Beginner + Intermediate (max 4), each with a dot
	// in its level colour (green, yellow), the same as on the card. An older link (max 1 or 3) lights the pill it falls in.
	$sel  = isset( $_GET['max_difficulty'] ) ? (int) $_GET['max_difficulty'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	$on   = $sel < 1 || $sel > 4 ? 0 : ( $sel <= 2 ? 2 : 4 );
	$base = remove_query_arg( 'max_difficulty', get_pagenum_link( 1, false ) );
	echo '<nav class="izl-pills" aria-label="' . esc_attr__( 'Difficulty', 'izeltlab' ) . '">';
	echo '<a class="izl-pill' . ( $on ? '' : ' is-on' ) . '" href="' . esc_url( $base ) . '"' . ( $on ? '' : ' aria-current="true"' ) . '>' . esc_html__( 'All', 'izeltlab' ) . '</a>';
	$pills = array(
		2 => array( izl_level_word( 1 ), array( 3 ) ),
		/* translators: 1: Beginner, 2: Intermediate (the Codex level words) */
		4 => array( sprintf( __( '%1$s + %2$s', 'izeltlab' ), izl_level_word( 1 ), izl_level_word( 2 ) ), array( 3, 4 ) ),
	);
	foreach ( $pills as $max => $pill ) {
		$dots = '';
		foreach ( $pill[1] as $lv ) {
			$dots .= '<i class="lv' . (int) $lv . '"></i>';
		}
		echo '<a class="izl-pill' . ( $on === $max ? ' is-on' : '' ) . '" href="' . esc_url( add_query_arg( 'max_difficulty', $max, $base ) ) . '"' . ( $on === $max ? ' aria-current="true"' : '' ) . '><span class="izl-pill-dots" aria-hidden="true">' . $dots . '</span>' . esc_html( $pill[0] ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</nav>';
}, 8 );

/* ------------------------------------------------------------------ product tiles (woocommerce/content-product.php) */

/**
 * The first photo, as the Codex card shows it: the Codex image or the featured image, in its Codex framing.
 */
function izl_tile_image( $product, $codex ) {
	$id    = 0;
	$frame = array( 50, 50, 1 );
	if ( $codex && function_exists( 'fsz_card_image_ids' ) ) {
		$ids = fsz_card_image_ids( $product->get_id() );
		$id  = $ids ? (int) $ids[0] : 0;
		if ( $id && function_exists( 'fsz_frame' ) ) {
			$frame = fsz_frame( fsz_frames( $product->get_id() ), $id );
		}
	}
	if ( ! $id ) {
		$id = (int) $product->get_image_id();
		if ( $id && ! $codex && function_exists( 'izl_photo_frame' ) ) {
			$frame = izl_photo_frame( $product->get_id(), $id ); // 1.7.21: Edit photos (inc/photos.php)
		}
	}
	if ( ! $id ) {
		return '<span class="izl-noimg">' . esc_html__( 'No photo yet', 'izeltlab' ) . '</span>';
	}
	$style = sprintf( 'object-position:%1$s%% %2$s%%;transform-origin:%1$s%% %2$s%%;transform:scale(%3$s)', round( $frame[0], 1 ), round( $frame[1], 1 ), round( $frame[2], 3 ) );
	return wp_get_attachment_image( $id, 'woocommerce_single', false, array( 'style' => $style, 'alt' => $product->get_name(), 'sizes' => '(min-width: 1100px) 300px, (min-width: 480px) 45vw, 90vw' ) );
}

function izl_product_tile( $product ) {
	$id    = $product->get_id();
	$codex = izl_is_codex( $id );
	$link  = $product->get_permalink();
	$name  = $product->get_name();
	$latin = '';
	$diff  = 0;
	$color = izl_teal();
	if ( $codex ) {
		$shown = trim( (string) get_post_meta( $id, '_fsz_name', true ) );
		$name  = '' === $shown ? $name : $shown;
		$latin = trim( (string) get_post_meta( $id, '_fsz_latin', true ) );
		$diff  = max( 0, min( 5, (int) get_post_meta( $id, '_fsz_difficulty', true ) ) );
		if ( function_exists( 'fsz_product_color' ) ) {
			$color = fsz_product_color( $id ); // own colour, else its group's (Codex 1.34+)
		} else {
			$own   = sanitize_hex_color( (string) get_post_meta( $id, '_fsz_color', true ) );
			$color = $own ? $own : $color;
		}
	}
	echo '<li ';
	wc_product_class( 'izl-tile ' . ( $codex ? 'is-codex' : 'is-supply' ), $product );
	echo ' style="--izl-tile:' . esc_attr( $color ) . ';--izl-tile-dark:' . esc_attr( izl_dark( $color ) ) . '">';

	echo '<a class="izl-tile-photo woocommerce-LoopProduct-link" href="' . esc_url( $link ) . '" tabindex="-1" aria-hidden="true">' . izl_tile_image( $product, $codex ); // phpcs:ignore WordPress.Security.EscapeOutput
	if ( $codex && function_exists( 'fsz_codex_number' ) ) {
		echo '<span class="izl-num">' . esc_html( fsz_codex_number( $id ) ) . '</span>';
	}
	// 2.2.0: sold out, but still in its place in the grid (Dan, 2026-11-05): a rubber stamp over the photo
	if ( ! $product->is_in_stock() ) {
		echo '<span class="izl-tile-out">' . esc_html__( 'Sold out', 'izeltlab' ) . '</span>';
	}
	echo '</a>';
	if ( $product->is_on_sale() ) {
		echo '<span class="onsale">' . esc_html__( 'Sale', 'izeltlab' ) . '</span>';
	}

	echo '<div class="izl-tile-body">';
	echo '<h2 class="woocommerce-loop-product__title izl-tile-name"><a href="' . esc_url( $link ) . '">' . esc_html( $name ) . '</a></h2>';
	if ( '' !== $latin ) {
		echo '<p class="izl-tile-latin">' . esc_html( $latin ) . '</p>';
	}
	echo '<div class="izl-tile-meta">';
	if ( $diff ) {
		// 1.7.14: the Codex level word in its colour (green, yellow, red), as on the card, instead of 5 stars.
		$level = izl_level( $diff );
		/* translators: %s: the Codex level word (Beginner, Intermediate, Expert) */
		$label = sprintf( __( 'Difficulty: %s', 'izeltlab' ), izl_level_word( $level ) );
		echo '<span class="izl-diff lv' . (int) ( $level + 2 ) . '" title="' . esc_attr( $label ) . '"><span class="screen-reader-text">' . esc_html__( 'Difficulty', 'izeltlab' ) . ': </span>' . esc_html( izl_level_word( $level ) ) . '</span>';
	}
	echo '<span class="price">' . $product->get_price_html() . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '</div>';
	echo '<div class="izl-tile-btns">';
	izl_tile_add_to_cart( $product );
	echo '<a class="izl-more" href="' . esc_url( $link ) . '">' . esc_html( $codex ? __( 'Codex', 'izeltlab' ) : __( 'Details', 'izeltlab' ) ) . '</a>';
	echo '</div></div></li>';
}

// 2.6.0: a product with packs is bought from its tile in one tap: "Kosárba (10 db)" puts the start pack (the one its
// page opens on) in the cart, like a simple product's button (WooCommerce's AJAX add to cart, with the pack's own id).
// Anything else, or a pack that cannot be bought right now, keeps WooCommerce's own button.
function izl_tile_add_to_cart( $product ) {
	if ( $product->is_type( 'variable' ) && $product->is_in_stock() ) {
		$v     = izl_start_variation( $product );
		$attrs = $v ? array_map( 'strval', $v->get_variation_attributes() ) : array();
		if ( $v && $v->is_purchasable() && $v->is_in_stock() && $attrs && ! in_array( '', $attrs, true ) ) {
			$pack = izl_start_pack_name( $product );
			/* translators: %s: the pack, e.g. "10 db" */
			$text = '' !== $pack ? sprintf( __( 'To the cart (%s)', 'izeltlab' ), $pack ) : __( 'To the cart', 'izeltlab' );
			/* translators: 1: the pack, e.g. "10 db", 2: product name */
			$label = sprintf( __( 'Add %1$s of %2$s to the cart', 'izeltlab' ), '' !== $pack ? $pack : '1', $product->get_name() );
			printf(
				'<a href="%1$s" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart izl-tile-pack" data-product_id="%2$d" data-product_sku="%3$s" aria-label="%4$s" rel="nofollow">%5$s</a>',
				esc_url( $v->add_to_cart_url() ),
				(int) $v->get_id(),
				esc_attr( $v->get_sku() ),
				esc_attr( $label ),
				esc_html( $text )
			);
			return;
		}
	}
	woocommerce_template_loop_add_to_cart();
}

/* ------------------------------------------------------------------ new products from the shop pages (1.7.15) */

// Admins add products from the shop: "New product" on a category page starts an empty draft in that category (1.7.16:
// no templates). A draft never reaches shoppers until it is published from the bar over its page.

function izl_can_add_products() {
	return is_user_logged_in() && current_user_can( 'publish_products' );
}

// The page a draft is seen on (drafts open as a preview), with "new" to open its editor.
function izl_draft_link( $id, $new = false ) {
	$url = get_preview_post_link( $id );
	return $new ? add_query_arg( 'izl_new', 1, $url ) : $url;
}

function izl_admin_form( $action, $fields, $button, $confirm = '' ) {
	$out = '<form class="izl-admin-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"' . ( $confirm ? ' onsubmit="return confirm(' . esc_attr( wp_json_encode( $confirm ) ) . ')"' : '' ) . '>';
	$out .= '<input type="hidden" name="action" value="' . esc_attr( $action ) . '">' . wp_nonce_field( $action, '_izl_nonce', true, false );
	foreach ( $fields as $name => $value ) {
		$out .= '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">';
	}
	return $out . $button . '</form>';
}

// The shop pages: "New product". On the shop itself, pick the category first.
function izl_new_product_bar() {
	if ( ! izl_can_add_products() || ! ( is_shop() || is_product_category() ) ) {
		return;
	}
	static $done = false;
	if ( $done ) {
		return;
	}
	$done   = true;
	$button = '<button type="submit" class="izl-btn izl-new-btn">+ ' . esc_html__( 'New product', 'izeltlab' ) . '</button>';
	echo '<div class="izl-newbar">';
	if ( is_product_category() ) {
		echo izl_admin_form( 'izl_new_product', array( 'cat' => get_queried_object_id() ), $button ); // phpcs:ignore WordPress.Security.EscapeOutput
	} else {
		$select = '<select name="cat" required aria-label="' . esc_attr__( 'Category', 'izeltlab' ) . '"><option value="">' . esc_html__( 'Choose a category', 'izeltlab' ) . '</option>';
		$terms  = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'orderby' => 'name' ) );
		$walk   = function ( $parent, $depth ) use ( &$walk, $terms, &$select ) {
			foreach ( $terms as $t ) {
				if ( (int) $t->parent === (int) $parent && 'uncategorized' !== $t->slug ) {
					$select .= '<option value="' . (int) $t->term_id . '">' . str_repeat( '— ', $depth ) . esc_html( $t->name ) . '</option>';
					$walk( $t->term_id, $depth + 1 );
				}
			}
		};
		$walk( 0, 0 );
		$select .= '</select>';
		echo izl_admin_form( 'izl_new_product', array(), $select . $button ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</div>';
}
add_action( 'woocommerce_before_shop_loop', 'izl_new_product_bar', 7 );
add_action( 'woocommerce_no_products_found', 'izl_new_product_bar', 5 );

// "New product": an empty draft in the category (and its parents), opened with its editor.
add_action( 'admin_post_izl_new_product', function () {
	check_admin_referer( 'izl_new_product', '_izl_nonce' );
	$term = get_term( isset( $_POST['cat'] ) ? absint( $_POST['cat'] ) : 0, 'product_cat' );
	if ( ! izl_can_add_products() || ! $term || is_wp_error( $term ) ) {
		wp_die( esc_html__( 'You cannot add products here.', 'izeltlab' ) );
	}
	$p = new WC_Product_Simple();
	$p->set_status( 'draft' );
	$p->set_name( izl_shop_text( 'New product' ) ); // the shop's language, whatever the admin's own
	$p->update_meta_data( '_izl_auto_title', 1 ); // Publish names it from the card when it is a species
	$cats = array( (int) $term->term_id );
	foreach ( get_ancestors( $term->term_id, 'product_cat', 'taxonomy' ) as $a ) {
		$cats[] = (int) $a;
	}
	$p->set_category_ids( $cats );
	$id = $p->save();
	// A genus page (a category under the group) starts the Latin name with the genus.
	if ( $term->parent && izl_is_codex( $id ) ) {
		update_post_meta( $id, '_fsz_latin', $term->name );
	}
	wp_safe_redirect( izl_draft_link( $id, true ) );
	exit;
} );

// "Publish" (and "Save name") on a draft.
add_action( 'admin_post_izl_publish', function () {
	check_admin_referer( 'izl_publish', '_izl_nonce' );
	$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
	$p  = $id ? wc_get_product( $id ) : null;
	if ( ! $p || ! izl_can_add_products() || ! current_user_can( 'edit_post', $id ) ) {
		wp_die( esc_html__( 'This product cannot be published from here.', 'izeltlab' ) );
	}
	$name = isset( $_POST['name'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['name'] ) ) ) : '';
	if ( '' !== $name ) {
		$p->set_name( $name );
		$p->delete_meta_data( '_izl_auto_title' );
	} elseif ( $p->get_meta( '_izl_auto_title' ) && izl_is_codex( $id ) ) {
		// A species is named like the others: "Latin – „Nickname”" (the name only search engines and screen readers get).
		$latin = trim( (string) get_post_meta( $id, '_fsz_latin', true ) );
		$nick  = trim( (string) get_post_meta( $id, '_fsz_name', true ) );
		if ( '' !== $latin && '' !== $nick ) {
			$p->set_name( $latin . ' – „' . $nick . '”' );
		} elseif ( '' !== $nick . $latin ) {
			$p->set_name( '' !== $nick ? $nick : $latin );
		}
	}
	$publish = ! empty( $_POST['publish'] );
	if ( $publish ) {
		$p->delete_meta_data( '_izl_auto_title' );
		$p->set_status( 'publish' );
	}
	$p->save();
	wp_safe_redirect( $publish ? get_permalink( $id ) : izl_draft_link( $id ) );
	exit;
} );

// "Delete": a draft goes to the trash (WordPress keeps it there for 30 days).
add_action( 'admin_post_izl_trash', function () {
	check_admin_referer( 'izl_trash', '_izl_nonce' );
	$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
	if ( ! $id || 'draft' !== get_post_status( $id ) || ! current_user_can( 'delete_post', $id ) ) {
		wp_die( esc_html__( 'Only drafts can be deleted from here.', 'izeltlab' ) );
	}
	$group = izl_group_term( $id );
	wp_trash_post( $id );
	$link = $group ? get_term_link( $group ) : '';
	wp_safe_redirect( $link && ! is_wp_error( $link ) ? $link : wc_get_page_permalink( 'shop' ) );
	exit;
} );

// On a draft's page: a bar over the page saying so, with Publish / Delete (and a name field for products without a
// Codex card, whose name shows on the page).
add_action( 'woocommerce_before_single_product', function () {
	$id = get_the_ID();
	if ( ! $id || 'draft' !== get_post_status( $id ) || ! izl_can_add_products() || ! current_user_can( 'edit_post', $id ) ) {
		return;
	}
	$codex = izl_is_codex( $id );
	echo '<div class="izl-draftbar">';
	echo '<p class="izl-draftbar-text"><b>' . esc_html__( 'Draft', 'izeltlab' ) . '</b> ' . esc_html( $codex ? __( 'Shoppers cannot see this page yet. Fill in the card and the buy box, then publish.', 'izeltlab' ) : __( 'Shoppers cannot see this page yet. Name it, fill in the buy box, then publish.', 'izeltlab' ) ) . '</p>';
	$name   = get_post_meta( $id, '_izl_auto_title', true ) ? '' : get_the_title( $id );
	$fields = $codex ? '' : '<label class="izl-draftbar-name"><span>' . esc_html__( 'Name', 'izeltlab' ) . '</span><input type="text" name="name" value="' . esc_attr( html_entity_decode( $name, ENT_QUOTES, 'UTF-8' ) ) . '" required></label><button type="submit" class="izl-btn is-alt">' . esc_html__( 'Save name', 'izeltlab' ) . '</button>';
	echo izl_admin_form( 'izl_publish', array( 'id' => $id ), $fields . '<button type="submit" name="publish" value="1" class="izl-btn">' . esc_html__( 'Publish', 'izeltlab' ) . '</button>' ); // phpcs:ignore WordPress.Security.EscapeOutput
	echo izl_admin_form( 'izl_trash', array( 'id' => $id ), '<button type="submit" class="izl-btn is-alt">' . esc_html__( 'Delete', 'izeltlab' ) . '</button>', __( 'Delete this draft?', 'izeltlab' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
	echo '</div>';
	// Just made with "New product": open the card editor (species) or the buy box editor (everything else).
	if ( ! empty( $_GET['izl_new'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		echo '<script>(function(){var n=0,t=setInterval(function(){var b=document.querySelector(' . wp_json_encode( $codex ? '.fsz-edit-open' : '.izl-buybox-open' ) . ');if(b||++n>40){clearInterval(t);if(b){b.click();}}},150);})();</script>';
	}
}, 5 );

/* ------------------------------------------------------------------ front page (front-page.php) */

function izl_home_defaults() {
	return array(
		'izl_hero_kicker' => __( 'Straight from the breeder', 'izeltlab' ),
		'izl_hero_title'  => __( 'Isopods for every terrarium', 'izeltlab' ),
		'izl_hero_text'   => __( 'Every species has its own Codex card: difficulty, care and good-to-know facts in one place, so you can choose with confidence.', 'izeltlab' ),
		'izl_about_title' => __( 'About the breeder', 'izeltlab' ),
		'izl_about_text'  => __( 'Write a few lines about yourself here: who you are, how long you have been breeding and what you pay attention to. (Edit it under Appearance → Customize → Ízeltláb front page.)', 'izeltlab' ),
	);
}

function izl_mod( $key ) {
	$d = izl_home_defaults();
	$v = get_theme_mod( $key, '' );
	return '' === trim( (string) $v ) ? $d[ $key ] : $v;
}

// The 3 Customizer slots of the front page carousel (the first one is the card in front at the start).
function izl_hero_slots() {
	return array( 'izl_hero_product', 'izl_hero_product_2', 'izl_hero_product_3' );
}

// The hover effect of the back cards (1.7.1): its name and strength 0-100 (0 = none), set in the "Edit cards" panel.
function izl_card_fx_strength() {
	return max( 0, min( 100, (int) get_theme_mod( 'izl_card_fx_strength', 60 ) ) );
}

// How many cards the front page shows (1-3; 1 = a single card, no carousel).
function izl_hero_count() {
	return max( 1, min( 3, (int) get_theme_mod( 'izl_hero_count', 3 ) ) );
}

/**
 * The species on the front page carousel, front card first: the ones picked in the Customizer or the quick edit,
 * an empty slot takes the Codex #001 (first slot) or the newest species not shown yet.
 */
function izl_hero_products() {
	$picked = array();
	foreach ( array_slice( izl_hero_slots(), 0, izl_hero_count() ) as $slot ) {
		$id       = absint( get_theme_mod( $slot, 0 ) );
		$picked[] = $id && 'publish' === get_post_status( $id ) && izl_is_codex( $id ) ? $id : 0;
	}
	$oldest = izl_codex_product_ids( 1, 'ASC' );
	$fill   = array_merge( $oldest, izl_codex_product_ids( 0 ) );
	$cards  = array();
	foreach ( $picked as $i => $id ) {
		if ( ! $id || in_array( $id, $cards, true ) ) {
			$id = 0;
			foreach ( $fill as $f ) {
				if ( ! in_array( (int) $f, $cards, true ) && ! in_array( (int) $f, $picked, true ) ) {
					$id = (int) $f;
					break;
				}
			}
		}
		if ( $id ) {
			$cards[] = $id;
		}
	}
	return $cards;
}

/**
 * Published, visible products of the isopod categories (or of one category, by slug), newest first.
 * $limit 0 = all.
 */
function izl_codex_product_ids( $limit = 4, $order = 'DESC' ) {
	if ( ! izl_has_codex() || ! function_exists( 'wc_get_products' ) ) {
		return array();
	}
	$slugs = wp_list_pluck( izl_isopod_terms(), 'slug' );
	if ( ! $slugs ) {
		return array();
	}
	$ids = wc_get_products( array(
		'status'     => 'publish',
		'visibility' => 'catalog',
		'category'   => $slugs,
		'limit'      => $limit ? $limit * 2 : -1, // a few more, in case some hide their card
		'orderby'    => 'date',
		'order'      => $order,
		'return'     => 'ids',
	) );
	$ids = array_values( array_filter( $ids, 'izl_is_codex' ) );
	return $limit ? array_slice( $ids, 0, $limit ) : $ids;
}

function izl_category_product_ids( $slug, $limit = 4 ) {
	if ( ! function_exists( 'wc_get_products' ) ) {
		return array();
	}
	return wc_get_products( array(
		'status'     => 'publish',
		'visibility' => 'catalog',
		'category'   => array( $slug ),
		'limit'      => $limit,
		'orderby'    => 'date',
		'order'      => 'DESC',
		'return'     => 'ids',
	) );
}

// A row of product tiles, the same as on the shop.
function izl_product_row( $ids ) {
	if ( ! $ids ) {
		return;
	}
	global $post;
	wc_set_loop_prop( 'columns', 4 );
	woocommerce_product_loop_start();
	foreach ( $ids as $id ) {
		$post = get_post( $id ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride
		setup_postdata( $post );
		wc_get_template_part( 'content', 'product' );
	}
	woocommerce_product_loop_end();
	wp_reset_postdata();
	wc_reset_loop();
}

/* ------------------------------------------------------------------ Customizer: Appearance → Customize → Ízeltláb front page */

add_action( 'customize_register', function ( $wp_customize ) {
	$wp_customize->add_section( 'izl_home', array(
		'title'       => __( 'Ízeltláb front page', 'izeltlab' ),
		'description' => __( 'Texts of the front page. Leave a field empty for the default text.', 'izeltlab' ),
		'priority'    => 30,
	) );
	$fields = array(
		'izl_hero_kicker' => array( __( 'Small label above the title', 'izeltlab' ), 'text' ),
		'izl_hero_title'  => array( __( 'Title', 'izeltlab' ), 'text' ),
		'izl_hero_text'   => array( __( 'Text under the title', 'izeltlab' ), 'textarea' ),
		'izl_about_title' => array( __( 'About: title', 'izeltlab' ), 'text' ),
		'izl_about_text'  => array( __( 'About: text', 'izeltlab' ), 'textarea' ),
	);
	foreach ( $fields as $key => $f ) {
		$wp_customize->add_setting( $key, array( 'default' => '', 'sanitize_callback' => 'textarea' === $f[1] ? 'wp_kses_post' : 'sanitize_text_field' ) );
		$wp_customize->add_control( $key, array( 'label' => $f[0], 'section' => 'izl_home', 'type' => $f[1], 'input_attrs' => array( 'placeholder' => izl_home_defaults()[ $key ] ) ) );
	}
	$choices = array( 0 => __( 'Automatic', 'izeltlab' ) );
	foreach ( izl_codex_product_ids( 0, 'ASC' ) as $id ) {
		$choices[ $id ] = ( function_exists( 'fsz_codex_number' ) ? fsz_codex_number( $id ) . ' ' : '' ) . html_entity_decode( get_the_title( $id ), ENT_QUOTES, 'UTF-8' );
	}
	$wp_customize->add_setting( 'izl_hero_count', array( 'default' => 3, 'sanitize_callback' => 'absint' ) );
	$wp_customize->add_control( 'izl_hero_count', array(
		'label'   => __( 'Number of Codex cards', 'izeltlab' ),
		'section' => 'izl_home',
		'type'    => 'select',
		'choices' => array( 1 => '1', 2 => '2', 3 => '3' ),
	) );
	$labels = array(
		__( 'Codex card 1 (in front at the start)', 'izeltlab' ),
		__( 'Codex card 2', 'izeltlab' ),
		__( 'Codex card 3', 'izeltlab' ),
	);
	foreach ( izl_hero_slots() as $i => $slot ) {
		$wp_customize->add_setting( $slot, array( 'default' => 0, 'sanitize_callback' => 'absint' ) );
		$wp_customize->add_control( $slot, array(
			'label'       => $labels[ $i ],
			'description' => $i ? '' : __( 'Automatic: card 1 is the Codex #001, the others the newest species.', 'izeltlab' ),
			'section'     => 'izl_home',
			'type'        => 'select',
			'choices'     => $choices,
		) );
	}
} );

/* ------------------------------------------------------------------ front page quick edit (logged-in admins): number of cards and which species */

function izl_can_edit_home() {
	return is_user_logged_in() && current_user_can( 'edit_theme_options' );
}

// The "Edit cards" button and its panel, next to the cards (front-page.php).
function izl_home_edit_panel() {
	if ( ! izl_can_edit_home() ) {
		return;
	}
	$species = izl_codex_product_ids( 0, 'ASC' );
	$count   = izl_hero_count();
	echo '<button type="button" class="izl-edit-open" aria-haspopup="dialog">' . esc_html__( 'Edit cards', 'izeltlab' ) . '</button>';
	echo '<dialog class="izl-edit" aria-labelledby="izl-edit-title"><form method="dialog">';
	echo '<h2 id="izl-edit-title">' . esc_html__( 'Front page cards', 'izeltlab' ) . '</h2>';
	echo '<fieldset class="izl-edit-count"><legend>' . esc_html__( 'Number of cards', 'izeltlab' ) . '</legend>';
	for ( $i = 1; $i <= 3; $i++ ) {
		echo '<label><input type="radio" name="count" value="' . (int) $i . '"' . checked( $count, $i, false ) . '><span>' . (int) $i . '</span></label>';
	}
	echo '</fieldset>';
	foreach ( izl_hero_slots() as $i => $slot ) {
		$sel = absint( get_theme_mod( $slot, 0 ) );
		/* translators: %d: card number, 1-3 */
		$label = 0 === $i ? __( 'Card 1 (in front at the start)', 'izeltlab' ) : sprintf( __( 'Card %d', 'izeltlab' ), $i + 1 );
		echo '<label class="izl-edit-card" data-card="' . (int) ( $i + 1 ) . '"><span>' . esc_html( $label ) . '</span><select name="' . esc_attr( $slot ) . '">';
		echo '<option value="0">' . esc_html_x( 'Automatic', 'quick edit: the species is picked by itself', 'izeltlab' ) . '</option>';
		foreach ( $species as $id ) {
			$name = ( function_exists( 'fsz_codex_number' ) ? fsz_codex_number( $id ) . ' ' : '' ) . html_entity_decode( get_the_title( $id ), ENT_QUOTES, 'UTF-8' );
			echo '<option value="' . (int) $id . '"' . selected( $sel, $id, false ) . '>' . esc_html( $name ) . '</option>';
		}
		echo '</select></label>';
	}
	echo '<p class="izl-edit-note">' . esc_html__( 'Automatic: card 1 shows the Codex #001, the others the newest species.', 'izeltlab' ) . '</p>';
	// 1.7.1: what the back cards do under the mouse. Shown on the cards behind this panel while it is open.
	echo '<fieldset class="izl-edit-fx"><legend>' . esc_html__( 'Back cards on hover', 'izeltlab' ) . '</legend>';
	echo '<label class="izl-edit-fx-range"><span>' . esc_html__( 'Float height', 'izeltlab' ) . ' <output>' . (int) izl_card_fx_strength() . '</output></span><input type="range" name="fx_strength" min="0" max="100" step="5" value="' . (int) izl_card_fx_strength() . '"></label>';
	echo '<p class="izl-edit-note">' . esc_html__( 'A pointed-at back card floats up. The cards behind this panel show it. 0 = no float.', 'izeltlab' ) . '</p></fieldset>';
	echo '<p class="izl-edit-msg" role="status"></p>';
	echo '<div class="izl-edit-btns"><button type="submit" value="cancel" class="izl-btn is-alt">' . esc_html__( 'Cancel', 'izeltlab' ) . '</button><button type="button" class="izl-btn izl-edit-save">' . esc_html__( 'Save', 'izeltlab' ) . '</button></div>';
	echo '</form></dialog>';
}

add_action( 'wp_enqueue_scripts', function () {
	if ( is_front_page() && izl_can_edit_home() ) {
		wp_enqueue_script( 'izeltlab-home-edit', get_stylesheet_directory_uri() . '/' . izl_min( 'assets/home-edit.js' ), array(), IZL_VERSION, true );
		wp_localize_script( 'izeltlab-home-edit', 'izlHomeEdit', array(
			'ajax'   => admin_url( 'admin-ajax.php', 'relative' ),
			'nonce'  => wp_create_nonce( 'izl_home_edit' ),
			'saving' => __( 'Saving…', 'izeltlab' ),
			'failed' => __( 'Could not save. Please try again.', 'izeltlab' ),
		) );
	}
}, 30 );

// Saves into the same settings as the Customizer, so the two always match.
add_action( 'wp_ajax_izl_home_edit', function () {
	check_ajax_referer( 'izl_home_edit', 'nonce' );
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_send_json_error( null, 403 );
	}
	set_theme_mod( 'izl_hero_count', max( 1, min( 3, isset( $_POST['count'] ) ? absint( $_POST['count'] ) : 3 ) ) );
	foreach ( izl_hero_slots() as $slot ) {
		$id = isset( $_POST[ $slot ] ) ? absint( $_POST[ $slot ] ) : 0;
		set_theme_mod( $slot, $id && izl_is_codex( $id ) ? $id : 0 );
	}
	remove_theme_mod( 'izl_card_fx' ); // the effect choice (1.7.1-1.7.4); the float is the only effect since 1.7.5
	if ( isset( $_POST['fx_strength'] ) ) {
		set_theme_mod( 'izl_card_fx_strength', max( 0, min( 100, absint( $_POST['fx_strength'] ) ) ) );
	}
	wp_send_json_success();
} );

/* ------------------------------------------------------------------ product page: the buy box next to the Codex card */

/**
 * The buy box is a "trust stack": sales line (species: instead of the name), pack choice, price with the VAT note,
 * quantity and the cart button, the stock line, then the trust points, the short description and a few questions.
 * Species (Codex products) get all of it; supplies get the price row, the pack choice and the quantity buttons.
 */
function izl_product_defaults() {
	$answer = __( 'Write the answer here: Appearance → Customize → Ízeltláb product page.', 'izeltlab' );
	return array(
		'izl_trust_1_title'    => __( 'Live arrival guarantee', 'izeltlab' ),
		'izl_trust_1_text'     => __( 'If something goes wrong on the way, we replace it or refund you.', 'izeltlab' ),
		'izl_trust_2_title'    => __( 'Insulated packaging', 'izeltlab' ),
		'izl_trust_2_text'     => __( 'Sent Monday to Wednesday, so it never spends a weekend in transit.', 'izeltlab' ),
		'izl_trust_3_title'    => __( 'Bred by us in Budapest', 'izeltlab' ),
		'izl_trust_3_text'     => __( 'Personal pickup is possible too.', 'izeltlab' ),
		'izl_trust_difficulty' => 1,
		'izl_faq_1_q'          => __( 'What exactly do I get?', 'izeltlab' ),
		'izl_faq_1_a'          => $answer,
		'izl_faq_2_q'          => __( 'How do you ship in winter?', 'izeltlab' ),
		'izl_faq_2_a'          => $answer,
		'izl_faq_3_q'          => '',
		'izl_faq_3_a'          => '',
		'izl_faq_4_q'          => '',
		'izl_faq_4_a'          => '',
		'izl_faq_5_q'          => '',
		'izl_faq_5_a'          => '',
		'izl_faq_6_q'          => '',
		'izl_faq_6_a'          => '',
		'izl_vat_note'         => __( 'incl. 27% VAT', 'izeltlab' ),
		'izl_free_ship'        => 18000,
		'izl_pack_question'    => __( 'How many do you want to start with?', 'izeltlab' ),
		'izl_pack_tip'         => __( 'A bigger pack starts the colony faster.', 'izeltlab' ),
		'izl_drawer_trim'      => 14, // 2.0.5: px off the room above Kosárba vele! in the closed phone drawer
		'izl_drawer_203'       => 0,  // 2.0.5: roll-back switch: the phone drawer of 2.0.3
	);
}

// A product page setting. An emptied field stays empty (that point is hidden); never set = the default.
function izl_pmod( $key ) {
	$d = izl_product_defaults();
	return get_theme_mod( $key, isset( $d[ $key ] ) ? $d[ $key ] : '' );
}

function izl_on_codex_product() {
	return function_exists( 'is_product' ) && is_product() && izl_is_codex( get_queried_object_id() );
}

add_action( 'wp', function () {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}
	remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
	add_action( 'woocommerce_single_product_summary', 'izl_price_row', 10 );
	add_action( 'woocommerce_single_product_summary', 'izl_sales_line', 7 );
	add_action( 'woocommerce_before_variations_form', 'izl_pack_question' );
	add_action( 'woocommerce_single_product_summary', 'izl_stock_line', 31 );
	add_action( 'woocommerce_single_product_summary', 'izl_ship_lines', 32 );
	add_filter( 'woocommerce_get_stock_html', 'izl_hide_wc_stock', 10, 2 );
	// 1.7.0: the row of small tiles under every product page has its own title per product (the Upsells first, see
	// izl_row_products), so there is no separate "You may also like…" block.
	remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
	remove_action( 'woocommerce_after_single_product_summary', 'storefront_upsell_display', 15 ); // Storefront's own copy
	add_filter( 'woocommerce_product_related_products_heading', 'izl_row_title' );
	if ( ! izl_on_codex_product() ) {
		// Supplies: the description right under the buy box (no tabs), categories and tags as pills under the photo.
		remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
		add_action( 'woocommerce_single_product_summary', 'izl_description', 45 );
		add_action( 'woocommerce_after_single_product_summary', 'izl_term_pills', 1 ); // floated under the photo (style.css)
		return;
	}
	// 1.7.18: species pages: the packs set the amount, so the quantity buttons are hidden (style.css).
	add_filter( 'body_class', function ( $classes ) {
		$classes[] = 'izl-species';
		return $classes;
	} );
	// The Codex card next to the buy box already shows the names (nickname, English, Latin on its detail page), so the
	// buy box does not repeat them.
	// The name stays in the page as the main heading, hidden, for search engines and screen readers.
	remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
	add_action( 'woocommerce_single_product_summary', 'izl_hidden_title', 5 );
	// 2.1.2: the fallback for Codex before 1.35 is gone; Codex itself puts its one card in place of the photos.
	remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
	// The short description goes under the trust points (unless the Codex "Hide WooCommerce details" removed it).
	if ( false !== has_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt' ) ) {
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
		add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 35 );
	}
	// 1.6.0: under the cart button "Goes well with" (supplies); the trust points as one line under the card and the buy
	// box, then the common questions, then the small-tile row ("Similar species").
	add_action( 'woocommerce_single_product_summary', 'izl_setup_items', 34 );
	add_action( 'woocommerce_single_product_summary', 'izl_codex_tag_chips', 6 ); // 1.7.13: above the sales line
	add_action( 'woocommerce_after_single_product_summary', 'izl_trust_points', 5 );
	add_action( 'woocommerce_after_single_product_summary', 'izl_product_faq', 8 );
	add_filter( 'body_class', function ( $classes ) {
		$classes[] = 'izl-codex-product';
		// 2.5.3: packs (variable products) are known from the first byte, so the card can be placed for the pack drawer
		// before the buy form further down the page has arrived (the card no longer moves when it does).
		$product = wc_get_product( get_queried_object_id() );
		if ( $product && $product->is_type( 'variable' ) ) {
			$classes[] = 'izl-pack';
		}
		return $classes;
	} );
}, 20 );

define( 'IZL_SETUP_COUNT', 3 ); // supplies under the cart button

// What to put next to this species: the product's own cross-sells (Product data → Linked products → Cross-sells),
// else supplies from Kiegészítők. Only simple products that can be bought right now, so "+" can add them at once.
function izl_setup_products( $product ) {
	$ok = function ( $p ) {
		return $p instanceof WC_Product && $p->is_type( 'simple' ) && $p->is_purchasable() && $p->is_in_stock() && 'publish' === $p->get_status();
	};
	$out = array();
	foreach ( $product->get_cross_sell_ids() as $id ) {
		$p = wc_get_product( $id );
		if ( $ok( $p ) ) {
			$out[] = $p;
		}
	}
	if ( count( $out ) < IZL_SETUP_COUNT ) {
		$cat = get_term_by( 'slug', 'kiegeszitok', 'product_cat' );
		if ( $cat ) {
			$more = wc_get_products( array(
				'status'       => 'publish',
				'type'         => 'simple',
				'stock_status' => 'instock',
				'category'     => array( $cat->slug ),
				'exclude'      => array_merge( array( $product->get_id() ), array_map( function ( $p ) {
					return $p->get_id();
				}, $out ) ), // 2.1.1: was wp_list_pluck( $out, 'id' ) (a protected property)
				'limit'        => IZL_SETUP_COUNT * 2,
				'orderby'      => 'popularity',
			) );
			foreach ( $more as $p ) {
				if ( $ok( $p ) ) {
					$out[] = $p;
				}
			}
		}
	}
	return array_slice( $out, 0, IZL_SETUP_COUNT );
}

// "Goes well with": a few supplies right under the cart button, each with its price and a "+" that puts it in the cart
// without leaving the page (WooCommerce's own AJAX add to cart). The moment someone decides is when they add more.
function izl_setup_items() {
	global $product;
	if ( ! $product instanceof WC_Product || ! $product->is_in_stock() ) {
		return;
	}
	$items = izl_setup_products( $product );
	// 1.7.19: three is the staple. Whoever can edit the shop also sees the empty places, up to three; shoppers never.
	$empty = current_user_can( 'edit_products' ) ? IZL_SETUP_COUNT - count( $items ) : 0;
	if ( ! $items && ! $empty ) {
		return;
	}
	wp_enqueue_script( 'wc-add-to-cart' );
	echo '<div class="izl-setup"><p class="izl-setup-title">' . esc_html__( 'Goes well with', 'izeltlab' ) . '</p><ul>';
	foreach ( $items as $p ) {
		$link = get_permalink( $p->get_id() );
		/* translators: %s: product name */
		$add   = sprintf( __( 'Add %s to the cart', 'izeltlab' ), $p->get_name() );
		$group = izl_setup_group( $p->get_id() );
		echo '<li style="--izl-c:' . esc_attr( $group['color'] ) . '"><a class="izl-setup-photo" href="' . esc_url( $link ) . '" tabindex="-1" aria-hidden="true">' . $p->get_image( 'woocommerce_gallery_thumbnail' ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<span class="izl-setup-text"><span class="izl-setup-group">' . esc_html( $group['name'] ) . '</span><a class="izl-setup-name" href="' . esc_url( $link ) . '">' . esc_html( $p->get_name() ) . '</a></span>';
		echo '<span class="izl-setup-price">' . $p->get_price_html() . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<a href="' . esc_url( $p->add_to_cart_url() ) . '" data-quantity="1" data-product_id="' . (int) $p->get_id() . '" data-product_sku="' . esc_attr( $p->get_sku() ) . '" data-izl-price="' . esc_attr( (float) wc_get_price_to_display( $p ) ) . '" class="izl-setup-add add_to_cart_button ajax_add_to_cart" rel="nofollow" aria-label="' . esc_attr( $add ) . '" title="' . esc_attr( $add ) . '"><span aria-hidden="true">+</span></a></li>';
	}
	for ( $i = 0; $i < $empty; $i++ ) {
		echo '<li class="izl-setup-empty"><b>' . esc_html__( 'Empty place', 'izeltlab' ) . '</b><span>' . esc_html__( 'No product set up · only you see this', 'izeltlab' ) . '</span></li>';
	}
	echo '</ul></div>';
}

// 1.7.19: the group of a "Goes well with" product, for its colour strip: name and colour. Supplies say "Supply" in one
// word; the colour is the group's Codex colour, else a calm grey-green.
function izl_setup_group( $product_id ) {
	$term     = izl_group_term( $product_id );
	$supplies = izl_supplies_term();
	$color    = $term ? (string) sanitize_hex_color( (string) get_term_meta( $term->term_id, 'fsz_color', true ) ) : ''; // the Codex group colour
	if ( $term && $supplies && (int) $term->term_id === (int) $supplies->term_id ) {
		return array( 'name' => _x( 'Supply', 'one supply product', 'izeltlab' ), 'color' => $color ? $color : '#8aa39b' );
	}
	return array( 'name' => $term ? $term->name : '', 'color' => $color ? $color : '#8aa39b' );
}

function izl_hidden_title() {
	echo '<h1 class="product_title entry-title screen-reader-text">' . esc_html( get_the_title() ) . '</h1>';
}

/* ------------------------------------------------------------------ buy box: sales line, pack question, stock line */

// Per product texts, in Product data → General, and on the product page for whoever can edit it (click Edit).
function izl_product_texts() {
	return array(
		'_izl_headline' => array( 'Sales line', 'One short sentence at the top of the buy box: why buy this one. Empty = nothing, the price moves up.' ),
		'_izl_pack_tip' => array( 'Pack tip', 'One line under "How many do you want to start with?" (products with packs). Empty = the default from Customize → Ízeltláb product page.' ),
		'_izl_row_title' => array( 'Row title', 'The title over the row of small product tiles under the page. Empty = "Similar species" (species) or "You might also need" (everything else).' ),
	);
}

add_action( 'woocommerce_product_options_general_product_data', function () {
	echo '<div class="options_group">';
	foreach ( izl_product_texts() as $key => $t ) {
		woocommerce_wp_text_input( array( 'id' => $key, 'label' => $t[0], 'description' => $t[1], 'desc_tip' => true ) );
	}
	echo '</div>';
} );

add_action( 'woocommerce_process_product_meta', function ( $post_id ) {
	foreach ( array_keys( izl_product_texts() ) as $key ) {
		if ( isset( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- WooCommerce checked the product form nonce
			update_post_meta( $post_id, $key, sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
		}
	}
} );

// The text with an Edit button for whoever can edit the product. Empty: visitors see nothing, editors a grey sample
// text in its place (click it or Edit to write the real one).
function izl_editable_text( $key, $text, $tag, $class, $sample ) {
	$can = current_user_can( 'edit_post', get_the_ID() );
	if ( '' === $text && ! $can ) {
		return;
	}
	$attrs = $can ? ' data-izl-edit="' . esc_attr( $key ) . '" data-izl-sample="' . esc_attr( $sample ) . '"' : '';
	echo '<' . $tag . ' class="' . esc_attr( $class . ( '' === $text ? ' is-empty' : '' ) ) . '"' . $attrs . '><span class="izl-edit-text">' . esc_html( '' === $text ? $sample : $text ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
	if ( $can ) {
		echo '<button type="button" class="izl-edit-btn">Edit</button>';
	}
	echo '</' . $tag . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
}

// The sales line: the reason to buy, where the name used to be.
function izl_sales_line() {
	izl_editable_text( '_izl_headline', trim( (string) get_post_meta( get_the_ID(), '_izl_headline', true ) ), 'p', 'izl-sales-line', '(add the sales line here)' );
}

// 1.7.13: the Codex tags as chips above the sales line, each a link to the shop filtered to that tag. Codex 1.38 also
// saves them as WooCommerce product tags; a tag without its shop page yet is left out.
function izl_codex_tag_chips() {
	$id   = get_the_ID();
	$tags = function_exists( 'fsz_tags' ) ? fsz_tags( $id ) : array();
	$out  = '';
	foreach ( $tags as $name ) {
		$term = get_term_by( 'name', $name, 'product_tag' );
		$link = $term ? get_term_link( $term ) : '';
		if ( $link && ! is_wp_error( $link ) ) {
			$out .= '<a href="' . esc_url( $link ) . '" rel="tag">' . esc_html( $name ) . '</a>';
		}
	}
	if ( '' !== $out ) {
		echo '<nav class="izl-tagchips" aria-label="' . esc_attr__( 'Tags', 'izeltlab' ) . '">' . $out . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

// Above the pack buttons: the question that makes them a choice, and a tip that leans towards the bigger pack.
function izl_pack_question() {
	global $product;
	if ( ! $product instanceof WC_Product_Variable || count( $product->get_children() ) < 2 ) {
		return;
	}
	$q = trim( (string) izl_pmod( 'izl_pack_question' ) );
	if ( '' !== $q ) {
		echo '<p class="izl-pack-q">' . esc_html( $q ) . '</p>';
	}
	$tip = trim( (string) get_post_meta( get_the_ID(), '_izl_pack_tip', true ) );
	if ( '' === $tip ) {
		$tip = trim( (string) izl_pmod( 'izl_pack_tip' ) );
	}
	izl_editable_text( '_izl_pack_tip', $tip, 'p', 'izl-pack-tip', '(add a pack tip here)' );
}

/* ------------------------------------------------------------------ buy ticket: stock stamp, ship lines, price row */

define( 'IZL_LOW_STOCK', 3 ); // this many or fewer in stock: "Only N left"

// [state, label] for a product or a pack: in, low, back(order), out.
function izl_stock_state( $product ) {
	if ( ! $product->is_in_stock() ) {
		return array( 'out', __( 'Currently unavailable', 'izeltlab' ) );
	}
	if ( $product->is_on_backorder( 1 ) ) {
		return array( 'back', __( 'Available to order', 'izeltlab' ) );
	}
	$qty = $product->managing_stock() ? (int) $product->get_stock_quantity() : 0;
	if ( $qty > 0 && $qty <= IZL_LOW_STOCK ) {
		/* translators: %d: how many are left */
		return array( 'low', sprintf( __( 'Only %d left', 'izeltlab' ), $qty ) );
	}
	return array( 'in', __( 'In stock', 'izeltlab' ) );
}

// The stock stamp on the buy ticket, next to the price (follows the chosen pack, see product.js).
function izl_stock_line() {
	global $product;
	if ( ! $product instanceof WC_Product || '' === (string) $product->get_price() ) {
		return;
	}
	$s = izl_stock_state( $product );
	$in_form = izl_head_in_form( $product );
	if ( ! empty( $GLOBALS['izl_head_now'] ) ) {
		echo '<p class="izl-stock is-' . esc_attr( $s[0] ) . '" aria-live="polite"><i aria-hidden="true"></i><b>' . esc_html( $s[1] ) . '</b></p>';
		return; // 2.0.7: inside the buy ticket (the ink filter below is printed with the summary)
	}
	// 1.7.18: uneven ink for the stamp's frame (style.css .izl-stock::before); the letters stay crisp.
	echo '<svg class="izl-defs" width="0" height="0" aria-hidden="true" focusable="false"><filter id="izl-stock-ink" x="-10%" y="-20%" width="120%" height="140%" color-interpolation-filters="sRGB">'
		. '<feTurbulence type="fractalNoise" baseFrequency="0.05" numOctaves="3" seed="4" result="low"/>'
		. '<feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="9" result="hi"/>'
		. '<feTurbulence type="turbulence" baseFrequency="0.08" numOctaves="2" seed="2" result="warp"/>'
		. '<feDisplacementMap in="SourceGraphic" in2="warp" scale="2" xChannelSelector="R" yChannelSelector="G" result="rough"/>'
		. '<feColorMatrix in="low" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  1.6 0 0 0 0.05" result="lowA"/>'
		. '<feColorMatrix in="hi" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  2.2 0 0 0 -0.2" result="hiA"/>'
		. '<feComposite in="lowA" in2="hiA" operator="arithmetic" k1="1" k2="0" k3="0" k4="0" result="mask"/>'
		. '<feComposite in="rough" in2="mask" operator="in"/></filter></svg>';
	if ( $in_form ) {
		return;
	}
	echo '<p class="izl-stock is-' . esc_attr( $s[0] ) . '" aria-live="polite"><i aria-hidden="true"></i><b>' . esc_html( $s[1] ) . '</b></p>';
}

// The ship lines (1.7.0). The rule itself (izl_ship_plan(), holidays) is in inc/shop-core.php.
// The labels of the two ship lines: plural for live animals ("they"), singular for the rest.
function izl_ship_labels( $type ) {
	return 'live' === $type
		? array( 'arrive' => _x( 'With you', 'live animals', 'izeltlab' ), 'leaves' => _x( 'Sets off', 'live animals', 'izeltlab' ) )
		: array( 'arrive' => _x( 'With you', 'product', 'izeltlab' ), 'leaves' => _x( 'Sets off', 'product', 'izeltlab' ) );
}

function izl_nudge_text() {
	/* translators: %s: the cutoff time, e.g. 14:00 */
	return sprintf( __( 'If you order by %s, we ship it today!', 'izeltlab' ), sprintf( '%02d:00', IZL_SHIP_CUTOFF ) );
}

// On the buy ticket (1.7.18): "With you on Tuesday, Nov 3" first (big, green), then "Sets off today", the order-by
// nudge (11:00 until 14:00 on shipping days) and the free shipping amount. product.js works the same out again in the
// visitor's browser (Budapest time), so a cached page still shows the right days; what is printed here is for the
// moment before the script runs.
function izl_ship_lines() {
	global $product;
	if ( ! $product instanceof WC_Product || '' === (string) $product->get_price() || ! $product->is_in_stock() ) {
		return; // nothing to ship while it can't be ordered (no buy panel then either)
	}
	if ( izl_head_in_form( $product ) ) {
		return; // 2.0.7: printed inside the buy ticket instead
	}
	$type   = izl_ship_type( $product->get_id() );
	$plan   = izl_ship_plan( $type );
	$words  = izl_ship_words();
	$labels = izl_ship_labels( $type );
	$when   = 0 === $plan[2] ? $words['today'] : ( 1 === $plan[2] ? $words['tomorrow'] : $words['on'][ (int) $plan[0]->format( 'N' ) ] );
	echo '<div class="izl-ship-lines" data-ship="' . esc_attr( $type ) . '">';
	echo '<p class="izl-when izl-arrive"><span>' . esc_html( $labels['arrive'] ) . '</span><i aria-hidden="true"></i><b>' . esc_html( izl_arrive_words( $plan[1] ) ) . '</b></p>';
	echo '<p class="izl-when izl-leaves"><span>' . esc_html( $labels['leaves'] ) . '</span><i aria-hidden="true"></i><b>' . esc_html( $when ) . '</b></p>';
	echo '<p class="izl-nudge"' . ( izl_nudge_now( $type ) ? '' : ' hidden' ) . '><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg><span>' . esc_html( izl_nudge_text() ) . '</span></p>';
	$free = izl_free_ship();
	if ( $free > 0 ) {
		/* translators: %s: order amount, e.g. 18 000 Ft */
		echo '<p class="izl-free-ship">' . izl_trust_icon( 'truck' ) . wp_kses_post( sprintf( __( 'Free shipping over %s', 'izeltlab' ), wc_price( $free ) ) ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</div>';
}

// The stock line says it already, so no second "5 in stock" in the buy panel.
function izl_hide_wc_stock( $html, $product ) {
	return is_product() && get_queried_object_id() === $product->get_id() ? '' : $html;
}

add_action( 'wp_ajax_izl_product_text', function () {
	if ( ! check_ajax_referer( 'izl_product_text', false, false ) ) {
		wp_send_json_error( 'The security check ran out. Reload the page and try again.', 403 );
	}
	$id  = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
	$key = isset( $_POST['key'] ) ? sanitize_key( wp_unslash( $_POST['key'] ) ) : '';
	// 2.0.6: the product's own name (the hidden name in the admin strip); the web address stays as it is
	if ( '_izl_name' === $key && $id && current_user_can( 'edit_post', $id ) ) {
		$text    = isset( $_POST['text'] ) ? sanitize_text_field( wp_unslash( $_POST['text'] ) ) : '';
		$product = wc_get_product( $id );
		if ( ! $product || '' === $text ) {
			wp_send_json_error( '' === $text ? 'The name cannot be empty.' : 'Product not found.' );
		}
		$product->set_name( $text );
		$product->delete_meta_data( '_izl_auto_title' ); // named by hand: Publish keeps it
		$product->save();
		wp_send_json_success( array( 'text' => $product->get_name() ) );
	}
	if ( ! $id || ! current_user_can( 'edit_post', $id ) || ! isset( izl_product_texts()[ $key ] ) ) {
		wp_send_json_error( 'Not allowed.', 403 );
	}
	$text = isset( $_POST['text'] ) ? sanitize_text_field( wp_unslash( $_POST['text'] ) ) : '';
	update_post_meta( $id, $key, $text );
	if ( '' === $text && '_izl_pack_tip' === $key ) {
		$text = trim( (string) izl_pmod( 'izl_pack_tip' ) ); // back to the default tip
	} elseif ( '' === $text && '_izl_row_title' === $key ) {
		$text = izl_row_default( $id, true ); // back to the default title
	}
	wp_send_json_success( array( 'text' => $text ) );
} );

function izl_price_row() {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	// No price: WooCommerce shows no cart button either. Visitors see nothing here; whoever can edit the product sees why.
	if ( '' === (string) $product->get_price() ) {
		if ( current_user_can( 'edit_post', $product->get_id() ) ) {
			echo '<p class="izl-admin-hint">' . esc_html( $product->is_type( 'variable' ) ? 'No price yet, so there is no cart button. Give the packs a price: Edit product → Product data → Variations.' : 'No price yet, so there is no cart button. Add one: Edit product → Product data → General → Regular price.' ) . '</p>';
		}
		return;
	}
	if ( izl_head_in_form( $product ) ) {
		return; // 2.0.7: printed inside the buy ticket instead (izl_buy_head())
	}
	$note = array_filter( array( trim( (string) izl_pmod( 'izl_vat_note' ) ) ) );
	// 2.0.7: the chosen pack's price and the big number are printed here (product.js bigPrice() did it after load,
	// so a slow page showed WooCommerce's range "2 500 Ft – 12 500 Ft" first)
	$shown = $product->is_type( 'variable' ) ? izl_start_variation( $product ) : null;
	$html  = $shown ? $shown->get_price_html() : $product->get_price_html();
	$px    = izl_px_html( $shown ? $shown : $product, $html, $shown ? izl_start_pack_name( $product ) : '' );
	echo '<div class="izl-price-row' . ( $px ? ' is-px' : '' ) . '">';
	echo '<p class="' . esc_attr( apply_filters( 'woocommerce_product_price_class', 'price' ) ) . '">' . $html . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
	if ( $note ) {
		echo '<span class="izl-price-note">' . esc_html( implode( ' · ', $note ) ) . '</span>';
	}
	echo $px; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '</div>';
}

/* ------------------------------------------------------------------ 2.0.7: the buy ticket comes ready from the server

   Before 2.0.7 product.js built the ticket after the page loaded: it moved the price, the stock stamp and the shipping
   lines into the cart panel, turned the pack dropdown into buttons, made the big price and added − + to the quantity.
   On a slow connection people saw WooCommerce's plain box, then a half-built one, then the ticket. Now the server
   prints all of it in place; product.js finds the parts already there and only wires them up (and still builds them
   itself on any page this does not cover, e.g. a sold-out variable product). */

// True when the price, stock stamp and shipping lines go inside the cart form (the form is on the page and has the
// panel), so the summary does not print them above it. Only for the page's own product, simple or with packs.
function izl_head_in_form( $product ) {
	if ( ! $product instanceof WC_Product || ! empty( $GLOBALS['izl_head_now'] ) || ! function_exists( 'is_product' ) || ! is_product() ) {
		return false;
	}
	static $memo = array();
	$id = (int) $product->get_id();
	if ( isset( $memo[ $id ] ) ) {
		return $memo[ $id ];
	}
	$ok = false;
	if ( $id === (int) get_queried_object_id() && '' !== (string) $product->get_price() && $product->is_purchasable() && $product->is_in_stock() ) {
		if ( $product->is_type( 'simple' ) ) {
			$ok = true;
		} elseif ( $product->is_type( 'variable' ) ) {
			foreach ( $product->get_visible_children() as $cid ) {
				$v = wc_get_product( $cid );
				if ( $v && $v->variation_is_visible() ) {
					$ok = true;
					break;
				}
			}
		}
	}
	return $memo[ $id ] = $ok;
}

add_action( 'woocommerce_before_add_to_cart_button', 'izl_buy_head', 1 );
function izl_buy_head() {
	global $product;
	static $done = false;
	if ( $done || ! izl_head_in_form( $product ) ) {
		return;
	}
	$done = true;
	$GLOBALS['izl_head_now'] = true;
	echo '<div class="izl-buy-head">';
	izl_price_row();
	izl_stock_line();
	izl_ship_lines();
	echo '</div>';
	$GLOBALS['izl_head_now'] = false;
}

// The pack the page starts on: the product's default, else (one choice to make) the first pack that can be bought,
// the same one product.js chips() used to pick after load. The pack dropdown starts on it too (filter below).
function izl_start_attrs( $product ) {
	if ( ! $product instanceof WC_Product_Variable ) {
		return array();
	}
	static $memo = array();
	$id = $product->get_id();
	if ( isset( $memo[ $id ] ) ) {
		return $memo[ $id ];
	}
	$attrs = $product->get_variation_attributes();
	$out   = array();
	foreach ( $attrs as $name => $options ) {
		$key = 'attribute_' . sanitize_title( $name );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$req = isset( $_REQUEST[ $key ] ) ? wc_clean( wp_unslash( $_REQUEST[ $key ] ) ) : null;
		$val = null !== $req ? $req : $product->get_variation_default_attribute( $name );
		if ( '' === (string) $val && 1 === count( $attrs ) ) {
			foreach ( $product->get_visible_children() as $cid ) {
				$v = wc_get_product( $cid );
				if ( $v && $v->variation_is_visible() && $v->is_purchasable() && $v->is_in_stock() ) {
					$va  = $v->get_variation_attributes();
					$val = isset( $va[ $key ] ) ? (string) $va[ $key ] : '';
					if ( '' !== $val ) {
						break;
					}
				}
			}
			// the first option in the dropdown's order when that variation covers "any"
			if ( '' === (string) $val && $options ) {
				$val = (string) reset( $options );
			}
		}
		if ( '' === (string) $val ) {
			return $memo[ $id ] = array(); // more than one choice left open: no start pack
		}
		$out[ $key ] = (string) $val;
	}
	return $memo[ $id ] = $out;
}

function izl_start_variation( $product ) {
	$attrs = izl_start_attrs( $product );
	if ( ! $attrs ) {
		return null;
	}
	$vid = WC_Data_Store::load( 'product' )->find_matching_product_variation( $product, $attrs );
	$v   = $vid ? wc_get_product( $vid ) : null;
	return $v && $v->variation_is_visible() && '' !== (string) $v->get_price() ? $v : null;
}

// The start pack's name as the pack buttons show it ("10 db"); only for the pack attribute.
function izl_start_pack_name( $product ) {
	$key   = 'attribute_' . sanitize_title( IZL_PACK_ATTR );
	$attrs = izl_start_attrs( $product );
	if ( ! isset( $attrs[ $key ] ) ) {
		return '';
	}
	$val = $attrs[ $key ];
	foreach ( $product->get_variation_attributes() as $name => $options ) {
		if ( 'attribute_' . sanitize_title( $name ) !== $key ) {
			continue;
		}
		if ( taxonomy_exists( $name ) ) {
			$term = get_term_by( 'slug', $val, $name );
			return $term ? (string) apply_filters( 'woocommerce_variation_option_name', $term->name, $term, $name, $product ) : '';
		}
		foreach ( $options as $o ) {
			if ( sanitize_title( $o ) === sanitize_title( $val ) || $o === $val ) {
				return (string) apply_filters( 'woocommerce_variation_option_name', $o, null, $name, $product );
			}
		}
	}
	return '';
}

// The big price (same markup product.js bigPrice() makes): one amount, not on sale. '' = WooCommerce's own price stays.
function izl_px_html( $p, $html, $pack ) {
	if ( 1 !== substr_count( $html, 'woocommerce-Price-amount' ) || false !== strpos( $html, '<del' ) ) {
		return '';
	}
	$num = number_format( (float) wc_get_price_to_display( $p ), wc_get_price_decimals(), wc_get_price_decimal_separator(), wc_get_price_thousand_separator() );
	$num = trim( preg_replace( '/[\s\x{00a0}\x{202f}]+/u', "\u{202f}", html_entity_decode( $num, ENT_QUOTES, 'UTF-8' ) ) );
	$cur = trim( html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' ) );
	$note = implode( ' · ', array_filter( array( $pack, trim( (string) izl_pmod( 'izl_vat_note' ) ) ) ) );
	return '<span class="izl-px"><span class="izl-px-num">' . esc_html( $num ) . '</span><span class="izl-px-side"><span class="izl-px-cur">' . esc_html( $cur ) . '</span><span class="izl-px-note">' . esc_html( $note ) . '</span></span></span>'
		. '<span class="izl-px-per">' . ( '' !== $pack ? esc_html( "/\u{00a0}" . $pack ) : '' ) . '</span>';
}

// The pack dropdown starts on the start pack, and the pack buttons are printed next to it (product.js chips() takes
// them over). The dropdown stays, hidden, for WooCommerce.
add_filter( 'woocommerce_dropdown_variation_attribute_options_args', function ( $args ) {
	if ( empty( $args['selected'] ) && ! empty( $args['product'] ) && izl_head_in_form( $args['product'] ) ) {
		$attrs = izl_start_attrs( $args['product'] );
		$key   = 'attribute_' . sanitize_title( $args['attribute'] );
		if ( isset( $attrs[ $key ] ) ) {
			$args['selected'] = $attrs[ $key ];
		}
	}
	return $args;
}, 20 );

add_filter( 'woocommerce_dropdown_variation_attribute_options_html', function ( $html, $args ) {
	if ( empty( $args['product'] ) || ! izl_head_in_form( $args['product'] ) || false !== strpos( $html, 'izl-chips-select' ) ) {
		return $html;
	}
	if ( ! preg_match_all( '/<option\s+value="([^"]*)"([^>]*)>(.*?)<\/option>/s', $html, $m, PREG_SET_ORDER ) ) {
		return $html;
	}
	$sel   = isset( $args['selected'] ) ? (string) $args['selected'] : '';
	$label = wc_attribute_label( $args['attribute'], $args['product'] );
	$row   = '<div class="izl-chips" role="radiogroup" aria-label="' . esc_attr( $label ) . '">';
	foreach ( $m as $o ) {
		if ( '' === $o[1] ) {
			continue;
		}
		$val  = html_entity_decode( $o[1], ENT_QUOTES, 'UTF-8' );
		$on   = '' !== $sel && ( $val === $sel || sanitize_title( $val ) === sanitize_title( $sel ) );
		$row .= '<button type="button" class="izl-chip" role="radio" data-value="' . esc_attr( $val ) . '" aria-checked="' . ( $on ? 'true' : 'false' ) . '">' . esc_html( wp_strip_all_tags( html_entity_decode( $o[3], ENT_QUOTES, 'UTF-8' ) ) ) . '</button>';
	}
	$row .= '</div>';
	$html = preg_replace( '/<select\s+([^>]*?)class="([^"]*)"/', '<select $1class="$2 izl-chips-select"', $html, 1, $n );
	if ( ! $n ) {
		$html = preg_replace( '/<select\s/', '<select class="izl-chips-select" ', $html, 1 );
	}
	return $row . $html;
}, 20, 2 );

// − and + around the quantity box (product.js stepper() made them after load); only in the page's own cart form.
add_action( 'woocommerce_before_add_to_cart_quantity', function () {
	global $product;
	$GLOBALS['izl_qty_here'] = izl_head_in_form( $product );
} );
add_action( 'woocommerce_after_add_to_cart_quantity', function () {
	$GLOBALS['izl_qty_here'] = false;
} );
add_filter( 'woocommerce_quantity_input_type', function ( $type ) {
	$GLOBALS['izl_qty_type'] = $type;
	return $type;
}, PHP_INT_MAX );
add_action( 'woocommerce_before_quantity_input_field', function () {
	if ( ! empty( $GLOBALS['izl_qty_here'] ) && 'number' === ( $GLOBALS['izl_qty_type'] ?? '' ) ) {
		echo '<button type="button" class="izl-qty-btn is-less" aria-label="' . esc_attr__( 'Decrease quantity', 'izeltlab' ) . '">−</button>';
	}
} );
add_action( 'woocommerce_after_quantity_input_field', function () {
	if ( ! empty( $GLOBALS['izl_qty_here'] ) && 'number' === ( $GLOBALS['izl_qty_type'] ?? '' ) ) {
		echo '<button type="button" class="izl-qty-btn is-more" aria-label="' . esc_attr__( 'Increase quantity', 'izeltlab' ) . '">+</button>';
	}
} );

/* ------------------------------------------------------------------ trust points and common questions */

function izl_trust_icon( $name ) {
	$paths = array(
		'shield' => '<path d="M12 3l7 3v5c0 4.5-3 8.3-7 10-4-1.7-7-5.5-7-10V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
		'truck'  => '<path d="M2.5 6h11v10h-11zM13.5 9.5h4l3 3.5v3h-7z"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/>',
		'home'   => '<path d="M4 11l8-7 8 7v9H4z"/><path d="M10 20v-5h4v5"/>',
		'star'   => '<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9 6.8 19.6l1-5.8L3.5 9.7l5.9-.9z"/>',
	);
	return '<span class="izl-trust-icon" aria-hidden="true"><svg viewBox="0 0 24 24">' . $paths[ $name ] . '</svg></span>';
}

// The difficulty point, from the species' Codex difficulty: [title, text] or null.
function izl_difficulty_point( $product_id ) {
	$diff = (int) get_post_meta( $product_id, '_fsz_difficulty', true );
	if ( $diff < 1 || $diff > 5 ) {
		return null;
	}
	// 1.7.14: told with the Codex level word, as on the card (was "Difficulty 3/5").
	$level = izl_level( $diff );
	$word  = izl_level_word( $level );
	if ( 1 === $level ) {
		/* translators: %s: the Codex level word */
		return array( __( 'Good for beginners', 'izeltlab' ), sprintf( __( '%s on the Codex: a good first species.', 'izeltlab' ), $word ) );
	}
	if ( 2 === $level ) {
		/* translators: %s: the Codex level word */
		return array( __( 'Medium difficulty', 'izeltlab' ), sprintf( __( '%s on the Codex: some experience helps.', 'izeltlab' ), $word ) );
	}
	/* translators: %s: the Codex level word */
	return array( __( 'For experienced keepers', 'izeltlab' ), sprintf( __( '%s on the Codex: best as a second or third species.', 'izeltlab' ), $word ) );
}

function izl_trust_points() {
	$points = array();
	foreach ( array( 1 => 'shield', 2 => 'truck' ) as $i => $icon ) {
		$points[] = array( $icon, izl_pmod( "izl_trust_{$i}_title" ), izl_pmod( "izl_trust_{$i}_text" ) );
	}
	$diff = izl_pmod( 'izl_trust_difficulty' ) ? izl_difficulty_point( get_the_ID() ) : null;
	if ( $diff ) {
		$points[] = array( 'star', $diff[0], $diff[1] );
	}
	$points[] = array( 'home', izl_pmod( 'izl_trust_3_title' ), izl_pmod( 'izl_trust_3_text' ) );
	$points   = array_filter( $points, function ( $p ) {
		return '' !== trim( (string) $p[1] );
	} );
	if ( ! $points ) {
		return;
	}
	// The icons take the species' Codex colour (its own, or its group's).
	$color = function_exists( 'fsz_product_color' ) ? fsz_product_color( get_the_ID() ) : izl_teal();
	echo '<ul class="izl-trust" style="--izl-group:' . esc_attr( $color ) . ';--izl-group-dark:' . esc_attr( izl_dark( $color ) ) . '" aria-label="' . esc_attr__( 'Why buy here', 'izeltlab' ) . '">';
	foreach ( $points as $p ) {
		echo '<li' . ( '' !== trim( (string) $p[2] ) ? ' title="' . esc_attr( $p[2] ) . '"' : '' ) . '>' . izl_trust_icon( $p[0] ) . '<div><b>' . esc_html( $p[1] ) . '</b>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( '' !== trim( (string) $p[2] ) ) {
			echo '<span>' . esc_html( $p[2] ) . '</span>';
		}
		echo '</div></li>';
	}
	echo '</ul>';
}

define( 'IZL_FAQ_COUNT', 6 ); // question slots in the Customizer

function izl_product_faq() {
	$faqs = array();
	for ( $i = 1; $i <= IZL_FAQ_COUNT; $i++ ) {
		$q = trim( (string) izl_pmod( "izl_faq_{$i}_q" ) );
		$a = trim( (string) izl_pmod( "izl_faq_{$i}_a" ) );
		if ( '' !== $q && '' !== $a ) {
			$faqs[] = '<details class="izl-faq"><summary>' . esc_html( $q ) . '</summary><div class="izl-faq-a">' . wpautop( wp_kses_post( $a ) ) . '</div></details>';
		}
	}
	if ( ! $faqs ) {
		return;
	}
	// Under the card and the buy box (1.6.0), all of them, in two columns: first half left, second half right.
	$half = (int) ceil( count( $faqs ) / 2 );
	echo '<section class="izl-faqs"><h2>' . esc_html__( 'Common questions', 'izeltlab' ) . '</h2><div class="izl-faq-cols"><div>' . implode( '', array_slice( $faqs, 0, $half ) ) . '</div><div>' . implode( '', array_slice( $faqs, $half ) ) . '</div></div></section>'; // phpcs:ignore WordPress.Security.EscapeOutput
}

/* ------------------------------------------------------------------ the cart button */

// 1.7.18: "Kosárba vele!" on the product page's cart button.
add_filter( 'woocommerce_product_single_add_to_cart_text', function ( $text, $product = null ) {
	if ( $product instanceof WC_Product && $product->is_type( 'external' ) ) {
		return $text; // its own button text (Product data → General)
	}
	return __( 'Add it to the cart!', 'izeltlab' );
}, 10, 2 );

// 1.7.17: the Kosárba button sends the form and WooCommerce shows the same page again; remember that this request put
// the product in the cart, so product.js can press the green "added" stamp onto the buy box.
add_action( 'woocommerce_add_to_cart', function ( $key, $product_id ) {
	$GLOBALS['izl_just_added'] = (int) $product_id;
}, 10, 2 );

function izl_just_added() {
	return ! empty( $GLOBALS['izl_just_added'] ) && (int) $GLOBALS['izl_just_added'] === (int) get_queried_object_id();
}

/* ------------------------------------------------------------------ product page script (assets/product.js) and its Customizer section */

add_action( 'wp_enqueue_scripts', function () {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}
	wp_enqueue_script( 'izeltlab-product', get_stylesheet_directory_uri() . '/' . izl_min( 'assets/product.js' ), array( 'jquery' ), IZL_VERSION, true );
	wp_localize_script( 'izeltlab-product', 'izlProduct', array(
		'vat'      => trim( (string) izl_pmod( 'izl_vat_note' ) ),
		'less'     => __( 'Decrease quantity', 'izeltlab' ),
		'more'     => __( 'Increase quantity', 'izeltlab' ),
		'low'      => IZL_LOW_STOCK,
		// 2.0.7: the price of one (no packs), for the cart guess on Kosárba vele! (packs: the chosen pack's price)
		'unit'     => ( $izl_pp = wc_get_product( get_queried_object_id() ) ) && ! $izl_pp->is_type( 'variable' ) && '' !== (string) $izl_pp->get_price() ? (float) wc_get_price_to_display( $izl_pp ) : 0,
		'added'    => izl_just_added(), // 1.7.17: the "added to cart" stamp on the buy box
		'addedSum' => izl_just_added() ? izl_cart_total() : null, // 1.7.18: free-shipping progress after a reload add
		'tz'       => 'Europe/Budapest',
		'ship'     => array(
			'cutoff' => IZL_SHIP_CUTOFF,
			'from'   => IZL_NUDGE_FROM,
			'days'   => IZL_SHIP_DAYS,
			'words'  => izl_ship_words(),
			'closed' => izl_closed_list(), // 2.1.0: holidays + closed days (Y-m-d), from today to the end of next year
		),
		// 1.7.18: Kosárba without a reload (WooCommerce's own AJAX add to cart), unless the shop goes to the cart after
		// adding (WooCommerce → Settings → Products), then the form is sent as before.
		'cart'     => array(
			'url'      => class_exists( 'WC_AJAX' ) ? WC_AJAX::get_endpoint( 'add_to_cart' ) : '',
			'redirect' => 'yes' === get_option( 'woocommerce_cart_redirect_after_add' ),
		),
		'freeShip' => izl_free_ship(),
		'money'    => array(
			'cur' => html_entity_decode( get_woocommerce_currency_symbol() ),
			'pos' => get_option( 'woocommerce_currency_pos', 'right_space' ),
		),
		'prog'     => array(
			/* translators: %s: amount still missing, e.g. 15 500 Ft */
			'more' => __( 'Only %s more and shipping is free!', 'izeltlab' ),
			'done' => __( 'Done! Shipping is free!', 'izeltlab' ),
		),
		'pack'     => sanitize_title( IZL_PACK_ATTR ), // the pack choice shows in the note under Ft
		'notify'   => __( 'Tell me when back!', 'izeltlab' ), // 2.2.0: the cart button of a sold-out product
		// 1.7.19: the phone product page (the bottom drawer)
		'phone'    => array(
			'open'     => __( 'Open the drawer', 'izeltlab' ),
			'close'    => __( 'Close the drawer', 'izeltlab' ),
			'ship'     => __( 'Shipping', 'izeltlab' ),
			/* translators: %s: the arrival day, e.g. "on Tuesday" */
			'arrive'   => __( '%s with you!', 'izeltlab' ),
			'photo'    => __( 'Photo', 'izeltlab' ),
			'closePic' => __( 'Close the photo', 'izeltlab' ),
			// 2.0.5: the closed drawer's room above the button (px off, capped so the handle never comes closer than
			// 6px) and the roll-back switch (2.0.3's drawer: no trim, pinch zoom allowed)
			'trim'     => (float) izl_pmod( 'izl_drawer_trim' ),
			'r203'     => (bool) izl_pmod( 'izl_drawer_203' ),
		),
		'stock'    => array(
			'in'   => __( 'In stock', 'izeltlab' ),
			/* translators: %d: how many are left */
			'low'  => __( 'Only %d left', 'izeltlab' ),
			'back' => __( 'Available to order', 'izeltlab' ),
			'out'  => __( 'Currently unavailable', 'izeltlab' ),
		),
		'edit'     => current_user_can( 'edit_post', get_queried_object_id() ) ? array(
			'ajax'  => admin_url( 'admin-ajax.php', 'relative' ),
			'nonce' => wp_create_nonce( 'izl_product_text' ),
			'id'    => get_queried_object_id(),
		) : null,
	) );
}, 30 );

add_action( 'customize_register', function ( $wp_customize ) {
	$d = izl_product_defaults();
	$wp_customize->add_section( 'izl_product', array(
		'title'       => __( 'Ízeltláb product page', 'izeltlab' ),
		'description' => __( 'The trust points, the questions, the pack question and the notes next to the price and the stock. Empty a field to hide it.', 'izeltlab' ),
		'priority'    => 31,
	) );
	$add = function ( $key, $label, $type, $description = '' ) use ( $wp_customize, $d ) {
		$sanitize = array(
			'text'     => 'sanitize_text_field',
			'textarea' => 'wp_kses_post',
			'checkbox' => 'absint',
			'number'   => function ( $v ) {
				return max( 0, (float) str_replace( ',', '.', (string) $v ) );
			},
		);
		$wp_customize->add_setting( $key, array( 'default' => $d[ $key ], 'sanitize_callback' => $sanitize[ $type ] ) );
		$wp_customize->add_control( $key, array( 'label' => $label, 'description' => $description, 'section' => 'izl_product', 'type' => $type ) );
	};
	for ( $i = 1; $i <= 3; $i++ ) {
		/* translators: %d: number of the trust point */
		$add( "izl_trust_{$i}_title", sprintf( __( 'Trust point %d: title', 'izeltlab' ), $i ), 'text' );
		/* translators: %d: number of the trust point */
		$add( "izl_trust_{$i}_text", sprintf( __( 'Trust point %d: text', 'izeltlab' ), $i ), 'text' );
	}
	$add( 'izl_trust_difficulty', __( 'Show the difficulty point', 'izeltlab' ), 'checkbox', __( 'Taken from the Codex difficulty of each species.', 'izeltlab' ) );
	for ( $i = 1; $i <= IZL_FAQ_COUNT; $i++ ) {
		/* translators: %d: number of the question */
		$add( "izl_faq_{$i}_q", sprintf( __( 'Question %d', 'izeltlab' ), $i ), 'text' );
		/* translators: %d: number of the question */
		$add( "izl_faq_{$i}_a", sprintf( __( 'Answer %d', 'izeltlab' ), $i ), 'textarea' );
	}
	$add( 'izl_vat_note', __( 'VAT note next to the price', 'izeltlab' ), 'text' );
	$add( 'izl_free_ship', __( 'Free shipping over (amount)', 'izeltlab' ), 'number', __( 'The line on the buy ticket and the progress after an add to cart. 0 = no line. Saving also sets it as the minimum order amount of the Free shipping method in every shipping zone (also in Edit buy box).', 'izeltlab' ) );
	$add( 'izl_pack_question', __( 'Question above the packs', 'izeltlab' ), 'text' );
	$add( 'izl_pack_tip', __( 'Pack tip (default)', 'izeltlab' ), 'text', __( 'Under the question. A product can have its own: Product data → General → Pack tip.', 'izeltlab' ) );
	// 2.0.5: the phone drawer
	$add( 'izl_drawer_trim', __( 'Phone: closed drawer, px less room above the button', 'izeltlab' ), 'number', __( 'The closed drawer starts lower; the button stays where it is. 0 = as in 2.0.3. Capped so the button stays at least 6px under the handle.', 'izeltlab' ) );
	$add( 'izl_drawer_203', __( 'Phone: roll back to the 2.0.3 drawer', 'izeltlab' ), 'checkbox', __( 'Only if the new drawer misbehaves on a phone: the closed drawer at its 2.0.3 height and pinch zoom allowed again. The 2.0.4 and 2.0.5 fixes stay.', 'izeltlab' ) );
} );

/* ------------------------------------------------------------------ buy box editor: the button and its data (saving: inc/shop-core.php) */

// What the editor shows: price of the base pack, base pack, the packs on offer (multiples), available.
function izl_buybox_data( $product ) {
	$id     = $product->get_id();
	$packs  = izl_is_codex( $id );
	$group  = izl_group_term( $id );
	$mults  = array();
	$price  = '';
	$avail  = $product->is_in_stock();
	if ( $product instanceof WC_Product_Variable ) {
		foreach ( $product->get_children() as $vid ) {
			$v = wc_get_product( $vid );
			if ( ! $v ) {
				continue;
			}
			$m = (int) $v->get_meta( '_izl_mult' );
			if ( $m > 0 ) {
				$mults[] = $m;
				if ( '' === $price && '' !== (string) $v->get_regular_price() ) {
					$price = (float) $v->get_regular_price() / $m;
				}
			} elseif ( '' === $price && '' !== (string) $v->get_regular_price() ) {
				$price = (float) $v->get_regular_price(); // packs made by hand before 1.3.6: the first one's price
			}
		}
	} else {
		$price = '' === (string) $product->get_regular_price() ? '' : (float) $product->get_regular_price();
	}
	return array(
		'id'         => $id,
		'packs'      => $packs,
		'price'      => '' === $price ? '' : round( $price, wc_get_price_decimals() ),
		'base'       => (int) get_post_meta( $id, '_izl_base_pack', true ),
		'groupBase'  => izl_group_base_pack( $group ),
		'groupName'  => $group ? $group->name : '',
		'mults'      => $mults ? array_values( array_unique( $mults ) ) : IZL_PACK_MULTS,
		'allMults'   => IZL_PACK_MULTS,
		'available'  => $avail,
		'low'        => $packs && 'yes' === get_post_meta( $id, '_fsz_low', true ), // 1.7.17: the Codex "Running low" light
		'handMade'   => $product instanceof WC_Product_Variable && ! $mults && (bool) $product->get_children(),
		'ship'       => izl_ship_type( $id ),
		'rowTitle'   => (string) get_post_meta( $id, '_izl_row_title', true ),
		'rowDefault' => izl_row_default( $id, true ),
		'currency'   => html_entity_decode( get_woocommerce_currency_symbol() ),
		'freeShip'   => izl_free_ship(), // 1.7.18: shop-wide, only for shop managers
		'canShop'    => current_user_can( 'manage_woocommerce' ),
	);
}

// The editor's button and dialog, at the top of the buy box, for whoever can edit the product.
add_action( 'woocommerce_single_product_summary', function () {
	global $product;
	if ( ! $product instanceof WC_Product || ! current_user_can( 'edit_post', $product->get_id() ) ) {
		return;
	}
	echo '<div class="izl-admin-strip"><button type="button" class="izl-buybox-open">Edit buy box</button>';
	if ( izl_is_codex( $product->get_id() ) ) {
		// 2.0.6: Edit next to it changes the product's own name here (the same text box as the sales line)
		echo '<p class="izl-admin-name" data-izl-edit="_izl_name">Hidden name (only search engines and screen readers get it): <b class="izl-edit-text">' . esc_html( $product->get_name() ) . '</b><button type="button" class="izl-edit-btn">Edit</button></p>';
	}
	echo '</div>';
	echo '<script type="application/json" id="izl-buybox-data">' . wp_json_encode( izl_buybox_data( $product ) ) . '</script>';
}, 4 );

/* ------------------------------------------------------------------ 1.7.0: product row, supply pages (reviews off: inc/shop-core.php) */

// The row's title when the product has none of its own: species "Similar species", everything else "You might also need".
// $shop: in the shop's language even when saved from an English dashboard.
function izl_row_default( $product_id, $shop = false ) {
	if ( $shop ) {
		return izl_shop_text( izl_is_codex( $product_id ) ? 'Similar species' : 'You might also need' );
	}
	return izl_is_codex( $product_id ) ? __( 'Similar species', 'izeltlab' ) : __( 'You might also need', 'izeltlab' );
}

// The title over the small-tile row: the product's own (Edit buy box, or Edit on the title itself), else the default.
function izl_row_title() {
	$own = trim( (string) get_post_meta( get_the_ID(), '_izl_row_title', true ) );
	return '' !== $own ? $own : izl_row_default( get_the_ID() );
}

// What the row shows: the product's Upsells (Product data → Linked products → Upsells) first, the rest filled up with
// WooCommerce's own related products (same category or tag), so the row is never half empty.
add_filter( 'woocommerce_related_products', function ( $related, $product_id, $args ) {
	$product = wc_get_product( $product_id );
	$ups     = $product ? array_map( 'absint', $product->get_upsell_ids() ) : array();
	if ( ! $ups ) {
		return $related;
	}
	$limit = isset( $args['limit'] ) && $args['limit'] > 0 ? (int) $args['limit'] : 6;
	$ids   = array_values( array_unique( array_merge( $ups, array_map( 'absint', (array) $related ) ) ) );
	return array_slice( array_diff( $ids, array( (int) $product_id ) ), 0, $limit );
}, 10, 3 );

// Supplies: the description under the buy box, as wide as the buy box, with the product's details (weight, size,
// attributes) under it if it has any.
function izl_description() {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$text  = trim( (string) $product->get_description() );
	$attrs = $product->has_attributes() || $product->has_weight() || $product->has_dimensions();
	if ( '' === $text && ! $attrs ) {
		return;
	}
	echo '<section class="izl-desc"><h2>' . esc_html__( 'Description', 'izeltlab' ) . '</h2>';
	if ( '' !== $text ) {
		echo '<div class="izl-desc-text">' . apply_filters( 'the_content', $text ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- post content
	}
	if ( $attrs ) {
		wc_display_product_attributes( $product );
	}
	echo '</section>';
}

// Supplies: categories and tags as small clickable pills under the photo (instead of "Categories: … Tags: …").
function izl_term_pills() {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$skip  = (int) get_option( 'default_product_cat' ); // "Uncategorized"
	$pills = array();
	foreach ( array( 'product_cat' => '', 'product_tag' => '#' ) as $tax => $mark ) {
		$terms = get_the_terms( $product->get_id(), $tax );
		if ( ! $terms || is_wp_error( $terms ) ) {
			continue;
		}
		foreach ( $terms as $t ) {
			if ( 'product_cat' === $tax && (int) $t->term_id === $skip ) {
				continue;
			}
			$link = get_term_link( $t );
			if ( ! is_wp_error( $link ) ) {
				$pills[] = '<a class="izl-term is-' . ( $mark ? 'tag' : 'cat' ) . '" href="' . esc_url( $link ) . '" rel="tag">' . esc_html( $mark . $t->name ) . '</a>';
			}
		}
	}
	if ( $pills ) {
		echo '<nav class="izl-terms" aria-label="' . esc_attr__( 'Categories and tags', 'izeltlab' ) . '">' . implode( '', $pills ) . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

/* ------------------------------------------------------------------ Edit photos and the font preload */

// 1.7.21: Edit photos (products without the Codex card): the dialog's server side and the photo frames.
require_once __DIR__ . '/inc/photos.php';

// 1.7.22: the Leírás text started in a stand-in font and swapped about a second later. The Plex Sans files it uses are
// now fetched with the page (preload) and the text waits for them (font-display:block in assets/fonts.css).
add_action( 'wp_head', function () {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}
	foreach ( array( '400-normal', '500-normal', '600-normal', '700-normal' ) as $f ) {
		printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( get_stylesheet_directory_uri() . '/assets/fonts/plex-sans-latin-' . $f . '.woff2' ) );
	}
	// 2.10.0: the price in the phone drawer (Plex Mono bold) is fetched with the page too. iPhones left the price out
	// for a moment while it loaded, so Kosárba vele! showed alone. The file the page really uses (Codex's copy if on).
	$mono = defined( 'FSZ_URL' ) && is_readable( WP_PLUGIN_DIR . '/codex/assets/fonts/ibm-plex-mono/latin-700.woff2' ) ? FSZ_URL . 'assets/fonts/ibm-plex-mono/latin-700.woff2' : get_stylesheet_directory_uri() . '/assets/fonts/plex-mono-latin-700.woff2';
	printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( $mono ) );
}, 1 );

/* ------------------------------------------------------------------ 2.1.0: launch pages (cart, checkout, thank-you, 404,
   footer, account, login, mini cart) and the holidays in the shipping dates */
require_once get_stylesheet_directory() . '/inc/launch.php';
require_once get_stylesheet_directory() . '/inc/swift.php'; // 2.3.0: smooth product page opening on phones
require_once get_stylesheet_directory() . '/inc/finder.php'; // 2.6.0: the header search
// 2.4.0: updates from the shop's GitHub repository (Settings → Ízeltláb updates), shared with Codex and Bolt
require_once get_stylesheet_directory() . '/inc/updater.php';
IZL_Updater::add( 'theme', 'theme', basename( get_stylesheet_directory() ), 'Ízeltláb theme', IZL_VERSION );
