<?php
// ==========================================================================
//  FILE: 404.php   (Ízeltláb theme)
//  WHAT: The "no such page" page in the shop's look.
//  SEEN: Any address that does not exist.
// ==========================================================================

/**
 * 2.1.0: the "no such page" page, in the shop's look: a short playful line, search, the way back, the newest isopods.
 */

get_header(); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main izl-404" role="main">
		<div class="izl-404-box">
			<p class="izl-404-code" aria-hidden="true">404</p>
			<h1 class="page-title"><?php esc_html_e( 'This path is empty', 'izeltlab' ); ?></h1>
			<p><?php esc_html_e( 'Whoever lived here has wandered off under a leaf. Search for them, or start again from the front page.', 'izeltlab' ); ?></p>
			<?php do_action( 'izl_404_suggest' ); // 2.2.0: the Ízeltláb Bolt plugin names species that sound like the address ?>
			<?php
			if ( function_exists( 'get_product_search_form' ) ) {
				get_product_search_form();
			} else {
				get_search_form();
			}
			?>
			<p class="izl-empty-btns">
				<a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Front page', 'izeltlab' ); ?></a>
				<?php if ( function_exists( 'izl_isopods_url' ) && izl_isopods_url() ) : ?>
					<a class="button is-light" href="<?php echo esc_url( izl_isopods_url() ); ?>"><?php esc_html_e( 'Isopods', 'izeltlab' ); ?></a>
				<?php endif; ?>
			</p>
		</div>
		<?php
		if ( function_exists( 'wc_get_products' ) && shortcode_exists( 'products' ) ) {
			echo '<h2 class="izl-404-more">' . esc_html__( 'Newest arrivals', 'izeltlab' ) . '</h2>';
			echo do_shortcode( '[products limit="4" columns="4" orderby="date" order="DESC" visibility="visible"]' );
		}
		?>
	</main>
</div>

<?php
get_footer();
