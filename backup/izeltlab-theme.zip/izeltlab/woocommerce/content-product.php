<?php
// ==========================================================================
//  FILE: woocommerce/content-product.php   (Ízeltláb theme)
//  WHAT: One product tile (calls izl_product_tile() in inc/shop-list.php).
//  SEEN: Shop, category and search lists, product rows.
// ==========================================================================

/**
 * One product tile on the shop, category, search and front page lists (built in functions.php: izl_product_tile).
 *
 * @package izeltlab
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}

izl_product_tile( $product );
