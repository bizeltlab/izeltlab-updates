<?php
// ==========================================================================
//  FILE: woocommerce/loop/result-count.php   (Ízeltláb theme)
//  WHAT: The short count above the products ("12 faj").
//  SEEN: Shop and category lists.
// ==========================================================================

/**
 * The count above the products. 2.6.0: short and in the shop's own words ("3 faj", "5 termék", "2 találat") instead
 * of WooCommerce's "Showing all 3 results"; on a later page of a long list "13–24 / 30 faj".
 *
 * Override of woocommerce/templates/loop/result-count.php (9.9.0). Gets $total, $per_page, $current, $orderedby.
 *
 * @package izeltlab
 * @version 9.9.0
 */

defined( 'ABSPATH' ) || exit;

$izl_total = (int) $total;
$izl_n     = number_format_i18n( $izl_total );
if ( is_search() ) {
	/* translators: %s: number of products found */
	$izl_what = sprintf( _n( '%s result', '%s results', $izl_total, 'izeltlab' ), $izl_n );
} elseif ( function_exists( 'izl_on_isopods_page' ) && izl_on_isopods_page() ) {
	/* translators: %s: number of species in the list */
	$izl_what = sprintf( _n( '%s species', '%s species', $izl_total, 'izeltlab' ), $izl_n );
} else {
	/* translators: %s: number of products in the list */
	$izl_what = sprintf( _n( '%s product', '%s products', $izl_total, 'izeltlab' ), $izl_n );
}
if ( -1 !== (int) $per_page && $izl_total > (int) $per_page ) {
	$izl_first = ( (int) $per_page * (int) $current ) - (int) $per_page + 1;
	$izl_last  = min( $izl_total, (int) $per_page * (int) $current );
	$izl_what  = number_format_i18n( $izl_first ) . '–' . number_format_i18n( $izl_last ) . ' / ' . $izl_what;
}
?>
<p class="woocommerce-result-count" role="alert" aria-relevant="all"><?php echo esc_html( $izl_what ); ?></p>
