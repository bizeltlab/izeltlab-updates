<?php
// ==========================================================================
//  FILE: inc/shop-list.php   (Ízeltláb theme)
//  WHAT: The shop and category lists: the difficulty pills and the product tiles (photo, name, price, cart button).
//  SEEN: The isopod list, category pages, product rows on the front page and under products.
//  SECTIONS IN THIS FILE:
//    1. Difficulty pills (in place of the Codex dropdown)
//    2. Product tiles (woocommerce/content-product.php)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Difficulty pills (in place of the Codex dropdown)
// ==========================================================================

add_action( 'woocommerce_before_shop_loop', function () {
	if ( ! izl_has_codex() || '1' !== fsz_opt( 'filter' ) ) {
		return;
	}
	// Same pages as the Codex filter: the shop and the isopod categories.
	if ( is_product_category() ) {
		if ( ! in_array( (int) get_queried_object_id(), fsz_category_ids(), true ) ) {
			return;
		}
	} elseif ( ! is_shop() ) {
		return;
	}
	// 1.7.14: the Codex levels instead of stars: All · Beginner (max 2) · Beginner + Intermediate (max 4), each with a dot
	// in its level colour (green, yellow), the same as on the card. An older link (max 1 or 3) lights the pill it falls in.
	$sel  = isset( $_GET['max_difficulty'] ) ? (int) $_GET['max_difficulty'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	$on   = $sel < 1 || $sel > 4 ? 0 : ( $sel <= 2 ? 2 : 4 );
	$base = remove_query_arg( 'max_difficulty', get_pagenum_link( 1, false ) );
	echo '<nav class="izl-pills" aria-label="' . esc_attr__( 'Difficulty', 'izeltlab' ) . '">';
	echo '<a class="izl-pill' . ( $on ? '' : ' is-on' ) . '" href="' . esc_url( $base ) . '"' . ( $on ? '' : ' aria-current="true"' ) . '>' . esc_html__( 'All', 'izeltlab' ) . '</a>';
	$pills = array(
		2 => array( izl_level_word( 1 ), array( 3 ) ),
		/* translators: 1: Beginner, 2: Intermediate (the Codex level words) */
		4 => array( sprintf( __( '%1$s + %2$s', 'izeltlab' ), izl_level_word( 1 ), izl_level_word( 2 ) ), array( 3, 4 ) ),
	);
	foreach ( $pills as $max => $pill ) {
		$dots = '';
		foreach ( $pill[1] as $lv ) {
			$dots .= '<i class="lv' . (int) $lv . '"></i>';
		}
		echo '<a class="izl-pill' . ( $on === $max ? ' is-on' : '' ) . '" href="' . esc_url( add_query_arg( 'max_difficulty', $max, $base ) ) . '"' . ( $on === $max ? ' aria-current="true"' : '' ) . '><span class="izl-pill-dots" aria-hidden="true">' . $dots . '</span>' . esc_html( $pill[0] ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</nav>';
}, 8 );

// ==========================================================================
//  Product tiles (woocommerce/content-product.php)
// ==========================================================================

/**
 * The first photo, as the Codex card shows it: the Codex image or the featured image, in its Codex framing.
 */
function izl_tile_image( $product, $codex ) {
	$id    = 0;
	$frame = array( 50, 50, 1 );
	if ( $codex && function_exists( 'fsz_card_image_ids' ) ) {
		$ids = fsz_card_image_ids( $product->get_id() );
		$id  = $ids ? (int) $ids[0] : 0;
		if ( $id && function_exists( 'fsz_frame' ) ) {
			$frame = fsz_frame( fsz_frames( $product->get_id() ), $id );
		}
	}
	if ( ! $id ) {
		$id = (int) $product->get_image_id();
		if ( $id && ! $codex && function_exists( 'izl_photo_frame' ) ) {
			$frame = izl_photo_frame( $product->get_id(), $id ); // 1.7.21: Edit photos (inc/photos.php)
		}
	}
	if ( ! $id ) {
		return '<span class="izl-noimg">' . esc_html__( 'No photo yet', 'izeltlab' ) . '</span>';
	}
	$style = sprintf( 'object-position:%1$s%% %2$s%%;transform-origin:%1$s%% %2$s%%;transform:scale(%3$s)', round( $frame[0], 1 ), round( $frame[1], 1 ), round( $frame[2], 3 ) );
	// 2.11.0: the sizes the browser picks a file by now follow the grid as it is really drawn (one column up to 480px,
	// two up to 820px, three up to 1100px, then four that grow with the window), times how much the 4:3 window crops and
	// zooms the photo. Before, tablets and small laptops were told a tile is 45% of the window (it is under 30%) and very
	// wide screens 300px (it is more). Filter: izl_tile_sizes.
	$meta = wp_get_attachment_metadata( $id );
	$k    = is_array( $meta ) && ! empty( $meta['width'] ) && ! empty( $meta['height'] ) ? max( 1, ( (int) $meta['width'] / (int) $meta['height'] ) / ( 4 / 3 ) ) : 1;
	$k   *= max( 1, (float) $frame[2] );
	$n    = function ( $v ) use ( $k ) {
		return (string) round( $v * $k, 1 );
	};
	$sizes = (string) apply_filters( 'izl_tile_sizes', '(min-width: 1101px) ' . $n( 16 ) . 'vw, (min-width: 821px) ' . $n( 28 ) . 'vw, (min-width: 481px) ' . $n( 45 ) . 'vw, ' . $n( 90 ) . 'vw', $id, $frame );
	// And the photo's list of files is tidied (izl_srcset_lean()): no file that is heavier than a wider one, and nothing
	// above 1024px (times the zoom): a sharp phone screen draws a tile about 1050 dots wide and was fetching the 1536px
	// file or the original for it.
	$lean = function ( $sources, $size, $src, $image_meta ) use ( $k ) {
		return izl_srcset_lean( $sources, $image_meta, (int) round( 1024 * $k ) );
	};
	add_filter( 'wp_calculate_image_srcset', $lean, 99, 4 );
	$html = wp_get_attachment_image( $id, 'woocommerce_single', false, array( 'style' => $style, 'alt' => $product->get_name(), 'sizes' => $sizes ) );
	remove_filter( 'wp_calculate_image_srcset', $lean, 99 );
	return $html;
}

/**
 * 2.11.0: a photo's list of sizes without the pointless ones: a file that is heavier than a WIDER file of the same photo
 * is never the better pick (it happens when the original was saved more tightly than the sizes WordPress made from it).
 * $cap: also leave out what is wider than this (0 = no limit); the narrowest
 * wider file stays when nothing under the limit comes close to it. Reads the file sizes from the uploads folder; if one cannot be read, the list stays as it
 * is. The same as Codex's fsz_srcset_lean() (the theme also works without Codex).
 */
function izl_srcset_lean( $sources, $meta, $cap = 0 ) {
	if ( ! is_array( $sources ) || count( $sources ) < 2 || empty( $meta['file'] ) ) {
		return $sources;
	}
	$up    = wp_get_upload_dir();
	$sub   = dirname( (string) $meta['file'] );
	$dir   = trailingslashit( $up['basedir'] ) . ( '.' === $sub ? '' : trailingslashit( $sub ) );
	$bytes = array();
	foreach ( $sources as $w => $src ) {
		$b = isset( $src['url'] ) ? (int) @filesize( $dir . wp_basename( rawurldecode( (string) strtok( (string) $src['url'], '?' ) ) ) ) : 0; // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( $b <= 0 ) {
			return $sources;
		}
		$bytes[ (int) $w ] = $b;
	}
	krsort( $bytes, SORT_NUMERIC ); // widest first
	foreach ( $bytes as $w => $b ) {
		foreach ( $bytes as $wider => $lighter ) {
			// "wider" only up to twice as wide: a phone should not have to unpack a far bigger picture to save a few KB
			if ( $wider > $w && $wider <= 2 * $w && $lighter <= $b ) {
				unset( $sources[ $w ], $bytes[ $w ] );
				break;
			}
		}
	}
	if ( $cap > 0 ) {
		// Widest first. Above the limit only the narrowest file may stay, and only when nothing under the limit comes
		// close to it (nine tenths of it): otherwise a sharp screen would be left with a file too small for it.
		$under = 0;
		foreach ( array_keys( $bytes ) as $w ) {
			$under = $w <= $cap ? max( $under, $w ) : $under;
		}
		$over = array_reverse( array_filter( array_keys( $bytes ), function ( $w ) use ( $cap ) {
			return $w > $cap;
		} ) ); // narrowest first
		foreach ( $over as $i => $w ) {
			if ( $i > 0 || $under >= 0.9 * $cap ) {
				unset( $sources[ $w ] );
			}
		}
	}
	return $sources;
}

function izl_product_tile( $product ) {
	$id    = $product->get_id();
	$codex = izl_is_codex( $id );
	$link  = $product->get_permalink();
	$name  = $product->get_name();
	$latin = '';
	$diff  = 0;
	$color = izl_teal();
	if ( $codex ) {
		// 3.1.0 (Dan, 2026-11-12): the Hungarian name alone (the Codex form's top field), and under it one line made from
		// the form, "English – Latin" (Panda King – Cubaris sp.). Only the parts that are filled in, no stray dash; with
		// neither, no line. Same names as on the card (fsz_names: an empty field falls back to the product name).
		if ( function_exists( 'fsz_names' ) ) {
			$names = fsz_names( $id );
			$name  = '' === $names['nick'] ? $name : $names['nick'];
			$latin = implode( ' – ', array_filter( array( trim( $names['english'] ), trim( $names['latin'] ) ), 'strlen' ) );
		} else {
			$shown = trim( (string) get_post_meta( $id, '_fsz_name', true ) );
			$name  = '' === $shown ? $name : $shown;
			$latin = trim( (string) get_post_meta( $id, '_fsz_latin', true ) );
		}
		$diff  = max( 0, min( 5, (int) get_post_meta( $id, '_fsz_difficulty', true ) ) );
		if ( function_exists( 'fsz_product_color' ) ) {
			$color = fsz_product_color( $id ); // own colour, else its group's (Codex 1.34+)
		} else {
			$own   = sanitize_hex_color( (string) get_post_meta( $id, '_fsz_color', true ) );
			$color = $own ? $own : $color;
		}
	}
	echo '<li ';
	wc_product_class( 'izl-tile ' . ( $codex ? 'is-codex' : 'is-supply' ), $product );
	echo ' style="--izl-tile:' . esc_attr( $color ) . ';--izl-tile-dark:' . esc_attr( izl_dark( $color ) ) . '">';

	echo '<a class="izl-tile-photo woocommerce-LoopProduct-link" href="' . esc_url( $link ) . '" tabindex="-1" aria-hidden="true">' . izl_tile_image( $product, $codex ); // phpcs:ignore WordPress.Security.EscapeOutput
	if ( $codex && function_exists( 'fsz_codex_number' ) ) {
		echo '<span class="izl-num">' . esc_html( fsz_codex_number( $id ) ) . '</span>';
	}
	// 2.2.0: sold out, but still in its place in the grid (Dan, 2026-11-05): a rubber stamp over the photo
	if ( ! $product->is_in_stock() ) {
		echo '<span class="izl-tile-out">' . esc_html__( 'Sold out', 'izeltlab' ) . '</span>';
	}
	echo '</a>';
	if ( $product->is_on_sale() ) {
		echo '<span class="onsale">' . esc_html__( 'Sale', 'izeltlab' ) . '</span>';
	}

	echo '<div class="izl-tile-body">';
	echo '<h2 class="woocommerce-loop-product__title izl-tile-name"><a href="' . esc_url( $link ) . '">' . esc_html( $name ) . '</a></h2>';
	if ( '' !== $latin ) {
		echo '<p class="izl-tile-latin">' . esc_html( $latin ) . '</p>';
	}
	echo '<div class="izl-tile-meta">';
	if ( $diff ) {
		// 1.7.14: the Codex level word in its colour (green, yellow, red), as on the card, instead of 5 stars.
		$level = izl_level( $diff );
		/* translators: %s: the Codex level word (Beginner, Intermediate, Expert) */
		$label = sprintf( __( 'Difficulty: %s', 'izeltlab' ), izl_level_word( $level ) );
		echo '<span class="izl-diff lv' . (int) ( $level + 2 ) . '" title="' . esc_attr( $label ) . '"><span class="screen-reader-text">' . esc_html__( 'Difficulty', 'izeltlab' ) . ': </span>' . esc_html( izl_level_word( $level ) ) . '</span>';
	}
	echo '<span class="price">' . izl_tile_price( $product ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '</div>';
	// 3.1.0 (Dan, 2026-11-12): no Codex / Részletek button; the whole tile opens the species (style.css, 3.1.0).
	echo '<div class="izl-tile-btns">';
	izl_tile_add_to_cart( $product );
	echo '</div></div></li>';
}

// 3.1.0 (Dan, 2026-11-13): the tile shows ONE price, never "from – to": the cheapest pack that can be bought now (else
// the cheapest of all, for a sold out species), and small under it which pack that is ("10 db-os csomag").
// Products without packs keep WooCommerce's own price.
function izl_tile_price( $product ) {
	if ( ! $product->is_type( 'variable' ) ) {
		return $product->get_price_html();
	}
	$prices = $product->get_variation_prices( true ); // the visible packs, cheapest first
	$ids    = isset( $prices['price'] ) ? array_keys( $prices['price'] ) : array();
	$pick   = null;
	foreach ( $ids as $vid ) {
		$v = wc_get_product( $vid );
		if ( $v && $v->is_purchasable() && $v->is_in_stock() ) {
			$pick = $v;
			break;
		}
	}
	if ( ! $pick && $ids ) {
		$pick = wc_get_product( $ids[0] );
	}
	if ( ! $pick ) {
		return $product->get_price_html();
	}
	$key  = 'attribute_' . sanitize_title( IZL_PACK_ATTR );
	$va   = $pick->get_variation_attributes();
	$pack = isset( $va[ $key ] ) && '' !== (string) $va[ $key ] ? izl_pack_option_name( $product, $key, (string) $va[ $key ] ) : '';
	$html = $pick->get_price_html();
	if ( '' !== $pack ) {
		/* translators: %s: the pack, e.g. "10 db" (Hungarian: "10 db-os csomag") */
		$text  = preg_match( '/\bdb$/u', $pack ) ? sprintf( __( '%s pack', 'izeltlab' ), $pack ) : $pack;
		$html .= '<span class="izl-tile-per">' . esc_html( $text ) . '</span>';
	}
	return $html;
}

// 2.6.0: a product with packs is bought from its tile in one tap: "Kosárba (10 db)" puts the start pack (the one its
// page opens on) in the cart, like a simple product's button (WooCommerce's AJAX add to cart, with the pack's own id).
// Anything else, or a pack that cannot be bought right now, keeps WooCommerce's own button.
function izl_tile_add_to_cart( $product ) {
	if ( $product->is_type( 'variable' ) && $product->is_in_stock() ) {
		$v     = izl_start_variation( $product );
		$attrs = $v ? array_map( 'strval', $v->get_variation_attributes() ) : array();
		if ( $v && $v->is_purchasable() && $v->is_in_stock() && $attrs && ! in_array( '', $attrs, true ) ) {
			$pack = izl_start_pack_name( $product );
			/* translators: %s: the pack, e.g. "10 db" */
			$text = '' !== $pack ? sprintf( __( 'To the cart (%s)', 'izeltlab' ), $pack ) : __( 'To the cart', 'izeltlab' );
			/* translators: 1: the pack, e.g. "10 db", 2: product name */
			$label = sprintf( __( 'Add %1$s of %2$s to the cart', 'izeltlab' ), '' !== $pack ? $pack : '1', $product->get_name() );
			printf(
				'<a href="%1$s" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart izl-tile-pack" data-product_id="%2$d" data-product_sku="%3$s" aria-label="%4$s" rel="nofollow">%5$s</a>',
				esc_url( $v->add_to_cart_url() ),
				(int) $v->get_id(),
				esc_attr( $v->get_sku() ),
				esc_attr( $label ),
				esc_html( $text )
			);
			return;
		}
	}
	woocommerce_template_loop_add_to_cart();
}
