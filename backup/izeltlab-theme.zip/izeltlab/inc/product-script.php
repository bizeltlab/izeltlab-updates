<?php
// ==========================================================================
//  FILE: inc/product-script.php   (Ízeltláb theme)
//  WHAT: Loads the product page script (assets/product.js) with its settings, and the product page's Customizer panel.
//  SEEN: Product pages; Appearance → Customize → Ízeltláb product page.
//  SECTIONS IN THIS FILE:
//    1. Product page script (assets/product.js) and its Customizer section
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Product page script (assets/product.js) and its Customizer section
// ==========================================================================

add_action( 'wp_enqueue_scripts', function () {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}
	wp_enqueue_script( 'izeltlab-product', get_stylesheet_directory_uri() . '/' . izl_min( 'assets/product.js' ), array( 'jquery' ), IZL_VERSION, true );
	wp_localize_script( 'izeltlab-product', 'izlProduct', array(
		'vat'      => trim( (string) izl_pmod( 'izl_vat_note' ) ),
		'less'     => __( 'Decrease quantity', 'izeltlab' ),
		'more'     => __( 'Increase quantity', 'izeltlab' ),
		'low'      => IZL_LOW_STOCK,
		// 2.0.7: the price of one (no packs), for the cart guess on Kosárba vele! (packs: the chosen pack's price)
		'unit'     => ( $izl_pp = wc_get_product( get_queried_object_id() ) ) && ! $izl_pp->is_type( 'variable' ) && '' !== (string) $izl_pp->get_price() ? (float) wc_get_price_to_display( $izl_pp ) : 0,
		'added'    => izl_just_added(), // 1.7.17: the "added to cart" stamp on the buy box
		'addedSum' => izl_just_added() ? izl_cart_total() : null, // 1.7.18: free-shipping progress after a reload add
		'tz'       => 'Europe/Budapest',
		'ship'     => array(
			'cutoff' => IZL_SHIP_CUTOFF,
			'from'   => IZL_NUDGE_FROM,
			'days'   => IZL_SHIP_DAYS,
			'words'  => izl_ship_words(),
			'closed' => izl_closed_list(), // 2.1.0: holidays + closed days (Y-m-d), from today to the end of next year
		),
		// 1.7.18: Kosárba without a reload (WooCommerce's own AJAX add to cart), unless the shop goes to the cart after
		// adding (WooCommerce → Settings → Products), then the form is sent as before.
		'cart'     => array(
			'url'      => class_exists( 'WC_AJAX' ) ? WC_AJAX::get_endpoint( 'add_to_cart' ) : '',
			'redirect' => 'yes' === get_option( 'woocommerce_cart_redirect_after_add' ),
		),
		'freeShip' => izl_free_ship(),
		'money'    => array(
			'cur' => html_entity_decode( get_woocommerce_currency_symbol() ),
			'pos' => get_option( 'woocommerce_currency_pos', 'right_space' ),
		),
		'prog'     => array(
			/* translators: %s: amount still missing, e.g. 15 500 Ft */
			'more' => __( 'Only %s more and shipping is free!', 'izeltlab' ),
			'done' => __( 'Done! Shipping is free!', 'izeltlab' ),
		),
		'pack'     => sanitize_title( IZL_PACK_ATTR ), // the pack choice shows in the note under Ft
		'notify'   => __( 'Tell me when back!', 'izeltlab' ), // 2.2.0: the cart button of a sold-out product
		// 1.7.19: the phone product page (the bottom drawer)
		'phone'    => array(
			'open'     => __( 'Open the drawer', 'izeltlab' ),
			'close'    => __( 'Close the drawer', 'izeltlab' ),
			'ship'     => __( 'Shipping', 'izeltlab' ),
			/* translators: %s: the arrival day, e.g. "on Tuesday" */
			'arrive'   => __( '%s with you!', 'izeltlab' ),
			'photo'    => __( 'Photo', 'izeltlab' ),
			'closePic' => __( 'Close the photo', 'izeltlab' ),
			// 2.0.5: the closed drawer's room above the button (px off, capped so the handle never comes closer than
			// 6px) and the roll-back switch (2.0.3's drawer: no trim, pinch zoom allowed)
			'trim'     => (float) izl_pmod( 'izl_drawer_trim' ),
			'r203'     => (bool) izl_pmod( 'izl_drawer_203' ),
		),
		'stock'    => array(
			'in'   => __( 'In stock', 'izeltlab' ),
			/* translators: %d: how many are left */
			'low'  => __( 'Only %d left', 'izeltlab' ),
			'back' => __( 'Available to order', 'izeltlab' ),
			'out'  => __( 'Currently unavailable', 'izeltlab' ),
		),
		'edit'     => current_user_can( 'edit_post', get_queried_object_id() ) ? array(
			'ajax'  => admin_url( 'admin-ajax.php', 'relative' ),
			'nonce' => wp_create_nonce( 'izl_product_text' ),
			'id'    => get_queried_object_id(),
		) : null,
	) );
	// 3.0.0: the editing tools are a file of their own that only editors get (shoppers download less)
	if ( current_user_can( 'edit_post', get_queried_object_id() ) ) {
		wp_enqueue_script( 'izeltlab-product-edit', get_stylesheet_directory_uri() . '/' . izl_min( 'assets/product-edit.js' ), array( 'jquery', 'izeltlab-product' ), IZL_VERSION, true );
	}
}, 30 );

add_action( 'customize_register', function ( $wp_customize ) {
	$d = izl_product_defaults();
	$wp_customize->add_section( 'izl_product', array(
		'title'       => __( 'Ízeltláb product page', 'izeltlab' ),
		'description' => __( 'The trust points, the questions, the pack question and the notes next to the price and the stock. Empty a field to hide it.', 'izeltlab' ),
		'priority'    => 31,
	) );
	$add = function ( $key, $label, $type, $description = '' ) use ( $wp_customize, $d ) {
		$sanitize = array(
			'text'     => 'sanitize_text_field',
			'textarea' => 'wp_kses_post',
			'checkbox' => 'absint',
			'number'   => function ( $v ) {
				return max( 0, (float) str_replace( ',', '.', (string) $v ) );
			},
		);
		$wp_customize->add_setting( $key, array( 'default' => $d[ $key ], 'sanitize_callback' => $sanitize[ $type ] ) );
		$wp_customize->add_control( $key, array( 'label' => $label, 'description' => $description, 'section' => 'izl_product', 'type' => $type ) );
	};
	for ( $i = 1; $i <= 3; $i++ ) {
		/* translators: %d: number of the trust point */
		$add( "izl_trust_{$i}_title", sprintf( __( 'Trust point %d: title', 'izeltlab' ), $i ), 'text' );
		/* translators: %d: number of the trust point */
		$add( "izl_trust_{$i}_text", sprintf( __( 'Trust point %d: text', 'izeltlab' ), $i ), 'text' );
	}
	$add( 'izl_trust_difficulty', __( 'Show the difficulty point', 'izeltlab' ), 'checkbox', __( 'Taken from the Codex difficulty of each species.', 'izeltlab' ) );
	for ( $i = 1; $i <= IZL_FAQ_COUNT; $i++ ) {
		/* translators: %d: number of the question */
		$add( "izl_faq_{$i}_q", sprintf( __( 'Question %d', 'izeltlab' ), $i ), 'text' );
		/* translators: %d: number of the question */
		$add( "izl_faq_{$i}_a", sprintf( __( 'Answer %d', 'izeltlab' ), $i ), 'textarea' );
	}
	$add( 'izl_vat_note', __( 'VAT note next to the price', 'izeltlab' ), 'text' );
	$add( 'izl_free_ship', __( 'Free shipping over (amount)', 'izeltlab' ), 'number', __( 'The line on the buy ticket and the progress after an add to cart. 0 = no line. Saving also sets it as the minimum order amount of the Free shipping method in every shipping zone (also in Edit buy box).', 'izeltlab' ) );
	$add( 'izl_pack_question', __( 'Question above the packs', 'izeltlab' ), 'text' );
	$add( 'izl_pack_tip', __( 'Pack tip (default)', 'izeltlab' ), 'text', __( 'Under the question. A product can have its own: Product data → General → Pack tip.', 'izeltlab' ) );
	// 2.0.5: the phone drawer
	$add( 'izl_drawer_trim', __( 'Phone: closed drawer, px less room above the button', 'izeltlab' ), 'number', __( 'The closed drawer starts lower; the button stays where it is. 0 = as in 2.0.3. Capped so the button stays at least 6px under the handle.', 'izeltlab' ) );
	$add( 'izl_drawer_203', __( 'Phone: roll back to the 2.0.3 drawer', 'izeltlab' ), 'checkbox', __( 'Only if the new drawer misbehaves on a phone: the closed drawer at its 2.0.3 height and pinch zoom allowed again. The 2.0.4 and 2.0.5 fixes stay.', 'izeltlab' ) );
} );
