<?php
// ==========================================================================
//  FILE: inc/photos.php   (Ízeltláb theme)
//  WHAT: EDITORS ONLY tools for supply products: the "Edit photos" dialog (server side) and the framed photo
//        on the page.
//  SEEN: Product pages of supplies (the photo); the Edit photos button for editors.
// ==========================================================================

/**
 * 1.7.21: "Edit photos" for products without the Codex card (supplies and every other non-animal product).
 *
 * An admin strip button opens a dialog (assets/photos.js): the product's photos in order (the first is the main photo),
 * add from the media library or the device, reorder, remove, and per photo a frame: which part shows and how close
 * (zoom). The frame is the same idea as the Codex card's: x %, y % and a zoom, saved per photo in _izl_frames. It shows
 * on the shop tiles (4:3), on the product page (the framed photo in a 4:3 window) and in Tedd mellé.
 *
 * @package izeltlab
 */

defined( 'ABSPATH' ) || exit;

// The frame as inline CSS for an <img> that fills its window with object-fit: cover.
function izl_photo_frame_style( $frame ) {
	return sprintf( 'object-position:%1$s%% %2$s%%;transform-origin:%1$s%% %2$s%%;transform:scale(%3$s)', round( $frame[0], 1 ), round( $frame[1], 1 ), round( $frame[2], 3 ) );
}

// The product page gallery: a framed photo shows in a 4:3 window (style.css .izl-framed), as on the shop tiles.
add_filter( 'woocommerce_single_product_image_thumbnail_html', function ( $html, $att_id ) {
	global $product;
	if ( ! $product instanceof WC_Product || izl_is_codex( $product->get_id() ) ) {
		return $html;
	}
	$frame = izl_photo_frame( $product->get_id(), (int) $att_id );
	if ( ! izl_photo_framed( $frame ) ) {
		return $html;
	}
	$html = preg_replace( '/class="woocommerce-product-gallery__image/', 'class="woocommerce-product-gallery__image izl-framed', $html, 1 );
	return preg_replace( '/<img /', '<img style="' . esc_attr( izl_photo_frame_style( $frame ) ) . '" ', $html, 1 );
}, 20, 2 );

// Tedd mellé and anywhere else a framed product's small square photo is printed through get_image().
add_filter( 'woocommerce_product_get_image', function ( $html, $product, $size ) {
	if ( ! $product instanceof WC_Product || izl_is_codex( $product->get_id() ) || ! $product->get_image_id() ) {
		return $html;
	}
	$frame = izl_photo_frame( $product->get_id(), (int) $product->get_image_id() );
	if ( ! izl_photo_framed( $frame ) || false !== strpos( $html, 'izl-framed-img' ) ) {
		return $html;
	}
	// The uncropped photo (the square thumbnail is already cut in the middle), cut by the frame instead.
	$img = wp_get_attachment_image( $product->get_image_id(), 'woocommerce_single', false, array(
		'class' => 'izl-framed-img',
		'style' => izl_photo_frame_style( $frame ),
		'alt'   => $product->get_name(),
	) );
	return $img ? '<span class="izl-framed-box">' . $img . '</span>' : $html;
}, 20, 3 );

// The editor data: the photos in order, with a small and a big address and the frame of each.
function izl_photos_data( $product ) {
	$id   = $product->get_id();
	$ids  = array_values( array_filter( array_merge( array( (int) $product->get_image_id() ), array_map( 'intval', $product->get_gallery_image_ids() ) ) ) );
	$list = array();
	foreach ( array_unique( $ids ) as $att ) {
		$thumb = wp_get_attachment_image_url( $att, 'woocommerce_thumbnail' );
		$big   = wp_get_attachment_image_url( $att, 'woocommerce_single' );
		if ( ! $big ) {
			continue;
		}
		$list[] = array(
			'id'    => $att,
			'thumb' => $thumb ? $thumb : $big,
			'big'   => $big,
			'frame' => izl_photo_frame( $id, $att ),
		);
	}
	return array( 'id' => $id, 'photos' => $list );
}

// The button (next to Edit buy box) and its data, for whoever can edit the product; non-Codex products only.
add_action( 'woocommerce_single_product_summary', function () {
	global $product;
	if ( ! $product instanceof WC_Product || izl_is_codex( $product->get_id() ) || ! current_user_can( 'edit_post', $product->get_id() ) ) {
		return;
	}
	echo '<script type="application/json" id="izl-photos-data">' . wp_json_encode( izl_photos_data( $product ) ) . '</script>';
}, 5 );

add_action( 'wp_enqueue_scripts', function () {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}
	$id = get_queried_object_id();
	if ( ! $id || izl_is_codex( $id ) || ! current_user_can( 'edit_post', $id ) || ! current_user_can( 'upload_files' ) ) {
		return;
	}
	wp_enqueue_media( array( 'post' => $id ) );
	wp_enqueue_script( 'izeltlab-photos', get_stylesheet_directory_uri() . '/' . izl_min( 'assets/photos.js' ), array( 'jquery', 'izeltlab-product' ), IZL_VERSION, true );
}, 40 );
