<?php
// ==========================================================================
//  FILE: inc/edit-new-product.php   (Ízeltláb theme)
//  WHAT: ADMIN ONLY. The "New product" bar over the shop lists and the draft bar (Publish / Delete) over a draft product.
//  SEEN: Only by logged-in shop managers.
//  SECTIONS IN THIS FILE:
//    1. New products from the shop pages (1.7.15)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  New products from the shop pages (1.7.15)
// ==========================================================================

// Admins add products from the shop: "New product" on a category page starts an empty draft in that category (1.7.16:
// no templates). A draft never reaches shoppers until it is published from the bar over its page.

function izl_can_add_products() {
	return is_user_logged_in() && current_user_can( 'publish_products' );
}

// The page a draft is seen on (drafts open as a preview), with "new" to open its editor.
function izl_draft_link( $id, $new = false ) {
	$url = get_preview_post_link( $id );
	return $new ? add_query_arg( 'izl_new', 1, $url ) : $url;
}

function izl_admin_form( $action, $fields, $button, $confirm = '' ) {
	$out = '<form class="izl-admin-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"' . ( $confirm ? ' onsubmit="return confirm(' . esc_attr( wp_json_encode( $confirm ) ) . ')"' : '' ) . '>';
	$out .= '<input type="hidden" name="action" value="' . esc_attr( $action ) . '">' . wp_nonce_field( $action, '_izl_nonce', true, false );
	foreach ( $fields as $name => $value ) {
		$out .= '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">';
	}
	return $out . $button . '</form>';
}

// The shop pages: "New product". On the shop itself, pick the category first.
function izl_new_product_bar() {
	if ( ! izl_can_add_products() || ! ( is_shop() || is_product_category() ) ) {
		return;
	}
	static $done = false;
	if ( $done ) {
		return;
	}
	$done   = true;
	$button = '<button type="submit" class="izl-btn izl-new-btn">+ ' . esc_html__( 'New product', 'izeltlab' ) . '</button>';
	echo '<div class="izl-newbar">';
	if ( is_product_category() ) {
		echo izl_admin_form( 'izl_new_product', array( 'cat' => get_queried_object_id() ), $button ); // phpcs:ignore WordPress.Security.EscapeOutput
	} else {
		$select = '<select name="cat" required aria-label="' . esc_attr__( 'Category', 'izeltlab' ) . '"><option value="">' . esc_html__( 'Choose a category', 'izeltlab' ) . '</option>';
		$terms  = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'orderby' => 'name' ) );
		$walk   = function ( $parent, $depth ) use ( &$walk, $terms, &$select ) {
			foreach ( $terms as $t ) {
				if ( (int) $t->parent === (int) $parent && 'uncategorized' !== $t->slug ) {
					$select .= '<option value="' . (int) $t->term_id . '">' . str_repeat( '— ', $depth ) . esc_html( $t->name ) . '</option>';
					$walk( $t->term_id, $depth + 1 );
				}
			}
		};
		$walk( 0, 0 );
		$select .= '</select>';
		echo izl_admin_form( 'izl_new_product', array(), $select . $button ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</div>';
}
add_action( 'woocommerce_before_shop_loop', 'izl_new_product_bar', 7 );
add_action( 'woocommerce_no_products_found', 'izl_new_product_bar', 5 );

// "New product": an empty draft in the category (and its parents), opened with its editor.
add_action( 'admin_post_izl_new_product', function () {
	check_admin_referer( 'izl_new_product', '_izl_nonce' );
	$term = get_term( isset( $_POST['cat'] ) ? absint( $_POST['cat'] ) : 0, 'product_cat' );
	if ( ! izl_can_add_products() || ! $term || is_wp_error( $term ) ) {
		wp_die( esc_html__( 'You cannot add products here.', 'izeltlab' ) );
	}
	$p = new WC_Product_Simple();
	$p->set_status( 'draft' );
	$p->set_name( izl_shop_text( 'New product' ) ); // the shop's language, whatever the admin's own
	$p->update_meta_data( '_izl_auto_title', 1 ); // Publish names it from the card when it is a species
	$cats = array( (int) $term->term_id );
	foreach ( get_ancestors( $term->term_id, 'product_cat', 'taxonomy' ) as $a ) {
		$cats[] = (int) $a;
	}
	$p->set_category_ids( $cats );
	$id = $p->save();
	// A genus page (a category under the group) starts the Latin name with the genus.
	if ( $term->parent && izl_is_codex( $id ) ) {
		update_post_meta( $id, '_fsz_latin', $term->name );
	}
	wp_safe_redirect( izl_draft_link( $id, true ) );
	exit;
} );

// "Publish" (and "Save name") on a draft.
add_action( 'admin_post_izl_publish', function () {
	check_admin_referer( 'izl_publish', '_izl_nonce' );
	$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
	$p  = $id ? wc_get_product( $id ) : null;
	if ( ! $p || ! izl_can_add_products() || ! current_user_can( 'edit_post', $id ) ) {
		wp_die( esc_html__( 'This product cannot be published from here.', 'izeltlab' ) );
	}
	$name = isset( $_POST['name'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['name'] ) ) ) : '';
	if ( '' !== $name ) {
		$p->set_name( $name );
		$p->delete_meta_data( '_izl_auto_title' );
	} elseif ( $p->get_meta( '_izl_auto_title' ) && izl_is_codex( $id ) ) {
		// A species is named like the others: "Latin – „Nickname”" (the name only search engines and screen readers get).
		$latin = trim( (string) get_post_meta( $id, '_fsz_latin', true ) );
		$nick  = trim( (string) get_post_meta( $id, '_fsz_name', true ) );
		if ( '' !== $latin && '' !== $nick ) {
			$p->set_name( $latin . ' – „' . $nick . '”' );
		} elseif ( '' !== $nick . $latin ) {
			$p->set_name( '' !== $nick ? $nick : $latin );
		}
	}
	$publish = ! empty( $_POST['publish'] );
	if ( $publish ) {
		$p->delete_meta_data( '_izl_auto_title' );
		$p->set_status( 'publish' );
	}
	$p->save();
	wp_safe_redirect( $publish ? get_permalink( $id ) : izl_draft_link( $id ) );
	exit;
} );

// "Delete": a draft goes to the trash (WordPress keeps it there for 30 days).
add_action( 'admin_post_izl_trash', function () {
	check_admin_referer( 'izl_trash', '_izl_nonce' );
	$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
	if ( ! $id || 'draft' !== get_post_status( $id ) || ! current_user_can( 'delete_post', $id ) ) {
		wp_die( esc_html__( 'Only drafts can be deleted from here.', 'izeltlab' ) );
	}
	$group = izl_group_term( $id );
	wp_trash_post( $id );
	$link = $group ? get_term_link( $group ) : '';
	wp_safe_redirect( $link && ! is_wp_error( $link ) ? $link : wc_get_page_permalink( 'shop' ) );
	exit;
} );

// On a draft's page: a bar over the page saying so, with Publish / Delete (and a name field for products without a
// Codex card, whose name shows on the page).
add_action( 'woocommerce_before_single_product', function () {
	$id = get_the_ID();
	if ( ! $id || 'draft' !== get_post_status( $id ) || ! izl_can_add_products() || ! current_user_can( 'edit_post', $id ) ) {
		return;
	}
	$codex = izl_is_codex( $id );
	echo '<div class="izl-draftbar">';
	echo '<p class="izl-draftbar-text"><b>' . esc_html__( 'Draft', 'izeltlab' ) . '</b> ' . esc_html( $codex ? __( 'Shoppers cannot see this page yet. Fill in the card and the buy box, then publish.', 'izeltlab' ) : __( 'Shoppers cannot see this page yet. Name it, fill in the buy box, then publish.', 'izeltlab' ) ) . '</p>';
	$name   = get_post_meta( $id, '_izl_auto_title', true ) ? '' : get_the_title( $id );
	$fields = $codex ? '' : '<label class="izl-draftbar-name"><span>' . esc_html__( 'Name', 'izeltlab' ) . '</span><input type="text" name="name" value="' . esc_attr( html_entity_decode( $name, ENT_QUOTES, 'UTF-8' ) ) . '" required></label><button type="submit" class="izl-btn is-alt">' . esc_html__( 'Save name', 'izeltlab' ) . '</button>';
	echo izl_admin_form( 'izl_publish', array( 'id' => $id ), $fields . '<button type="submit" name="publish" value="1" class="izl-btn">' . esc_html__( 'Publish', 'izeltlab' ) . '</button>' ); // phpcs:ignore WordPress.Security.EscapeOutput
	echo izl_admin_form( 'izl_trash', array( 'id' => $id ), '<button type="submit" class="izl-btn is-alt">' . esc_html__( 'Delete', 'izeltlab' ) . '</button>', __( 'Delete this draft?', 'izeltlab' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
	echo '</div>';
	// Just made with "New product": open the card editor (species) or the buy box editor (everything else).
	if ( ! empty( $_GET['izl_new'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		echo '<script>(function(){var n=0,t=setInterval(function(){var b=document.querySelector(' . wp_json_encode( $codex ? '.fsz-edit-open' : '.izl-buybox-open' ) . ');if(b||++n>40){clearInterval(t);if(b){b.click();}}},150);})();</script>';
	}
}, 5 );
