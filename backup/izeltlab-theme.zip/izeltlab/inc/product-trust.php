<?php
// ==========================================================================
//  FILE: inc/product-trust.php   (Ízeltláb theme)
//  WHAT: Trust points and common questions under the buy box, and the cart button's text.
//  SEEN: Product pages, under the cart button.
//  SECTIONS IN THIS FILE:
//    1. Trust points and common questions
//    2. The cart button
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Trust points and common questions
// ==========================================================================

function izl_trust_icon( $name ) {
	$paths = array(
		'shield' => '<path d="M12 3l7 3v5c0 4.5-3 8.3-7 10-4-1.7-7-5.5-7-10V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
		'truck'  => '<path d="M2.5 6h11v10h-11zM13.5 9.5h4l3 3.5v3h-7z"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/>',
		'home'   => '<path d="M4 11l8-7 8 7v9H4z"/><path d="M10 20v-5h4v5"/>',
		'star'   => '<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9 6.8 19.6l1-5.8L3.5 9.7l5.9-.9z"/>',
	);
	return '<span class="izl-trust-icon" aria-hidden="true"><svg viewBox="0 0 24 24">' . $paths[ $name ] . '</svg></span>';
}

// The difficulty point, from the species' Codex difficulty: [title, text] or null.
function izl_difficulty_point( $product_id ) {
	$diff = (int) get_post_meta( $product_id, '_fsz_difficulty', true );
	if ( $diff < 1 || $diff > 5 ) {
		return null;
	}
	// 1.7.14: told with the Codex level word, as on the card (was "Difficulty 3/5").
	$level = izl_level( $diff );
	$word  = izl_level_word( $level );
	if ( 1 === $level ) {
		/* translators: %s: the Codex level word */
		return array( __( 'Good for beginners', 'izeltlab' ), sprintf( __( '%s on the Codex: a good first species.', 'izeltlab' ), $word ) );
	}
	if ( 2 === $level ) {
		/* translators: %s: the Codex level word */
		return array( __( 'Medium difficulty', 'izeltlab' ), sprintf( __( '%s on the Codex: some experience helps.', 'izeltlab' ), $word ) );
	}
	/* translators: %s: the Codex level word */
	return array( __( 'For experienced keepers', 'izeltlab' ), sprintf( __( '%s on the Codex: best as a second or third species.', 'izeltlab' ), $word ) );
}

function izl_trust_points() {
	$points = array();
	foreach ( array( 1 => 'shield', 2 => 'truck' ) as $i => $icon ) {
		$points[] = array( $icon, izl_pmod( "izl_trust_{$i}_title" ), izl_pmod( "izl_trust_{$i}_text" ) );
	}
	$diff = izl_pmod( 'izl_trust_difficulty' ) ? izl_difficulty_point( get_the_ID() ) : null;
	if ( $diff ) {
		$points[] = array( 'star', $diff[0], $diff[1] );
	}
	$points[] = array( 'home', izl_pmod( 'izl_trust_3_title' ), izl_pmod( 'izl_trust_3_text' ) );
	$points   = array_filter( $points, function ( $p ) {
		return '' !== trim( (string) $p[1] );
	} );
	if ( ! $points ) {
		return;
	}
	// The icons take the species' Codex colour (its own, or its group's).
	$color = function_exists( 'fsz_product_color' ) ? fsz_product_color( get_the_ID() ) : izl_teal();
	echo '<ul class="izl-trust" style="--izl-group:' . esc_attr( $color ) . ';--izl-group-dark:' . esc_attr( izl_dark( $color ) ) . '" aria-label="' . esc_attr__( 'Why buy here', 'izeltlab' ) . '">';
	foreach ( $points as $p ) {
		echo '<li' . ( '' !== trim( (string) $p[2] ) ? ' title="' . esc_attr( $p[2] ) . '"' : '' ) . '>' . izl_trust_icon( $p[0] ) . '<div><b>' . esc_html( $p[1] ) . '</b>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( '' !== trim( (string) $p[2] ) ) {
			echo '<span>' . esc_html( $p[2] ) . '</span>';
		}
		echo '</div></li>';
	}
	echo '</ul>';
}

define( 'IZL_FAQ_COUNT', 6 ); // question slots in the Customizer

function izl_product_faq() {
	$faqs = array();
	for ( $i = 1; $i <= IZL_FAQ_COUNT; $i++ ) {
		$q = trim( (string) izl_pmod( "izl_faq_{$i}_q" ) );
		$a = trim( (string) izl_pmod( "izl_faq_{$i}_a" ) );
		if ( '' !== $q && '' !== $a ) {
			$faqs[] = '<details class="izl-faq"><summary>' . esc_html( $q ) . '</summary><div class="izl-faq-a">' . wpautop( wp_kses_post( $a ) ) . '</div></details>';
		}
	}
	if ( ! $faqs ) {
		return;
	}
	// Under the card and the buy box (1.6.0), all of them, in two columns: first half left, second half right.
	$half = (int) ceil( count( $faqs ) / 2 );
	echo '<section class="izl-faqs"><h2>' . esc_html__( 'Common questions', 'izeltlab' ) . '</h2><div class="izl-faq-cols"><div>' . implode( '', array_slice( $faqs, 0, $half ) ) . '</div><div>' . implode( '', array_slice( $faqs, $half ) ) . '</div></div></section>'; // phpcs:ignore WordPress.Security.EscapeOutput
}

// ==========================================================================
//  The cart button
// ==========================================================================

// 1.7.18: "Kosárba vele!" on the product page's cart button.
add_filter( 'woocommerce_product_single_add_to_cart_text', function ( $text, $product = null ) {
	if ( $product instanceof WC_Product && $product->is_type( 'external' ) ) {
		return $text; // its own button text (Product data → General)
	}
	return __( 'Add it to the cart!', 'izeltlab' );
}, 10, 2 );

// 1.7.17: the Kosárba button sends the form and WooCommerce shows the same page again; remember that this request put
// the product in the cart, so product.js can press the green "added" stamp onto the buy box.
add_action( 'woocommerce_add_to_cart', function ( $key, $product_id ) {
	$GLOBALS['izl_just_added'] = (int) $product_id;
}, 10, 2 );

function izl_just_added() {
	return ! empty( $GLOBALS['izl_just_added'] ) && (int) $GLOBALS['izl_just_added'] === (int) get_queried_object_id();
}
