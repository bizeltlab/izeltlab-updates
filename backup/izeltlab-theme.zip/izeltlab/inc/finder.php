<?php
/**
 * 2.6.0: the header search (Dan, 2026-11-06). The search button opens the top bar downwards (a short slide, no popup
 * box), with a search field and the results right under it while typing: species first, then supplies, each with a
 * photo, name, Latin name, price and pack, and a "+" that puts the start pack in the cart in one tap. The matching is
 * Ízeltláb Bolt's (names in Hungarian, English and Latin, the Codex card's words, the badges, the level, typos
 * forgiven); without Bolt, WordPress's own product search. Enter opens the full results page, Esc closes.
 * Without JavaScript the button still opens the panel (a #izl-sp link) and the field searches on Enter.
 * Off: add_filter( 'izl_live_search', '__return_false' ) keeps the panel with its field, without the live results.
 */

defined( 'ABSPATH' ) || exit;

// The matching product ids, best first (the same matching as the results page).
function izl_find_ids( $q, $limit ) {
	$fix = '';
	if ( function_exists( 'izb_search_ids' ) && function_exists( 'izb_opt' ) && izb_opt( 'search_on' ) ) {
		$words = array_values( array_unique( array_filter( explode( ' ', izb_norm( $q ) ) ) ) );
		if ( ! $words ) {
			return array( array(), '' );
		}
		izb_search_fill();
		$ids = izb_search_ids( $words );
		if ( ! $ids ) {
			$fixed = izb_search_fix( $words );
			$ids   = $fixed ? izb_search_ids( $fixed ) : array();
			$fix   = $ids ? implode( ' ', $fixed ) : '';
		}
		return array( array_keys( $ids ), $fix );
	}
	$ids = get_posts( array(
		'post_type'      => 'product',
		'post_status'    => 'publish',
		's'              => $q,
		'posts_per_page' => $limit * 2,
		'fields'         => 'ids',
	) );
	return array( array_map( 'intval', $ids ), '' );
}

// One result as the panel shows it.
function izl_find_item( $product ) {
	$id    = $product->get_id();
	$codex = izl_is_codex( $id );
	$name  = $product->get_name();
	$latin = '';
	$num   = '';
	$img   = 0;
	$frame = array( 50, 50, 1 );
	if ( $codex ) {
		$shown = trim( (string) get_post_meta( $id, '_fsz_name', true ) );
		$name  = '' === $shown ? $name : $shown;
		$latin = trim( (string) get_post_meta( $id, '_fsz_latin', true ) );
		$num   = function_exists( 'fsz_codex_number' ) ? (string) fsz_codex_number( $id ) : '';
		if ( function_exists( 'fsz_card_image_ids' ) ) {
			$ids = fsz_card_image_ids( $id );
			$img = $ids ? (int) $ids[0] : 0;
			if ( $img && function_exists( 'fsz_frame' ) ) {
				$frame = fsz_frame( fsz_frames( $id ), $img );
			}
		}
	}
	if ( ! $img ) {
		$img = (int) $product->get_image_id();
		if ( $img && ! $codex && function_exists( 'izl_photo_frame' ) ) {
			$frame = izl_photo_frame( $id, $img );
		}
	}
	$in    = $product->is_in_stock();
	$pack  = '';
	$price = $product->get_price_html();
	$add   = 0;
	if ( $product->is_type( 'variable' ) ) {
		$v = izl_start_variation( $product );
		if ( $v ) {
			$pack  = izl_start_pack_name( $product );
			$price = wc_price( wc_get_price_to_display( $v ) );
			$attrs = array_map( 'strval', $v->get_variation_attributes() );
			$add   = $in && $v->is_purchasable() && $v->is_in_stock() && $attrs && ! in_array( '', $attrs, true ) ? $v->get_id() : 0;
		}
	} elseif ( $product->is_type( 'simple' ) && $in && $product->is_purchasable() ) {
		$add = $id;
	}
	$label = $add ? sprintf( __( 'Add %1$s of %2$s to the cart', 'izeltlab' ), '' !== $pack ? $pack : '1', $name ) : '';
	return array(
		'name'  => html_entity_decode( $name, ENT_QUOTES, 'UTF-8' ),
		'latin' => $latin,
		'num'   => $num,
		'url'   => $product->get_permalink(),
		'img'   => $img ? (string) wp_get_attachment_image_url( $img, 'woocommerce_thumbnail' ) : '',
		'pos'   => round( $frame[0], 1 ) . '% ' . round( $frame[1], 1 ) . '%',
		'zoom'  => round( max( 1, (float) $frame[2] ), 3 ),
		'price' => trim( html_entity_decode( wp_strip_all_tags( $price ), ENT_QUOTES, 'UTF-8' ) ),
		'pack'  => $pack,
		'out'   => ! $in,
		'sp'    => $codex,
		'add'   => (int) $add,
		'label' => $label,
	);
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'izl/v1', '/find', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true', // the same products anyone sees in the shop
		'args'                => array( 'q' => array( 'type' => 'string', 'required' => true ) ),
		'callback'            => function ( $req ) {
			$q = trim( mb_substr( sanitize_text_field( (string) $req['q'] ), 0, 80 ) );
			if ( '' === $q || ! function_exists( 'wc_get_product' ) || ! apply_filters( 'izl_live_search', true ) ) {
				return array( 'items' => array(), 'fix' => '', 'more' => 0 );
			}
			list( $ids, $fix ) = izl_find_ids( $q, 8 );
			$items = array();
			$total = 0;
			foreach ( array_slice( $ids, 0, 60 ) as $id ) {
				$p = wc_get_product( $id );
				if ( ! $p || 'publish' !== $p->get_status() || ! $p->is_visible() ) {
					continue;
				}
				$total++;
				if ( count( $items ) < 8 ) {
					$items[] = izl_find_item( $p );
				}
			}
			// species first, then supplies; each keeps its best-first order (sold out already last)
			usort( $items, function ( $a, $b ) {
				return (int) $b['sp'] - (int) $a['sp'];
			} );
			$res = rest_ensure_response( array( 'items' => $items, 'fix' => $fix, 'more' => $total ) );
			$res->header( 'Cache-Control', 'no-store' );
			return $res;
		},
	) );
} );

// The panel: right under the top bar's row, inside the top bar (storefront_header, after the row closes at 41).
add_action( 'storefront_header', 'izl_search_panel', 45 );
function izl_search_panel() {
	if ( ! function_exists( 'wc_get_page_permalink' ) ) {
		return;
	}
	$chips = array();
	foreach ( izl_menu_items() as $item ) {
		$chips[] = array( $item[0], $item[1] );
	}
	$isopods = izl_isopods_url();
	if ( $isopods ) {
		array_splice( $chips, min( 1, count( $chips ) ), 0, array( array( __( 'New arrivals', 'izeltlab' ), add_query_arg( 'orderby', 'date', $isopods ) ) ) );
	}
	$q = get_search_query();
	echo '<div class="izl-sp" id="izl-sp" role="search"><div class="izl-sp-in">';
	echo '<form class="izl-sp-form" method="get" action="' . esc_url( home_url( '/' ) ) . '">';
	echo '<label class="screen-reader-text" for="izl-sp-q">' . esc_html__( 'Search the shop', 'izeltlab' ) . '</label>';
	echo '<span class="izl-sp-field">' . izl_icon( 'search' ); // phpcs:ignore WordPress.Security.EscapeOutput
	echo '<input type="search" id="izl-sp-q" class="search-field" name="s" value="' . esc_attr( $q ) . '" placeholder="' . esc_attr__( 'Name, Latin name, trait…', 'izeltlab' ) . '" autocomplete="off" autocapitalize="off" spellcheck="false" enterkeyhint="search">';
	echo '</span><input type="hidden" name="post_type" value="product">';
	echo '<button type="submit" class="izl-sp-go">' . esc_html__( 'Search', 'izeltlab' ) . '</button>';
	echo '<a class="izl-sp-x" href="#" aria-label="' . esc_attr__( 'Close search', 'izeltlab' ) . '"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6L6 18"/></svg></a>';
	echo '</form>';
	echo '<div class="izl-sp-out"><span class="screen-reader-text izl-sp-status" aria-live="polite"></span>';
	echo '<div class="izl-sp-chips">';
	foreach ( $chips as $c ) {
		echo '<a class="izl-sp-chip" href="' . esc_url( $c[1] ) . '">' . esc_html( $c[0] ) . '</a>';
	}
	echo '</div><div class="izl-sp-list" id="izl-sp-list"></div></div>';
	echo '</div></div>';
}

add_action( 'wp_enqueue_scripts', function () {
	if ( ! function_exists( 'wc_get_page_permalink' ) || ! apply_filters( 'izl_live_search', true ) ) {
		return;
	}
	wp_enqueue_script( 'izeltlab-finder', get_stylesheet_directory_uri() . '/' . izl_min( 'assets/finder.js' ), array(), IZL_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	wp_localize_script( 'izeltlab-finder', 'izlFind', array(
		'api'  => esc_url_raw( rest_url( 'izl/v1/find' ) ),
		'cart' => class_exists( 'WC_AJAX' ) ? esc_url_raw( WC_AJAX::get_endpoint( 'add_to_cart' ) ) : '',
		't'    => array(
			'species'  => __( 'Species', 'izeltlab' ),
			'supplies' => __( 'Supplies', 'izeltlab' ),
			'out'      => __( 'Sold out', 'izeltlab' ),
			/* translators: %s: what was searched */
			'none'     => __( 'No critter or supply answers to “%s”. Try one of these:', 'izeltlab' ),
			/* translators: %s: the word searched instead of a typo */
			'fix'      => __( 'Showing results for: %s', 'izeltlab' ),
			/* translators: %d: number of results */
			'all'      => __( 'All results (%d)', 'izeltlab' ),
			'added'    => __( 'In the cart', 'izeltlab' ),
			/* translators: %d: number of results */
			'count'    => __( '%d found', 'izeltlab' ),
			'fail'     => __( 'Could not add it, please try on its page.', 'izeltlab' ),
		),
	) );
} );
