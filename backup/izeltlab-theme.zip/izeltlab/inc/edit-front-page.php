<?php
// ==========================================================================
//  FILE: inc/edit-front-page.php   (Ízeltláb theme)
//  WHAT: ADMIN ONLY. The "Edit cards" panel on the front page (how many cards, which species).
//  SEEN: Only by logged-in admins, on the front page.
//  SECTIONS IN THIS FILE:
//    1. Front page quick edit (logged-in admins): number of cards and which species
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Front page quick edit (logged-in admins): number of cards and which species
// ==========================================================================

function izl_can_edit_home() {
	return is_user_logged_in() && current_user_can( 'edit_theme_options' );
}

// The "Edit cards" button and its panel, next to the cards (front-page.php).
function izl_home_edit_panel() {
	if ( ! izl_can_edit_home() ) {
		return;
	}
	$species = izl_codex_product_ids( 0, 'ASC' );
	$count   = izl_hero_count();
	echo '<button type="button" class="izl-edit-open" aria-haspopup="dialog">' . esc_html__( 'Edit cards', 'izeltlab' ) . '</button>';
	echo '<dialog class="izl-edit" aria-labelledby="izl-edit-title"><form method="dialog">';
	echo '<h2 id="izl-edit-title">' . esc_html__( 'Front page cards', 'izeltlab' ) . '</h2>';
	echo '<fieldset class="izl-edit-count"><legend>' . esc_html__( 'Number of cards', 'izeltlab' ) . '</legend>';
	for ( $i = 1; $i <= 3; $i++ ) {
		echo '<label><input type="radio" name="count" value="' . (int) $i . '"' . checked( $count, $i, false ) . '><span>' . (int) $i . '</span></label>';
	}
	echo '</fieldset>';
	foreach ( izl_hero_slots() as $i => $slot ) {
		$sel = absint( get_theme_mod( $slot, 0 ) );
		/* translators: %d: card number, 1-3 */
		$label = 0 === $i ? __( 'Card 1 (in front at the start)', 'izeltlab' ) : sprintf( __( 'Card %d', 'izeltlab' ), $i + 1 );
		echo '<label class="izl-edit-card" data-card="' . (int) ( $i + 1 ) . '"><span>' . esc_html( $label ) . '</span><select name="' . esc_attr( $slot ) . '">';
		echo '<option value="0">' . esc_html_x( 'Automatic', 'quick edit: the species is picked by itself', 'izeltlab' ) . '</option>';
		foreach ( $species as $id ) {
			$name = ( function_exists( 'fsz_codex_number' ) ? fsz_codex_number( $id ) . ' ' : '' ) . html_entity_decode( get_the_title( $id ), ENT_QUOTES, 'UTF-8' );
			echo '<option value="' . (int) $id . '"' . selected( $sel, $id, false ) . '>' . esc_html( $name ) . '</option>';
		}
		echo '</select></label>';
	}
	echo '<p class="izl-edit-note">' . esc_html__( 'Automatic: card 1 shows the Codex #001, the others the newest species.', 'izeltlab' ) . '</p>';
	// 1.7.1: what the back cards do under the mouse. Shown on the cards behind this panel while it is open.
	echo '<fieldset class="izl-edit-fx"><legend>' . esc_html__( 'Back cards on hover', 'izeltlab' ) . '</legend>';
	echo '<label class="izl-edit-fx-range"><span>' . esc_html__( 'Float height', 'izeltlab' ) . ' <output>' . (int) izl_card_fx_strength() . '</output></span><input type="range" name="fx_strength" min="0" max="100" step="5" value="' . (int) izl_card_fx_strength() . '"></label>';
	echo '<p class="izl-edit-note">' . esc_html__( 'A pointed-at back card floats up. The cards behind this panel show it. 0 = no float.', 'izeltlab' ) . '</p></fieldset>';
	echo '<p class="izl-edit-msg" role="status"></p>';
	echo '<div class="izl-edit-btns"><button type="submit" value="cancel" class="izl-btn is-alt">' . esc_html__( 'Cancel', 'izeltlab' ) . '</button><button type="button" class="izl-btn izl-edit-save">' . esc_html__( 'Save', 'izeltlab' ) . '</button></div>';
	echo '</form></dialog>';
}

add_action( 'wp_enqueue_scripts', function () {
	if ( is_front_page() && izl_can_edit_home() ) {
		wp_enqueue_script( 'izeltlab-home-edit', get_stylesheet_directory_uri() . '/' . izl_min( 'assets/home-edit.js' ), array(), IZL_VERSION, true );
		wp_localize_script( 'izeltlab-home-edit', 'izlHomeEdit', array(
			'ajax'   => admin_url( 'admin-ajax.php', 'relative' ),
			'nonce'  => wp_create_nonce( 'izl_home_edit' ),
			'saving' => __( 'Saving…', 'izeltlab' ),
			'failed' => __( 'Could not save. Please try again.', 'izeltlab' ),
		) );
	}
}, 30 );

// Saves into the same settings as the Customizer, so the two always match.
add_action( 'wp_ajax_izl_home_edit', function () {
	check_ajax_referer( 'izl_home_edit', 'nonce' );
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_send_json_error( null, 403 );
	}
	set_theme_mod( 'izl_hero_count', max( 1, min( 3, isset( $_POST['count'] ) ? absint( $_POST['count'] ) : 3 ) ) );
	foreach ( izl_hero_slots() as $slot ) {
		$id = isset( $_POST[ $slot ] ) ? absint( $_POST[ $slot ] ) : 0;
		set_theme_mod( $slot, $id && izl_is_codex( $id ) ? $id : 0 );
	}
	remove_theme_mod( 'izl_card_fx' ); // the effect choice (1.7.1-1.7.4); the float is the only effect since 1.7.5
	if ( isset( $_POST['fx_strength'] ) ) {
		set_theme_mod( 'izl_card_fx_strength', max( 0, min( 100, absint( $_POST['fx_strength'] ) ) ) );
	}
	wp_send_json_success();
} );
