<?php
// ==========================================================================
//  FILE: inc/product-fonts.php   (Ízeltláb theme)
//  WHAT: Tells the browser to fetch the product page's fonts with the page, so texts do not swap fonts a moment later.
//  SEEN: Product pages (behind the scenes).
//  SECTIONS IN THIS FILE:
//    1. Product page: fonts fetched early
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Product page: fonts fetched early
// ==========================================================================

// 1.7.22: the Leírás text started in a stand-in font and swapped about a second later. The Plex Sans files it uses are
// now fetched with the page (preload) and the text waits for them (font-display:block in assets/fonts.css).
add_action( 'wp_head', function () {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}
	foreach ( array( '400-normal', '500-normal', '600-normal', '700-normal' ) as $f ) {
		printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( get_stylesheet_directory_uri() . '/assets/fonts/plex-sans-hu-' . $f . '.woff2' ) );
	}
	// 2.10.0: the price in the phone drawer (Plex Mono bold) is fetched with the page too. iPhones left the price out
	// for a moment while it loaded, so Kosárba vele! showed alone. The file the page really uses (Codex's copy if on).
	$mono = izl_mono_url( 'hu-700' );
	printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( $mono ) );
}, 1 );
