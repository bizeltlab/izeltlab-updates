<?php
// ==========================================================================
//  FILE: inc/product-texts.php   (Ízeltláb theme)
//  WHAT: The buy box texts: sales line, Codex tag chips, the pack question.
//  SEEN: Product pages, above the price.
//  SECTIONS IN THIS FILE:
//    1. Buy box: sales line, pack question, stock line
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Buy box: sales line, pack question, stock line
// ==========================================================================

// Per product texts, in Product data → General, and on the product page for whoever can edit it (click Edit).
function izl_product_texts() {
	return array(
		'_izl_headline' => array( 'Sales line', 'One short sentence at the top of the buy box: why buy this one. Empty = nothing, the price moves up.' ),
		'_izl_pack_tip' => array( 'Pack tip', 'One line under "How many do you want to start with?" (products with packs). Empty = the default from Customize → Ízeltláb product page.' ),
		'_izl_row_title' => array( 'Row title', 'The title over the row of small product tiles under the page. Empty = "Similar species" (species) or "You might also need" (everything else).' ),
	);
}

add_action( 'woocommerce_product_options_general_product_data', function () {
	echo '<div class="options_group">';
	foreach ( izl_product_texts() as $key => $t ) {
		woocommerce_wp_text_input( array( 'id' => $key, 'label' => $t[0], 'description' => $t[1], 'desc_tip' => true ) );
	}
	echo '</div>';
} );

add_action( 'woocommerce_process_product_meta', function ( $post_id ) {
	foreach ( array_keys( izl_product_texts() ) as $key ) {
		if ( isset( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- WooCommerce checked the product form nonce
			update_post_meta( $post_id, $key, sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
		}
	}
} );

// The text with an Edit button for whoever can edit the product. Empty: visitors see nothing, editors a grey sample
// text in its place (click it or Edit to write the real one).
function izl_editable_text( $key, $text, $tag, $class, $sample ) {
	$can = current_user_can( 'edit_post', get_the_ID() );
	if ( '' === $text && ! $can ) {
		return;
	}
	$attrs = $can ? ' data-izl-edit="' . esc_attr( $key ) . '" data-izl-sample="' . esc_attr( $sample ) . '"' : '';
	echo '<' . $tag . ' class="' . esc_attr( $class . ( '' === $text ? ' is-empty' : '' ) ) . '"' . $attrs . '><span class="izl-edit-text">' . esc_html( '' === $text ? $sample : $text ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
	if ( $can ) {
		echo '<button type="button" class="izl-edit-btn">Edit</button>';
	}
	echo '</' . $tag . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
}

// The sales line: the reason to buy, where the name used to be.
function izl_sales_line() {
	izl_editable_text( '_izl_headline', trim( (string) get_post_meta( get_the_ID(), '_izl_headline', true ) ), 'p', 'izl-sales-line', '(add the sales line here)' );
}

// 1.7.13: the Codex tags as chips above the sales line, each a link to the shop filtered to that tag. Codex 1.38 also
// saves them as WooCommerce product tags; a tag without its shop page yet is left out.
function izl_codex_tag_chips() {
	$id   = get_the_ID();
	$tags = function_exists( 'fsz_tags' ) ? fsz_tags( $id ) : array();
	$out  = '';
	foreach ( $tags as $name ) {
		$term = get_term_by( 'name', $name, 'product_tag' );
		$link = $term ? get_term_link( $term ) : '';
		if ( $link && ! is_wp_error( $link ) ) {
			$out .= '<a href="' . esc_url( $link ) . '" rel="tag">' . esc_html( $name ) . '</a>';
		}
	}
	if ( '' !== $out ) {
		echo '<nav class="izl-tagchips" aria-label="' . esc_attr__( 'Tags', 'izeltlab' ) . '">' . $out . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

// Above the pack buttons: the question that makes them a choice, and a tip that leans towards the bigger pack.
function izl_pack_question() {
	global $product;
	if ( ! $product instanceof WC_Product_Variable || count( $product->get_children() ) < 2 ) {
		return;
	}
	$q = trim( (string) izl_pmod( 'izl_pack_question' ) );
	if ( '' !== $q ) {
		echo '<p class="izl-pack-q">' . esc_html( $q ) . '</p>';
	}
	$tip = trim( (string) get_post_meta( get_the_ID(), '_izl_pack_tip', true ) );
	if ( '' === $tip ) {
		$tip = trim( (string) izl_pmod( 'izl_pack_tip' ) );
	}
	izl_editable_text( '_izl_pack_tip', $tip, 'p', 'izl-pack-tip', '(add a pack tip here)' );
}
