<?php
// ==========================================================================
//  FILE: shop-core.php   (shared file)
//  WHAT: The shop's rules and data: Codex helpers, shop texts, whole-forint prices, packs, photo frames,
//        free shipping amount, shipping days and holidays. This one file is copied by the build into the theme (inc/) and Bolt (inc/); edit it in shared/ only.
//  SEEN: Prices, packs, shipping dates and the free-shipping bar everywhere.
//  SECTIONS IN THIS FILE:
//    1. 1. Codex helpers (all optional: the shop works without the Codex plugin)
//    2. 2. shop texts and the supplies category
//    3. 3. prices in whole forints, no reviews
//    4. 4. packs: price, base pack, 1× 2× 5×, available (saved by Edit buy box)
//    5. 5. photo frames (saved by Edit photos, shown by the theme)
//    6. 6. free shipping amount and the cart total
//    7. 7. shipping days: when it leaves, when it is expected, holidays (1.7.0, 2.1.0)
// ==========================================================================

/**
 * The shop's rules and data (shared core of the Ízeltláb theme and the Ízeltláb Bolt plugin).
 *
 * The SAME file ships in both: the plugin's copy loads first (plugins load before themes) and the theme then skips
 * its copy (both include lines check IZL_CORE first, because PHP would otherwise declare the functions twice). Without the plugin the theme's copy runs, so the shop works either way. With the plugin,
 * these rules keep working after a theme change: ship dates, holidays, packs, free shipping, whole forints, no reviews,
 * the Kiegészítők category and the saved photo frames. Everything you SEE (buy ticket, drawer, tiles, cart look) stays
 * in the theme and only calls these functions.
 *
 * Edit the two copies together (theme inc/shop-core.php = plugin inc/shop-core.php); IZL_CORE_VERSION says which ran.
 *
 * Contents: 1 Codex helpers · 2 shop texts and the Kiegészítők category · 3 prices and reviews · 4 packs (Edit buy box
 * save) · 5 photo frames (Edit photos save) · 6 free shipping and the cart total · 7 shipping days and holidays
 */

defined( 'ABSPATH' ) || exit;

// Include this file only through: if ( ! defined( 'IZL_CORE' ) ) { require_once ...; }
define( 'IZL_CORE', __FILE__ );
define( 'IZL_CORE_VERSION', '1.0.0' );

// ==========================================================================
//  1. Codex helpers (all optional: the shop works without the Codex plugin)
// ==========================================================================

function izl_has_codex() {
	return function_exists( 'fsz_opt' ) && function_exists( 'fsz_is_live' );
}

function izl_is_codex( $product_id ) {
	return izl_has_codex() && fsz_is_live( $product_id );
}

/**
 * The isopod categories: the Codex categories (settings), without the ones that sit under another chosen one.
 * With the Codex plugin off, a category with the slug "aszkak" or "isopoda" if there is one.
 */
function izl_isopod_terms() {
	$slugs = izl_has_codex() ? array_filter( array_map( 'sanitize_title', explode( ',', fsz_opt( 'categories' ) ) ) ) : array( 'aszkak', 'isopoda' );
	$terms = array();
	foreach ( $slugs as $slug ) {
		$t = get_term_by( 'slug', $slug, 'product_cat' );
		if ( $t && ! is_wp_error( $t ) ) {
			$terms[ (int) $t->term_id ] = $t;
		}
	}
	return array_values( array_filter( $terms, function ( $t ) use ( $terms ) {
		foreach ( get_ancestors( $t->term_id, 'product_cat', 'taxonomy' ) as $a ) {
			if ( isset( $terms[ $a ] ) ) {
				return false;
			}
		}
		return true;
	} ) );
}

// ==========================================================================
//  2. shop texts and the supplies category
// ==========================================================================

define( 'IZL_SUPPLIES', 'kiegeszitok' ); // slug of the supplies category (tubs, substrate, food …)

function izl_supplies_term() {
	$t = get_term_by( 'slug', IZL_SUPPLIES, 'product_cat' );
	return $t && ! is_wp_error( $t ) ? $t : null;
}

// A theme text in the shop's language, read straight from the theme's translation file. Saving in the dashboard runs
// in the admin's own language (which may be English), but this is text the customers see.
function izl_shop_text( $text ) {
	static $mo = null;
	if ( determine_locale() === get_locale() ) {
		return translate( $text, 'izeltlab' ); // phpcs:ignore WordPress.WP.I18n
	}
	if ( null === $mo ) {
		$mo   = new MO();
		$file = get_stylesheet_directory() . '/languages/' . get_locale() . '.mo';
		if ( ! is_readable( $file ) || ! $mo->import_from_file( $file ) ) {
			$mo = false;
		}
	}
	return $mo ? $mo->translate( $text ) : $text;
}

// Made once when the theme is switched on (or the Ízeltláb Bolt plugin is activated), if it is not there yet.
function izl_make_supplies_term() {
	if ( taxonomy_exists( 'product_cat' ) && ! izl_supplies_term() ) {
		// In the shop's language (the customers see it), not in the admin's own.
		wp_insert_term( izl_shop_text( 'Supplies' ), 'product_cat', array( 'slug' => IZL_SUPPLIES ) );
	}
}
add_action( 'after_switch_theme', 'izl_make_supplies_term' );

// ==========================================================================
//  3. prices in whole forints, no reviews
// ==========================================================================

// Forint has no fillér: 2 500 Ft, never 2 500,00 Ft (product pages, shop, cart, checkout, emails).
add_filter( 'wc_get_price_decimals', function ( $decimals ) {
	return function_exists( 'get_woocommerce_currency' ) && 'HUF' === get_woocommerce_currency() ? 0 : $decimals;
} );

// No reviews anywhere (no tab, no stars, no review form): the theme keeps WooCommerce's "Enable reviews" off.
add_filter( 'pre_option_woocommerce_enable_reviews', function () {
	return 'no';
} );
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	unset( $tabs['reviews'] );
	return $tabs;
}, 98 );

// ==========================================================================
//  4. packs: price, base pack, 1× 2× 5×, available (saved by Edit buy box)
// ==========================================================================

// Packs are multiples of the base pack: 1×, 2×, 5× (base 10 → 10 / 20 / 50 db). Each is a WooCommerce variation of
// the attribute "Csomag", priced at the base price × its multiple, so the cart, orders and the product edit screen
// show the same thing. Stock is not counted: the "available" switch sets every pack in stock or out of stock.
define( 'IZL_PACK_MULTS', array( 1, 2, 5 ) );
define( 'IZL_PACK_ATTR', 'Csomag' );

// The product's group: its top-level category (the name on the Codex card), or null.
function izl_group_term( $product_id ) {
	if ( function_exists( 'fsz_group_term' ) ) {
		return fsz_group_term( $product_id );
	}
	$terms = get_the_terms( $product_id, 'product_cat' );
	if ( ! $terms || is_wp_error( $terms ) ) {
		return null;
	}
	$term = $terms[0];
	while ( $term->parent ) {
		$parent = get_term( $term->parent, 'product_cat' );
		if ( ! $parent || is_wp_error( $parent ) ) {
			break;
		}
		$term = $parent;
	}
	return $term;
}

// A group's base pack: its own setting (term meta izl_base_pack), else 10 for an isopod group, else 1.
function izl_group_base_pack( $term ) {
	if ( ! $term ) {
		return 1;
	}
	$own = (int) get_term_meta( $term->term_id, 'izl_base_pack', true );
	if ( $own > 0 ) {
		return $own;
	}
	foreach ( izl_isopod_terms() as $t ) {
		if ( (int) $t->term_id === (int) $term->term_id || in_array( (int) $term->term_id, get_ancestors( $t->term_id, 'product_cat', 'taxonomy' ), true ) ) {
			return 10;
		}
	}
	return 1;
}

// The product's base pack (its own, for rarer species), else its group's.
function izl_base_pack( $product_id ) {
	$own = (int) get_post_meta( $product_id, '_izl_base_pack', true );
	return $own > 0 ? $own : izl_group_base_pack( izl_group_term( $product_id ) );
}

// "10 db". $shop: in the shop's language, read straight from the theme's translation file, because the editor saves
// in the admin's own dashboard language (which may be English) and the label is stored on the product.
function izl_pack_label( $count, $shop = false ) {
	/* translators: %d: number of animals in the pack */
	$format = __( '%d pcs', 'izeltlab' );
	if ( $shop && determine_locale() !== get_locale() ) {
		$mo   = new MO();
		$file = get_stylesheet_directory() . '/languages/' . get_locale() . '.mo';
		$format = is_readable( $file ) && $mo->import_from_file( $file ) ? $mo->translate( '%d pcs' ) : '%d pcs';
	}
	return sprintf( $format, $count );
}

// Saves the editor into WooCommerce.
function izl_buybox_save( $id, $in ) {
	$product = wc_get_product( $id );
	if ( ! $product ) {
		return new WP_Error( 'none', 'Product not found.' );
	}
	$price = isset( $in['price'] ) && '' !== trim( (string) $in['price'] ) ? max( 0, (float) str_replace( array( ' ', ',' ), array( '', '.' ), (string) $in['price'] ) ) : '';
	$avail = ! empty( $in['available'] );
	$stock = $avail ? 'instock' : 'outofstock';

	// 1.7.18: the free shipping amount (one for the whole shop), kept in step with WooCommerce's Free shipping.
	if ( isset( $in['freeShip'] ) && null !== $in['freeShip'] && current_user_can( 'manage_woocommerce' ) ) {
		izl_set_free_ship( $in['freeShip'] );
	}

	// 1.7.0: live animal or normal product (when it ships), and the title of the tile row under the page.
	if ( isset( $in['ship'] ) && isset( IZL_SHIP_DAYS[ $in['ship'] ] ) ) {
		update_post_meta( $id, '_izl_ship_type', $in['ship'] );
	}
	if ( isset( $in['rowTitle'] ) ) {
		update_post_meta( $id, '_izl_row_title', $in['rowTitle'] );
	}

	// 1.7.17: "Running low" makes the yellow light on the Codex card blink (the same switch as in the Codex quick edit).
	if ( isset( $in['low'] ) && izl_is_codex( $id ) ) {
		$in['low'] ? update_post_meta( $id, '_fsz_low', 'yes' ) : delete_post_meta( $id, '_fsz_low' );
	}

	if ( ! izl_is_codex( $id ) ) {
		// Supplies: the price and available. Packs made by hand stay as they are, only their stock changes.
		if ( $product instanceof WC_Product_Variable ) {
			foreach ( $product->get_children() as $vid ) {
				$v = wc_get_product( $vid );
				if ( $v ) {
					$v->set_manage_stock( false );
					$v->set_stock_status( $stock );
					$v->save();
				}
			}
			WC_Product_Variable::sync( $id );
			return true;
		}
		$product->set_regular_price( '' === $price ? '' : (string) $price );
		$product->set_manage_stock( false );
		$product->set_stock_status( $stock );
		$product->save();
		return true;
	}

	// The base pack: the product's own, or empty = its group's. "Group default" saves it for the whole group.
	$base = isset( $in['base'] ) ? absint( $in['base'] ) : 0;
	$group = izl_group_term( $id );
	if ( ! empty( $in['groupDefault'] ) && $group && $base > 0 ) {
		update_term_meta( $group->term_id, 'izl_base_pack', $base );
		delete_post_meta( $id, '_izl_base_pack' );
	} elseif ( $base > 0 && $base !== izl_group_base_pack( $group ) ) {
		update_post_meta( $id, '_izl_base_pack', $base );
	} else {
		delete_post_meta( $id, '_izl_base_pack' );
	}
	$base  = izl_base_pack( $id );
	$mults = array_values( array_intersect( IZL_PACK_MULTS, array_map( 'intval', isset( $in['mults'] ) ? (array) $in['mults'] : array() ) ) );
	if ( ! $mults ) {
		$mults = array( 1 );
	}

	// A simple product becomes a product with packs.
	if ( ! $product instanceof WC_Product_Variable ) {
		wp_set_object_terms( $id, 'variable', 'product_type' );
		$product = new WC_Product_Variable( $id );
		$product->set_regular_price( '' );
		$product->set_sale_price( '' );
	}
	$labels = array();
	foreach ( $mults as $m ) {
		$labels[ $m ] = izl_pack_label( $base * $m, true );
	}
	$attrs = array();
	foreach ( $product->get_attributes() as $key => $a ) {
		if ( sanitize_title( IZL_PACK_ATTR ) !== sanitize_title( $a->get_name() ) ) {
			$attrs[ $key ] = $a; // other attributes stay
		}
	}
	$attr = new WC_Product_Attribute();
	$attr->set_name( IZL_PACK_ATTR );
	$attr->set_options( array_values( $labels ) );
	$attr->set_visible( true );
	$attr->set_variation( true );
	$attr->set_position( 0 );
	$attrs[ sanitize_title( IZL_PACK_ATTR ) ] = $attr;
	$product->set_attributes( $attrs );
	$product->set_default_attributes( array( sanitize_title( IZL_PACK_ATTR ) => reset( $labels ) ) );
	$product->set_manage_stock( false );
	$product->save();

	// One variation per pack, found again by its multiple; packs taken off (and ones made by hand) are removed.
	$keep = array();
	foreach ( $product->get_children() as $vid ) {
		$v = wc_get_product( $vid );
		$m = $v ? (int) $v->get_meta( '_izl_mult' ) : 0;
		if ( $v && in_array( $m, $mults, true ) && ! isset( $keep[ $m ] ) ) {
			$keep[ $m ] = $v;
		} elseif ( $v ) {
			$v->delete( true );
		}
	}
	foreach ( $mults as $i => $m ) {
		$v = isset( $keep[ $m ] ) ? $keep[ $m ] : new WC_Product_Variation();
		$v->set_parent_id( $id );
		$v->set_attributes( array( sanitize_title( IZL_PACK_ATTR ) => $labels[ $m ] ) );
		$v->set_regular_price( '' === $price ? '' : (string) round( $price * $m, wc_get_price_decimals() ) );
		$v->set_sale_price( '' );
		$v->set_manage_stock( false );
		$v->set_stock_status( $stock );
		$v->set_menu_order( $i );
		$v->update_meta_data( '_izl_mult', $m );
		$v->save();
	}
	WC_Product_Variable::sync( $id );
	wc_delete_product_transients( $id );
	return true;
}

add_action( 'wp_ajax_izl_buybox_save', function () {
	if ( ! check_ajax_referer( 'izl_product_text', false, false ) ) {
		wp_send_json_error( 'The security check ran out. Reload the page and try again.', 403 );
	}
	$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
	if ( ! $id || ! current_user_can( 'edit_post', $id ) ) {
		wp_send_json_error( 'Not allowed.', 403 );
	}
	$in = array(
		'price'        => isset( $_POST['price'] ) ? sanitize_text_field( wp_unslash( $_POST['price'] ) ) : '',
		'base'         => isset( $_POST['base'] ) ? absint( $_POST['base'] ) : 0,
		'groupDefault' => ! empty( $_POST['groupDefault'] ),
		'mults'        => isset( $_POST['mults'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['mults'] ) ) : array(), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		'available'    => ! empty( $_POST['available'] ),
		'low'          => isset( $_POST['low'] ) ? ! empty( $_POST['low'] ) : null,
		'ship'         => isset( $_POST['ship'] ) ? sanitize_key( wp_unslash( $_POST['ship'] ) ) : '',
		'rowTitle'     => isset( $_POST['rowTitle'] ) ? sanitize_text_field( wp_unslash( $_POST['rowTitle'] ) ) : null,
		'freeShip'     => isset( $_POST['freeShip'] ) ? sanitize_text_field( wp_unslash( $_POST['freeShip'] ) ) : null,
	);
	$r = izl_buybox_save( $id, $in );
	if ( is_wp_error( $r ) ) {
		wp_send_json_error( $r->get_error_message() );
	}
	wp_send_json_success();
} );

// ==========================================================================
//  5. photo frames (saved by Edit photos, shown by the theme)
// ==========================================================================

// The saved frames of a product: attachment id => [ x %, y %, zoom ].
function izl_photo_frames( $product_id ) {
	$f = get_post_meta( $product_id, '_izl_frames', true );
	return is_array( $f ) ? $f : array();
}

// One photo's frame, [ 50, 50, 1 ] (centred, no zoom) when none is saved.
function izl_photo_frame( $product_id, $att_id ) {
	$all = izl_photo_frames( $product_id );
	$f   = isset( $all[ $att_id ] ) && is_array( $all[ $att_id ] ) ? array_values( $all[ $att_id ] ) : array();
	return 3 === count( $f ) ? array( (float) $f[0], (float) $f[1], (float) $f[2] ) : array( 50, 50, 1 );
}

function izl_photo_framed( $frame ) {
	return abs( $frame[0] - 50 ) > 0.05 || abs( $frame[1] - 50 ) > 0.05 || abs( $frame[2] - 1 ) > 0.001;
}

// Saves the order (first = main photo, the rest = the gallery) and the frames.
add_action( 'wp_ajax_izl_photos_save', function () {
	if ( ! check_ajax_referer( 'izl_product_text', false, false ) ) {
		wp_send_json_error( 'The security check ran out. Reload the page and try again.', 403 );
	}
	$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
	if ( ! $id || ! current_user_can( 'edit_post', $id ) ) {
		wp_send_json_error( 'Not allowed.', 403 );
	}
	$product = wc_get_product( $id );
	if ( ! $product ) {
		wp_send_json_error( 'Product not found.' );
	}
	$ids = isset( $_POST['ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['ids'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$ids = array_values( array_unique( array_filter( $ids, function ( $a ) {
		return $a && wp_attachment_is_image( $a );
	} ) ) );
	$raw    = isset( $_POST['frames'] ) ? json_decode( wp_unslash( $_POST['frames'] ), true ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$frames = array();
	foreach ( $ids as $att ) {
		if ( isset( $raw[ $att ] ) && is_array( $raw[ $att ] ) && 3 === count( $raw[ $att ] ) ) {
			$f = array_map( 'floatval', array_values( $raw[ $att ] ) );
			$f = array( max( 0, min( 100, $f[0] ) ), max( 0, min( 100, $f[1] ) ), max( 1, min( 4, $f[2] ) ) );
			if ( izl_photo_framed( $f ) ) {
				$frames[ $att ] = array( round( $f[0], 2 ), round( $f[1], 2 ), round( $f[2], 3 ) );
			}
		}
	}
	$product->set_image_id( $ids ? $ids[0] : 0 );
	$product->set_gallery_image_ids( array_slice( $ids, 1 ) );
	$product->save();
	$frames ? update_post_meta( $id, '_izl_frames', $frames ) : delete_post_meta( $id, '_izl_frames' );
	wc_delete_product_transients( $id );
	wp_send_json_success();
} );

// ==========================================================================
//  6. free shipping amount and the cart total
// ==========================================================================

define( 'IZL_FREE_SHIP_DEFAULT', 18000 );

// One amount for the whole shop (Edit buy box, or Customize → Ízeltláb product page). 0 = no free shipping line.
// Kept in the option izl_free_ship (so it survives a theme change) and, for the Customizer, as the theme setting of
// the same name; a shop that never saved it yet reads the theme setting, then the default (18 000 Ft).
function izl_free_ship() {
	$v = is_customize_preview() ? false : get_option( 'izl_free_ship' );
	if ( false === $v ) {
		$v = get_theme_mod( 'izl_free_ship', IZL_FREE_SHIP_DEFAULT );
	}
	return max( 0, (float) $v );
}

// Saves the amount and sets it as the minimum order amount of WooCommerce's Free shipping in every shipping zone (also
// "Locations not covered by your other zones"), so the ticket, the progress bar and the checkout always agree. A Free
// shipping that needed nothing now needs the amount, one that needed a coupon now needs a coupon or the amount; "a
// coupon and the amount" stays. 0 only removes the line from the ticket: WooCommerce is left as it is.
function izl_set_free_ship( $amount ) {
	$amount = max( 0, round( (float) str_replace( array( ' ', ',' ), array( '', '.' ), (string) $amount ), wc_get_price_decimals() ) );
	set_theme_mod( 'izl_free_ship', $amount );
	update_option( 'izl_free_ship', $amount );
	if ( $amount > 0 ) {
		izl_sync_free_ship( $amount );
	}
}

function izl_sync_free_ship( $amount ) {
	if ( ! class_exists( 'WC_Shipping_Zones' ) || $amount <= 0 ) {
		return;
	}
	$ids = array_merge( array( 0 ), array_map( 'intval', array_keys( WC_Shipping_Zones::get_zones() ) ) );
	foreach ( array_unique( $ids ) as $zone_id ) {
		$zone = new WC_Shipping_Zone( $zone_id );
		foreach ( $zone->get_shipping_methods( false ) as $method ) {
			if ( 'free_shipping' !== $method->id ) {
				continue;
			}
			$key  = $method->get_instance_option_key();
			$opts = get_option( $key, array() );
			$opts = is_array( $opts ) ? $opts : array();
			$req  = isset( $opts['requires'] ) ? (string) $opts['requires'] : '';
			$opts['min_amount'] = wc_format_decimal( $amount );
			if ( '' === $req ) {
				$opts['requires'] = 'min_amount';
			} elseif ( 'coupon' === $req ) {
				$opts['requires'] = 'either';
			}
			update_option( $key, $opts );
		}
	}
	if ( class_exists( 'WC_Cache_Helper' ) ) {
		WC_Cache_Helper::get_transient_version( 'shipping', true ); // carts work their shipping out again
	}
}

// The Customizer field does the same when it changes.
add_action( 'customize_save_after', function ( $manager ) {
	$values = $manager->unsanitized_post_values();
	if ( array_key_exists( 'izl_free_ship', $values ) ) {
		update_option( 'izl_free_ship', max( 0, (float) get_theme_mod( 'izl_free_ship', IZL_FREE_SHIP_DEFAULT ) ) );
		izl_sync_free_ship( izl_free_ship() );
	}
} );

// 1.7.18: what the cart counts toward free shipping, the way WooCommerce's Free shipping works it out (the shown
// subtotal less the discounts).
function izl_cart_total() {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return 0;
	}
	$cart  = WC()->cart;
	$total = (float) $cart->get_displayed_subtotal() - (float) $cart->get_discount_total();
	if ( $cart->display_prices_including_tax() ) {
		$total -= (float) $cart->get_discount_tax();
	}
	return max( 0, round( $total, wc_get_price_decimals() ) );
}

// ==========================================================================
//  7. shipping days: when it leaves, when it is expected, holidays (1.7.0, 2.1.0)
// ==========================================================================

// Everything ordered before 14:00 (Budapest) on a shipping day leaves the same day, later orders on the next shipping
// day. Live animals go out Monday to Wednesday only (never a weekend in a depot), everything else Monday to Friday.
// Foxpost and GLS deliver on the next working day, so the expected delivery is 1 working day after it leaves.
define( 'IZL_SHIP_CUTOFF', 14 ); // hour; 1.7.18: shown in the order-by nudge
define( 'IZL_NUDGE_FROM', 11 ); // 1.7.18: the nudge shows from this hour until the cutoff, on shipping days
define( 'IZL_SHIP_DAYS', array( 'live' => array( 1, 2, 3 ), 'normal' => array( 1, 2, 3, 4, 5 ) ) );

// "live" or "normal": the product's own choice (Edit buy box), else live for species, normal for everything else.
function izl_ship_type( $product_id ) {
	$own = (string) get_post_meta( $product_id, '_izl_ship_type', true );
	if ( isset( IZL_SHIP_DAYS[ $own ] ) ) {
		return $own;
	}
	return izl_is_codex( $product_id ) ? 'live' : 'normal';
}

// [the day it leaves, the expected delivery day, days from today until it leaves], days at midnight in Budapest.
function izl_ship_plan( $type, $now = null ) {
	$now  = $now ? $now : new DateTimeImmutable( 'now', new DateTimeZone( 'Europe/Budapest' ) );
	$days = IZL_SHIP_DAYS[ isset( IZL_SHIP_DAYS[ $type ] ) ? $type : 'normal' ];
	$out  = $now->setTime( 0, 0 );
	// 2.1.0: public holidays (and the shop's own closed days) are neither shipping nor delivery days (izl_is_closed()).
	// Live animals also wait when the next day is closed, so they never spend a holiday in a depot either.
	$no = function ( $d ) use ( $days, $type ) {
		return ! in_array( (int) $d->format( 'N' ), $days, true ) || izl_is_closed( $d ) || ( 'live' === $type && izl_is_closed( $d->modify( '+1 day' ) ) );
	};
	if ( $no( $out ) || (int) $now->format( 'G' ) >= IZL_SHIP_CUTOFF ) {
		do {
			$out = $out->modify( '+1 day' );
		} while ( $no( $out ) );
	}
	$arrive = $out->modify( '+1 day' );
	while ( (int) $arrive->format( 'N' ) > 5 || izl_is_closed( $arrive ) ) {
		$arrive = $arrive->modify( '+1 day' );
	}
	return array( $out, $arrive, (int) round( ( $out->getTimestamp() - $now->setTime( 0, 0 )->getTimestamp() ) / DAY_IN_SECONDS ) );
}

// The words for the day it leaves: today, tomorrow, on Monday … (index = ISO weekday).
function izl_ship_words() {
	return array(
		'today'    => _x( 'today', 'ships', 'izeltlab' ),
		'tomorrow' => _x( 'tomorrow', 'ships', 'izeltlab' ),
		'on'       => array( '', __( 'on Monday', 'izeltlab' ), __( 'on Tuesday', 'izeltlab' ), __( 'on Wednesday', 'izeltlab' ), __( 'on Thursday', 'izeltlab' ), __( 'on Friday', 'izeltlab' ), __( 'on Saturday', 'izeltlab' ), __( 'on Sunday', 'izeltlab' ) ),
		// 1.7.18: short month names for the arrival date ("kedden, nov. 3.")
		'months'   => array( _x( 'Jan', 'short month', 'izeltlab' ), _x( 'Feb', 'short month', 'izeltlab' ), _x( 'Mar', 'short month', 'izeltlab' ), _x( 'Apr', 'short month', 'izeltlab' ), _x( 'May', 'short month', 'izeltlab' ), _x( 'Jun', 'short month', 'izeltlab' ), _x( 'Jul', 'short month', 'izeltlab' ), _x( 'Aug', 'short month', 'izeltlab' ), _x( 'Sep', 'short month', 'izeltlab' ), _x( 'Oct', 'short month', 'izeltlab' ), _x( 'Nov', 'short month', 'izeltlab' ), _x( 'Dec', 'short month', 'izeltlab' ) ),
		/* translators: arrival date. 1: the day word (on Tuesday), 2: short month, 3: day of the month */
		'date'     => _x( '%1$s, %2$s %3$d', 'arrival date', 'izeltlab' ),
	);
}

// "on Tuesday, Nov 3" for a day (at midnight, Budapest).
function izl_arrive_words( $day ) {
	$w = izl_ship_words();
	return sprintf( $w['date'], $w['on'][ (int) $day->format( 'N' ) ], $w['months'][ (int) $day->format( 'n' ) - 1 ], (int) $day->format( 'j' ) );
}

// 1.7.18: the order-by nudge shows now? (a shipping day, from IZL_NUDGE_FROM until the cutoff, Budapest time)
function izl_nudge_now( $type, $now = null ) {
	$now  = $now ? $now : new DateTimeImmutable( 'now', new DateTimeZone( 'Europe/Budapest' ) );
	$days = IZL_SHIP_DAYS[ isset( IZL_SHIP_DAYS[ $type ] ) ? $type : 'normal' ];
	$hour = (int) $now->format( 'G' );
	return 0 === izl_ship_plan( $type, $now->setTime( 0, 0 ) )[2] && $hour >= IZL_NUDGE_FROM && $hour < IZL_SHIP_CUTOFF; // 2.1.0: a day it ships (holidays counted)
}

// Easter Sunday (Gregorian, anonymous algorithm), so Good Friday, Easter Monday and Whit Monday move with it.
function izl_easter( $y ) {
	$a = $y % 19;
	$b = intdiv( $y, 100 );
	$c = $y % 100;
	$d = intdiv( $b, 4 );
	$e = $b % 4;
	$f = intdiv( $b + 8, 25 );
	$g = intdiv( $b - $f + 1, 3 );
	$h = ( 19 * $a + $b - $d - $g + 15 ) % 30;
	$i = intdiv( $c, 4 );
	$k = $c % 4;
	$l = ( 32 + 2 * $e + 2 * $i - $h - $k ) % 7;
	$m = intdiv( $a + 11 * $h + 22 * $l, 451 );
	$mo = intdiv( $h + $l - 7 * $m + 114, 31 );
	$da = ( ( $h + $l - 7 * $m + 114 ) % 31 ) + 1;
	return new DateTimeImmutable( sprintf( '%04d-%02d-%02d', $y, $mo, $da ), new DateTimeZone( 'Europe/Budapest' ) );
}

// Hungary's public holidays of a year (Mt. 102. §), Y-m-d. Dec 24 is a rest day since 2024 as well.
function izl_holidays( $y ) {
	$e   = izl_easter( $y );
	$out = array( "$y-01-01", "$y-03-15", "$y-05-01", "$y-08-20", "$y-10-23", "$y-11-01", "$y-12-24", "$y-12-25", "$y-12-26" );
	foreach ( array( '-2 days', '+1 day', '+50 days' ) as $shift ) { // Good Friday, Easter Monday, Whit Monday
		$out[] = $e->modify( $shift )->format( 'Y-m-d' );
	}
	return $out;
}

// All closed days, this year and next: holidays + the shop's own (filter izl_closed_days, the Ízeltláb Bolt plugin
// adds the "Extra closed days" there).
function izl_closed_days() {
	static $all = null;
	if ( null === $all ) {
		$y   = (int) wp_date( 'Y' );
		$all = array_merge( izl_holidays( $y ), izl_holidays( $y + 1 ) );
		$all = array_values( array_unique( (array) apply_filters( 'izl_closed_days', $all ) ) );
	}
	return $all;
}

function izl_is_closed( $day ) {
	return in_array( $day->format( 'Y-m-d' ), izl_closed_days(), true );
}

// For product.js: the closed days from today on (the script works the dates out again in the browser).
function izl_closed_list() {
	$today = wp_date( 'Y-m-d' );
	return array_values( array_filter( izl_closed_days(), function ( $d ) use ( $today ) {
		return $d >= $today;
	} ) );
}
