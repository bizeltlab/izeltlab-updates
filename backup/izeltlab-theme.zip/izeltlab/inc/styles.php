<?php
// ==========================================================================
//  FILE: inc/styles.php   (Ízeltláb theme)
//  WHAT: Loads the theme's stylesheets, fonts and the front page scripts.
//  SEEN: Every page (fonts and styles); the front page (card scripts).
//  SECTIONS IN THIS FILE:
//    1. Styles
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Styles
// ==========================================================================

/**
 * 2.11.0: where the Izeltlab Mono files (IBM Plex Mono 400/700) come from. With Codex on (1.71.0 or newer) it is Codex's
 * copy of the same files, byte for byte, so the browser downloads them once for the card and the shop (2.1.2); without
 * it, the theme's own. $file: e.g. 'hu-700' or 'latin-ext-400'. Returns the URL.
 */
function izl_mono_url( $file ) {
	static $codex = null;
	if ( null === $codex ) {
		$codex = defined( 'FSZ_URL' ) && defined( 'FSZ_DIR' ) && is_readable( FSZ_DIR . 'assets/fonts/ibm-plex-mono/hu-400.woff2' ) && is_readable( FSZ_DIR . 'assets/fonts/ibm-plex-mono/hu-700.woff2' );
	}
	return $codex ? FSZ_URL . 'assets/fonts/ibm-plex-mono/' . $file . '.woff2' : get_stylesheet_directory_uri() . '/assets/fonts/plex-mono-' . $file . '.woff2';
}

/**
 * 2.11.0: the font rules of Izeltlab Mono, printed with the page (they were in assets/fonts.css, and a second set was
 * printed on top for Codex's copy, so some pages fetched the same font from both places). One file per weight for
 * Hungarian text (hu-*: Latin plus the letters with a double acute accent); the Latin Extended file is only fetched for
 * other accented letters, as its range leaves those four out.
 */
function izl_mono_css() {
	$ext = 'U+0100-014F,U+0152-016F,U+0172-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF';
	$hu  = 'U+0000-00FF,U+0131,U+0150-0153,U+0170-0171,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD';
	$css = '';
	foreach ( array( 400, 700 ) as $w ) {
		foreach ( array( 'latin-ext' => $ext, 'hu' => $hu ) as $sub => $range ) {
			$css .= "@font-face{font-family:'Izeltlab Mono';font-style:normal;font-weight:{$w};font-display:swap;src:url(" . esc_url( izl_mono_url( $sub . '-' . $w ) ) . ") format('woff2');unicode-range:{$range}}";
		}
	}
	return $css;
}

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'izeltlab-fonts', get_stylesheet_directory_uri() . '/' . izl_min( 'assets/fonts.css' ), array(), IZL_VERSION );
	// 2.1.2: Storefront's Google font (Source Sans Pro) is not shown anywhere (every text uses the bundled fonts), so its
	// request to Google (a slow, render-blocking third-party file, and a visitor's IP sent to Google) is dropped.
	wp_dequeue_style( 'storefront-fonts' );
	// Izeltlab Mono (IBM Plex Mono 400/700): from Codex's copy of the same files when Codex is on (see izl_mono_css()).
	wp_add_inline_style( 'izeltlab-fonts', izl_mono_css() );
	// The Codex colour theme for the whole shop (style.css itself is loaded by Storefront).
	$teal = izl_teal();
	wp_add_inline_style( 'izeltlab-fonts', ':root{--izl-teal:' . $teal . ';--izl-teal-dark:' . izl_dark( $teal ) . '}' );
	// The front page shows the Codex cards, turning on a carousel when there are more than one.
	if ( is_front_page() && function_exists( 'fsz_enqueue_front' ) ) {
		fsz_enqueue_front();
		// Mirrored resting turn: the card faces the headline and the buttons, so the eye follows it to them.
		wp_add_inline_style( 'izeltlab-fonts', '.izl-hero-card .fsz-device{--fsz-turn:' . ( -1 * (int) fsz_opt( 'turn' ) ) . 'deg!important}' );
		// 1.7.10: the fake resting side stays at its resting size (style.css), the mirror of what Codex's codex.js sets
		// at rest: sideways 1 - turn / ref, down 1 - lean / ref (ref = tilt x 0.65, or 6.5 without tilt), kept 0-2.
		$ref = (float) fsz_opt( 'tilt' ) * 0.65;
		$ref = $ref > 0 ? $ref : 6.5;
		$kx  = max( 0, min( 2, 1 - (float) fsz_opt( 'turn' ) / $ref ) );
		$ky  = max( 0, min( 2, 1 - (float) fsz_opt( 'lean' ) / $ref ) );
		wp_add_inline_style( 'izeltlab-fonts', '.izl-hero-card .fsz-device{--izl-kx:' . round( $kx, 3 ) . ';--izl-ky:' . round( $ky, 3 ) . '}' );
		// The hero's scripts (hero-link.js, home-phone.js, carousel.js) are printed right under the hero since 2.5.0:
		// izl_hero_scripts(), called by front-page.php.
	}
}, 20 );

/**
 * 2.5.0: the hero's three scripts, printed inline right after the hero's markup (front-page.php), so they run before the
 * browser first draws the page: the three cards show up together at their places and sizes, with the title already
 * fitted. Before, they ran at the very end of the page: the front card showed alone for a moment, bigger, with the title
 * running off the screen, then everything jumped into place. In this order: 1.7.2 the card in front opens its product
 * page (before carousel.js, see the script); 2.4.0 phones: the title on one line, the cards at the product page's size;
 * the carousel (only with more than one card).
 */
function izl_hero_scripts() {
	$files = array( 'hero-link', 'home-phone' );
	if ( count( izl_hero_products() ) > 1 ) {
		$files[] = 'carousel';
	}
	foreach ( $files as $f ) {
		$js = (string) file_get_contents( get_stylesheet_directory() . '/' . izl_min( 'assets/' . $f . '.js' ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		echo '<script id="izeltlab-' . esc_attr( $f ) . '-js">' . str_replace( '</script', '<\\/script', $js ) . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

// 2.5.0: the front page's title font (Plex Mono bold) and the logo font are fetched with the page, so the title is fitted
// to its real letters straight away instead of shrinking a moment later.
add_action( 'wp_head', function () {
	if ( ! is_front_page() ) {
		return;
	}
	// The files the page really uses: Izeltlab Mono from Codex's copy when Codex is on (izl_mono_url()). 2.11.0: one file
	// each (the Hungarian letters are inside), so two early downloads instead of three.
	$urls = array( izl_mono_url( 'hu-700' ), get_stylesheet_directory_uri() . '/assets/fonts/space-mono-hu-700.woff2' );
	foreach ( $urls as $u ) {
		printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( $u ) );
	}
}, 1 );
