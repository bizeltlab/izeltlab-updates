<?php
// ==========================================================================
//  FILE: inc/product-page.php   (Ízeltláb theme)
//  WHAT: The product page layout: the buy box next to the Codex card, its settings, and the "Tedd mellé" supplies.
//  SEEN: Every product page.
//  SECTIONS IN THIS FILE:
//    1. Product page: the buy box next to the Codex card
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Product page: the buy box next to the Codex card
// ==========================================================================

/**
 * The buy box is a "trust stack": sales line (species: instead of the name), pack choice, price with the VAT note,
 * quantity and the cart button, the stock line, then the trust points, the short description and a few questions.
 * Species (Codex products) get all of it; supplies get the price row, the pack choice and the quantity buttons.
 */
function izl_product_defaults() {
	$answer = __( 'Write the answer here: Appearance → Customize → Ízeltláb product page.', 'izeltlab' );
	return array(
		'izl_trust_1_title'    => __( 'Live arrival guarantee', 'izeltlab' ),
		'izl_trust_1_text'     => __( 'If something goes wrong on the way, we replace it or refund you.', 'izeltlab' ),
		'izl_trust_2_title'    => __( 'Insulated packaging', 'izeltlab' ),
		'izl_trust_2_text'     => __( 'Sent Monday to Wednesday, so it never spends a weekend in transit.', 'izeltlab' ),
		'izl_trust_3_title'    => __( 'Bred by us in Budapest', 'izeltlab' ),
		'izl_trust_3_text'     => __( 'Personal pickup is possible too.', 'izeltlab' ),
		'izl_trust_difficulty' => 1,
		'izl_faq_1_q'          => __( 'What exactly do I get?', 'izeltlab' ),
		'izl_faq_1_a'          => $answer,
		'izl_faq_2_q'          => __( 'How do you ship in winter?', 'izeltlab' ),
		'izl_faq_2_a'          => $answer,
		'izl_faq_3_q'          => '',
		'izl_faq_3_a'          => '',
		'izl_faq_4_q'          => '',
		'izl_faq_4_a'          => '',
		'izl_faq_5_q'          => '',
		'izl_faq_5_a'          => '',
		'izl_faq_6_q'          => '',
		'izl_faq_6_a'          => '',
		'izl_vat_note'         => __( 'incl. 27% VAT', 'izeltlab' ),
		'izl_free_ship'        => 18000,
		'izl_pack_question'    => __( 'How many do you want to start with?', 'izeltlab' ),
		'izl_pack_tip'         => __( 'A bigger pack starts the colony faster.', 'izeltlab' ),
		'izl_drawer_trim'      => 14, // 2.0.5: px off the room above Kosárba vele! in the closed phone drawer
		'izl_drawer_203'       => 0,  // 2.0.5: roll-back switch: the phone drawer of 2.0.3
	);
}

// A product page setting. An emptied field stays empty (that point is hidden); never set = the default.
function izl_pmod( $key ) {
	$d = izl_product_defaults();
	return get_theme_mod( $key, isset( $d[ $key ] ) ? $d[ $key ] : '' );
}

function izl_on_codex_product() {
	return function_exists( 'is_product' ) && is_product() && izl_is_codex( get_queried_object_id() );
}

add_action( 'wp', function () {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}
	remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
	add_action( 'woocommerce_single_product_summary', 'izl_price_row', 10 );
	add_action( 'woocommerce_single_product_summary', 'izl_sales_line', 7 );
	add_action( 'woocommerce_before_variations_form', 'izl_pack_question' );
	add_action( 'woocommerce_single_product_summary', 'izl_stock_line', 31 );
	add_action( 'woocommerce_single_product_summary', 'izl_ship_lines', 32 );
	add_filter( 'woocommerce_get_stock_html', 'izl_hide_wc_stock', 10, 2 );
	// 1.7.0: the row of small tiles under every product page has its own title per product (the Upsells first, see
	// izl_row_products), so there is no separate "You may also like…" block.
	remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
	remove_action( 'woocommerce_after_single_product_summary', 'storefront_upsell_display', 15 ); // Storefront's own copy
	add_filter( 'woocommerce_product_related_products_heading', 'izl_row_title' );
	if ( ! izl_on_codex_product() ) {
		// Supplies: the description right under the buy box (no tabs), categories and tags as pills under the photo.
		remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
		add_action( 'woocommerce_single_product_summary', 'izl_description', 45 );
		add_action( 'woocommerce_after_single_product_summary', 'izl_term_pills', 1 ); // floated under the photo (style.css)
		return;
	}
	// 1.7.18: species pages: the packs set the amount, so the quantity buttons are hidden (style.css).
	add_filter( 'body_class', function ( $classes ) {
		$classes[] = 'izl-species';
		return $classes;
	} );
	// The Codex card next to the buy box already shows the names (nickname, English, Latin on its detail page), so the
	// buy box does not repeat them.
	// The name stays in the page as the main heading, hidden, for search engines and screen readers.
	remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
	add_action( 'woocommerce_single_product_summary', 'izl_hidden_title', 5 );
	// 2.1.2: the fallback for Codex before 1.35 is gone; Codex itself puts its one card in place of the photos.
	remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
	// The short description goes under the trust points (unless the Codex "Hide WooCommerce details" removed it).
	if ( false !== has_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt' ) ) {
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
		add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 35 );
	}
	// 1.6.0: under the cart button "Goes well with" (supplies); the trust points as one line under the card and the buy
	// box, then the common questions, then the small-tile row ("Similar species").
	add_action( 'woocommerce_single_product_summary', 'izl_setup_items', 34 );
	add_action( 'woocommerce_single_product_summary', 'izl_codex_tag_chips', 6 ); // 1.7.13: above the sales line
	add_action( 'woocommerce_after_single_product_summary', 'izl_trust_points', 5 );
	add_action( 'woocommerce_after_single_product_summary', 'izl_product_faq', 8 );
	add_filter( 'body_class', function ( $classes ) {
		$classes[] = 'izl-codex-product';
		// 2.5.3: packs (variable products) are known from the first byte, so the card can be placed for the pack drawer
		// before the buy form further down the page has arrived (the card no longer moves when it does).
		$product = wc_get_product( get_queried_object_id() );
		if ( $product && $product->is_type( 'variable' ) ) {
			$classes[] = 'izl-pack';
		}
		return $classes;
	} );
}, 20 );

define( 'IZL_SETUP_COUNT', 3 ); // supplies under the cart button

// What to put next to this species: the product's own cross-sells (Product data → Linked products → Cross-sells),
// else supplies from Kiegészítők. Only simple products that can be bought right now, so "+" can add them at once.
function izl_setup_products( $product ) {
	$ok = function ( $p ) {
		return $p instanceof WC_Product && $p->is_type( 'simple' ) && $p->is_purchasable() && $p->is_in_stock() && 'publish' === $p->get_status();
	};
	$out = array();
	foreach ( $product->get_cross_sell_ids() as $id ) {
		$p = wc_get_product( $id );
		if ( $ok( $p ) ) {
			$out[] = $p;
		}
	}
	if ( count( $out ) < IZL_SETUP_COUNT ) {
		$cat = get_term_by( 'slug', 'kiegeszitok', 'product_cat' );
		if ( $cat ) {
			$more = wc_get_products( array(
				'status'       => 'publish',
				'type'         => 'simple',
				'stock_status' => 'instock',
				'category'     => array( $cat->slug ),
				'exclude'      => array_merge( array( $product->get_id() ), array_map( function ( $p ) {
					return $p->get_id();
				}, $out ) ), // 2.1.1: was wp_list_pluck( $out, 'id' ) (a protected property)
				'limit'        => IZL_SETUP_COUNT * 2,
				'orderby'      => 'popularity',
			) );
			foreach ( $more as $p ) {
				if ( $ok( $p ) ) {
					$out[] = $p;
				}
			}
		}
	}
	return array_slice( $out, 0, IZL_SETUP_COUNT );
}

// "Goes well with": a few supplies right under the cart button, each with its price and a "+" that puts it in the cart
// without leaving the page (WooCommerce's own AJAX add to cart). The moment someone decides is when they add more.
function izl_setup_items() {
	global $product;
	if ( ! $product instanceof WC_Product || ! $product->is_in_stock() ) {
		return;
	}
	$items = izl_setup_products( $product );
	// 1.7.19: three is the staple. Whoever can edit the shop also sees the empty places, up to three; shoppers never.
	$empty = current_user_can( 'edit_products' ) ? IZL_SETUP_COUNT - count( $items ) : 0;
	if ( ! $items && ! $empty ) {
		return;
	}
	wp_enqueue_script( 'wc-add-to-cart' );
	echo '<div class="izl-setup"><p class="izl-setup-title">' . esc_html__( 'Goes well with', 'izeltlab' ) . '</p><ul>';
	foreach ( $items as $p ) {
		$link = get_permalink( $p->get_id() );
		/* translators: %s: product name */
		$add   = sprintf( __( 'Add %s to the cart', 'izeltlab' ), $p->get_name() );
		$group = izl_setup_group( $p->get_id() );
		echo '<li style="--izl-c:' . esc_attr( $group['color'] ) . '"><a class="izl-setup-photo" href="' . esc_url( $link ) . '" tabindex="-1" aria-hidden="true">' . $p->get_image( 'woocommerce_gallery_thumbnail' ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<span class="izl-setup-text"><span class="izl-setup-group">' . esc_html( $group['name'] ) . '</span><a class="izl-setup-name" href="' . esc_url( $link ) . '">' . esc_html( $p->get_name() ) . '</a></span>';
		echo '<span class="izl-setup-price">' . $p->get_price_html() . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<a href="' . esc_url( $p->add_to_cart_url() ) . '" data-quantity="1" data-product_id="' . (int) $p->get_id() . '" data-product_sku="' . esc_attr( $p->get_sku() ) . '" data-izl-price="' . esc_attr( (float) wc_get_price_to_display( $p ) ) . '" class="izl-setup-add add_to_cart_button ajax_add_to_cart" rel="nofollow" aria-label="' . esc_attr( $add ) . '" title="' . esc_attr( $add ) . '"><span aria-hidden="true">+</span></a></li>';
	}
	for ( $i = 0; $i < $empty; $i++ ) {
		echo '<li class="izl-setup-empty"><b>' . esc_html__( 'Empty place', 'izeltlab' ) . '</b><span>' . esc_html__( 'No product set up · only you see this', 'izeltlab' ) . '</span></li>';
	}
	echo '</ul></div>';
}

// 1.7.19: the group of a "Goes well with" product, for its colour strip: name and colour. Supplies say "Supply" in one
// word; the colour is the group's Codex colour, else a calm grey-green.
function izl_setup_group( $product_id ) {
	$term     = izl_group_term( $product_id );
	$supplies = izl_supplies_term();
	$color    = $term ? (string) sanitize_hex_color( (string) get_term_meta( $term->term_id, 'fsz_color', true ) ) : ''; // the Codex group colour
	if ( $term && $supplies && (int) $term->term_id === (int) $supplies->term_id ) {
		return array( 'name' => _x( 'Supply', 'one supply product', 'izeltlab' ), 'color' => $color ? $color : '#8aa39b' );
	}
	return array( 'name' => $term ? $term->name : '', 'color' => $color ? $color : '#8aa39b' );
}

function izl_hidden_title() {
	echo '<h1 class="product_title entry-title screen-reader-text">' . esc_html( get_the_title() ) . '</h1>';
}
