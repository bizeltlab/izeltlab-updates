<?php
// ==========================================================================
//  FILE: inc/front-page.php   (Ízeltláb theme)
//  WHAT: The front page: its texts and settings, the hero cards, the product rows, and its Customizer panel.
//  SEEN: The front page; Appearance → Customize → Ízeltláb front page.
//  SECTIONS IN THIS FILE:
//    1. Front page (front-page.php), the group tiles and buttons (3.21.0)
//    2. Customizer: Appearance → Customize → Ízeltláb front page
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Front page (front-page.php)
// ==========================================================================

function izl_home_defaults() {
	return array(
		'izl_hero_kicker' => __( 'Straight from the breeder', 'izeltlab' ),
		'izl_hero_title'  => __( 'Isopods for every terrarium', 'izeltlab' ),
		'izl_hero_text'   => __( 'Every species has its own Codex card: difficulty, care and good-to-know facts in one place, so you can choose with confidence.', 'izeltlab' ),
		'izl_about_title' => __( 'About the breeder', 'izeltlab' ),
		'izl_about_text'  => __( 'Write a few lines about yourself here: who you are, how long you have been breeding and what you pay attention to. (Edit it under Appearance → Customize → Ízeltláb front page.)', 'izeltlab' ),
	);
}

function izl_mod( $key ) {
	$d = izl_home_defaults();
	$v = get_theme_mod( $key, '' );
	return '' === trim( (string) $v ) ? $d[ $key ] : $v;
}

// The 3 Customizer slots of the front page carousel (the first one is the card in front at the start).
function izl_hero_slots() {
	return array( 'izl_hero_product', 'izl_hero_product_2', 'izl_hero_product_3' );
}

// The hover effect of the back cards (1.7.1): its name and strength 0-100 (0 = none), set in the "Edit cards" panel.
function izl_card_fx_strength() {
	return max( 0, min( 100, (int) get_theme_mod( 'izl_card_fx_strength', 60 ) ) );
}

// How many cards the front page shows (1-3; 1 = a single card, no carousel).
function izl_hero_count() {
	return max( 1, min( 3, (int) get_theme_mod( 'izl_hero_count', 3 ) ) );
}

/**
 * The species on the front page carousel, front card first: the ones picked in the Customizer or the quick edit,
 * an empty slot takes the Codex #001 (first slot) or the newest species not shown yet.
 */
function izl_hero_products() {
	$picked = array();
	foreach ( array_slice( izl_hero_slots(), 0, izl_hero_count() ) as $slot ) {
		$id       = absint( get_theme_mod( $slot, 0 ) );
		$picked[] = $id && 'publish' === get_post_status( $id ) && izl_is_codex( $id ) ? $id : 0;
	}
	$oldest = izl_codex_product_ids( 1, 'ASC' );
	$fill   = array_merge( $oldest, izl_codex_product_ids( 0 ) );
	$cards  = array();
	foreach ( $picked as $i => $id ) {
		if ( ! $id || in_array( $id, $cards, true ) ) {
			$id = 0;
			foreach ( $fill as $f ) {
				if ( ! in_array( (int) $f, $cards, true ) && ! in_array( (int) $f, $picked, true ) ) {
					$id = (int) $f;
					break;
				}
			}
		}
		if ( $id ) {
			$cards[] = $id;
		}
	}
	return $cards;
}

/**
 * Published, visible products of the isopod categories (or of one category, by slug), newest first.
 * $limit 0 = all.
 */
function izl_codex_product_ids( $limit = 4, $order = 'DESC' ) {
	if ( ! izl_has_codex() || ! function_exists( 'wc_get_products' ) ) {
		return array();
	}
	$slugs = wp_list_pluck( izl_isopod_terms(), 'slug' );
	if ( ! $slugs ) {
		return array();
	}
	$ids = wc_get_products( array(
		'status'     => 'publish',
		'visibility' => 'catalog',
		'category'   => $slugs,
		'limit'      => $limit ? $limit * 2 : -1, // a few more, in case some hide their card
		'orderby'    => 'date',
		'order'      => $order,
		'return'     => 'ids',
	) );
	$ids = array_values( array_filter( $ids, 'izl_is_codex' ) );
	return $limit ? array_slice( $ids, 0, $limit ) : $ids;
}

function izl_category_product_ids( $slug, $limit = 4 ) {
	if ( ! function_exists( 'wc_get_products' ) ) {
		return array();
	}
	return wc_get_products( array(
		'status'     => 'publish',
		'visibility' => 'catalog',
		'category'   => array( $slug ),
		'limit'      => $limit,
		'orderby'    => 'date',
		'order'      => 'DESC',
		'return'     => 'ids',
	) );
}

// A row of product tiles, the same as on the shop.
function izl_product_row( $ids ) {
	if ( ! $ids ) {
		return;
	}
	global $post;
	wc_set_loop_prop( 'columns', 4 );
	woocommerce_product_loop_start();
	foreach ( $ids as $id ) {
		$post = get_post( $id ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride
		setup_postdata( $post );
		wc_get_template_part( 'content', 'product' );
	}
	woocommerce_product_loop_end();
	wp_reset_postdata();
	wc_reset_loop();
}

/**
 * 3.21.0 (Dan, 2026-11-24): the group tiles (PC) and buttons (phones) under the front page text follow the header's
 * group buttons: the same groups in the same order (set in the Groups dialog). The first one is the yellow one. Each:
 * label, url, small line (set in the Groups dialog; the isopods and supplies have their own line by default), icon kind.
 */
function izl_front_groups() {
	$cfg = izl_groups_cfg();
	$out = array();
	foreach ( izl_cat_items() as $item ) {
		$line = isset( $cfg['lines'][ $item['key'] ] ) ? trim( (string) $cfg['lines'][ $item['key'] ] ) : '';
		if ( '' === $line && 'isopoda' === $item['kind'] ) {
			$line = __( 'Beginner species and rarities', 'izeltlab' );
		} elseif ( '' === $line && 'supplies' === $item['kind'] ) {
			$line = __( 'Hideouts, leaf litter, food', 'izeltlab' );
		}
		$out[] = array( 'label' => $item[0], 'url' => $item[1], 'line' => $line, 'kind' => $item['kind'], 'empty' => $item['empty'] );
	}
	return $out;
}

// The small drawing on a front page group tile: the isopod, the leaf for the supplies, an animal for the other set-up
// groups, and a plain box for any other group.
function izl_group_icon( $kind ) {
	$icons = array(
		'isopoda'    => '<svg width="34" height="22" viewBox="0 0 40 24" aria-hidden="true" focusable="false"><path d="M6 20C6 9 14 4 22 4s14 5 14 16z"/><path d="M14 6v14M20 4v16M26 4v16M31 7v13M6 14q-4-3-5-8"/></svg>',
		'supplies'   => '<svg width="26" height="26" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 19C5 10 11 5 20 4c-1 9-6 15-15 15z"/><path d="M5 19l8-8"/></svg>',
		'blattodea'  => '<svg width="30" height="24" viewBox="0 0 30 24" aria-hidden="true" focusable="false"><ellipse cx="13" cy="12" rx="9" ry="5.5"/><path d="M22 12h3M24 10q3-5 5-6M24 14q3 5 5 6M8 7l-2-4M13 6.5V3M18 7l2-4M8 17l-2 4M13 17.5V21M18 17l2 4M5 12h16"/></svg>',
		'collembola' => '<svg width="30" height="22" viewBox="0 0 30 22" aria-hidden="true" focusable="false"><path d="M4 11c0-3 6-4 11-4s9 1 9 4-4 4-9 4-11-1-11-4z"/><path d="M24 10l3-4M24 12l3 4M10 15l-4 5M15 15l-1 5M19 15l1 4"/></svg>',
		'arachnida'  => '<svg width="30" height="24" viewBox="0 0 30 24" aria-hidden="true" focusable="false"><ellipse cx="11" cy="12" rx="5.5" ry="4.5"/><circle cx="19" cy="12" r="3"/><path d="M20 9l3-5 5-2M21 10l5-2 3 2M21 14l5 2 3-2M20 15l3 5 5 2M9 8L7 3M12 7.6l1-5M9 16l-2 5M12 16.4l1 5"/></svg>',
	);
	return isset( $icons[ $kind ] ) ? $icons[ $kind ] : '<svg width="26" height="26" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="4" y="7" width="16" height="13" rx="2"/><path d="M4 11h16M9 4h6l1 3H8z"/></svg>';
}

// ==========================================================================
//  Customizer: Appearance → Customize → Ízeltláb front page
// ==========================================================================

add_action( 'customize_register', function ( $wp_customize ) {
	$wp_customize->add_section( 'izl_home', array(
		'title'       => __( 'Ízeltláb front page', 'izeltlab' ),
		'description' => __( 'Texts of the front page. Leave a field empty for the default text.', 'izeltlab' ),
		'priority'    => 30,
	) );
	$fields = array(
		'izl_hero_kicker' => array( __( 'Small label above the title', 'izeltlab' ), 'text' ),
		'izl_hero_title'  => array( __( 'Title', 'izeltlab' ), 'text' ),
		'izl_hero_text'   => array( __( 'Text under the title', 'izeltlab' ), 'textarea' ),
		'izl_about_title' => array( __( 'About: title', 'izeltlab' ), 'text' ),
		'izl_about_text'  => array( __( 'About: text', 'izeltlab' ), 'textarea' ),
	);
	foreach ( $fields as $key => $f ) {
		$wp_customize->add_setting( $key, array( 'default' => '', 'sanitize_callback' => 'textarea' === $f[1] ? 'wp_kses_post' : 'sanitize_text_field' ) );
		$wp_customize->add_control( $key, array( 'label' => $f[0], 'section' => 'izl_home', 'type' => $f[1], 'input_attrs' => array( 'placeholder' => izl_home_defaults()[ $key ] ) ) );
	}
	$choices = array( 0 => __( 'Automatic', 'izeltlab' ) );
	foreach ( izl_codex_product_ids( 0, 'ASC' ) as $id ) {
		$choices[ $id ] = ( function_exists( 'fsz_codex_number' ) ? fsz_codex_number( $id ) . ' ' : '' ) . html_entity_decode( get_the_title( $id ), ENT_QUOTES, 'UTF-8' );
	}
	$wp_customize->add_setting( 'izl_hero_count', array( 'default' => 3, 'sanitize_callback' => 'absint' ) );
	$wp_customize->add_control( 'izl_hero_count', array(
		'label'   => __( 'Number of Codex cards', 'izeltlab' ),
		'section' => 'izl_home',
		'type'    => 'select',
		'choices' => array( 1 => '1', 2 => '2', 3 => '3' ),
	) );
	$labels = array(
		__( 'Codex card 1 (in front at the start)', 'izeltlab' ),
		__( 'Codex card 2', 'izeltlab' ),
		__( 'Codex card 3', 'izeltlab' ),
	);
	foreach ( izl_hero_slots() as $i => $slot ) {
		$wp_customize->add_setting( $slot, array( 'default' => 0, 'sanitize_callback' => 'absint' ) );
		$wp_customize->add_control( $slot, array(
			'label'       => $labels[ $i ],
			'description' => $i ? '' : __( 'Automatic: card 1 is the Codex #001, the others the newest species.', 'izeltlab' ),
			'section'     => 'izl_home',
			'type'        => 'select',
			'choices'     => $choices,
		) );
	}
} );
