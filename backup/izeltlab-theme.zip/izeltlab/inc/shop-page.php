<?php
// ==========================================================================
//  FILE: inc/shop-page.php   (Ízeltláb theme)
//  WHAT: The shop page (since 3.2.0): the slim filter bar (Csoport switches, Nehézség buttons, the phone's "Szűrők"
//        bar), the grid's room, in-stock-first order, "Utolsó N db" and sold-out tiles, the free-shipping line above
//        the grid and the friendly empty list. The script is assets/shop.js, the look the last section of style.css.
//  SEEN: The shop, the isopod list and category lists (not search results, not the product rows elsewhere).
//  SECTIONS IN THIS FILE:
//    1. Where the filter bar is on, which layout
//    2. The list: all products on one page, in stock first, then newest
//    3. What each tile carries (group, level, stock)
//    4. The filter bar
//    5. Free-shipping line and the empty list
//    6. Old links and the script
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Where the filter bar is on, which layout
// ==========================================================================

/**
 * True on the pages that get the new shop page: the shop (with or without ?izl_view=isopods) and every product
 * category, but not a search. Switch it off with add_filter( 'izl_shop_filter', '__return_false' ): the old
 * difficulty pills come back (inc/shop-list.php).
 */
function izl_sf_on() {
	if ( ! function_exists( 'is_shop' ) || is_search() || is_admin() ) {
		return false;
	}
	return (bool) apply_filters( 'izl_shop_filter', is_shop() || is_product_category() );
}

/**
 * "bar" (the slim bar above the grid, for now) or "side" (the sticky column on the left with an empty column of the
 * same width on the right, for a bigger shop later). Set it with the izl_shop_filter_layout filter, or the theme
 * setting izl_shop_filter_layout ("side"), e.g. add_filter( 'izl_shop_filter_layout', function () { return 'side'; } );
 */
function izl_sf_layout() {
	$l = (string) apply_filters( 'izl_shop_filter_layout', (string) get_theme_mod( 'izl_shop_filter_layout', 'bar' ) );
	return 'side' === $l ? 'side' : 'bar';
}

// From how many products phones show two tiles per row instead of one.
function izl_sf_two_up_at() {
	return (int) apply_filters( 'izl_shop_two_up_at', 12 );
}

// The state asked for in the address: ?csoport=<category slug>&nehezseg=<1-3>.
function izl_sf_state() {
	// phpcs:disable WordPress.Security.NonceVerification
	$g = isset( $_GET['csoport'] ) ? sanitize_title( wp_unslash( (string) $_GET['csoport'] ) ) : '';
	$l = isset( $_GET['nehezseg'] ) ? (int) $_GET['nehezseg'] : 0;
	// phpcs:enable
	return array( 'g' => $g, 'l' => $l >= 1 && $l <= 3 ? $l : 0 );
}

add_filter( 'body_class', function ( $classes ) {
	if ( izl_sf_on() ) {
		$classes[] = 'izl-shopf';
		$classes[] = 'izl-shopf-' . izl_sf_layout();
		global $wp_query;
		if ( (int) $wp_query->post_count >= izl_sf_two_up_at() ) {
			$classes[] = 'izl-shopf-two'; // phones: two tiles per row
		}
	}
	return $classes;
} );

// ==========================================================================
//  The list: all products on one page, in stock first, then newest
// ==========================================================================

// The filters work in the browser over the whole list, so the list is one page (up to 120 products; past that the
// page numbers come back and the sidebar layout is the better fit). Sold out goes last, whatever the sort; the
// default sort is "newest first" (Dan, 2026-11-13; "Népszerű" later).
add_action( 'woocommerce_product_query', function ( $q ) {
	if ( ! $q->is_main_query() || ! izl_sf_on() ) {
		return;
	}
	$q->set( 'posts_per_page', max( (int) $q->get( 'posts_per_page' ), (int) apply_filters( 'izl_shop_per_page', 120 ) ) );
	$q->set( 'izl_stock_first', 1 );
}, 20 );

add_filter( 'woocommerce_get_catalog_ordering_args', function ( $args, $orderby = '', $order = '' ) {
	if ( izl_sf_on() && ( '' === (string) $orderby || 'menu_order' === $orderby ) ) {
		$args['orderby'] = array( 'date' => 'DESC', 'ID' => 'DESC' );
		$args['order']   = 'DESC';
	}
	return $args;
}, 20, 3 );

add_filter( 'posts_clauses', function ( $c, $q ) {
	if ( ! $q->get( 'izl_stock_first' ) ) {
		return $c;
	}
	global $wpdb;
	$c['join']   .= " LEFT JOIN {$wpdb->wc_product_meta_lookup} izl_sl ON {$wpdb->posts}.ID = izl_sl.product_id";
	$first        = "CASE WHEN izl_sl.stock_status = 'outofstock' THEN 1 ELSE 0 END ASC";
	$c['orderby'] = '' !== trim( (string) $c['orderby'] ) ? $first . ', ' . $c['orderby'] : $first;
	return $c;
}, 20, 2 );

// ==========================================================================
//  What each tile carries (group, level, stock)
// ==========================================================================

/**
 * One product's filter data: group (top category: slug, name), level (1-3, 0 = none, e.g. supplies). Cached.
 */
function izl_sf_item( $product ) {
	static $cache = array();
	$id = $product->get_id();
	if ( ! isset( $cache[ $id ] ) ) {
		$term  = izl_group_term( $id );
		$codex = izl_is_codex( $id );
		$cache[ $id ] = array(
			'g'    => $term ? $term->slug : '',
			'name' => $term ? $term->name : '',
			'l'    => $codex ? izl_level( (int) get_post_meta( $id, '_fsz_difficulty', true ) ) : 0,
		);
	}
	return $cache[ $id ];
}

// The products of the list on this page (the main query), with their filter data.
function izl_sf_items() {
	global $wp_query;
	$out = array();
	foreach ( (array) $wp_query->posts as $post ) {
		$p = wc_get_product( $post );
		if ( $p && $p->is_visible() ) {
			$out[ $p->get_id() ] = izl_sf_item( $p );
		}
	}
	return $out;
}

// True while the main list of a filter page is drawn (not the product rows or anything else on the page).
function izl_sf_in_loop( $set = null ) {
	static $on = false;
	if ( null !== $set ) {
		$on = (bool) $set;
	}
	return $on;
}
add_action( 'woocommerce_before_shop_loop', function () {
	izl_sf_in_loop( izl_sf_on() );
}, 1 );
add_action( 'woocommerce_after_shop_loop', function () {
	izl_sf_in_loop( false );
}, 1 );

// The tile's extra attributes in the list (izl_product_tile() prints them): data-g, data-l, and hidden when the
// address already asks for another group or level.
function izl_sf_tile_attrs( $product ) {
	if ( ! izl_sf_in_loop() ) {
		return '';
	}
	$it = izl_sf_item( $product );
	$st = izl_sf_state();
	$out = ( $st['g'] && $st['g'] !== $it['g'] ) || ( $st['l'] && $st['l'] !== $it['l'] );
	return ' data-g="' . esc_attr( $it['g'] ) . '" data-l="' . (int) $it['l'] . '"' . ( $out ? ' hidden' : '' );
}

/**
 * "Utolsó N db" on the photo: in stock, and the stock count is at or under the buy ticket's "few" (IZL_LOW_STOCK, 3), or the
 * Codex "Running low" switch is on (the card's blinking yellow light). Without a stock count: "Utolsó darabok".
 */
function izl_sf_low_badge( $product ) {
	if ( ! izl_sf_in_loop() || ! $product->is_in_stock() ) {
		return '';
	}
	$qty  = $product->managing_stock() ? (int) $product->get_stock_quantity() : null;
	$flag = 'yes' === get_post_meta( $product->get_id(), '_fsz_low', true );
	$low  = null !== $qty && $qty > 0 && $qty <= ( defined( 'IZL_LOW_STOCK' ) ? IZL_LOW_STOCK : 3 ); // the same "few" as the buy ticket
	if ( ! $low && ! $flag ) {
		return '';
	}
	/* translators: %d: how many are left */
	$text = null !== $qty && $qty > 0 ? sprintf( __( 'Only %d left', 'izeltlab' ), $qty ) : __( 'Last few left', 'izeltlab' );
	return '<span class="izl-tile-low"><i aria-hidden="true"></i>' . esc_html( $text ) . '</span>';
}

// The photo sizes the browser picks a file by, for this grid (3 columns across the page on a PC, 2 on a tablet, 1 or 2 on a
// phone), times how much the 4:3 window crops and zooms the photo (the same reckoning as izl_tile_image()).
add_filter( 'izl_tile_sizes', function ( $sizes, $id, $frame ) {
	if ( ! izl_sf_in_loop() ) {
		return $sizes;
	}
	global $wp_query;
	$meta = wp_get_attachment_metadata( $id );
	$k    = is_array( $meta ) && ! empty( $meta['width'] ) && ! empty( $meta['height'] ) ? max( 1, ( (int) $meta['width'] / (int) $meta['height'] ) / ( 4 / 3 ) ) : 1;
	$k   *= max( 1, (float) $frame[2] );
	$n    = function ( $v ) use ( $k ) {
		return (string) round( $v * $k, 1 );
	};
	$side = 'side' === izl_sf_layout();
	$two  = (int) $wp_query->post_count >= izl_sf_two_up_at();
	return '(min-width: 1101px) ' . $n( $side ? 12 : 22 ) . 'vw, (min-width: 821px) ' . $n( $side ? 20 : 29 ) . 'vw, (min-width: 481px) ' . $n( 45 ) . 'vw, ' . $n( $two ? 45 : 90 ) . 'vw';
}, 10, 3 );

// The sold-out tile's button in the list: "Szólj, ha újra van", to the sign-up form on its page (Ízeltláb Bolt).
function izl_sf_notify_button( $product ) {
	if ( ! izl_sf_in_loop() || $product->is_in_stock() || ! function_exists( 'izb_notify_offered' ) || ! izb_notify_offered( $product ) ) {
		return false;
	}
	echo '<a class="button izl-tile-notify" href="' . esc_url( $product->get_permalink() . '#izb-notify' ) . '">' . esc_html__( 'Tell me when it is back', 'izeltlab' ) . '</a>';
	return true;
}

// ==========================================================================
//  The filter bar
// ==========================================================================

// The bar's own room: one box around the bar, the count and sort row, the free-shipping line and the grid, so both
// layouts (bar and sidebar) can place them. Closed after the page numbers.
add_action( 'woocommerce_before_shop_loop', function () {
	if ( izl_sf_on() ) {
		echo '<div class="izl-sf-stage is-' . esc_attr( izl_sf_layout() ) . '">';
		izl_sf_bar();
	}
}, 8 );
add_action( 'woocommerce_after_shop_loop', function () {
	if ( izl_sf_on() ) {
		izl_sf_empty();
		echo '</div>';
	}
}, 40 );

// The address of the list without our own words in it (and without the page number).
function izl_sf_base_url() {
	return remove_query_arg( array( 'csoport', 'nehezseg', 'max_difficulty', 'paged' ), get_pagenum_link( 1, false ) );
}

function izl_sf_bar() {
	$items = izl_sf_items();
	$st    = izl_sf_state();
	// The groups in this list, in the order the categories are sorted, and the levels any of them has.
	$groups = array();
	$levels = array();
	foreach ( $items as $it ) {
		if ( '' !== $it['g'] && ! isset( $groups[ $it['g'] ] ) ) {
			$groups[ $it['g'] ] = $it['name'];
		}
		if ( $it['l'] ) {
			$levels[ $it['l'] ] = true;
		}
	}
	$st['g'] = isset( $groups[ $st['g'] ] ) ? $st['g'] : '';
	$st['l'] = isset( $levels[ $st['l'] ] ) ? $st['l'] : 0;
	$count = function ( $g, $l ) use ( $items ) {
		$n = 0;
		foreach ( $items as $it ) {
			$n += ( ! $g || $g === $it['g'] ) && ( ! $l || $l === $it['l'] ) ? 1 : 0;
		}
		return $n;
	};
	$show_g = count( $groups ) > 1;
	$show_l = count( $levels ) > 0;
	if ( ! $show_g && ! $show_l ) {
		return;
	}
	$words = array( 1 => izl_level_word( 1 ), 2 => izl_level_word( 2 ), 3 => izl_level_word( 3 ) );
	$cfg   = array(
		'g'      => $st['g'],
		'l'      => $st['l'],
		'names'  => $groups,
		'words'  => $words,
		/* translators: %s: the chosen filters, e.g. "Ászkák · Kezdő" */
		'sumOn'  => __( 'Filters: %s', 'izeltlab' ),
		'sumOff' => __( 'Filters', 'izeltlab' ),
		/* translators: %s: e.g. "5 faj" */
		'show'   => __( 'Show: %s', 'izeltlab' ),
		/* translators: %s: number of species in the list */
		'fmt'    => izl_on_isopods_page() ? _n( '%s species', '%s species', 2, 'izeltlab' ) : _n( '%s product', '%s products', 2, 'izeltlab' ),
	);
	$hidden = '';
	// phpcs:disable WordPress.Security.NonceVerification
	foreach ( $_GET as $k => $v ) {
		if ( ! in_array( $k, array( 'csoport', 'nehezseg', 'max_difficulty', 'paged' ), true ) && is_scalar( $v ) ) {
			$hidden .= '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( wp_unslash( (string) $v ) ) . '">';
		}
	}
	// phpcs:enable
	$chosen = array_filter( array( $st['g'] ? $groups[ $st['g'] ] : '', $st['l'] ? $words[ $st['l'] ] : '' ) );
	$n      = $count( $st['g'], $st['l'] );
	$nword  = sprintf( $cfg['fmt'], number_format_i18n( $n ) );
	echo '<div class="izl-sf" data-cfg="' . esc_attr( wp_json_encode( $cfg ) ) . '">';
	// Phone: the slim bar that opens the panel ("Szűrők: Ászkák · Kezdő [5 faj]"). The inline line hides the panel
	// before the first paint (without JavaScript the panel simply stays open).
	echo '<script>document.currentScript.parentNode.className+=" is-js"</script>';
	echo '<div class="izl-sf-phone"><button type="button" class="izl-sf-open" aria-expanded="false" aria-controls="izl-sf-panel">';
	echo '<span class="izl-sf-ico" aria-hidden="true"><i></i><i></i><i></i></span><span class="izl-sf-sum">' . esc_html( $chosen ? sprintf( $cfg['sumOn'], implode( ' · ', $chosen ) ) : $cfg['sumOff'] ) . '</span>';
	echo '<span class="izl-sf-n">' . esc_html( $nword ) . '</span><span class="izl-sf-arrow" aria-hidden="true"></span></button>';
	if ( $show_l && isset( $levels[1] ) ) {
		echo '<button type="button" class="izl-sf-beg" data-l="1" hidden>' . esc_html__( 'For beginners', 'izeltlab' ) . '</button>';
	}
	echo '</div>';
	// Without JavaScript the switches send this form. The choice already made comes first, so a pressed button (later
	// in the form, so its value wins) changes only its own part.
	foreach ( array( 'csoport' => $st['g'], 'nehezseg' => $st['l'] ) as $k => $v ) {
		$hidden .= $v ? '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( (string) $v ) . '">' : '';
	}
	echo '<form class="izl-sf-panel" id="izl-sf-panel" method="get" action="' . esc_url( izl_sf_base_url() ) . '" aria-label="' . esc_attr__( 'Filters', 'izeltlab' ) . '">' . $hidden; // phpcs:ignore WordPress.Security.EscapeOutput
	if ( $show_g ) {
		echo '<div class="izl-sf-part is-g"><p class="izl-sf-h" id="izl-sf-hg">' . esc_html__( 'Group', 'izeltlab' ) . '</p><div class="izl-sf-sw" role="group" aria-labelledby="izl-sf-hg">';
		foreach ( $groups as $slug => $name ) {
			$on = $st['g'] === $slug;
			// Pressing the lit one sends an empty group (= all).
			echo '<button type="submit" name="csoport" value="' . esc_attr( $on ? '' : $slug ) . '" data-g="' . esc_attr( $slug ) . '" aria-pressed="' . ( $on ? 'true' : 'false' ) . '"><span class="izl-sf-led" aria-hidden="true"></span><span class="izl-sf-gn">' . esc_html( $name ) . '</span><span class="izl-sf-c">' . (int) $count( $slug, $st['l'] ) . '</span></button>';
		}
		echo '</div></div>';
	}
	if ( $show_l ) {
		echo '<div class="izl-sf-part is-l"><p class="izl-sf-h" id="izl-sf-hl">' . esc_html__( 'Difficulty', 'izeltlab' ) . '</p><div class="izl-sf-lv" role="group" aria-labelledby="izl-sf-hl">';
		foreach ( $words as $l => $word ) {
			if ( ! isset( $levels[ $l ] ) ) {
				continue;
			}
			$on = $st['l'] === $l;
			echo '<button type="submit" name="nehezseg" value="' . ( $on ? '' : (int) $l ) . '" data-l="' . (int) $l . '" class="lv' . (int) ( $l + 2 ) . '" aria-pressed="' . ( $on ? 'true' : 'false' ) . '"><span class="izl-sf-lw">' . esc_html( $word ) . '</span><span class="izl-sf-seg" aria-hidden="true">' . str_repeat( '<i class="is-f"></i>', $l ) . str_repeat( '<i></i>', 3 - $l ) . '</span></button>';
		}
		echo '</div></div>';
	}
	echo '<a class="izl-sf-clear" href="' . esc_url( izl_sf_base_url() ) . '"' . ( $chosen ? '' : ' aria-disabled="true"' ) . '>' . esc_html__( 'Clear filters', 'izeltlab' ) . '</a>';
	echo '<button type="button" class="izl-sf-show">' . esc_html( sprintf( $cfg['show'], $nword ) ) . '</button>';
	echo '</form></div>';
}

// ==========================================================================
//  Free-shipping line and the empty list
// ==========================================================================

// Above the grid: "18 000 Ft felett ingyenes a szállítás"; with something in the cart "Még X Ft az ingyenes
// szállításig", then "Megvan! Ingyenes a szállítás!" (the same amount and cart total as the cart page: shop-core).
// The cart part is filled in by shop.js from the cart icon's data-total (the page itself may come from the cache).
// Never the 14:00 cut-off.
add_action( 'woocommerce_before_shop_loop', function () {
	if ( ! izl_sf_on() ) {
		return;
	}
	$goal = (float) izl_free_ship();
	if ( $goal <= 0 ) {
		return;
	}
	$money = function ( $v ) {
		return html_entity_decode( wp_strip_all_tags( wc_price( $v ) ), ENT_QUOTES, 'UTF-8' );
	};
	$cfg = array(
		'goal' => $goal,
		/* translators: %s: amount still missing, e.g. 4 500 Ft */
		'more' => __( '%s more to free shipping', 'izeltlab' ),
		'done' => __( 'Done! Shipping is free!', 'izeltlab' ),
		'zero' => $money( 0 ),
		'one'  => $money( 1000 ),
	);
	/* translators: %s: the free shipping amount, e.g. 18 000 Ft */
	$text = sprintf( __( 'Shipping is free over %s', 'izeltlab' ), $money( $goal ) );
	echo '<p class="izl-sf-free" data-cfg="' . esc_attr( wp_json_encode( $cfg ) ) . '"><span class="izl-sf-van" aria-hidden="true"></span><span class="izl-sf-ft" aria-live="polite">' . esc_html( $text ) . '</span></p>';
}, 35 );

// When the filters leave nothing: "Ilyen még nincs a kolóniában. Szólj, és értesítünk." with the newsletter form
// (Ízeltláb Bolt), and the way back. Printed hidden; shop.js shows it.
function izl_sf_empty() {
	$st = izl_sf_state();
	echo '<div class="izl-sf-empty"' . ( izl_sf_has_match( $st ) ? ' hidden' : '' ) . '>';
	echo '<p class="izl-sf-et">' . esc_html__( 'None of these in the colony yet.', 'izeltlab' ) . '</p>';
	echo '<p class="izl-sf-es">' . esc_html__( 'Tell us, and we will let you know.', 'izeltlab' ) . '</p>';
	if ( function_exists( 'izb_form' ) && function_exists( 'izb_opt' ) && izb_opt( 'news_on' ) ) {
		echo str_replace( 'izb-mail-news', 'izb-mail-empty', izb_form( 'news' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '<p><a class="izl-sf-clear is-back" href="' . esc_url( izl_sf_base_url() ) . '">' . esc_html__( 'Clear filters', 'izeltlab' ) . '</a></p></div>';
}

function izl_sf_has_match( $st ) {
	if ( ! $st['g'] && ! $st['l'] ) {
		return true;
	}
	foreach ( izl_sf_items() as $it ) {
		if ( ( ! $st['g'] || $st['g'] === $it['g'] ) && ( ! $st['l'] || $st['l'] === $it['l'] ) ) {
			return true;
		}
	}
	return false;
}

// ==========================================================================
//  Old links and the script
// ==========================================================================

// An old difficulty link (?max_difficulty=2, the menu's "Kezdőknek" before 3.2.0, bookmarks) opens the new filter:
// up to Beginner = Kezdő; the old "Kezdő + Haladó" = everything. The old link let Codex cut the list on the server.
add_action( 'template_redirect', function () {
	if ( ! isset( $_GET['max_difficulty'] ) || ! izl_sf_on() ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$max = (int) $_GET['max_difficulty']; // phpcs:ignore WordPress.Security.NonceVerification
	$url = remove_query_arg( 'max_difficulty' );
	if ( $max >= 1 && $max <= izl_beginner_level() ) {
		$url = add_query_arg( 'nehezseg', 1, $url );
	}
	wp_safe_redirect( $url, 302 );
	exit;
} );

add_action( 'wp_enqueue_scripts', function () {
	if ( izl_sf_on() ) {
		wp_enqueue_script( 'izeltlab-shop', get_stylesheet_directory_uri() . '/' . izl_min( 'assets/shop.js' ), array(), IZL_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	}
}, 30 );
