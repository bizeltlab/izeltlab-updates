<?php
// ==========================================================================
//  FILE: inc/unused-files.php   (Ízeltláb theme)
//  WHAT: Stops loading Storefront files the shop does not use: the icon font's 1 500 unused classes, the block
//        styles on pages without blocks, the brand styles and script while the shop has no brands.
//        Nothing here changes the look: a file is only left out where none of its rules can apply.
//  SEEN: Behind the scenes, on every page (less to download).
//  SWITCH OFF: add_filter( 'izl_drop_unused_files', '__return_false' );
//  SECTIONS IN THIS FILE:
//    1. Storefront's icon stylesheet: the short copy
//    2. Block styles: only where blocks can be
//    3. Brand styles and script: only when the shop has brands
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'wp_enqueue_scripts', function () {
	if ( ! apply_filters( 'izl_drop_unused_files', true ) ) {
		return;
	}

	// ==========================================================================
	//  Storefront's icon stylesheet: the short copy
	// ==========================================================================
	// Storefront's icons.css is 80 KB: about 100 rules that draw Storefront's own icons, and 1 478 "fa-…" classes for
	// icons typed into a page by hand, which nothing in the shop uses. The build makes a copy without those classes
	// (assets/storefront-icons-lite.min.css: the icon font and every other rule stay, in the same order). The copy is
	// used only while Storefront's file is still the one it was made from (same size); after a Storefront update that
	// changes the file, the original loads again until the next build.
	$rec  = izl_built( 'storefront:assets/css/base/icons.css' );
	$orig = get_template_directory() . '/assets/css/base/icons.css';
	$lite = 'assets/storefront-icons-lite.min.css';
	if ( $rec && wp_style_is( 'storefront-icons', 'enqueued' ) && 'storefront' === basename( get_template_directory() )
		&& ! is_rtl() && is_readable( get_stylesheet_directory() . '/' . $lite )
		&& (int) @filesize( $orig ) === (int) $rec['size'] ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
		$style = wp_styles()->registered['storefront-icons'];
		$style->src = get_stylesheet_directory_uri() . '/' . $lite;
		$style->ver = IZL_VERSION;
	}

	// ==========================================================================
	//  Block styles: only where blocks can be
	// ==========================================================================
	// Storefront's gutenberg-blocks.css (43 KB) styles the block editor's blocks. Shop lists, product pages, the cart and
	// the front page are not built from blocks, so the file is left out there. It stays wherever a block can show: a
	// page or product whose text holds blocks, any page while a block widget is in use, and every blog page.
	if ( ! izl_page_may_have_blocks() ) {
		wp_dequeue_style( 'storefront-gutenberg-blocks' );
	}

	// ==========================================================================
	//  Brand styles and script: only when the shop has brands
	// ==========================================================================
	// WooCommerce's "Brands" feature: Storefront loads a stylesheet and a script for it on every page. With no brand
	// created (Products → Brands is empty) there is nothing for them to style.
	if ( ! taxonomy_exists( 'product_brand' ) || 0 === (int) wp_count_terms( array( 'taxonomy' => 'product_brand', 'hide_empty' => false ) ) ) {
		wp_dequeue_style( 'storefront-woocommerce-brands-style' );
		wp_dequeue_script( 'storefront-woocommerce-brands' );
	}
}, 200 );

// Can this page show a block-editor block? Yes whenever in doubt.
function izl_page_may_have_blocks() {
	// a block widget in a widget area this page shows (footer columns, header; the sidebar only where the theme keeps
	// it: inc/layout.php takes it off the shop, product, cart, checkout, account and front pages)
	foreach ( (array) wp_get_sidebars_widgets() as $area => $widgets ) {
		if ( 'wp_inactive_widgets' === $area || ( 'sidebar-1' === $area && izl_full_width() ) ) {
			continue;
		}
		foreach ( (array) $widgets as $id ) {
			if ( 0 === strpos( (string) $id, 'block-' ) ) {
				return true;
			}
		}
	}
	$shop_list = function_exists( 'is_shop' ) && ( is_shop() || is_product_taxonomy() );
	if ( $shop_list || is_404() || ( is_search() && 'product' === get_query_var( 'post_type' ) ) ) {
		return false; // lists of tiles: no page text is printed
	}
	if ( is_front_page() && ! is_page_template( 'template-fullwidth.php' ) ) {
		return is_page() && has_blocks( get_queried_object() ); // the theme's own front page (front-page.php)
	}
	if ( is_singular() ) {
		$post = get_queried_object();
		return ! $post instanceof WP_Post || has_blocks( $post->post_content ) || has_blocks( $post->post_excerpt );
	}
	return true; // blog lists and everything else
}
