<?php
/**
 * 2.1.0: the launch pages in the Retro Handheld look (assets/launch.css): cart (free-shipping bar, item cards on a
 * phone; 2.2.0: the bar drawn like the buy box's, the "Szállítás" route box, the bar in the mini cart too),
 * phone), checkout, thank-you ("what happens now"), empty cart, mini cart under the header cart icon (desktop),
 * footer (useful links, contact, newsletter slot), 404, no search results, My account, the WordPress login screen.
 * Plus the Hungarian public holidays in the "Sets off" / "With you" dates.
 * Nothing here changes the product page, the shop tiles, the header or the Codex card.
 */

defined( 'ABSPATH' ) || exit;

/* ------------------------------------------------------------------ styles */

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'izeltlab-launch', get_stylesheet_directory_uri() . '/' . izl_min( 'assets/launch.css' ), array(), IZL_VERSION );
}, 30 );

/* ------------------------------------------------------------------ cart: free-shipping bar, empty cart */

// The bar above the cart table: "Only 4 500 Ft more and shipping is free!" (the same words as the product page).
// 2.2.0: drawn like the buy box's free-shipping line (the thin yellow bar, green with a tick once it is free), so the
// cart and the product page speak the same way (Dan, 2026-11-05).
function izl_free_line( $extra = '' ) {
	$goal = (float) izl_free_ship();
	if ( $goal <= 0 || ! WC()->cart || WC()->cart->is_empty() ) {
		return '';
	}
	$sum  = (float) izl_cart_total();
	$left = max( 0, $goal - $sum );
	$pct  = max( 3, min( 100, round( $sum / $goal * 100 ) ) );
	/* translators: %s: amount still missing, e.g. 15 500 Ft */
	$txt  = $left > 0 ? esc_html( sprintf( __( 'Only %s more and shipping is free!', 'izeltlab' ), html_entity_decode( wp_strip_all_tags( wc_price( $left ) ) ) ) )
		: '<span class="izl-prog-ck" aria-hidden="true">✓</span>' . esc_html__( 'Done! Shipping is free!', 'izeltlab' );
	return '<p class="izl-prog' . ( $left > 0 ? '' : ' is-done' ) . ( $extra ? ' ' . esc_attr( $extra ) : '' ) . '" role="status"><span class="izl-prog-t">' . $txt . '</span><span class="izl-prog-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' . (int) $pct . '"><i style="width:' . (int) $pct . '%"></i></span></p>';
}

function izl_cart_progress() {
	$line = izl_free_line();
	if ( $line ) {
		echo '<div class="izl-cart-prog">' . $line . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

// 2.9.0 (Dan, 2026-11-07): the bar lives in the "Kosár összesen" box, right above the Szállítás block, on PC and phone
// (the phone's bottom bar keeps its own line too). Inside .cart_totals, so the cart's AJAX refresh redraws it.
function izl_cart_progress_row() {
	$line = izl_free_line();
	if ( $line ) {
		echo '<tr class="izl-prog-row"><td colspan="2"><div class="izl-cart-prog">' . $line . '</div></td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}
add_action( 'woocommerce_cart_totals_before_shipping', 'izl_cart_progress_row', 5 );
// No shipping row in the box (no shipping zone yet): the bar goes right above the total instead.
add_action( 'woocommerce_cart_totals_before_order_total', function () {
	if ( WC()->cart && ! ( WC()->cart->needs_shipping() && WC()->cart->show_shipping() ) ) {
		izl_cart_progress_row();
	}
}, 5 );

/* ------------------------------------------------------------------ 2.9.0: the Szállítás block in the cart box */

// One "Ingyenes szállítás" only: when a shipping zone holds two Free shipping methods (the shop showed "Free shipping"
// and "Ingyenes szállítás" side by side), the first one stays, under its Hungarian name. Cart and checkout alike.
add_filter( 'woocommerce_package_rates', function ( $rates ) {
	$seen = false;
	foreach ( $rates as $id => $rate ) {
		if ( 'free_shipping' !== $rate->get_method_id() ) {
			continue;
		}
		if ( $seen ) {
			unset( $rates[ $id ] );
			continue;
		}
		$seen = true;
		$rate->set_label( __( 'Free shipping', 'izeltlab' ) );
	}
	return $rates;
}, 50 );

// Each delivery option is a card: its name on the left, its price on the right (izl-sm-n / izl-sm-p, launch.css).
add_filter( 'woocommerce_cart_shipping_method_full_label', function ( $label, $method ) {
	if ( ! is_cart() ) {
		return $label;
	}
	$name = $method->get_label();
	$pre  = $name . ': ';
	if ( 0 === strpos( $label, $pre ) ) {
		return '<span class="izl-sm-n">' . esc_html( $name ) . '</span><span class="izl-sm-p">' . substr( $label, strlen( $pre ) ) . '</span>';
	}
	return '<span class="izl-sm-n">' . $label . '</span>';
}, 20, 2 );

// No address form on the cart (most shops leave it for the checkout); one plain line in its place, also when no
// delivery option exists yet. The options themselves show up in the block on their own once shipping is set up.
add_filter( 'woocommerce_shipping_show_shipping_calculator', function ( $show ) {
	return is_cart() ? false : $show;
} );
function izl_ship_wait_html() {
	return '<span class="izl-ship-wait">' . esc_html__( 'You choose the way of delivery at the checkout.', 'izeltlab' ) . '</span>';
}
add_filter( 'woocommerce_shipping_estimate_html', function ( $html ) {
	return is_cart() ? izl_ship_wait_html() : $html;
} );
add_filter( 'woocommerce_cart_no_shipping_available_html', 'izl_ship_wait_html' );

// Cross-sells sit between the products and the box (phone: under the products; PC: under the table, left column), not
// squeezed into the box's column.
add_action( 'init', function () {
	if ( has_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' ) ) {
		remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );
		add_action( 'woocommerce_before_cart_collaterals', 'woocommerce_cross_sell_display' );
	}
}, 20 );

// 2.2.0: the mini cart under the header cart icon (desktop) shows the same line above its buttons.
add_action( 'woocommerce_widget_shopping_cart_before_buttons', function () {
	echo izl_free_line( 'izl-mini-prog' ); // phpcs:ignore WordPress.Security.EscapeOutput
} );

// 2.2.0: the cart's "Szállítás" box, as in the phone buy box: ÚTRA KELNEK (the day it leaves, yellow van) and NÁLAD
// LESZNEK (the day it arrives, green house) with the little isopod on the road, right above "Proceed to checkout".
// The strictest item of the cart decides (live animals). It replaces the Ízeltláb Bolt plugin's one-line version here.
function izl_cart_route() {
	if ( ! WC()->cart || WC()->cart->is_empty() ) {
		return;
	}
	$type = 'normal';
	foreach ( WC()->cart->get_cart() as $item ) {
		if ( 'live' === izl_ship_type( $item['product_id'] ) ) {
			$type = 'live';
		}
	}
	$plan   = izl_ship_plan( $type );
	$words  = izl_ship_words();
	$labels = izl_ship_labels( $type );
	$when   = 0 === $plan[2] ? $words['today'] : ( 1 === $plan[2] ? $words['tomorrow'] : $words['on'][ (int) $plan[0]->format( 'N' ) ] );
	$still  = '';
	echo '<div class="izl-route izl-cart-route" data-ship="' . esc_attr( $type ) . '"><div class="izl-route-h"><span>' . esc_html( $labels['leaves'] ) . '</span><span>' . esc_html( $labels['arrive'] ) . '</span></div><div class="izl-route-b">';
	echo '<span class="izl-route-v is-out"><span class="izl-route-ic" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M3 7h11v9H3zM14 10h4l3 3v3h-7z"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/></svg></span><span class="izl-route-t">' . esc_html( $when ) . '</span></span>';
	echo '<svg class="izl-route-road" viewBox="0 -2 100 46" aria-hidden="true"><path id="izl-road" d="M4 33 C20 33 34 31 46 24 C60 15 55 4 44 9 C34 14 46 33 66 31 C80 29 90 24 98 20"/>';
	echo '<g class="izl-route-bug"><animateMotion dur="8s" repeatCount="indefinite" rotate="auto"><mpath href="#izl-road"/></animateMotion><ellipse rx="10" ry="6" fill="#17322e"/><path d="M-3.3 -5.9q-2.2 5.9 0 11.8M1.1 -6q-2.2 6 0 12M5.5 -5.2q-1.8 5.2 0 10.4" stroke="#9cc5b8" stroke-width="1.2" fill="none"/><path d="M10 -2q5.4 -3.2 8.6 -5.4M10 2q5.4 3.2 8.6 5.4" stroke="#17322e" stroke-width="1.2" fill="none" stroke-linecap="round"/><path d="M-5.4 -5.7l-1.6 -2.7M0 -6v-3.2M5.4 -5.1l1.6 -2.7M-5.4 5.7l-1.6 2.7M0 6v3.2M5.4 5.1l1.6 2.7" stroke="#17322e" stroke-width="1.2" stroke-linecap="round"/></g></svg>';
	echo '<span class="izl-route-v is-in"><span class="izl-route-t">' . esc_html( izl_arrive_words( $plan[1] ) ) . '</span><span class="izl-route-ic" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M3 11l9-7 9 7M5 10v10h14V10M10 20v-6h4v6"/></svg></span></span></div></div>';
	// reduced motion: the isopod stands still on the road (as on the product page)
	echo '<script>(function(){var b=document.currentScript.previousElementSibling;if(b&&window.matchMedia&&matchMedia("(prefers-reduced-motion: reduce)").matches){var m=b.querySelector("animateMotion");if(m){m.parentNode.setAttribute("transform","translate(46 24) rotate(-30)");m.parentNode.removeChild(m);}}})();</script>';
}
add_action( 'woocommerce_proceed_to_checkout', 'izl_cart_route', 5 );

// 2.7.0: the Pénztár bar pinned to the bottom of a phone screen on the cart page (Dan, 2026-11-07): the cart's sum
// (what counts toward free shipping), one line of the free-shipping progress right above its bar, and a big yellow
// Pénztár button. It sits inside .cart_totals, so the cart's own AJAX refresh (quantity steps, remove) redraws it.
// Hidden from 768px up (launch.css); the PC cart keeps its box.
function izl_cart_dock() {
	if ( ! WC()->cart || WC()->cart->is_empty() ) {
		return;
	}
	$sum  = (float) izl_cart_total();
	$goal = (float) izl_free_ship();
	$left = $goal > 0 ? max( 0, $goal - $sum ) : 0;
	$pct  = $goal > 0 ? max( 3, min( 100, round( $sum / $goal * 100 ) ) ) : 100;
	echo '<div class="izl-dock" role="region" aria-label="' . esc_attr__( 'Checkout', 'izeltlab' ) . '"><div class="izl-dock-in">';
	echo '<span class="izl-dock-sum" aria-live="polite">' . wp_kses_post( wc_price( $sum ) ) . '</span>';
	echo '<a class="button izl-dock-go" href="' . esc_url( wc_get_checkout_url() ) . '">' . esc_html__( 'Checkout →', 'izeltlab' ) . '</a>';
	if ( $goal > 0 ) {
		/* translators: %s: amount still missing, e.g. 2 700 Ft */
		$txt = $left > 0 ? esc_html( sprintf( __( 'Only %s more and it is free!', 'izeltlab' ), html_entity_decode( wp_strip_all_tags( wc_price( $left ) ) ) ) )
			: '<span class="izl-prog-ck" aria-hidden="true">✓</span>' . esc_html__( 'Shipping is free!', 'izeltlab' );
		echo '<p class="izl-dock-ship' . ( $left > 0 ? '' : ' is-done' ) . '">' . $txt . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<span class="izl-dock-bar' . ( $left > 0 ? '' : ' is-done' ) . '" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' . (int) $pct . '"><i style="width:' . (int) $pct . '%"></i></span>';
	}
	echo '</div></div>';
}
add_action( 'woocommerce_after_cart_totals', 'izl_cart_dock', 20 );

// 2.7.0: quantities save themselves (assets/cart.js), so WooCommerce's "Cart updated." and "… removed. Undo?" notes
// would pop up (and scroll the page up) on every tap. Only on those two cart requests; errors still show.
add_action( 'wp_loaded', function () {
	if ( empty( $_POST['update_cart'] ) && empty( $_GET['remove_item'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$removing = ! empty( $_GET['remove_item'] ); // phpcs:ignore WordPress.Security.NonceVerification
	add_filter( 'woocommerce_add_success', function ( $msg ) use ( $removing ) {
		// a remove request adds only the "… removed. Undo?" note; an update only "Cart updated."
		return ( $removing || __( 'Cart updated.', 'woocommerce' ) === $msg ) ? '' : $msg;
	} );
}, 5 );

// 2.7.0: the cart page's script: − / + steppers, saving a quantity without a reload (WooCommerce's own cart AJAX),
// the dock's room at the bottom. The header cart count follows through WooCommerce's cart fragments.
add_action( 'wp_enqueue_scripts', function () {
	if ( ! function_exists( 'is_cart' ) || ! is_cart() ) {
		return;
	}
	wp_enqueue_script( 'izeltlab-cart', get_stylesheet_directory_uri() . '/' . izl_min( 'assets/cart.js' ), array( 'jquery', 'wc-cart' ), IZL_VERSION, true );
	wp_localize_script( 'izeltlab-cart', 'izlCart', array(
		'less'   => __( 'One less', 'izeltlab' ),
		'more'   => __( 'One more', 'izeltlab' ),
		'remove' => __( 'Remove from cart', 'izeltlab' ),
	) );
	if ( wp_script_is( 'wc-cart-fragments', 'registered' ) ) {
		wp_enqueue_script( 'wc-cart-fragments' );
	}
}, 40 );
add_filter( 'izb_cart_ship_line', '__return_false' );

// "Keep browsing": 2.7.0 "Valamit elfelejtettem!" (Dan, 2026-11-07). 2.9.0: on PC a quiet link under the table (left
// column); on a phone a white bubble button at the very end, under "Kosár összesen", so products → total → Pénztár
// reads straight through (launch.css shows one of the two).
function izl_cart_back( $where ) {
	echo '<p class="izl-cart-back is-' . esc_attr( $where ) . '"><a href="' . esc_url( izl_isopods_url() ? izl_isopods_url() : wc_get_page_permalink( 'shop' ) ) . '">' . esc_html__( '← I forgot something!', 'izeltlab' ) . '</a></p>';
}
add_action( 'woocommerce_after_cart_table', function () {
	izl_cart_back( 'pc' );
} );
add_action( 'woocommerce_after_cart', function () {
	izl_cart_back( 'ph' );
}, 5 );

// 2.7.0: the empty cart is one bubble: a little isopod walking on the spot (two 8-bit frames, one step a second),
// "Még nem mászott senki a kosaradba!" and one button back to the isopods (Dan, 2026-11-07). WooCommerce's own
// message box stays in the page but hidden (launch.css): the cart's AJAX looks for it when the last item goes.
add_filter( 'wc_empty_cart_message', function () {
	return __( 'Nobody has crawled into your cart yet!', 'izeltlab' );
} );

function izl_walker_svg() {
	$legs_a = 'M34 66v12M70 66v12M106 66v12';
	$legs_b = 'M52 66v12M88 66v12M122 66v12';
	$up_a   = 'M52 66v6M88 66v6M122 66v6';
	$up_b   = 'M34 66v6M70 66v6M106 66v6';
	return '<svg class="izl-walker" viewBox="0 0 150 86" aria-hidden="true" focusable="false">'
		. '<g class="izl-walker-body"><path class="izl-walker-shell" d="M20 66C20 36 44 22 78 22C112 22 134 38 134 66Z"/>'
		. '<path class="izl-walker-line" d="M54 25Q50 46 54 66M72 22Q68 46 72 66M90 22Q88 46 90 66M108 26Q108 46 110 66"/>'
		. '<circle class="izl-walker-eye" cx="36" cy="50" r="2.6"/>'
		. '<path class="izl-walker-line izl-wf-a" d="M24 48Q12 42 6 32"/><path class="izl-walker-line izl-wf-b" d="M24 48Q12 47 6 41"/></g>'
		. '<g class="izl-wf-a"><path class="izl-walker-line" d="' . $legs_a . '"/><path class="izl-walker-line" d="' . $up_a . '"/></g>'
		. '<g class="izl-wf-b"><path class="izl-walker-line" d="' . $legs_b . '"/><path class="izl-walker-line" d="' . $up_b . '"/></g>'
		. '</svg>';
}

add_action( 'woocommerce_cart_is_empty', function () {
	echo '<div class="izl-empty-cart">' . izl_walker_svg(); // phpcs:ignore WordPress.Security.EscapeOutput
	echo '<p class="izl-empty-title">' . esc_html__( 'Nobody has crawled into your cart yet!', 'izeltlab' ) . '</p>';
	echo '<a class="button izl-empty-go" href="' . esc_url( izl_isopods_url() ? izl_isopods_url() : wc_get_page_permalink( 'shop' ) ) . '">' . esc_html__( 'Back among them!', 'izeltlab' ) . '</a>';
	echo '</div>';
}, 20 );
// WooCommerce's own "Return to shop" button is hidden by launch.css (the two buttons above take its place).

/* ------------------------------------------------------------------ mini cart (desktop, under the header cart icon) */

add_action( 'izl_after_cart_icon', function () {
	if ( ! function_exists( 'woocommerce_mini_cart' ) || is_cart() || is_checkout() ) {
		return;
	}
	echo '<div class="izl-minicart" aria-hidden="true"><div class="izl-minicart-box"><p class="izl-minicart-title">' . esc_html__( 'Cart', 'izeltlab' ) . '</p><div class="widget_shopping_cart_content">';
	woocommerce_mini_cart();
	echo '</div></div></div>';
} );

/* ------------------------------------------------------------------ thank-you page */

// What happens now: the order number stamp, when it sets off, when it arrives, and that a mail comes.
add_action( 'woocommerce_before_thankyou', function ( $order_id ) {
	$order = wc_get_order( $order_id );
	if ( ! $order || $order->has_status( 'failed' ) ) {
		return;
	}
	$type = 'normal';
	foreach ( $order->get_items() as $it ) {
		if ( 'live' === izl_ship_type( $it->get_product_id() ) ) {
			$type = 'live';
		}
	}
	$plan  = izl_ship_plan( $type, $order->get_date_created() ? ( new DateTimeImmutable( '@' . $order->get_date_created()->getTimestamp() ) )->setTimezone( new DateTimeZone( 'Europe/Budapest' ) ) : null );
	$w     = izl_ship_words();
	echo '<div class="izl-thanks"><p class="izl-thanks-stamp">' . esc_html__( 'Thank you!', 'izeltlab' ) . '</p>';
	/* translators: %s: order number */
	echo '<p class="izl-thanks-lead">' . esc_html( sprintf( __( 'Order %s has arrived. We are getting it ready.', 'izeltlab' ), '#' . $order->get_order_number() ) ) . '</p>';
	echo '<ol class="izl-thanks-steps">';
	/* translators: %s: customer email */
	echo '<li><b>' . esc_html__( 'Confirmation', 'izeltlab' ) . '</b><span>' . esc_html( sprintf( __( 'A letter is on its way to %s.', 'izeltlab' ), $order->get_billing_email() ) ) . '</span></li>';
	echo '<li><b>' . esc_html__( 'Sets off', 'izeltlab' ) . '</b><span>' . esc_html( izl_arrive_words( $plan[0] ) ) . '</span></li>';
	echo '<li><b>' . esc_html__( 'With you', 'izeltlab' ) . '</b><span>' . esc_html( izl_arrive_words( $plan[1] ) ) . '</span></li>';
	echo '</ol>';
	if ( 'live' === $type ) {
		echo '<p class="izl-thanks-note">' . esc_html__( 'When the parcel is on its way you get the tracking number. Please take it in soon and open it at room temperature.', 'izeltlab' ) . '</p>';
	}
	echo '</div>';
}, 5 );

/* ------------------------------------------------------------------ footer */

// The pages the footer links to, if they exist (published; drafts only for whoever can edit them).
function izl_footer_links() {
	$out = array();
	$add = function ( $slug, $label ) use ( &$out ) {
		$p = get_page_by_path( $slug, OBJECT, 'page' );
		if ( $p && ( 'publish' === $p->post_status || current_user_can( 'edit_page', $p->ID ) ) ) {
			$out[] = array( $label, get_permalink( $p ), 'publish' !== $p->post_status );
		}
	};
	$add( 'szallitas', __( 'Shipping', 'izeltlab' ) );
	$add( 'erkezesi-garancia', __( 'Arrival guarantee', 'izeltlab' ) );
	$add( 'gyik', __( 'Questions', 'izeltlab' ) );
	$add( 'aszf', __( 'Terms', 'izeltlab' ) );
	$add( 'adatkezeles', __( 'Privacy', 'izeltlab' ) );
	$add( 'elallas', __( 'Withdrawal', 'izeltlab' ) );
	$add( 'panaszkezeles', __( 'Complaints', 'izeltlab' ) );
	$add( 'impresszum', __( 'Imprint', 'izeltlab' ) );
	return $out;
}

add_action( 'storefront_footer', function () {
	$mail = function_exists( 'izb_email' ) ? izb_email() : get_option( 'admin_email' );
	echo '<div class="izl-foot-grid">';
	echo '<div class="izl-foot-brand"><p class="izl-foot-name">' . esc_html( get_bloginfo( 'name' ) ) . '</p><p>' . esc_html__( 'Isopods raised with care in Budapest, sent all over the country.', 'izeltlab' ) . '</p>';
	echo '<p class="izl-foot-mail"><a href="mailto:' . esc_attr( $mail ) . '">' . esc_html( $mail ) . '</a></p></div>';
	$links = izl_footer_links();
	echo '<nav class="izl-foot-links" aria-label="' . esc_attr__( 'Useful pages', 'izeltlab' ) . '"><p class="izl-foot-head">' . esc_html__( 'Good to know', 'izeltlab' ) . '</p><ul>';
	foreach ( $links as $l ) {
		echo '<li><a href="' . esc_url( $l[1] ) . '">' . esc_html( $l[0] ) . '</a>' . ( $l[2] ? ' <small>(' . esc_html__( 'draft', 'izeltlab' ) . ')</small>' : '' ) . '</li>';
	}
	if ( function_exists( 'izb_opt' ) && izb_opt( 'cookie_on' ) ) {
		echo '<li><a href="#" data-izb-cookies>' . esc_html__( 'Cookie settings', 'izeltlab' ) . '</a></li>';
	}
	echo '</ul></nav>';
	echo '<div class="izl-foot-sign">';
	do_action( 'izl_footer_signup' ); // the Ízeltláb Bolt plugin's newsletter form
	echo '</div></div>';
}, 15 );

/* ------------------------------------------------------------------ search with no results */

add_action( 'woocommerce_no_products_found', function () {
	echo '<div class="izl-none"><p>' . esc_html__( 'Nobody by that name lives here. Try another word, or look around:', 'izeltlab' ) . '</p>';
	echo '<p class="izl-empty-btns"><a class="button" href="' . esc_url( izl_isopods_url() ? izl_isopods_url() : wc_get_page_permalink( 'shop' ) ) . '">' . esc_html__( 'Isopods', 'izeltlab' ) . '</a>';
	$sup = izl_supplies_term();
	if ( $sup ) {
		echo '<a class="button is-light" href="' . esc_url( get_term_link( $sup ) ) . '">' . esc_html__( 'Supplies', 'izeltlab' ) . '</a>';
	}
	echo '</p></div>';
}, 20 );

/* ------------------------------------------------------------------ the WordPress login screen */

add_action( 'login_enqueue_scripts', function () {
	wp_enqueue_style( 'izeltlab-fonts', get_stylesheet_directory_uri() . '/' . izl_min( 'assets/fonts.css' ), array(), IZL_VERSION );
	wp_add_inline_style( 'izeltlab-fonts', '
body.login{background:#E9F1EC;font-family:"Izeltlab Sans",system-ui,sans-serif}
.login h1 a{background:none;width:auto;height:auto;text-indent:0;font:700 28px "Izeltlab Mono",monospace;color:#17302E}
.login form{border:2px solid #17302E;border-radius:12px;box-shadow:6px 6px 0 #14605F}
.login input[type=text],.login input[type=password]{border:2px solid #17302E;border-radius:10px}
.wp-core-ui .button-primary{background:#F4D35E;border:2px solid #17302E;border-radius:10px;color:#17302E;box-shadow:0 4px 0 #17302E;text-shadow:none;font-weight:700}
.wp-core-ui .button-primary:hover,.wp-core-ui .button-primary:focus{background:#F4D35E;color:#17302E;border-color:#17302E}
.login #nav a,.login #backtoblog a{color:#14605F}' );
} );
add_filter( 'login_headerurl', function () {
	return home_url( '/' );
} );
add_filter( 'login_headertext', function () {
	return get_bloginfo( 'name' );
} );
