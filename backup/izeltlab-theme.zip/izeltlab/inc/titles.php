<?php
// ==========================================================================
//  FILE: inc/titles.php   (Ízeltláb theme)
//  WHAT: Small text changes: no Storefront credit in the footer, the breadcrumb trail, the shop page title.
//  SEEN: Breadcrumbs and titles on shop pages; the footer.
//  SECTIONS IN THIS FILE:
//    1. Footer
//    2. Page titles
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Footer
// ==========================================================================

// No "Built with WooCommerce" line under the shop: only the copyright stays.
add_filter( 'storefront_credit_link', '__return_false' );

// ==========================================================================
//  Page titles
// ==========================================================================

// The breadcrumb says "Isopods" there too, not "Shop".
add_filter( 'woocommerce_get_breadcrumb', function ( $crumbs ) {
	if ( $crumbs && izl_on_isopods_page() && is_shop() ) {
		$crumbs[ count( $crumbs ) - 1 ][0] = __( 'Isopods', 'izeltlab' );
	}
	return $crumbs;
} );

// 1.7.11: the breadcrumb is a strip under the header (style.css, woocommerce/global/breadcrumb.php), with a bold ›
// between the steps in place of Storefront's slash.
add_filter( 'woocommerce_breadcrumb_defaults', function ( $defaults ) {
	$defaults['delimiter'] = '<span class="izl-crumb-sep" aria-hidden="true">&#8250;</span>';
	return $defaults;
}, 20 );

add_filter( 'woocommerce_page_title', function ( $title ) {
	return izl_on_isopods_page() ? __( 'Isopods', 'izeltlab' ) : $title;
} );
