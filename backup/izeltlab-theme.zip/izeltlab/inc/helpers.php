<?php
// ==========================================================================
//  FILE: inc/helpers.php   (Ízeltláb theme)
//  WHAT: Theme setup and small helpers the other files use: the shop's teal, the isopod list address, the Codex difficulty levels.
//  SEEN: Nothing on its own; other files call these.
//  SECTIONS IN THIS FILE:
//    1. Theme setup: translations and the menu place
//    2. Helpers: colours, the isopod pages, the Codex levels (izl_is_codex() etc. are in inc/shop-core.php)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Theme setup: translations and the menu place
// ==========================================================================

add_action( 'after_setup_theme', function () {
	load_child_theme_textdomain( 'izeltlab', get_stylesheet_directory() . '/languages' );
	register_nav_menus( array( 'izeltlab-main' => 'Main menu (Ízeltláb header)' ) );
} );

// ==========================================================================
//  Helpers: colours, the isopod pages, the Codex levels (izl_is_codex() etc. are in inc/shop-core.php)
// ==========================================================================

// The Codex default colour theme, so the whole shop follows it.
function izl_teal() {
	$c = izl_has_codex() ? sanitize_hex_color( fsz_opt( 'device' ) ) : '';
	return $c ? $c : '#1F8A8A';
}

function izl_dark( $hex ) {
	if ( function_exists( 'fsz_theme_dark' ) ) {
		$d = fsz_theme_dark( $hex );
		if ( $d ) {
			return $d;
		}
	}
	$hex = ltrim( (string) sanitize_hex_color( $hex ), '#' );
	if ( 6 !== strlen( $hex ) ) {
		return '#14605F';
	}
	$out = '#';
	foreach ( str_split( $hex, 2 ) as $c ) {
		$out .= sprintf( '%02X', (int) round( hexdec( $c ) * 0.7 ) );
	}
	return $out;
}

// The "Isopods" page: the one isopod category, or the shop showing only the isopod categories (?izl_view=isopods).
function izl_isopods_url() {
	$terms = izl_isopod_terms();
	if ( ! $terms || ! function_exists( 'wc_get_page_permalink' ) ) {
		return '';
	}
	if ( 1 === count( $terms ) ) {
		$link = get_term_link( $terms[0] );
		return is_wp_error( $link ) ? '' : $link;
	}
	return add_query_arg( 'izl_view', 'isopods', get_post_type_archive_link( 'product' ) );
}

// Every product (the shop page), for the "All products" button on the front page.
function izl_all_products_url() {
	return function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
}

// 1.7.1: the isopod on the front page "Isopods" button: rolled into a ball, it unrolls when the button is pointed at
// (style.css, "rolling isopod"). Seven back plates swing from a ring into an arch; the ball fades as they open.
// The isopod on the "Isopods" button (1.7.6): a rolled-up ball; pointed at, it unrolls (seen from above, facing right)
// and walks in place; it rolls up again after. Without a mouse (phones) it stays open and still.
function izl_bug_icon() {
	echo '<svg class="izl-bug" viewBox="0 0 30 24" aria-hidden="true" focusable="false"><g class="izl-bug-walk">'
		. '<path class="izl-bug-leg is-a is-top" d="M9.0 8.2l-1.1 -1.5"/><path class="izl-bug-leg is-b is-bottom" d="M9.0 15.8l-1.1 1.5"/><path class="izl-bug-leg is-b is-top" d="M11.0 7.5l-1.1 -1.5"/><path class="izl-bug-leg is-a is-bottom" d="M11.0 16.5l-1.1 1.5"/><path class="izl-bug-leg is-a is-top" d="M13.0 7.2l-1.1 -1.5"/><path class="izl-bug-leg is-b is-bottom" d="M13.0 16.8l-1.1 1.5"/><path class="izl-bug-leg is-b is-top" d="M15.0 7.2l-1.1 -1.5"/><path class="izl-bug-leg is-a is-bottom" d="M15.0 16.8l-1.1 1.5"/><path class="izl-bug-leg is-a is-top" d="M17.0 7.5l-1.1 -1.5"/><path class="izl-bug-leg is-b is-bottom" d="M17.0 16.5l-1.1 1.5"/><path class="izl-bug-leg is-b is-top" d="M18.8 8.1l-1.1 -1.5"/><path class="izl-bug-leg is-a is-bottom" d="M18.8 15.9l-1.1 1.5"/><path class="izl-bug-leg is-a is-top" d="M20.4 9.0l-1.1 -1.5"/><path class="izl-bug-leg is-b is-bottom" d="M20.4 15.0l-1.1 1.5"/>'
		. '<path class="izl-bug-line" d="M5.8 11.3L3.2 10.1M5.8 12.7L3.2 13.9M23.6 10.2Q25.8 7.2 29.2 6.6M23.6 13.8Q25.8 16.8 29.2 17.4"/>'
		. '<ellipse class="izl-bug-body" cx="14" cy="12" rx="8.6" ry="5.4"/><path class="izl-bug-band" d="M8.0 8.5Q9.1 12 8.0 15.5M10.1 7.5Q11.2 12 10.1 16.5M12.2 7.1Q13.3 12 12.2 16.9M14.3 7.0Q15.4 12 14.3 17.0M16.4 7.2Q17.5 12 16.4 16.8M18.4 7.7Q19.5 12 18.4 16.3"/><ellipse class="izl-bug-head" cx="22.6" cy="12" rx="1.8" ry="3"/>'
		. '</g><g class="izl-bug-ball"><circle cx="14" cy="12" r="7.4"/><path class="izl-bug-band" d="M8.7 7.1Q11.2 12 8.7 16.9M11.3 5.4Q13.8 12 11.3 18.6M14 4.9Q16.5 12 14 19.1M16.7 5.4Q19.2 12 16.7 18.6M19.3 7.1Q21.8 12 19.3 16.9"/></g></svg>'; // phpcs:ignore WordPress.Security.EscapeOutput -- fixed markup
}

function izl_isopods_view() {
	return isset( $_GET['izl_view'] ) && 'isopods' === $_GET['izl_view'] && count( izl_isopod_terms() ) > 1; // phpcs:ignore WordPress.Security.NonceVerification
}

function izl_on_isopods_page() {
	if ( ! function_exists( 'is_product_category' ) ) {
		return false;
	}
	if ( is_product_category() ) {
		return in_array( get_queried_object()->slug, wp_list_pluck( izl_isopod_terms(), 'slug' ), true );
	}
	return is_shop() && izl_isopods_view();
}

// The shop with ?izl_view=isopods: only the isopod categories (and the ones under them).
add_action( 'woocommerce_product_query', function ( $q ) {
	if ( ! izl_isopods_view() || ! $q->is_main_query() ) {
		return;
	}
	$tax   = (array) $q->get( 'tax_query' );
	$tax[] = array(
		'taxonomy'         => 'product_cat',
		'field'            => 'term_id',
		'terms'            => wp_list_pluck( izl_isopod_terms(), 'term_id' ),
		'include_children' => true,
	);
	$q->set( 'tax_query', $tax );
} );

// The beginner level: species saved up to this difficulty (1-5). Codex 1.47+ shows three levels: 1-2 Beginner,
// 3-4 Intermediate, 5 Expert.
function izl_beginner_level() {
	return (int) apply_filters( 'izl_beginner_level', 2 );
}

// 1.7.14: the Codex level (1 Beginner, 2 Intermediate, 3 Expert) of a saved difficulty, 0 when none is set.
function izl_level( $diff ) {
	if ( function_exists( 'fsz_level' ) ) {
		return fsz_level( $diff );
	}
	$diff = (int) $diff;
	return $diff < 1 ? 0 : ( $diff <= 2 ? 1 : ( $diff <= 4 ? 2 : 3 ) );
}

// The level's word, the same as on the Codex card.
function izl_level_word( $level ) {
	if ( function_exists( 'fsz_levels' ) ) {
		$levels = fsz_levels();
		if ( isset( $levels[ $level ] ) ) {
			return $levels[ $level ]['word'];
		}
	}
	$words = array( 1 => __( 'Beginner', 'izeltlab' ), 2 => __( 'Intermediate', 'izeltlab' ), 3 => __( 'Expert', 'izeltlab' ) );
	return isset( $words[ $level ] ) ? $words[ $level ] : '';
}
