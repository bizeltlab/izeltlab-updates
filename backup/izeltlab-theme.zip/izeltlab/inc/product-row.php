<?php
// ==========================================================================
//  FILE: inc/product-row.php   (Ízeltláb theme)
//  WHAT: Supply product pages and the product row under a product (title, which products, the description, the tag pills).
//  SEEN: Product pages of supplies; the row of tiles under every product.
//  SECTIONS IN THIS FILE:
//    1. Product row, supply pages (reviews off: inc/shop-core.php) (since 1.7.0)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Product row, supply pages (reviews off: inc/shop-core.php) (since 1.7.0)
// ==========================================================================

// The row's title when the product has none of its own: species "Similar species", everything else "You might also need".
// $shop: in the shop's language even when saved from an English dashboard.
function izl_row_default( $product_id, $shop = false ) {
	if ( $shop ) {
		return izl_shop_text( izl_is_codex( $product_id ) ? 'Similar species' : 'You might also need' );
	}
	return izl_is_codex( $product_id ) ? __( 'Similar species', 'izeltlab' ) : __( 'You might also need', 'izeltlab' );
}

// The title over the small-tile row: the product's own (Edit buy box, or Edit on the title itself), else the default.
function izl_row_title() {
	$own = trim( (string) get_post_meta( get_the_ID(), '_izl_row_title', true ) );
	return '' !== $own ? $own : izl_row_default( get_the_ID() );
}

// What the row shows: the product's Upsells (Product data → Linked products → Upsells) first, the rest filled up with
// WooCommerce's own related products (same category or tag), so the row is never half empty.
add_filter( 'woocommerce_related_products', function ( $related, $product_id, $args ) {
	$product = wc_get_product( $product_id );
	$ups     = $product ? array_map( 'absint', $product->get_upsell_ids() ) : array();
	if ( ! $ups ) {
		return $related;
	}
	$limit = isset( $args['limit'] ) && $args['limit'] > 0 ? (int) $args['limit'] : 6;
	$ids   = array_values( array_unique( array_merge( $ups, array_map( 'absint', (array) $related ) ) ) );
	return array_slice( array_diff( $ids, array( (int) $product_id ) ), 0, $limit );
}, 10, 3 );

// Supplies: the description under the buy box, as wide as the buy box, with the product's details (weight, size,
// attributes) under it if it has any.
function izl_description() {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$text  = trim( (string) $product->get_description() );
	$attrs = $product->has_attributes() || $product->has_weight() || $product->has_dimensions();
	if ( '' === $text && ! $attrs ) {
		return;
	}
	echo '<section class="izl-desc"><h2>' . esc_html__( 'Description', 'izeltlab' ) . '</h2>';
	if ( '' !== $text ) {
		echo '<div class="izl-desc-text">' . apply_filters( 'the_content', $text ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- post content
	}
	if ( $attrs ) {
		wc_display_product_attributes( $product );
	}
	echo '</section>';
}

// Supplies: categories and tags as small clickable pills under the photo (instead of "Categories: … Tags: …").
function izl_term_pills() {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$skip  = (int) get_option( 'default_product_cat' ); // "Uncategorized"
	$pills = array();
	foreach ( array( 'product_cat' => '', 'product_tag' => '#' ) as $tax => $mark ) {
		$terms = get_the_terms( $product->get_id(), $tax );
		if ( ! $terms || is_wp_error( $terms ) ) {
			continue;
		}
		foreach ( $terms as $t ) {
			if ( 'product_cat' === $tax && (int) $t->term_id === $skip ) {
				continue;
			}
			$link = get_term_link( $t );
			if ( ! is_wp_error( $link ) ) {
				$pills[] = '<a class="izl-term is-' . ( $mark ? 'tag' : 'cat' ) . '" href="' . esc_url( $link ) . '" rel="tag">' . esc_html( $mark . $t->name ) . '</a>';
			}
		}
	}
	if ( $pills ) {
		echo '<nav class="izl-terms" aria-label="' . esc_attr__( 'Categories and tags', 'izeltlab' ) . '">' . implode( '', $pills ) . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}
