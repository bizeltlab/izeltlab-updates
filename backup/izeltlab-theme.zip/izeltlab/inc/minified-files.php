<?php
// ==========================================================================
//  FILE: inc/minified-files.php   (Ízeltláb theme)
//  WHAT: Picks the small (minified) copy of each stylesheet and script for shoppers, and the readable source when it was edited by hand.
//  SEEN: Every shop page (behind the scenes).
//  SECTIONS IN THIS FILE:
//    1. Minified copies: shoppers get the small built files (and the readable file after a hand edit)
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Minified copies: shoppers get the small built files
// ==========================================================================

// What the build recorded about one source file (assets/min.json): its md5 and size. Null when it is not listed.
function izl_built( $key ) {
	static $map = null;
	if ( null === $map ) {
		$file = get_stylesheet_directory() . '/assets/min.json';
		$map  = is_readable( $file ) ? json_decode( (string) file_get_contents( $file ), true ) : array(); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$map  = is_array( $map ) ? $map : array();
	}
	return isset( $map[ $key ] ) && is_array( $map[ $key ] ) ? $map[ $key ] : null;
}

/**
 * 2.8.0: shoppers get the minified copies of the theme's stylesheets and scripts (no comments, no spaces: about half the
 * size, the same rules and code), built by build/build.js next to their sources (style.min.css, assets/*.min.js,
 * assets/*.min.css). A copy is used only while it was built from the source as it is now (assets/min.json holds each
 * source's md5 and size), so a hand edit to a source is never hidden by an older copy. SCRIPT_DEBUG serves the sources.
 * $rel: the source's path in the theme (e.g. 'assets/product.js'). Returns the path to serve.
 */
function izl_min( $rel ) {
	$map = array( $rel => izl_built( $rel ) );
	if ( ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) || empty( $map[ $rel ]['md5'] ) ) {
		return $rel;
	}
	$dir = get_stylesheet_directory() . '/';
	$min = preg_replace( '/\.(js|css)$/', '.min.$1', $rel );
	if ( ! izl_source_untouched( $rel, $map[ $rel ] ) || ! is_readable( $dir . $min ) ) {
		return $rel;
	}
	return $min;
}

/**
 * Is this source still the file the build saw? 2.11.0: the everyday check is the source's size (the server knows it
 * without opening the file) instead of reading and hashing eleven files on every page.
 * 3.0.0: a hand edit can keep the size (one colour changed to another colour), so the file's change time is remembered
 * too: when it moves, the file is read and fingerprinted once, and the answer is kept (option izl_min_seen) until the
 * file changes again. With WP_DEBUG on, the full md5 check runs every time, as before.
 */
function izl_source_untouched( $rel, $rec ) {
	static $seen = null, $save = false;
	$path = get_stylesheet_directory() . '/' . $rel;
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		return md5_file( $path ) === $rec['md5'];
	}
	if ( (int) @filesize( $path ) !== (int) $rec['size'] ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
		return false;
	}
	if ( null === $seen ) {
		$seen = get_option( 'izl_min_seen', array() );
		$seen = is_array( $seen ) ? $seen : array();
	}
	$time = (int) @filemtime( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	if ( ! isset( $seen[ $rel ][2] ) || $seen[ $rel ][0] !== $time || $seen[ $rel ][1] !== $rec['md5'] ) {
		$seen[ $rel ] = array( $time, $rec['md5'], md5_file( $path ) === $rec['md5'] );
		if ( ! $save ) {
			$save = true;
			add_action( 'shutdown', function () use ( &$seen ) {
				update_option( 'izl_min_seen', $seen, true );
			} );
		}
	}
	return (bool) $seen[ $rel ][2];
}

// 3.0.0: a source that is served as written (edited by hand since the build, or SCRIPT_DEBUG) gets its change time in
// its address, so a browser that kept an older copy fetches the new one after every edit. Built copies keep the plain
// version number.
function izl_edit_stamp( $src ) {
	$base = get_stylesheet_directory_uri() . '/';
	if ( ! is_string( $src ) || 0 !== strpos( $src, $base ) ) {
		return $src;
	}
	$rel = (string) strtok( substr( $src, strlen( $base ) ), '?' );
	if ( null === izl_built( $rel ) ) {
		return $src; // a built copy, or a file the build does not know
	}
	$time = (int) @filemtime( get_stylesheet_directory() . '/' . $rel ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	return $time ? add_query_arg( 'ver', IZL_VERSION . '.' . $time, $src ) : $src;
}
add_filter( 'style_loader_src', 'izl_edit_stamp' );
add_filter( 'script_loader_src', 'izl_edit_stamp' );

// The theme's own style.css (loaded by Storefront as storefront-child-style): its minified copy on the shop side.
add_filter( 'stylesheet_uri', function ( $uri ) {
	if ( is_admin() ) {
		return $uri;
	}
	$min = izl_min( 'style.css' );
	if ( 'style.css' === $min ) {
		return $uri; // style.css was edited by hand since the last build: every page gets it as written
	}
	// 3.0.0: about half of style.css is only for the product page. Every other page gets the built copy without those
	// rules (style.lite.min.css, made by the build from style.css: same rules, same order, the product page's left out).
	// The product page gets the whole stylesheet, as before.
	if ( function_exists( 'is_product' ) && ! is_product() && did_action( 'wp' ) && is_readable( get_stylesheet_directory() . '/style.lite.min.css' ) && apply_filters( 'izl_lite_style', true ) ) {
		return get_stylesheet_directory_uri() . '/style.lite.min.css';
	}
	return get_stylesheet_directory_uri() . '/' . $min;
} );
