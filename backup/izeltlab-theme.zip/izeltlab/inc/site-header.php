<?php
// ==========================================================================
//  FILE: inc/site-header.php   (Ízeltláb theme)
//  WHAT: The top bar: logo, menu, search / account / cart icons and the cart counter.
//  SEEN: The top of every page.
//  SECTIONS IN THIS FILE:
//    1. Header: logo, menu, search / account / cart
// ==========================================================================

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
//  Header: logo, menu, search / account / cart
// ==========================================================================

add_action( 'init', function () {
	remove_action( 'storefront_header', 'storefront_secondary_navigation', 30 );
	remove_action( 'storefront_header', 'storefront_product_search', 40 );
	remove_action( 'storefront_header', 'storefront_header_cart', 60 );
	remove_action( 'storefront_header', 'storefront_primary_navigation_wrapper', 42 );
	remove_action( 'storefront_header', 'storefront_primary_navigation', 50 );
	remove_action( 'storefront_header', 'storefront_primary_navigation_wrapper_close', 68 );
	add_action( 'storefront_header', 'izl_header_nav', 30 );
	add_action( 'storefront_header', 'izl_header_icons', 35 );
	// Sorting and count only above the products, not twice (the page numbers stay below).
	remove_action( 'woocommerce_after_shop_loop', 'woocommerce_catalog_ordering', 10 );
	remove_action( 'woocommerce_after_shop_loop', 'woocommerce_result_count', 20 );
	// Storefront's previous / next product photos, half hidden at the two screen edges: they look like a broken image.
	remove_action( 'woocommerce_after_single_product_summary', 'storefront_single_product_pagination', 30 );
} );

/**
 * The menu: a menu set under Appearance → Menus → "Main menu (Ízeltláb header)" if there is one,
 * otherwise Isopods, Supplies and For beginners, made from the shop's own categories.
 */
function izl_header_nav() {
	echo '<nav class="izl-nav" aria-label="' . esc_attr__( 'Main menu', 'izeltlab' ) . '">';
	if ( has_nav_menu( 'izeltlab-main' ) ) {
		wp_nav_menu( array( 'theme_location' => 'izeltlab-main', 'container' => false, 'depth' => 1, 'fallback_cb' => false ) );
	} else {
		echo '<ul class="menu">';
		foreach ( izl_menu_items() as $item ) {
			echo '<li' . ( $item[2] ? ' class="is-current"' : '' ) . '><a href="' . esc_url( $item[1] ) . '"' . ( $item[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $item[0] ) . '</a></li>';
		}
		echo '</ul>';
	}
	echo '</nav>';
}

// 2.6.0: on phones the top bar has no menu row (the same slim bar on every page); the list pages show the menu links
// under their title instead (style.css .izl-list-menu, hidden on computers, where the header keeps its menu).
add_action( 'woocommerce_archive_description', 'izl_list_menu', 1 );
function izl_list_menu() {
	$items = izl_menu_items();
	if ( ! $items ) {
		return;
	}
	echo '<nav aria-label="' . esc_attr__( 'Main menu', 'izeltlab' ) . '"><ul class="izl-list-menu">';
	foreach ( $items as $item ) {
		echo '<li' . ( $item[2] ? ' class="is-current"' : '' ) . '><a href="' . esc_url( $item[1] ) . '"' . ( $item[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $item[0] ) . '</a></li>';
	}
	echo '</ul></nav>';
}

function izl_menu_items() {
	$items    = array();
	$isopods  = izl_isopods_url();
	$supplies = izl_supplies_term();
	$level    = isset( $_GET['max_difficulty'] ) ? (int) $_GET['max_difficulty'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	// 3.2.0: the shop page's filter (inc/shop-page.php) takes ?nehezseg=1 for Kezdő; "Kezdőknek" opens it with Kezdő on.
	$new      = function_exists( 'izl_sf_on' ) && apply_filters( 'izl_shop_filter', true );
	if ( $new ) {
		$level = isset( $_GET['nehezseg'] ) && 1 === (int) $_GET['nehezseg'] ? izl_beginner_level() : 0; // phpcs:ignore WordPress.Security.NonceVerification
	}
	$on       = izl_on_isopods_page();
	if ( $isopods ) {
		$items[] = array( __( 'Isopods', 'izeltlab' ), $isopods, $on && izl_beginner_level() !== $level );
	}
	if ( $supplies ) {
		$items[] = array( __( 'Supplies', 'izeltlab' ), get_term_link( $supplies ), function_exists( 'is_product_category' ) && is_product_category( IZL_SUPPLIES ) );
	}
	// Needs the Codex difficulty filter (WooCommerce → Codex → "Difficulty filter in the shop").
	if ( $isopods && izl_has_codex() && '1' === fsz_opt( 'filter' ) ) {
		$items[] = array( __( 'For beginners', 'izeltlab' ), $new ? add_query_arg( 'nehezseg', 1, $isopods ) : add_query_arg( 'max_difficulty', izl_beginner_level(), $isopods ), $on && izl_beginner_level() === $level );
	}
	return $items;
}

function izl_icon( $name ) {
	$paths = array(
		'search' => '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
		'user'   => '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>',
		'cart'   => '<path d="M3 5h3l2.5 11h10L21 8H7"/><circle cx="10" cy="20" r="1.4"/><circle cx="17" cy="20" r="1.4"/>',
	);
	return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $paths[ $name ] . '</svg>';
}

// The count on the cart icon. 1.7.18: it carries the cart total too (data-total), so the free-shipping progress on the
// product page knows it right after an add to cart.
function izl_cart_count_html() {
	$n = function_exists( 'WC' ) && WC()->cart ? (int) WC()->cart->get_cart_contents_count() : 0;
	return '<span class="izl-cart-count' . ( $n ? '' : ' is-empty' ) . '" data-total="' . esc_attr( izl_cart_total() ) . '">' . (int) $n . '</span>';
}

function izl_header_icons() {
	if ( ! function_exists( 'wc_get_cart_url' ) ) {
		return;
	}
	echo '<div class="izl-icons">';
	// 2.6.0: opens the search panel under the top bar (inc/finder.php); a plain link to it without JavaScript
	echo '<a class="izl-icon izl-search-btn" href="#izl-sp" role="button" aria-controls="izl-sp" aria-expanded="false" aria-label="' . esc_attr__( 'Search', 'izeltlab' ) . '" title="' . esc_attr__( 'Search', 'izeltlab' ) . '">' . izl_icon( 'search' ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '<a class="izl-icon" href="' . esc_url( wc_get_page_permalink( 'myaccount' ) ) . '" aria-label="' . esc_attr__( 'My account', 'izeltlab' ) . '" title="' . esc_attr__( 'My account', 'izeltlab' ) . '">' . izl_icon( 'user' ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '<a class="izl-icon izl-cart" href="' . esc_url( wc_get_cart_url() ) . '" aria-label="' . esc_attr__( 'Cart', 'izeltlab' ) . '" title="' . esc_attr__( 'Cart', 'izeltlab' ) . '">' . izl_icon( 'cart' ) . izl_cart_count_html() . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	do_action( 'izl_after_cart_icon' ); // 2.1.0: the mini cart (inc/launch.php)
	echo '</div>';
}

// The count on the cart icon follows "add to cart" without a reload.
add_filter( 'woocommerce_add_to_cart_fragments', function ( $fragments ) {
	$fragments['span.izl-cart-count'] = izl_cart_count_html();
	return $fragments;
} );
