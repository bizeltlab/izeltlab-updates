<?php
// ==========================================================================
//  FILE: header.php   (Ízeltláb theme)
//  WHAT: The page skeleton above the content: the <head> and the top bar's frame (Storefront's header.php
//        with small changes).
//  SEEN: The top of every page.
// ==========================================================================

/**
 * The header: Storefront 4.6.1's header.php, word for word, except the viewport line.
 *
 * 2.4.0: viewport-fit=cover. Without it an iPhone turned sideways leaves an empty strip at both sides of every page
 * (the notch's room), and the teal header stopped short of the screen edges. With it the colours reach the edges and
 * style.css keeps the text clear of the notch (env(safe-area-inset-*)).
 *
 * @package izeltlab
 */

?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<link rel="profile" href="http://gmpg.org/xfn/11">
<?php
// 2.11.0: the pingback address is only printed while XML-RPC is on (Bolt's security box turns it off: the link then
// pointed at a switched-off door and told robots where it is).
if ( apply_filters( 'xmlrpc_enabled', true ) ) :
	?>
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php endif; ?>

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<?php wp_body_open(); ?>

<?php do_action( 'storefront_before_site' ); ?>

<div id="page" class="hfeed site">
	<?php do_action( 'storefront_before_header' ); ?>

	<header id="masthead" class="site-header" role="banner" style="<?php storefront_header_styles(); ?>">

		<?php
		/**
		 * Functions hooked into storefront_header action
		 *
		 * @hooked storefront_header_container                 - 0
		 * @hooked storefront_skip_links                       - 5
		 * @hooked storefront_social_icons                     - 10
		 * @hooked storefront_site_branding                    - 20
		 * @hooked storefront_secondary_navigation             - 30
		 * @hooked storefront_product_search                   - 40
		 * @hooked storefront_header_container_close           - 41
		 * @hooked storefront_primary_navigation_wrapper       - 42
		 * @hooked storefront_primary_navigation               - 50
		 * @hooked storefront_header_cart                      - 60
		 * @hooked storefront_primary_navigation_wrapper_close - 68
		 */
		do_action( 'storefront_header' );
		?>

	</header><!-- #masthead -->

	<?php
	/**
	 * Functions hooked in to storefront_before_content
	 *
	 * @hooked storefront_header_widget_region - 10
	 * @hooked woocommerce_breadcrumb - 10
	 */
	do_action( 'storefront_before_content' );
	?>

	<div id="content" class="site-content" tabindex="-1">
		<div class="col-full">

		<?php
		do_action( 'storefront_content_top' );
