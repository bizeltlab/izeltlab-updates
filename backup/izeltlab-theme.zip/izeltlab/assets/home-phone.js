// ==========================================================================
//  FILE: assets/home-phone.js   (Ízeltláb theme)
//  WHAT: The front page on a phone: the title on one line, the cards at the product page's size.
//  SEEN: The front page on phones.
// ==========================================================================

/**
 * 2.4.0: the front page on a phone (under 768px wide), Dan's pick "A": the title, the Codex cards and the two buttons
 * fit on the first screen.
 *
 * - The cards get the product page's size: as wide as the screen allows (screen - 46px, at most 344px) times .86, the
 *   same numbers as the phone product page (style.css --fsz-fit-scale, codex.php fszFitScreen). When the screen is too
 *   short for that, they get just small enough that the buttons under them still show (never under 240px wide).
 * - The title stays on one line: its letters get smaller until it fits (down to 20px); a longer title (Customizer)
 *   that still does not fit wraps onto two lines instead.
 *
 * It is worked out again when the width changes (a phone turned, a window resized), not when only the height changes:
 * Safari's bars folding away while scrolling would otherwise resize the cards under the finger.
 * 3.6.0: worked out in the same frame as the resize (before: 0.12 s later, so the title and the cards caught up a
 * moment after the window changed). The title stays measured here: a CSS-only fit gave 1px other sizes at some widths
 * (the browser rounds the letters' widths differently on each system), and the look must not change.
 */
( function () {
	'use strict';

	var PHONE = window.matchMedia ? window.matchMedia( '(max-width: 767px)' ) : null;
	var U = 440; // the card's width in --fsz-u (codex.css); its height is 750
	var MIN_W = 240, MAX_W = 344, SCALE = 0.86, SIDE = 46;
	var TITLE_MIN = 20; // px

	function devices() {
		return Array.prototype.slice.call( document.querySelectorAll( '.izl-hero-card .fsz-device' ) );
	}

	function title() {
		var h = document.querySelector( '.izl-hero h1' );
		if ( ! h ) {
			return;
		}
		h.style.fontSize = '';
		h.classList.remove( 'is-wrap' );
		if ( ! PHONE || ! PHONE.matches ) {
			return;
		}
		var fs = parseFloat( window.getComputedStyle( h ).fontSize ) || 36;
		while ( h.scrollWidth > h.clientWidth + 1 && fs > TITLE_MIN ) {
			fs -= 1;
			h.style.fontSize = fs + 'px';
		}
		if ( h.scrollWidth > h.clientWidth + 1 ) {
			h.classList.add( 'is-wrap' );
		}
	}

	function cards() {
		var list = devices();
		if ( ! list.length ) {
			return;
		}
		list.forEach( function ( d ) {
			d.style.removeProperty( '--fsz-u' );
		} );
		if ( ! PHONE || ! PHONE.matches ) {
			return;
		}
		var front = document.querySelector( '.izl-hero-card .is-front .fsz-device' ) || list[ 0 ];
		var stage = front.closest( '.izl-carousel' ) || front.closest( '.izl-hero-single' ) || front.parentNode;
		var btns = document.querySelector( '.izl-hero-btns' );
		var W = document.documentElement.clientWidth;
		var w = Math.min( W - SIDE, MAX_W ) * SCALE;
		list.forEach( function ( d ) {
			d.style.setProperty( '--fsz-u', ( w / U ).toFixed( 4 ) + 'px' );
		} );
		// room for the card: the window's height minus what sits above the card and what has to show under it. The card
		// is measured as drawn (its tilt, depth and float make it a little taller than its box), twice, as it moves up
		// a little when it gets smaller.
		var cs = window.getComputedStyle( stage );
		var below = ( parseFloat( cs.paddingBottom ) || 0 ) + ( btns ? btns.offsetHeight + ( parseFloat( window.getComputedStyle( btns ).marginTop ) || 0 ) : 0 ) + 12;
		var stageTop = stage.getBoundingClientRect().top + window.pageYOffset + ( parseFloat( cs.paddingTop ) || 0 );
		for ( var n = 0; n < 2; n++ ) {
			var r = front.getBoundingClientRect();
			if ( ! r.height ) {
				return;
			}
			var top = Math.min( stageTop, r.top + window.pageYOffset );
			var room = window.innerHeight - top - below;
			if ( r.height <= room + 1 ) {
				break;
			}
			w = Math.max( Math.min( MIN_W, w ), w * room / r.height );
			list.forEach( function ( d ) {
				d.style.setProperty( '--fsz-u', ( w / U ).toFixed( 4 ) + 'px' );
			} );
		}
	}

	var lastW = 0;
	function fit( force ) {
		var W = document.documentElement.clientWidth;
		if ( ! force && W === lastW ) {
			return;
		}
		lastW = W;
		title();
		cards();
		// the carousel (carousel.js) places the side cards from the front card's width: let it measure again
		window.dispatchEvent( new window.Event( 'izl:hero-fit' ) );
	}

	function init() {
		fit( true );
		if ( document.fonts && document.fonts.ready ) {
			document.fonts.ready.then( function () {
				fit( true );
			} );
		}
		// 3.6.0: in the same frame as the resize (was 0.12 s later)
		var t = 0;
		window.addEventListener( 'resize', function () {
			window.cancelAnimationFrame( t );
			t = window.requestAnimationFrame( function () {
				fit();
			} );
		} );
		window.addEventListener( 'orientationchange', function () {
			window.setTimeout( function () {
				fit( true );
			}, 250 );
		} );
	}
	// 2.6.0: printed right after the hero (izl_hero_scripts()), so the title and the cards are fitted before the first
	// paint instead of at the end of the page's loading (the title shrank and everything under it moved up 10px).
	if ( document.readyState !== 'loading' || document.querySelector( '.izl-hero h1' ) ) {
		init();
	} else {
		document.addEventListener( 'DOMContentLoaded', init );
	}
}() );
