// ==========================================================================
//  FILE: assets/cart.js   (Ízeltláb theme)
//  WHAT: The cart page: quantity changes without a reload, the pinned Pénztár bar, the free-shipping line.
//  SEEN: The cart page.
// ==========================================================================

/* Ízeltláb cart page (2.7.0, Dan 2026-11-07).
   - Every quantity gets − / + buttons (shown on phones; PC keeps its number box, launch.css).
   - A changed quantity saves itself without a reload: WooCommerce's own cart AJAX (wc-cart) is started by "clicking"
     its hidden "Update cart" button, so the items, the totals and the Pénztár bar are redrawn by WooCommerce.
   - − on 1 is a ✕ and removes the line (WooCommerce's remove link, also AJAX).
   - The page keeps room at the bottom for the pinned Pénztár bar (--izl-dock-h). */
( function ( $ ) {
	'use strict';
	if ( ! $ ) {
		return;
	}
	var T = window.izlCart || {};
	var timer = 0;
	var root = document.documentElement;
	root.classList.add( 'izl-cart-live' ); // launch.css hides the "Update cart" button only when this script runs

	function form() {
		return $( 'form.woocommerce-cart-form' );
	}

	// Ask WooCommerce to save the quantities (after the last tap, 0.45 s), waiting while a save is still running.
	function save( delay ) {
		clearTimeout( timer );
		timer = setTimeout( function () {
			var $f = form();
			if ( ! $f.length ) {
				return;
			}
			if ( $f.is( '.processing' ) || $f.find( '.blockUI' ).length ) {
				save( 250 );
				return;
			}
			var $b = $f.find( ':input[name="update_cart"]' );
			if ( ! $b.length ) {
				return;
			}
			$f.find( ':input[type=submit]' ).removeAttr( 'clicked' );
			$b.prop( 'disabled', false ).attr( 'clicked', 'true' );
			$f.trigger( 'submit' );
		}, delay );
	}

	function minus( $inp ) {
		var min = parseFloat( $inp.attr( 'min' ) );
		return isNaN( min ) || min < 1 ? 1 : min; // below this the − is a ✕
	}

	function paint( $wrap ) {
		var $inp = $wrap.find( 'input.qty' );
		var v = parseFloat( $inp.val() ) || 0;
		var $less = $wrap.find( '.izl-step-less' );
		var gone = v <= minus( $inp );
		$less.toggleClass( 'is-remove', gone ).attr( 'aria-label', gone ? ( T.remove || 'Remove' ) : ( T.less || '−' ) );
		$less.find( 'span' ).text( gone ? '✕' : '−' );
		var max = parseFloat( $inp.attr( 'max' ) );
		$wrap.find( '.izl-step-more' ).prop( 'disabled', ! isNaN( max ) && max > 0 && v >= max );
	}

	function steppers() {
		form().find( '.product-quantity input.qty[type=number]' ).each( function () {
			var $inp = $( this );
			if ( $inp.closest( '.izl-step' ).length ) {
				return;
			}
			$inp.attr( 'inputmode', 'numeric' );
			var $wrap = $inp.closest( '.quantity' ).addClass( 'izl-step' );
			$wrap.find( 'label' ).addClass( 'screen-reader-text' );
			$( '<button type="button" class="izl-step-less"><span aria-hidden="true">−</span></button>' ).insertBefore( $inp );
			$( '<button type="button" class="izl-step-more"><span aria-hidden="true">+</span></button>' ).attr( 'aria-label', T.more || '+' ).insertAfter( $inp );
			paint( $wrap );
		} );
	}

	$( document.body )
		.on( 'click', '.izl-step-less, .izl-step-more', function ( e ) {
			e.preventDefault();
			var $btn = $( this );
			var $wrap = $btn.closest( '.izl-step' );
			var $inp = $wrap.find( 'input.qty' );
			var v = parseFloat( $inp.val() ) || 0;
			var step = parseFloat( $inp.attr( 'step' ) ) || 1;
			if ( $btn.is( '.izl-step-less' ) ) {
				if ( v <= minus( $inp ) ) {
					clearTimeout( timer );
					$btn.closest( 'tr' ).find( '.product-remove a.remove' ).trigger( 'click' );
					return;
				}
				v -= step;
			} else {
				var max = parseFloat( $inp.attr( 'max' ) );
				if ( ! isNaN( max ) && max > 0 && v + step > max ) {
					return;
				}
				v += step;
			}
			$inp.val( v );
			paint( $wrap );
			save( 450 );
		} )
		// typing a number (or PC's own little arrows): save once the typing stops
		.on( 'input change', '.woocommerce-cart-form input.qty', function ( e ) {
			var $wrap = $( this ).closest( '.izl-step' );
			if ( $wrap.length ) {
				paint( $wrap );
			}
			if ( '' === this.value ) {
				return; // still typing
			}
			save( 'change' === e.type ? 150 : 700 );
		} )
		.on( 'updated_wc_div updated_cart_totals wc_cart_emptied', function () {
			steppers();
			room();
		} );

	// room at the bottom of the page for the pinned bar, so the footer's last line is never under it
	var ro = window.ResizeObserver ? new ResizeObserver( function () {
		room();
	} ) : null;
	function room() {
		var d = document.querySelector( '.izl-dock' );
		var h = d && d.offsetParent !== null ? Math.ceil( d.getBoundingClientRect().height ) : 0;
		root.style.setProperty( '--izl-dock-h', h + 'px' );
		if ( ro && d && ! d.izlSeen ) {
			d.izlSeen = true;
			ro.observe( d );
		}
	}
	$( window ).on( 'resize orientationchange', room );

	$( function () {
		steppers();
		room();
	} );
}( window.jQuery ) );
