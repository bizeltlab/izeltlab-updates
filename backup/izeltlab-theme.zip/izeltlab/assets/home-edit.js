// ==========================================================================
//  FILE: assets/home-edit.js   (Ízeltláb theme)
//  WHAT: ADMIN ONLY. The "Edit cards" panel of the front page.
//  SEEN: The front page, for logged-in admins.
// ==========================================================================

/**
 * Front page quick edit (logged-in admins): number of Codex cards, which species each shows, and the back cards'
 * hover effect (1.7.1).
 * Saves through admin-ajax (izl_home_edit) into the Customizer settings, then reloads the page.
 */
( function () {
	'use strict';

	var open = document.querySelector( '.izl-edit-open' );
	var dialog = document.querySelector( '.izl-edit' );
	if ( ! open || ! dialog || ! window.izlHomeEdit ) {
		return;
	}
	var form = dialog.querySelector( 'form' );
	var msg = dialog.querySelector( '.izl-edit-msg' );
	var save = dialog.querySelector( '.izl-edit-save' );

	// Only the card pickers of the chosen number of cards.
	function showCards() {
		var n = parseInt( ( form.querySelector( 'input[name="count"]:checked' ) || {} ).value, 10 ) || 3;
		Array.prototype.forEach.call( form.querySelectorAll( '.izl-edit-card' ), function ( card ) {
			card.hidden = parseInt( card.getAttribute( 'data-card' ), 10 ) > n;
		} );
	}

	// The back cards' float on hover: shown on the cards behind the panel while it is open, as the height is chosen.
	var carousel = document.querySelector( '.izl-carousel' );
	var start = carousel ? carousel.style.getPropertyValue( '--izl-fx' ) : '';
	function showFx() {
		var range = form.querySelector( 'input[name="fx_strength"]' );
		if ( range ) {
			range.parentNode.querySelector( 'output' ).textContent = range.value;
			if ( carousel ) {
				carousel.style.setProperty( '--izl-fx', range.value / 100 );
			}
		}
	}

	open.addEventListener( 'click', function () {
		msg.textContent = '';
		showCards();
		showFx();
		if ( carousel ) {
			carousel.classList.add( 'is-fx-demo' );
		}
		dialog.showModal();
	} );
	dialog.addEventListener( 'close', function () {
		if ( carousel && ! save.disabled ) { // closed without saving: back to the saved height
			carousel.classList.remove( 'is-fx-demo' );
			carousel.style.setProperty( '--izl-fx', start );
		}
	} );
	form.addEventListener( 'change', showCards );
	form.addEventListener( 'input', showFx );
	dialog.addEventListener( 'click', function ( e ) {
		if ( e.target === dialog ) {
			dialog.close(); // a click on the backdrop
		}
	} );

	save.addEventListener( 'click', function () {
		var data = new FormData( form );
		data.append( 'action', 'izl_home_edit' );
		data.append( 'nonce', izlHomeEdit.nonce );
		save.disabled = true;
		msg.textContent = izlHomeEdit.saving;
		fetch( izlHomeEdit.ajax, { method: 'POST', body: data, credentials: 'same-origin' } )
			.then( function ( r ) {
				return r.json();
			} )
			.then( function ( r ) {
				if ( ! r || ! r.success ) {
					throw new Error( 'save' );
				}
				window.location.reload();
			} )
			.catch( function () {
				save.disabled = false;
				msg.textContent = izlHomeEdit.failed;
			} );
	} );
}() );
