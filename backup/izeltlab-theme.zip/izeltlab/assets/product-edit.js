// ==========================================================================
//  FILE: assets/product-edit.js   (Ízeltláb theme)
//  WHAT: EDITORS ONLY. Edit the sales line and pack tip in place, and the buy box editor (price, packs,
//        availability).
//  SEEN: Product pages, only for logged-in editors.
//  SECTIONS IN THIS FILE:
//    1. Saving: one helper with clear error messages
//    2. Editing a text in place (sales line, pack tip, row title)
//    3. The buy box editor dialog
//    4. The toolbar row above the card
// ==========================================================================

/**
 * Product page, EDITORS ONLY: whoever can edit the product edits the sales line and the pack tip in place, and the
 * price, packs and availability in the buy box editor (saved into WooCommerce, then the page reloads). Shoppers never
 * get this file. assets/product.js calls window.izlProductEdit() once the buy box is ready.
 */
( function ( $ ) {
	'use strict';

	var cfg = window.izlProduct || {};

	/* saving (admin): one request helper that always ends with a clear message, never a silent failure */

	// ==========================================================================
	//  Saving: one helper with clear error messages
	// ==========================================================================

	// Sent the same way as the Codex quick edit (fetch + form data, same-origin cookies), which works on every set-up so far.
	function request( data ) {
		var done = $.Deferred(), body = new window.FormData();
		data._ajax_nonce = cfg.edit.nonce;
		Object.keys( data ).forEach( function ( k ) {
			if ( Array.isArray( data[ k ] ) ) {
				data[ k ].forEach( function ( v ) {
					body.append( k + '[]', v );
				} );
			} else {
				body.append( k, data[ k ] );
			}
		} );
		function answer( status, text ) {
			var json = null, at = text.indexOf( '{"success"' );
			if ( at > -1 ) {
				try {
					json = JSON.parse( text.slice( at ) ); // anything a plugin printed before the answer is skipped
				} catch ( e ) {
					json = null;
				}
			}
			if ( json && json.success ) {
				done.resolve( json.data || {} );
			} else if ( json && json.data ) {
				done.reject( String( json.data ) );
			} else if ( '0' === text.trim() ) {
				done.reject( 'Not saved: this address does not see you logged in. Log in again here, then reload the page.' );
			} else if ( '-1' === text.trim() ) {
				done.reject( 'The security check ran out. Reload the page and try again.' );
			} else {
				done.reject( 'Not saved (error ' + status + ( text ? ': ' + text.replace( /<[^>]+>/g, ' ' ).replace( /\s+/g, ' ' ).trim().slice( 0, 140 ) : '' ) + '). Send me this text.' );
			}
		}
		window.fetch( cfg.edit.ajax, { method: 'POST', credentials: 'same-origin', body: body } )
			.then( function ( r ) {
				return r.text().then( function ( t ) {
					answer( r.status, t );
				} );
			} )
			.catch( function ( e ) {
				done.reject( 'Not saved: the site did not answer (' + ( e && e.message ? e.message : 'network' ) + '). Check that you are logged in on this address, then reload.' );
			} );
		return done.promise();
	}

	function showError( after, msg ) {
		var p = after.parentNode.querySelector( '.izl-edit-error' );
		if ( ! p ) {
			p = document.createElement( 'p' );
			p.className = 'izl-edit-error';
			p.setAttribute( 'role', 'alert' );
			after.after( p );
		}
		p.textContent = msg;
	}

	/* sales line and pack tip: Edit → a text box with Save / Cancel, saved without a reload */

	// ==========================================================================
	//  Editing a text in place (sales line, pack tip, row title)
	// ==========================================================================

	function editable( box ) {
		var text = box.querySelector( '.izl-edit-text' ), btn = box.querySelector( '.izl-edit-btn' );
		text.addEventListener( 'click', function () {
			if ( box.classList.contains( 'is-empty' ) ) {
				btn.click();
			}
		} );
		btn.addEventListener( 'click', function ( e ) {
			e.preventDefault();
			var input = document.createElement( 'input' ), save = document.createElement( 'button' ), cancel = document.createElement( 'button' );
			input.type = 'text';
			input.className = 'izl-edit-input';
			input.placeholder = box.getAttribute( 'data-izl-sample' ) || '';
			input.value = box.classList.contains( 'is-empty' ) ? '' : text.textContent;
			input.setAttribute( 'aria-label', { _izl_headline: 'Sales line', _izl_pack_tip: 'Pack tip', _izl_row_title: 'Row title', _izl_name: 'Product name' }[ box.getAttribute( 'data-izl-edit' ) ] || 'Text' );
			save.type = cancel.type = 'button';
			save.className = 'izl-edit-save';
			save.textContent = 'Save';
			cancel.className = 'izl-edit-cancel';
			cancel.textContent = 'Cancel';
			var wrap = document.createElement( 'span' );
			wrap.className = 'izl-edit-form';
			wrap.append( input, save, cancel );
			text.hidden = btn.hidden = true;
			box.appendChild( wrap );
			input.focus();
			function close() {
				wrap.remove();
				if ( box.querySelector( '.izl-edit-error' ) ) {
					box.querySelector( '.izl-edit-error' ).remove();
				}
				text.hidden = btn.hidden = false;
			}
			function send() {
				save.disabled = true;
				request( { action: 'izl_product_text', id: cfg.edit.id, key: box.getAttribute( 'data-izl-edit' ), text: input.value } )
					.done( function ( r ) {
						text.textContent = r.text || box.getAttribute( 'data-izl-sample' ) || '';
						box.classList.toggle( 'is-empty', ! r.text );
						if ( box.izlAdd ) {
							box.izlAdd.hidden = ! r.text ? false : true; // 3.8.0: the "+ Sales line" pill goes once there is one
						}
						if ( '_izl_name' === box.getAttribute( 'data-izl-edit' ) ) {
							document.querySelectorAll( '.product_title' ).forEach( function ( t ) {
								t.textContent = r.text; // 2.0.6: the page's hidden title follows the new name
							} );
						}
						close();
					} )
					.fail( function ( msg ) {
						save.disabled = false;
						showError( wrap, msg );
					} );
			}
			save.addEventListener( 'click', send );
			cancel.addEventListener( 'click', close );
			input.addEventListener( 'keydown', function ( ev ) {
				if ( 'Enter' === ev.key ) {
					ev.preventDefault();
					send();
				} else if ( 'Escape' === ev.key ) {
					close();
				}
			} );
		} );
	}

	/* the title over the small-tile row: Edit next to it, like the sales line (the default comes back when emptied) */

	function rowTitle() {
		var h = document.querySelector( '.related.products > h2' ), json = document.getElementById( 'izl-buybox-data' );
		if ( ! h || ! json ) {
			return;
		}
		var span = document.createElement( 'span' ), btn = document.createElement( 'button' );
		span.className = 'izl-edit-text';
		span.textContent = h.textContent.trim();
		btn.type = 'button';
		btn.className = 'izl-edit-btn';
		btn.textContent = 'Edit';
		h.textContent = '';
		h.append( span, btn );
		h.setAttribute( 'data-izl-edit', '_izl_row_title' );
		h.setAttribute( 'data-izl-sample', JSON.parse( json.textContent ).rowDefault || '' );
		editable( h );
	}

	/* buy box editor (English, like the other admin tools) */

	// ==========================================================================
	//  The buy box editor dialog
	// ==========================================================================

	function esc( t ) {
		return String( t == null ? '' : t ).replace( /&/g, '&amp;' ).replace( /"/g, '&quot;' ).replace( /</g, '&lt;' );
	}

	function money( n, cur ) {
		return Math.round( n ).toString().replace( /\B(?=(\d{3})+(?!\d))/g, ' ' ) + ' ' + cur;
	}

	function buybox() {
		var open = document.querySelector( '.izl-buybox-open' ), json = document.getElementById( 'izl-buybox-data' );
		if ( ! open || ! json || ! cfg.edit ) {
			return;
		}
		var d = JSON.parse( json.textContent );
		var dlg = document.createElement( 'dialog' );
		dlg.className = 'izl-buybox';
		var packs = d.packs ? '<fieldset class="izl-bb-row"><legend>Base pack</legend>' +
			'<label class="izl-bb-inline"><input type="number" id="izl-bb-base" min="1" step="1" value="' + ( d.base || d.groupBase ) + '"> pcs = 1 product</label>' +
			'<p class="izl-bb-help">' + ( d.groupName ? 'Group ' + d.groupName + ': ' + d.groupBase + ' pcs. ' : '' ) + 'Change it here for a rarer species.</p>' +
			( d.groupName ? '<label class="izl-bb-check"><input type="checkbox" id="izl-bb-group"> Make this the default for the whole group ' + d.groupName + '</label>' : '' ) +
			'</fieldset><fieldset class="izl-bb-row"><legend>Packs people can choose</legend><div class="izl-bb-packs">' +
			d.allMults.map( function ( m ) {
				return '<label class="izl-bb-pack"><input type="checkbox" name="izl-bb-mult" value="' + m + '"' + ( d.mults.indexOf( m ) > -1 ? ' checked' : '' ) + '><span data-mult="' + m + '"></span></label>';
			} ).join( '' ) + '</div>' +
			( d.handMade ? '<p class="izl-bb-warn">This product has packs made by hand. Saving replaces them with these.</p>' : '' ) +
			'</fieldset>' : '';
		dlg.innerHTML = '<form method="dialog" class="izl-bb-form"><h2>Buy box</h2>' +
			'<fieldset class="izl-bb-row"><legend>' + ( d.packs ? 'Price of 1 product (the base pack)' : 'Price' ) + '</legend>' +
			'<label class="izl-bb-inline"><input type="number" id="izl-bb-price" min="0" step="1" value="' + d.price + '"> ' + d.currency + '</label>' +
			( d.packs ? '<p class="izl-bb-help">Bigger packs cost the same per piece: 2× and 5× this price.</p>' : '' ) + '</fieldset>' +
			packs +
			'<fieldset class="izl-bb-row"><legend>Available</legend><label class="izl-bb-switch"><input type="checkbox" id="izl-bb-avail"' + ( d.available ? ' checked' : '' ) + '><span></span> <b id="izl-bb-avail-text"></b></label></fieldset>' +
			( d.packs ? '<fieldset class="izl-bb-row"><legend>Running low</legend><label class="izl-bb-switch"><input type="checkbox" id="izl-bb-low"' + ( d.low ? ' checked' : '' ) + '><span></span> <b id="izl-bb-low-text"></b></label></fieldset>' : '' ) +
			'<fieldset class="izl-bb-row"><legend>Shipping</legend><div class="izl-bb-ship">' +
			'<label class="izl-bb-radio"><input type="radio" name="izl-bb-ship" value="live"' + ( 'live' === d.ship ? ' checked' : '' ) + '><span><b>Live animal</b> Ships Monday to Wednesday</span></label>' +
			'<label class="izl-bb-radio"><input type="radio" name="izl-bb-ship" value="normal"' + ( 'live' !== d.ship ? ' checked' : '' ) + '><span><b>Normal product</b> Ships Monday to Friday</span></label></div>' +
			'<p class="izl-bb-help">Ordered before 2 pm on a shipping day: ships the same day, else on the next one. Customers see "today", "tomorrow" or "on Monday", and the expected delivery 1 working day later.</p></fieldset>' +
			( d.canShop ? '<fieldset class="izl-bb-row"><legend>Free shipping over (whole shop)</legend>' +
				'<label class="izl-bb-inline"><input type="number" id="izl-bb-free" min="0" step="1" value="' + esc( d.freeShip ) + '"> ' + d.currency + '</label>' +
				'<p class="izl-bb-help">One amount for every product: the "Free shipping over" line on the ticket and the "Only … more" bar after an add to cart. ' +
				'Saving also sets it as the minimum order amount of WooCommerce\'s Free shipping in every shipping zone, so the checkout agrees. 0 = no line and no bar (WooCommerce is left as it is).</p></fieldset>' : '' ) +
			'<fieldset class="izl-bb-row"><legend>Title of the product row under the page</legend>' +
			'<input type="text" id="izl-bb-row" class="izl-bb-text" maxlength="80" placeholder="' + esc( d.rowDefault ) + '" value="' + esc( d.rowTitle ) + '">' +
			'<p class="izl-bb-help">Empty = "' + esc( d.rowDefault ) + '". The row shows this product\'s Upsells first (Edit product → Linked products), then products from the same category.</p></fieldset>' +
			'<p class="izl-bb-note">Saved into WooCommerce: the product edit screen shows the same.</p>' +
			'<div class="izl-bb-actions"><button type="button" class="izl-bb-cancel">Cancel</button><button type="submit" class="izl-bb-save">Save</button></div></form>';
		document.body.appendChild( dlg );
		var $d = function ( sel ) {
			return dlg.querySelector( sel );
		};
		function refresh() {
			var price = parseFloat( $d( '#izl-bb-price' ).value ) || 0, base = d.packs ? ( parseInt( $d( '#izl-bb-base' ).value, 10 ) || 1 ) : 1;
			dlg.querySelectorAll( '[data-mult]' ).forEach( function ( el ) {
				var m = parseInt( el.getAttribute( 'data-mult' ), 10 );
				el.textContent = ( base * m ) + ' pcs' + ( price ? ' · ' + money( price * m, d.currency ) : '' );
			} );
			$d( '#izl-bb-avail-text' ).textContent = $d( '#izl-bb-avail' ).checked ? 'Yes, people can buy it' : 'No: "Currently unavailable", no cart button';
			if ( $d( '#izl-bb-low' ) ) {
				$d( '#izl-bb-low-text' ).textContent = $d( '#izl-bb-low' ).checked ? 'Yes: the yellow light on the card blinks (while it is available)' : 'No';
			}
		}
		dlg.addEventListener( 'input', refresh );
		refresh();
		open.addEventListener( 'click', function () {
			dlg.showModal();
		} );
		$d( '.izl-bb-cancel' ).addEventListener( 'click', function () {
			dlg.close();
		} );
		$d( 'form' ).addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			var save = $d( '.izl-bb-save' ), mults = [];
			dlg.querySelectorAll( '[name="izl-bb-mult"]:checked' ).forEach( function ( c ) {
				mults.push( c.value );
			} );
			save.disabled = true;
			save.textContent = 'Saving…';
			var row = $d( '#izl-bb-row' ); // sent only when changed here (Edit on the row title may have changed it since)
			var free = $d( '#izl-bb-free' ); // the same: only when changed (it is shop-wide)
			request( $.extend( {
				action: 'izl_buybox_save',
				id: d.id,
				price: $d( '#izl-bb-price' ).value,
				base: d.packs ? $d( '#izl-bb-base' ).value : 0,
				groupDefault: d.packs && $d( '#izl-bb-group' ) && $d( '#izl-bb-group' ).checked ? 1 : 0,
				mults: mults,
				available: $d( '#izl-bb-avail' ).checked ? 1 : 0,
				ship: ( dlg.querySelector( '[name="izl-bb-ship"]:checked' ) || {} ).value || ''
			}, row.value !== row.defaultValue ? { rowTitle: row.value } : {}, $d( '#izl-bb-low' ) ? { low: $d( '#izl-bb-low' ).checked ? 1 : 0 } : {},
				free && free.value !== free.defaultValue ? { freeShip: free.value || 0 } : {} ) ).done( function () {
				window.location.reload();
			} ).fail( function ( msg ) {
				save.disabled = false;
				save.textContent = 'Save';
				showError( $d( '.izl-bb-actions' ), msg );
			} );
		} );
	}

	/* admins: one toolbar row above the card and the buy box ("Edit card", "Edit buy box", the hidden name), so the
	   buy box itself is as tall for an admin as for a customer and the page fits the screen the same way.
	   3.8.0: only on a phone now (where the editor tools are in the drawer); on a computer the tools float over the
	   page (floating() below), so the page is laid out exactly as a customer sees it. */

	// ==========================================================================
	//  The toolbar row above the card (phone)
	// ==========================================================================

	function toolbar() {
		var strip = document.querySelector( '.summary .izl-admin-strip' ), wrap = document.querySelector( 'div.product > .fsz-wrap' );
		if ( ! strip || ! wrap ) {
			return;
		}
		var bar = wrap.parentNode.querySelector( ':scope > .fsz-editbar' );
		if ( bar ) {
			strip.insertBefore( bar, strip.firstChild );
		}
		var link = document.querySelector( '.summary > .edit-link' ); // WordPress's own "Edit" (the product in the dashboard)
		if ( link ) {
			strip.insertBefore( link, strip.querySelector( '.izl-admin-name' ) );
		}
		wrap.parentNode.insertBefore( strip, wrap );
		strip.classList.add( 'is-toolbar' );
		// The admin bar and this toolbar push the card down; give that room back, so the card has the customer's size.
		var adminbar = document.getElementById( 'wpadminbar' ), cs = window.getComputedStyle( strip );
		var extra = strip.offsetHeight + parseFloat( cs.marginTop ) + parseFloat( cs.marginBottom ) + ( adminbar ? adminbar.offsetHeight : 0 );
		extra -= parseFloat( window.getComputedStyle( document.documentElement ).fontSize ); // customers have 1rem of space there instead
		wrap.style.setProperty( '--izl-admin-extra', Math.round( extra ) + 'px' );
		if ( window.fszFit ) {
			window.fszFit();
		}
	}

	// ==========================================================================
	//  3.8.0: computer: the editor tools float over the page
	// ==========================================================================

	/* Nothing an editor sees takes room on the page (Dan, 2026-11-14): "Edit card" floats on the card's top edge,
	   "Edit buy box" and the hidden name just above the buy box, "Edit photos" on the photo, the small "Edit" buttons
	   at the end of their line. A text a customer would not see (an empty sales line or pack tip) is left out of the
	   page, with a "+ Sales line" pill among the floating tools that opens it. WordPress's own Edit link is in the
	   admin bar at the top, as "WooEdit" (inc/edit-buy-box.php). The look: style.css section 45. */
	function holder( el ) {
		if ( el && 'static' === window.getComputedStyle( el ).position ) {
			el.style.position = 'relative';
		}
	}
	function floating() {
		var strip = document.querySelector( '.summary .izl-admin-strip' ), sum = strip && strip.closest( '.summary' );
		if ( ! strip || ! sum ) {
			return;
		}
		document.body.classList.add( 'izl-tools-float' );
		strip.classList.add( 'is-float' );
		holder( sum );
		var wrap = document.querySelector( 'div.product > .fsz-wrap' ), bar = document.querySelector( 'div.product > .fsz-editbar' );
		if ( wrap && bar ) {
			holder( wrap );
			bar.classList.add( 'is-float' );
			wrap.appendChild( bar );
		}
		var names = { _izl_headline: 'Sales line', _izl_pack_tip: 'Pack tip' };
		sum.querySelectorAll( '[data-izl-edit]' ).forEach( function ( box ) {
			var btn = box.querySelector( '.izl-edit-btn' ), key = box.getAttribute( 'data-izl-edit' );
			if ( ! btn || ! names[ key ] || box.closest( '.izl-admin-strip' ) ) {
				return;
			}
			var add = document.createElement( 'button' );
			add.type = 'button';
			add.className = 'izl-add-text';
			add.textContent = '+ ' + names[ key ];
			add.hidden = ! box.classList.contains( 'is-empty' );
			add.addEventListener( 'click', function () {
				btn.click();
			} );
			strip.appendChild( add );
			box.izlAdd = add;
		} );
		var photos = strip.querySelector( '.izl-photos-open' ), gal = document.querySelector( 'div.product .woocommerce-product-gallery' );
		if ( photos && gal ) {
			holder( gal );
			var f = document.createElement( 'div' );
			f.className = 'izl-admin-float';
			f.appendChild( photos );
			gal.appendChild( f );
		}
		if ( wrap ) {
			// the admin bar still pushes the card down: give that room back, so the card has the customer's size
			var adminbar = document.getElementById( 'wpadminbar' );
			wrap.style.setProperty( '--izl-admin-extra', ( adminbar ? adminbar.offsetHeight : 0 ) + 'px' );
			if ( window.fszFit ) {
				window.fszFit();
			}
		}
	}

	window.izlProductEdit = function () {
		document.querySelectorAll( '.summary [data-izl-edit]' ).forEach( editable );
		buybox();
		rowTitle();
		if ( window.matchMedia && window.matchMedia( '(max-width: 767px)' ).matches ) {
			toolbar();
		} else {
			floating();
		}
	};
}( jQuery ) );
