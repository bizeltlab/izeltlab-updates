/**
 * Front page Codex carousel: up to 3 cards on a ring, seen from a little in front.
 * Seen from above the cards sit on a ring: one in front, one on each side, set back, all facing the customer.
 * Every few seconds the ring turns clockwise (seen from above): the front card goes to the left,
 * the right one comes to the front and the left one travels behind to the right. The cards never pass through
 * each other and never turn or change shape, they only slide and shrink evenly, in two steps: first the front card
 * slides left and back, a little past its spot, until it is clear of the right card; then the right card comes forward
 * while the left one settles into its spot behind it. The card travelling round the back stays below both.
 */
( function () {
	'use strict';

	var INTERVAL = 7000; // ms between two turns
	var DURATION = 1300; // ms of one turn (two steps)
	var SIDE_X = 0.4; // side cards: sideways, in card widths
	var SIDE_Z = 0.62; // side cards: how far back, in card widths
	var DIM = 0.45; // brightness of the cards in the back
	// The Firefox engine (Firefox, LibreWolf, other Gecko browsers; 1.7.7): a blur on a card that holds a 3D card
	// lagged there and flashed white boxes, so the back cards are only dimmed, never blurred (style.css .izl-gecko).
	// 1.7.8: during a turn the dimming changes in a few steps, the drift pauses and positions are read before the cards
	// move (each change of a filter makes Firefox redraw the whole 3D card). functions.php sets the class in the head.
	// Chromium browsers say "like Gecko" without the slash, and support neither check, so they are unchanged.
	var GECKO = document.documentElement.classList.contains( 'izl-gecko' ) || /\bGecko\/\d/.test( navigator.userAgent ) || !! ( window.CSS && CSS.supports && CSS.supports( '-moz-orient', 'inline' ) );
	var BLUR = GECKO ? 0 : 1.5; // px
	if ( GECKO ) {
		document.documentElement.classList.add( 'izl-gecko' );
	}
	var OVER = 0.3; // step 1: how far past its side spot the leaving card slides, in card widths
	var STEP_1 = 0.5; // step 1 (the front card steps aside) ends here, as a part of the turn
	var STEP_2 = 0.42; // step 2 (the next card comes forward, the leaving one settles) starts here

	function ease( t ) {
		return t < 0.5 ? 4 * t * t * t : 1 - Math.pow( -2 * t + 2, 3 ) / 2;
	}

	function setup( box ) {
		var slots = Array.prototype.slice.call( box.querySelectorAll( '.izl-slot' ) );
		var n = slots.length;
		if ( n < 2 ) {
			return;
		}
		// Ring places, in degrees: 0 = front, 90 = right side, -90 = left side (180 = straight behind).
		var places = n === 2 ? [ 0, 90 ] : [ 0, 90, -90 ];
		var pos = slots.map( function ( s, i ) {
			return i;
		} );
		var angle = places.slice( 0, n );
		var still = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
		var busy = false, paused = false, timer = 0;

		// The ring follows the card width, so the side cards stay mostly hidden behind the front one.
		function radius() {
			var front = slots[ pos.indexOf( 0 ) ].querySelector( '.fsz-device' );
			return front ? front.offsetWidth : 380;
		}

		function place( slot, x, z, near, zi ) {
			if ( GECKO && near <= 0.999 ) {
				near = Math.round( near * 4 ) / 4; // Firefox: the dimming in quarter steps (the same filter is not redrawn)
			}
			// Every card faces the customer, at rest and while moving; the Codex resting angle and float (codex.css) stay on all of them.
			slot.style.transform = near > 0.999 ? 'none' : 'translate3d(' + x.toFixed( 1 ) + 'px,0,' + z.toFixed( 1 ) + 'px)';
			slot.style.filter = near > 0.999 ? 'none' : 'brightness(' + ( DIM + ( 1 - DIM ) * near ).toFixed( 3 ) + ') saturate(' + ( 0.55 + 0.45 * near ).toFixed( 3 ) + ')' + ( BLUR ? ' blur(' + ( BLUR * ( 1 - near ) ).toFixed( 2 ) + 'px)' : '' );
			slot.style.zIndex = String( zi );
		}

		function overlap( p, q ) {
			var a = p.querySelector( '.fsz-device' ).getBoundingClientRect(), b = q.querySelector( '.fsz-device' ).getBoundingClientRect();
			return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;
		}

		function pairClear( move ) {
			var out = slots[ move.role.indexOf( 'out' ) ], inc = slots[ move.role.indexOf( 'in' ) ];
			return !! ( out && inc && ! overlap( out, inc ) );
		}

		// At rest: a = ring angle per card. During a turn, move = { t: time 0..1, k: eased, role: per card 'out' | 'in' | 'back',
		// side: where the leaving card goes (-1 left, 1 right), swapped: the incoming card is already drawn on top }.
		// The order changes once the two cards no longer cover each other, at the latest when step 2 starts.
		function draw( a, w, move ) {
			// Whether the two cards cover each other, read before they move (no extra layout pass each frame). 2.1.2: in every
			// browser (Chromium read it after the move, which laid the page out again on every frame of a turn). The order
			// only changes while they do not cover each other, so one frame later shows the same.
			var clear = move && ! move.swapped ? pairClear( move ) : false;
			slots.forEach( function ( slot, i ) {
				var role = move ? move.role[ i ] : '';
				var rad = a[ i ] * Math.PI / 180;
				var cos = Math.cos( rad ), sin = Math.sin( rad );
				if ( 'out' === role ) {
					// Step 1: slides aside and back, past its spot, until it is clear of the next card. Step 2: settles into its spot.
					var go = ease( Math.min( 1, move.t / STEP_1 ) ), settle = ease( Math.max( 0, ( move.t - STEP_2 ) / ( 1 - STEP_2 ) ) );
					place( slot, move.side * w * ( SIDE_X * go + OVER * ( go - settle ) ), -SIDE_Z * w * go, 1 - go, move.swapped ? 200 : 300 );
				} else if ( 'in' === role ) {
					// Step 2: comes forward from its side spot to the front, in front of the card that just stepped aside.
					var q = ease( Math.max( 0, ( move.t - STEP_2 ) / ( 1 - STEP_2 ) ) );
					place( slot, -move.side * SIDE_X * w * ( 1 - q ), -SIDE_Z * w * ( 1 - q ), q, move.swapped ? 300 : 200 );
				} else {
					// At rest, and the card travelling round the back (always below the other two).
					place( slot, SIDE_X * w * sin, SIDE_Z * w * ( cos - 1 ), Math.max( 0, cos ), move ? 100 : 100 + Math.round( cos * 50 ) );
				}
			} );
			// The drawing order changes only while the two cards do not cover each other, so nothing ever pops or cuts through.
			if ( move && ! move.swapped ) {
				var out = slots[ move.role.indexOf( 'out' ) ], inc = slots[ move.role.indexOf( 'in' ) ];
				if ( out && inc && ( move.t >= STEP_2 || clear ) ) {
					move.swapped = true;
					out.style.zIndex = '200';
					inc.style.zIndex = '300';
				}
			}
		}

		function settle() {
			slots.forEach( function ( slot, i ) {
				var front = pos[ i ] === 0;
				slot.classList.toggle( 'is-front', front );
				// Not inert: an inert card cannot be clicked, and a click on a back card turns it to the front.
				// Its links and buttons only leave the keyboard order (style.css stops clicks on them).
				if ( front ) {
					slot.removeAttribute( 'aria-hidden' );
				} else {
					slot.setAttribute( 'aria-hidden', 'true' );
				}
				Array.prototype.forEach.call( slot.querySelectorAll( 'a,button,input,select,textarea,[tabindex]' ), function ( el ) {
					if ( front ) {
						if ( el.hasAttribute( 'data-izl-tab' ) ) {
							var was = el.getAttribute( 'data-izl-tab' );
							if ( was ) {
								el.setAttribute( 'tabindex', was );
							} else {
								el.removeAttribute( 'tabindex' );
							}
							el.removeAttribute( 'data-izl-tab' );
						}
					} else if ( ! el.hasAttribute( 'data-izl-tab' ) ) {
						el.setAttribute( 'data-izl-tab', el.getAttribute( 'tabindex' ) || '' );
						el.setAttribute( 'tabindex', '-1' );
					}
				} );
			} );
		}

		// dir -1 = clockwise seen from above (the right card comes to the front), +1 = the other way.
		function turn( dir ) {
			if ( busy ) {
				return;
			}
			var from = angle.slice(), to = [], role = [];
			pos = pos.map( function ( p ) {
				return ( p + dir + n ) % n; // clockwise: one place back in the list (front → left, right → front)
			} );
			slots.forEach( function ( s, i ) {
				var target = places[ pos[ i ] ];
				var delta = ( ( ( target - from[ i ] ) % 360 ) + 360 ) % 360; // 0..359, the way round the other way
				if ( dir < 0 && delta > 0 ) {
					delta -= 360;
				}
				to[ i ] = from[ i ] + delta;
				role[ i ] = Math.abs( from[ i ] % 360 ) < 1 ? 'out' : ( 0 === pos[ i ] ? 'in' : 'back' );
			} );
			// The leaving card goes left on a clockwise turn (seen from above), right on the other.
			var side = dir < 0 ? -1 : 1;
			var r = radius(); // 2.1.2: read before settle() changes the classes, so it needs no fresh layout
			settle();
			if ( still ) {
				angle = to.map( function ( a ) {
					return ( ( a % 360 ) + 360 ) % 360;
				} );
				draw( angle, r );
				return;
			}
			busy = true;
			if ( GECKO ) {
				box.classList.add( 'is-turning' ); // Firefox: the drift pauses for the turn (style.css)
			}
			var start = performance.now();
			var move = { t: 0, k: 0, role: role, side: side, swapped: false };
			function frame( now ) {
				var t = Math.min( 1, ( now - start ) / DURATION ), k = ease( t );
				draw( from.map( function ( a, i ) {
					return a + ( to[ i ] - a ) * k;
				} ), r, t < 1 ? ( move.t = t, move.k = k, move ) : null );
				if ( t < 1 ) {
					window.requestAnimationFrame( frame );
				} else {
					angle = to.map( function ( a ) {
						return ( ( a % 360 ) + 360 ) % 360;
					} );
					busy = false;
					if ( GECKO ) {
						box.classList.remove( 'is-turning' );
					}
				}
			}
			window.requestAnimationFrame( frame );
		}

		function restart() {
			window.clearInterval( timer );
			if ( ! still ) {
				timer = window.setInterval( function () {
					if ( ! paused && ! document.hidden && ! box.classList.contains( 'is-away' ) ) {
						turn( -1 );
					}
				}, INTERVAL );
			}
		}

		// A click on a back card brings it to the front, the short way round.
		slots.forEach( function ( slot, i ) {
			// Back cards stay still under the mouse (no Codex tilt); they float up on hover (style.css), which says they can be clicked.
			slot.addEventListener( 'mousemove', function ( e ) {
				if ( pos[ i ] !== 0 ) {
					e.stopPropagation();
				}
			}, true );
			slot.addEventListener( 'click', function ( e ) {
				if ( pos[ i ] === 0 ) {
					return;
				}
				e.preventDefault();
				turn( pos[ i ] === 1 ? -1 : 1 );
				restart();
			} );
		} );
		// No turning while someone reads or uses the front card.
		box.addEventListener( 'mouseenter', function () {
			paused = true;
		} );
		box.addEventListener( 'mouseleave', function () {
			paused = false;
		} );
		box.addEventListener( 'focusin', function () {
			paused = true;
		} );
		box.addEventListener( 'focusout', function () {
			paused = false;
		} );
		// Out of view (scrolled away): no turning, and the cards' idle drift stops (style.css .is-away), so the page
		// below scrolls without redrawing the 3D cards on every frame.
		if ( 'IntersectionObserver' in window ) {
			new IntersectionObserver( function ( entries ) {
				box.classList.toggle( 'is-away', ! entries[ 0 ].isIntersecting );
			} ).observe( box );
		}
		window.addEventListener( 'resize', function () {
			if ( ! busy ) {
				draw( angle, radius() );
			}
		} );

		box.classList.add( 'is-ready' );
		settle();
		draw( angle, radius() );
		restart();
	}

	function init() {
		Array.prototype.forEach.call( document.querySelectorAll( '.izl-carousel' ), setup );
	}
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
