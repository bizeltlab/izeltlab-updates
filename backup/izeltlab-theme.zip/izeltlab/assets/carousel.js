// ==========================================================================
//  FILE: assets/carousel.js   (Ízeltláb theme)
//  WHAT: The front page's card carousel: the hero cards turn, the one in front is the active one.
//  SEEN: The front page, with more than one hero card.
// ==========================================================================

/**
 * Front page Codex carousel: up to 3 cards on a ring, seen from a little in front.
 * Seen from above the cards sit on a ring: one in front, one on each side, set back, all facing the customer.
 * Every few seconds the ring turns clockwise (seen from above): the front card goes to the left,
 * the right one comes to the front and the left one travels behind to the right. The cards never pass through
 * each other and never turn or change shape, they only slide and shrink evenly, in two steps: first the front card
 * slides left and back, a little past its spot, until it is clear of the right card; then the right card comes forward
 * while the left one settles into its spot behind it. The card travelling round the back stays below both.
 */
( function () {
	'use strict';

	var INTERVAL = 7000; // ms between two turns
	var DURATION = 1300; // ms of one turn (two steps)
	var SIDE_X = 0.4; // side cards: sideways, in card widths
	var SIDE_Z = 0.62; // side cards: how far back, in card widths
	var DIM = 0.45; // brightness of the cards in the back
	// The Firefox engine (Firefox, LibreWolf, other Gecko browsers; 1.7.7): a blur on a card that holds a 3D card
	// lagged there and flashed white boxes, so the back cards are only dimmed, never blurred (style.css .izl-gecko).
	// 1.7.8: during a turn the dimming changes in a few steps, the drift pauses and positions are read before the cards
	// move (each change of a filter makes Firefox redraw the whole 3D card). functions.php sets the class in the head.
	// Chromium browsers say "like Gecko" without the slash, and support neither check, so they are unchanged.
	var GECKO = document.documentElement.classList.contains( 'izl-gecko' ) || /\bGecko\/\d/.test( navigator.userAgent ) || !! ( window.CSS && CSS.supports && CSS.supports( '-moz-orient', 'inline' ) );
	var BLUR = GECKO ? 0 : 1.5; // px
	if ( GECKO ) {
		document.documentElement.classList.add( 'izl-gecko' );
	}
	var OVER = 0.3; // step 1: how far past its side spot the leaving card slides, in card widths
	var STEP_1 = 0.5; // step 1 (the front card steps aside) ends here, as a part of the turn
	var STEP_2 = 0.42; // step 2 (the next card comes forward, the leaving one settles) starts here
	// 2.4.0 phones (under 768px): the back cards sit further back (smaller), and only as far out to the sides as the
	// screen allows, so their outer edges never get cut off. A swipe left or right turns the ring that way.
	var PHONE = window.matchMedia ? window.matchMedia( '(max-width: 767px)' ) : null;
	var PHONE_Z = 1; // phones: how far back the side cards sit, in card widths
	var EDGE = 14; // phones: px kept free between a back card and the screen edge
	var SWIPE = 40; // px: a sideways finger move this long turns the ring

	function ease( t ) {
		return t < 0.5 ? 4 * t * t * t : 1 - Math.pow( -2 * t + 2, 3 ) / 2;
	}

	function setup( box ) {
		var slots = Array.prototype.slice.call( box.querySelectorAll( '.izl-slot' ) );
		var n = slots.length;
		if ( n < 2 ) {
			return;
		}
		// Ring places, in degrees: 0 = front, 90 = right side, -90 = left side (180 = straight behind).
		var places = n === 2 ? [ 0, 90 ] : [ 0, 90, -90 ];
		var pos = slots.map( function ( s, i ) {
			return i;
		} );
		var angle = places.slice( 0, n );
		var still = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
		var busy = false, paused = false, timer = 0;

		// The ring follows the card width, so the side cards stay mostly hidden behind the front one.
		function radius() {
			var front = slots[ pos.indexOf( 0 ) ].querySelector( '.fsz-device' );
			return front ? front.offsetWidth : 380;
		}

		function place( slot, x, z, near, zi ) {
			if ( GECKO && near <= 0.999 ) {
				near = Math.round( near * 4 ) / 4; // Firefox: the dimming in quarter steps (the same filter is not redrawn)
			}
			// Every card faces the customer, at rest and while moving; the Codex resting angle and float (codex.css) stay on all of them.
			slot.style.transform = near > 0.999 ? 'none' : 'translate3d(' + x.toFixed( 1 ) + 'px,0,' + z.toFixed( 1 ) + 'px)';
			slot.style.filter = near > 0.999 ? 'none' : 'brightness(' + ( DIM + ( 1 - DIM ) * near ).toFixed( 3 ) + ') saturate(' + ( 0.55 + 0.45 * near ).toFixed( 3 ) + ')' + ( BLUR ? ' blur(' + ( BLUR * ( 1 - near ) ).toFixed( 2 ) + 'px)' : '' );
			slot.style.zIndex = String( zi );
		}

		// Where the side cards sit, in card widths: [sideways, back]. On a phone 'sideways' is worked out from the room:
		// a card set back by z looks smaller by P / (P + z) (P = the box's perspective), and so does its distance from
		// the middle, so its outer edge is at (x + w / 2) * P / (P + z), which has to stay EDGE px inside the box.
		function geo( w ) {
			if ( ! PHONE || ! PHONE.matches || ! w ) {
				return [ SIDE_X, SIDE_Z ];
			}
			var P = parseFloat( window.getComputedStyle( box ).perspective ) || 1400;
			var s = P / ( P + PHONE_Z * w ), half = box.clientWidth / 2;
			return [ Math.max( 0.12, Math.min( SIDE_X, ( ( half - EDGE ) / s - w / 2 ) / w ) ), PHONE_Z ];
		}

		function overlap( p, q ) {
			var a = p.querySelector( '.fsz-device' ).getBoundingClientRect(), b = q.querySelector( '.fsz-device' ).getBoundingClientRect();
			return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;
		}

		function pairClear( move ) {
			var out = slots[ move.role.indexOf( 'out' ) ], inc = slots[ move.role.indexOf( 'in' ) ];
			return !! ( out && inc && ! overlap( out, inc ) );
		}

		// At rest: a = ring angle per card. During a turn, move = { t: time 0..1, k: eased, role: per card 'out' | 'in' | 'back',
		// side: where the leaving card goes (-1 left, 1 right), swapped: the incoming card is already drawn on top }.
		// The order changes once the two cards no longer cover each other, at the latest when step 2 starts.
		function draw( a, w, move ) {
			// Whether the two cards cover each other, read before they move (no extra layout pass each frame). 2.1.2: in every
			// browser (Chromium read it after the move, which laid the page out again on every frame of a turn). The order
			// only changes while they do not cover each other, so one frame later shows the same.
			var clear = move && ! move.swapped ? pairClear( move ) : false;
			var g = geo( w ), SX = g[ 0 ], SZ = g[ 1 ];
			slots.forEach( function ( slot, i ) {
				var role = move ? move.role[ i ] : '';
				var rad = a[ i ] * Math.PI / 180;
				var cos = Math.cos( rad ), sin = Math.sin( rad );
				if ( 'out' === role ) {
					// Step 1: slides aside and back, past its spot, until it is clear of the next card. Step 2: settles into its spot.
					var go = ease( Math.min( 1, move.t / STEP_1 ) ), settle = ease( Math.max( 0, ( move.t - STEP_2 ) / ( 1 - STEP_2 ) ) );
					place( slot, move.side * w * ( SX * go + OVER * ( go - settle ) ), -SZ * w * go, 1 - go, move.swapped ? 200 : 300 );
				} else if ( 'in' === role ) {
					// Step 2: comes forward from its side spot to the front, in front of the card that just stepped aside.
					var q = ease( Math.max( 0, ( move.t - STEP_2 ) / ( 1 - STEP_2 ) ) );
					place( slot, -move.side * SX * w * ( 1 - q ), -SZ * w * ( 1 - q ), q, move.swapped ? 300 : 200 );
				} else {
					// At rest, and the card travelling round the back (always below the other two).
					place( slot, SX * w * sin, SZ * w * ( cos - 1 ), Math.max( 0, cos ), move ? 100 : 100 + Math.round( cos * 50 ) );
				}
			} );
			// The drawing order changes only while the two cards do not cover each other, so nothing ever pops or cuts through.
			if ( move && ! move.swapped ) {
				var out = slots[ move.role.indexOf( 'out' ) ], inc = slots[ move.role.indexOf( 'in' ) ];
				if ( out && inc && ( move.t >= STEP_2 || clear ) ) {
					move.swapped = true;
					out.style.zIndex = '200';
					inc.style.zIndex = '300';
				}
			}
		}

		function settle() {
			slots.forEach( function ( slot, i ) {
				var front = pos[ i ] === 0;
				slot.classList.toggle( 'is-front', front );
				// Not inert: an inert card cannot be clicked, and a click on a back card turns it to the front.
				// Its links and buttons only leave the keyboard order (style.css stops clicks on them).
				if ( front ) {
					slot.removeAttribute( 'aria-hidden' );
				} else {
					slot.setAttribute( 'aria-hidden', 'true' );
				}
				Array.prototype.forEach.call( slot.querySelectorAll( 'a,button,input,select,textarea,[tabindex]' ), function ( el ) {
					if ( front ) {
						if ( el.hasAttribute( 'data-izl-tab' ) ) {
							var was = el.getAttribute( 'data-izl-tab' );
							if ( was ) {
								el.setAttribute( 'tabindex', was );
							} else {
								el.removeAttribute( 'tabindex' );
							}
							el.removeAttribute( 'data-izl-tab' );
						}
					} else if ( ! el.hasAttribute( 'data-izl-tab' ) ) {
						el.setAttribute( 'data-izl-tab', el.getAttribute( 'tabindex' ) || '' );
						el.setAttribute( 'tabindex', '-1' );
					}
				} );
			} );
		}

		// dir -1 = clockwise seen from above (the right card comes to the front), +1 = the other way.
		function turn( dir ) {
			if ( busy ) {
				return;
			}
			var from = angle.slice(), to = [], role = [];
			pos = pos.map( function ( p ) {
				return ( p + dir + n ) % n; // clockwise: one place back in the list (front → left, right → front)
			} );
			slots.forEach( function ( s, i ) {
				var target = places[ pos[ i ] ];
				var delta = ( ( ( target - from[ i ] ) % 360 ) + 360 ) % 360; // 0..359, the way round the other way
				if ( dir < 0 && delta > 0 ) {
					delta -= 360;
				}
				to[ i ] = from[ i ] + delta;
				role[ i ] = Math.abs( from[ i ] % 360 ) < 1 ? 'out' : ( 0 === pos[ i ] ? 'in' : 'back' );
			} );
			// The leaving card goes left on a clockwise turn (seen from above), right on the other.
			var side = dir < 0 ? -1 : 1;
			var r = radius(); // 2.1.2: read before settle() changes the classes, so it needs no fresh layout
			settle();
			if ( still ) {
				angle = to.map( function ( a ) {
					return ( ( a % 360 ) + 360 ) % 360;
				} );
				draw( angle, r );
				return;
			}
			busy = true;
			if ( GECKO ) {
				box.classList.add( 'is-turning' ); // Firefox: the drift pauses for the turn (style.css)
			}
			var start = performance.now();
			var move = { t: 0, k: 0, role: role, side: side, swapped: false };
			function frame( now ) {
				var t = Math.min( 1, ( now - start ) / DURATION ), k = ease( t );
				draw( from.map( function ( a, i ) {
					return a + ( to[ i ] - a ) * k;
				} ), r, t < 1 ? ( move.t = t, move.k = k, move ) : null );
				if ( t < 1 ) {
					window.requestAnimationFrame( frame );
				} else {
					angle = to.map( function ( a ) {
						return ( ( a % 360 ) + 360 ) % 360;
					} );
					busy = false;
					if ( GECKO ) {
						box.classList.remove( 'is-turning' );
					}
				}
			}
			window.requestAnimationFrame( frame );
		}

		function restart() {
			window.clearInterval( timer );
			if ( ! still ) {
				timer = window.setInterval( function () {
					if ( ! paused && ! document.hidden && ! box.classList.contains( 'is-away' ) ) {
						turn( -1 );
					}
				}, INTERVAL );
			}
		}

		// A click on a back card brings it to the front, the short way round.
		slots.forEach( function ( slot, i ) {
			// Back cards stay still under the mouse (no Codex tilt); they float up on hover (style.css), which says they can be clicked.
			slot.addEventListener( 'mousemove', function ( e ) {
				if ( pos[ i ] !== 0 ) {
					e.stopPropagation();
				}
			}, true );
			slot.addEventListener( 'click', function ( e ) {
				if ( pos[ i ] === 0 ) {
					return;
				}
				e.preventDefault();
				turn( pos[ i ] === 1 ? -1 : 1 );
				restart();
			} );
		} );
		// 2.4.0: a finger swiped sideways over the cards turns the ring the same way: to the left brings the right card
		// to the front, to the right brings the left one. Up and down still scroll the page (style.css touch-action).
		// A swipe that starts on a photo with more photos to show changes the photo instead (Codex), as before.
		var sw = null, swiped = false;
		box.addEventListener( 'pointerdown', function ( e ) {
			sw = null;
			if ( 'mouse' === e.pointerType || ( e.target.closest && e.target.closest( '.fsz-photo[role=button], .fsz-page-more' ) ) ) {
				return;
			}
			sw = [ e.clientX, e.clientY ];
		}, { passive: true } );
		box.addEventListener( 'pointermove', function ( e ) {
			if ( ! sw ) {
				return;
			}
			var dx = e.clientX - sw[ 0 ], dy = e.clientY - sw[ 1 ];
			if ( Math.abs( dy ) > Math.abs( dx ) && Math.abs( dy ) > 12 ) {
				sw = null; // scrolling the page
				return;
			}
			if ( Math.abs( dx ) >= SWIPE && Math.abs( dx ) > Math.abs( dy ) * 1.2 ) {
				sw = null;
				swiped = true;
				turn( dx < 0 ? -1 : 1 );
				restart();
			}
		}, { passive: true } );
		[ 'pointerup', 'pointercancel' ].forEach( function ( n ) {
			box.addEventListener( n, function () {
				sw = null;
			}, { passive: true } );
		} );
		// the tap that ended a swipe opens nothing (capture: before the card's own link, hero-link.js)
		box.addEventListener( 'click', function ( e ) {
			if ( swiped ) {
				swiped = false;
				e.stopPropagation();
				e.preventDefault();
			}
		}, true );
		box.addEventListener( 'pointerdown', function () {
			swiped = false;
		}, { capture: true, passive: true } );

		// No turning while someone reads or uses the front card.
		box.addEventListener( 'mouseenter', function () {
			paused = true;
		} );
		box.addEventListener( 'mouseleave', function () {
			paused = false;
		} );
		box.addEventListener( 'focusin', function () {
			paused = true;
		} );
		box.addEventListener( 'focusout', function () {
			paused = false;
		} );
		// Out of view (scrolled away): no turning, and the cards' idle drift stops (style.css .is-away), so the page
		// below scrolls without redrawing the 3D cards on every frame.
		if ( 'IntersectionObserver' in window ) {
			new IntersectionObserver( function ( entries ) {
				box.classList.toggle( 'is-away', ! entries[ 0 ].isIntersecting );
			} ).observe( box );
		}
		var redraw = function () {
			if ( ! busy ) {
				draw( angle, radius() );
			}
		};
		window.addEventListener( 'resize', redraw );
		window.addEventListener( 'izl:hero-fit', redraw ); // 2.4.0: home-phone.js resized the cards

		box.classList.add( 'is-ready' );
		settle();
		draw( angle, radius() );
		restart();
		together( box );
	}

	// 3.1.0: the cards appear together (Dan, 2026-11-12). Before, the front card showed first and the two behind it a
	// moment later, each when its own photo and the ring were ready. Now the whole carousel stays invisible until every
	// card is ready: its first photo loaded and decoded, the fonts in, the ring placed and the cards set up by codex.js
	// (two frames after that). Then all of them appear at the same moment. The hiding starts in a one-line script right
	// before the carousel (front-page.php: class izl-hero-wait on <html>, style.css), so not even the front card is drawn
	// early; that script also holds the safety stop: after 2 s the cards appear anyway, so a slow photo never leaves the
	// page empty. Without JavaScript nothing is hidden. Codex gives every hero card's first photo the same top priority on
	// this page (front-page.php, filter fsz_high_cards), so they arrive together.
	function show() {
		document.documentElement.classList.remove( 'izl-hero-wait' );
	}
	function together( box ) {
		if ( ! document.documentElement.classList.contains( 'izl-hero-wait' ) ) {
			return;
		}
		var imgs = Array.prototype.slice.call( box.querySelectorAll( '.izl-slot .fsz-slides > img:first-child' ) );
		var left = imgs.length + 1;
		var one = function () {
			left--;
			if ( left > 0 ) {
				return;
			}
			window.requestAnimationFrame( function () {
				window.requestAnimationFrame( show );
			} );
		};
		var decoded = function ( img ) {
			if ( img.decode ) {
				img.decode().then( one, one );
			} else {
				one();
			}
		};
		imgs.forEach( function ( img ) {
			if ( img.complete ) {
				decoded( img );
			} else {
				img.addEventListener( 'load', function () {
					decoded( img );
				}, { once: true } );
				img.addEventListener( 'error', one, { once: true } );
			}
		} );
		if ( document.fonts && document.fonts.ready ) {
			document.fonts.ready.then( one, one );
		} else {
			one();
		}
	}

	function init() {
		Array.prototype.forEach.call( document.querySelectorAll( '.izl-carousel' ), setup );
	}
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
