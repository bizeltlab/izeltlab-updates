// ==========================================================================
//  FILE: assets/shop.js   (Ízeltláb theme)
//  WHAT: The shop page (since 3.2.0): the filter bar works in place, the address and the sort keep the choice, the
//        phone's "Szűrők" panel, Kezdő pointed out on a first visit, the free-shipping line follows the cart.
//  SEEN: The shop and category lists (inc/shop-page.php prints the markup).
//  SECTIONS IN THIS FILE:
//    1. Filter
//    2. Phone panel and first visit
//    3. Free-shipping line
// ==========================================================================

( function () {
	'use strict';

	// ==========================================================================
	//  Filter
	// ==========================================================================

	function filters( bar ) {
		var cfg;
		try {
			cfg = JSON.parse( bar.getAttribute( 'data-cfg' ) );
		} catch ( e ) {
			return;
		}
		var st = { g: cfg.g || '', l: +cfg.l || 0 };
		var tiles = [].slice.call( document.querySelectorAll( 'ul.products > li.izl-tile[data-g]' ) );
		var empty = document.querySelector( '.izl-sf-empty' );
		var list = document.querySelector( '.izl-sf-stage ul.products' );
		var count = document.querySelector( '.izl-sf-stage .woocommerce-result-count' );

		function fits( t, g, l ) {
			return ( ! g || t.getAttribute( 'data-g' ) === g ) && ( ! l || +t.getAttribute( 'data-l' ) === l );
		}
		function many( g, l ) {
			var n = 0;
			tiles.forEach( function ( t ) {
				n += fits( t, g, l ) ? 1 : 0;
			} );
			return n;
		}
		function word( n ) {
			return cfg.fmt.replace( '%s', n );
		}

		// Draw the state: tiles, counts, pressed buttons, the phone bar, the empty note, the address, the sort form.
		function draw() {
			var n = 0;
			tiles.forEach( function ( t ) {
				var on = fits( t, st.g, st.l );
				t.hidden = ! on;
				n += on ? 1 : 0;
			} );
			[].forEach.call( bar.querySelectorAll( '.izl-sf-sw button[data-g]' ), function ( b ) {
				var g = b.getAttribute( 'data-g' ), c = b.querySelector( '.izl-sf-c' );
				b.setAttribute( 'aria-pressed', st.g === g ? 'true' : 'false' );
				b.value = st.g === g ? '' : g;
				if ( c ) {
					c.textContent = many( g, st.l );
				}
			} );
			[].forEach.call( bar.querySelectorAll( '.izl-sf-lv button[data-l]' ), function ( b ) {
				var l = +b.getAttribute( 'data-l' );
				b.setAttribute( 'aria-pressed', st.l === l ? 'true' : 'false' );
				b.value = st.l === l ? '' : l;
			} );
			var chosen = [];
			if ( st.g && cfg.names[ st.g ] ) {
				chosen.push( cfg.names[ st.g ] );
			}
			if ( st.l && cfg.words[ st.l ] ) {
				chosen.push( cfg.words[ st.l ] );
			}
			set( '.izl-sf-sum', chosen.length ? cfg.sumOn.replace( '%s', chosen.join( ' · ' ) ) : cfg.sumOff );
			set( '.izl-sf-n', word( n ) );
			set( '.izl-sf-show', cfg.show.replace( '%s', word( n ) ) );
			var clear = bar.querySelector( '.izl-sf-panel .izl-sf-clear' );
			if ( clear ) {
				if ( chosen.length ) {
					clear.removeAttribute( 'aria-disabled' );
				} else {
					clear.setAttribute( 'aria-disabled', 'true' );
				}
			}
			if ( count ) {
				count.textContent = word( n );
			}
			if ( empty ) {
				empty.hidden = n > 0;
			}
			if ( list ) {
				list.hidden = ! n;
			}
			// The address carries the choice (back from a species shows the same list), and so does the sort form.
			try {
				var u = new URL( location.href );
				u.searchParams.delete( 'max_difficulty' );
				put( u.searchParams, 'csoport', st.g );
				put( u.searchParams, 'nehezseg', st.l || '' );
				history.replaceState( history.state, '', u.toString() );
			} catch ( e ) {}
			[].forEach.call( document.querySelectorAll( 'form.woocommerce-ordering' ), function ( f ) {
				keep( f, 'csoport', st.g );
				keep( f, 'nehezseg', st.l || '' );
			} );
		}
		function set( sel, text ) {
			var el = bar.querySelector( sel );
			if ( el ) {
				el.textContent = text;
			}
		}
		function put( params, k, v ) {
			if ( v ) {
				params.set( k, v );
			} else {
				params.delete( k );
			}
		}
		function keep( form, k, v ) {
			var input = form.querySelector( 'input[name="' + k + '"]' );
			if ( ! v ) {
				if ( input ) {
					input.parentNode.removeChild( input );
				}
				return;
			}
			if ( ! input ) {
				input = document.createElement( 'input' );
				input.type = 'hidden';
				input.name = k;
				form.appendChild( input );
			}
			input.value = v;
		}

		function choose( g, l ) {
			st.g = g;
			st.l = l;
			draw();
			try {
				localStorage.setItem( 'izl_sf_seen', '1' );
			} catch ( e ) {}
			var hint = bar.querySelector( '.is-hint' );
			if ( hint ) {
				hint.classList.remove( 'is-hint' );
			}
			var beg = bar.querySelector( '.izl-sf-beg' );
			if ( beg ) {
				beg.hidden = true;
			}
		}

		bar.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( 'button, a' );
			if ( ! b || ! bar.contains( b ) ) {
				return;
			}
			if ( b.hasAttribute( 'data-g' ) ) {
				e.preventDefault();
				choose( st.g === b.getAttribute( 'data-g' ) ? '' : b.getAttribute( 'data-g' ), st.l );
			} else if ( b.hasAttribute( 'data-l' ) ) {
				e.preventDefault();
				var l = +b.getAttribute( 'data-l' );
				choose( st.g, b.classList.contains( 'izl-sf-beg' ) || st.l !== l ? l : 0 );
			} else if ( b.classList.contains( 'izl-sf-clear' ) ) {
				e.preventDefault();
				choose( '', 0 );
			}
		} );
		if ( empty ) {
			empty.addEventListener( 'click', function ( e ) {
				if ( e.target.closest( '.izl-sf-clear' ) ) {
					e.preventDefault();
					choose( '', 0 );
					bar.scrollIntoView( { block: 'nearest' } );
				}
			} );
		}
		draw();
		phone( bar, st );
	}

	// ==========================================================================
	//  Phone panel and first visit
	// ==========================================================================

	function phone( bar, st ) {
		var open = bar.querySelector( '.izl-sf-open' ), show = bar.querySelector( '.izl-sf-show' );
		function toggle( on ) {
			bar.classList.toggle( 'is-open', on );
			if ( open ) {
				open.setAttribute( 'aria-expanded', on ? 'true' : 'false' );
			}
		}
		if ( open ) {
			open.addEventListener( 'click', function () {
				toggle( ! bar.classList.contains( 'is-open' ) );
			} );
		}
		if ( show ) {
			show.addEventListener( 'click', function () {
				toggle( false );
				var top = bar.getBoundingClientRect().top;
				if ( top < 0 ) {
					bar.scrollIntoView( { block: 'start' } );
				}
				if ( open ) {
					open.focus( { preventScroll: true } );
				}
			} );
		}
		// First visit (nothing chosen yet): Kezdő is pointed out, and phones get a "Kezdőknek" shortcut next to the bar.
		var seen = true;
		try {
			seen = !! localStorage.getItem( 'izl_sf_seen' );
			localStorage.setItem( 'izl_sf_seen', '1' );
		} catch ( e ) {}
		if ( seen || st.g || st.l ) {
			return;
		}
		var beg = bar.querySelector( '.izl-sf-lv button[data-l="1"]' ), chip = bar.querySelector( '.izl-sf-beg' );
		if ( beg ) {
			beg.classList.add( 'is-hint' );
		}
		if ( chip ) {
			chip.hidden = false;
		}
	}

	// ==========================================================================
	//  Free-shipping line
	// ==========================================================================

	// "18 000 Ft felett ingyenes a szállítás" until something is in the cart, then "Még X Ft az ingyenes
	// szállításig", then "Megvan! Ingyenes a szállítás!". The cart total comes from the cart icon (data-total), which
	// WooCommerce refreshes after an add to cart.
	function free( line ) {
		var cfg, text = line.querySelector( '.izl-sf-ft' ), first = text.textContent;
		try {
			cfg = JSON.parse( line.getAttribute( 'data-cfg' ) );
		} catch ( e ) {
			return;
		}
		// Money as the shop writes it: the shop's own "1 000 Ft" with the number swapped.
		function money( n ) {
			var num = Math.round( n ).toString(), one = cfg.one, m = /1(\D?)000/.exec( one ), sep = m ? m[ 1 ] : ' ';
			num = num.replace( /\B(?=(\d{3})+(?!\d))/g, sep );
			return m ? one.replace( m[ 0 ], num ) : num;
		}
		function draw() {
			var c = document.querySelector( '.izl-cart-count' ), total = c ? parseFloat( c.getAttribute( 'data-total' ) ) : 0;
			total = isNaN( total ) ? 0 : total;
			var done = total > 0 && total >= cfg.goal;
			line.classList.toggle( 'is-done', done );
			text.textContent = total <= 0 ? first : ( done ? cfg.done : cfg.more.replace( '%s', money( cfg.goal - total ) ) );
		}
		draw();
		if ( window.jQuery ) {
			window.jQuery( document.body ).on( 'added_to_cart removed_from_cart wc_fragments_refreshed wc_fragments_loaded', function () {
				setTimeout( draw, 0 );
			} );
		}
	}

	function start() {
		var bar = document.querySelector( '.izl-sf' ), line = document.querySelector( '.izl-sf-free' );
		if ( bar ) {
			filters( bar );
		}
		if ( line ) {
			free( line );
		}
	}
	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', start );
	} else {
		start();
	}
}() );
