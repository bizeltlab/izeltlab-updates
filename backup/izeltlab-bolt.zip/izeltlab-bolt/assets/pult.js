// ==========================================================================
//  FILE: assets/pult.js   (Ízeltláb Bolt plugin)
//  WHAT: STAFF ONLY. The order desk ("Rendelés-pult"): today's orders to pack and ship. 1.18.0 (Dan, 2026-11-24): tabs
//        Küldésre vár (with the pick list folded in) / Elküldve (last 14 days) / Készlet (every product, − / +); on PC
//        the window can be dragged by its header and resized from every edge and corner (remembered on this device,
//        double-click the header to reset); phones show it full screen; the browser tab says "(N) Rendelés".
//  SEEN: The pill in the corner for staff; the secret phone page.
//  SECTIONS IN THIS FILE:
//    1. Helpers and loading the data
//    2. Building
//    3. Drawing
//    4. Moving and resizing (1.18.0)
//    5. Start
// ==========================================================================

/* Ízeltláb Bolt 1.2.0: the order desk ("Rendelés-pult"). A pill in a corner for shop managers (logged in), or the whole
   panel on the private phone page. Data from admin-ajax (izb_pult / izb_pult_t), refreshed every minute while the tab
   is visible. No jQuery. */
( function () {
	'use strict';
	var C = window.izbPult;
	if ( ! C || ! window.fetch ) {
		return;
	}
	var T = C.txt, PAGE = 'page' === C.mode;
	var data = null, isOpen = PAGE, tab = 'todo', got = 0, lastId = null, openIds = {}, shipIds = {}, busy = false;
	var pill, panel, body, head, baseTitle = document.title;

	// ==========================================================================
	//  Helpers and loading the data
	// ==========================================================================

	function el( tag, cls, text ) {
		var n = document.createElement( tag );
		if ( cls ) {
			n.className = cls;
		}
		if ( null != text ) {
			n.textContent = text;
		}
		return n;
	}
	function icon( d ) {
		var s = document.createElementNS( 'http://www.w3.org/2000/svg', 'svg' );
		s.setAttribute( 'viewBox', '0 0 24 24' );
		s.setAttribute( 'aria-hidden', 'true' );
		s.innerHTML = d;
		return s;
	}
	var IC = {
		box: '<path d="M3 8l9-5 9 5v8l-9 5-9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
		x: '<path d="M6 6l12 12M18 6L6 18"/>',
		re: '<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 5v6h-6"/>',
		clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'
	};

	function req( action, params ) {
		var fd = new FormData();
		fd.append( 'action', action );
		if ( PAGE ) {
			fd.append( 'k', C.token );
		} else {
			fd.append( 'nonce', C.nonce );
		}
		Object.keys( params || {} ).forEach( function ( k ) {
			fd.append( k, params[ k ] );
		} );
		return fetch( C.ajax, { method: 'POST', body: fd, credentials: 'same-origin', cache: 'no-store' } ).then( function ( r ) {
			return r.json();
		} ).then( function ( r ) {
			if ( ! r || ! r.success ) {
				throw new Error( 'fail' );
			}
			return r.data;
		} );
	}

	function load() {
		if ( busy ) {
			return;
		}
		busy = true;
		if ( panel ) {
			panel.classList.add( 'is-busy' );
		}
		req( PAGE ? 'izb_pult_t' : 'izb_pult' ).then( function ( d ) {
			var fresh = d.latest && lastId !== null && d.latest.id > lastId;
			lastId = d.latest ? d.latest.id : 0;
			data = d;
			got = Date.now();
			render();
			if ( fresh ) {
				ding();
			}
		} ).catch( function () {
			if ( body && ! data ) {
				body.textContent = T.error;
			}
		} ).then( function () {
			busy = false;
			if ( panel ) {
				panel.classList.remove( 'is-busy' );
			}
		} );
	}

	// A new order since the last look: the pill hops (and beeps, if that is switched on).
	function ding() {
		if ( pill ) {
			pill.classList.remove( 'is-new' );
			void pill.offsetWidth;
			pill.classList.add( 'is-new' );
			pill.setAttribute( 'title', T.newOrder );
		}
		if ( C.sound && window.AudioContext ) {
			try {
				var a = new window.AudioContext(), o = a.createOscillator(), g = a.createGain();
				o.frequency.value = 880;
				g.gain.setValueAtTime( 0.12, a.currentTime );
				g.gain.exponentialRampToValueAtTime( 0.001, a.currentTime + 0.5 );
				o.connect( g ).connect( a.destination );
				o.start();
				o.stop( a.currentTime + 0.5 );
			} catch ( e ) {}
		}
	}

	// ==========================================================================
	//  Building
	// ==========================================================================

	function build() {
		panel = el( 'section', 'izb-pult-panel' );
		panel.setAttribute( 'aria-label', T.title );
		head = el( 'header', 'izb-pult-head' );
		var h = el( 'p', 'izb-pult-h' );
		h.appendChild( icon( IC.box ) );
		h.appendChild( el( 'span', '', T.title ) );
		head.appendChild( h );
		head.appendChild( el( 'p', 'izb-pult-stats' ) );
		var re = el( 'button', 'izb-pult-ic izb-pult-re' );
		re.type = 'button';
		re.title = T.refresh;
		re.setAttribute( 'aria-label', T.refresh );
		re.appendChild( icon( IC.re ) );
		re.addEventListener( 'click', load );
		head.appendChild( re );
		if ( ! PAGE ) {
			var x = el( 'button', 'izb-pult-ic izb-pult-x' );
			x.type = 'button';
			x.setAttribute( 'aria-label', T.close );
			x.appendChild( icon( IC.x ) );
			x.addEventListener( 'click', function () {
				toggle( false );
			} );
			head.appendChild( x );
		}
		panel.appendChild( head );
		panel.appendChild( el( 'div', 'izb-pult-cut' ) );
		panel.appendChild( el( 'p', 'izb-pult-warn' ) );
		var tabs = el( 'div', 'izb-pult-tabs' );
		tabs.setAttribute( 'role', 'tablist' );
		[ [ 'todo', T.todo ], [ 'sent', T.sent ], [ 'stock', T.stock ] ].forEach( function ( t ) {
			var b = el( 'button', 'izb-pult-tab' );
			b.type = 'button';
			b.setAttribute( 'role', 'tab' );
			b.setAttribute( 'data-tab', t[ 0 ] );
			b.appendChild( el( 'span', '', t[ 1 ] ) );
			b.appendChild( el( 'b', 'izb-pult-n' ) );
			b.addEventListener( 'click', function () {
				tab = t[ 0 ];
				render();
			} );
			tabs.appendChild( b );
		} );
		panel.appendChild( tabs );
		body = el( 'div', 'izb-pult-body' );
		panel.appendChild( body );
		if ( PAGE ) {
			panel.appendChild( el( 'p', 'izb-pult-ro', T.readonly ) );
		}

		if ( PAGE ) {
			( document.getElementById( 'izb-pult-root' ) || document.body ).appendChild( panel );
			return;
		}
		mover();
		var wrap = el( 'div', 'izb-pult is-c-' + ( C.corner || 'br' ) );
		pill = el( 'button', 'izb-pult-pill' );
		pill.type = 'button';
		pill.setAttribute( 'aria-expanded', 'false' );
		pill.setAttribute( 'aria-label', T.open );
		pill.appendChild( icon( IC.box ) );
		pill.appendChild( el( 'b', 'izb-pult-pn', '·' ) );
		pill.appendChild( el( 'span', 'izb-pult-pp' ) );
		pill.appendChild( el( 'span', 'izb-pult-pc' ) );
		pill.addEventListener( 'click', function () {
			toggle( ! isOpen );
		} );
		panel.hidden = true;
		wrap.appendChild( panel );
		wrap.appendChild( pill );
		document.body.appendChild( wrap );
		document.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key && isOpen ) {
				toggle( false );
				pill.focus();
			}
		} );
	}

	function toggle( v ) {
		isOpen = v;
		panel.hidden = ! v;
		if ( v ) {
			place( readBox() );
		}
		pill.setAttribute( 'aria-expanded', v ? 'true' : 'false' );
		pill.classList.toggle( 'is-open', v );
		pill.classList.remove( 'is-new' );
		if ( v && ( ! data || Date.now() - got > 20000 ) ) {
			load();
		}
	}

	// ==========================================================================
	//  Drawing
	// ==========================================================================

	function left() {
		if ( ! data || ! data.cut ) {
			return 0;
		}
		return Math.max( 0, data.cut.left - Math.round( ( Date.now() - got ) / 1000 ) );
	}
	function hm( s ) {
		var h = Math.floor( s / 3600 ), m = Math.floor( ( s % 3600 ) / 60 );
		return h ? h + ' ' + T.hour + ' ' + m + ' ' + T.min : m + ' ' + T.min;
	}

	function clock() {
		if ( ! data ) {
			return;
		}
		var s = left(), cut = panel.querySelector( '.izb-pult-cut' );
		cut.textContent = '';
		cut.className = 'izb-pult-cut';
		if ( s > 0 ) {
			cut.appendChild( icon( IC.clock ) );
			cut.appendChild( el( 'span', '', T.cutoff + ' ' ) );
			cut.appendChild( el( 'b', '', hm( s ) ) );
			var bar = el( 'i', 'izb-pult-cutbar' );
			bar.style.width = Math.max( 2, Math.min( 100, s / ( 6 * 3600 ) * 100 ) ) + '%'; // the last 6 hours before 14:00
			cut.appendChild( bar );
			cut.classList.toggle( 'is-hot', s < 1800 );
		} else {
			cut.appendChild( el( 'span', '', data.cut.ship ? T.closed : T.noship ) );
			cut.classList.add( 'is-off' );
		}
		if ( pill ) {
			var pc = pill.querySelector( '.izb-pult-pc' ), todayN = data.todo.filter( function ( o ) {
				return ! o.packed && ( 'today' === o.outk || 'late' === o.outk );
			} ).length;
			pc.textContent = s > 0 && todayN ? hm( s ) : '';
			pc.hidden = ! pc.textContent;
			pill.classList.toggle( 'is-hot', s > 0 && s < 1800 && todayN > 0 );
		}
	}

	function render() {
		if ( ! data ) {
			return;
		}
		var todo = data.todo, waiting = todo.filter( function ( o ) {
			return ! o.packed;
		} ).length;
		if ( pill ) {
			pill.querySelector( '.izb-pult-pn' ).textContent = String( todo.length );
			pill.classList.toggle( 'is-zero', ! todo.length );
			pill.querySelector( '.izb-pult-pp' ).textContent = data.latest ? data.latest.total : '';
			pill.title = data.latest ? '#' + data.latest.num + ' · ' + data.latest.name + ' · ' + data.latest.total : T.title;
		}
		head.querySelector( '.izb-pult-stats' ).textContent = T.today + ': ' + data.today.n + ' ' + T.orders + ' · ' + data.today.sum + ' · ' + data.now;
		var warn = panel.querySelector( '.izb-pult-warn' );
		warn.textContent = data.backup ? '⚠ ' + T.backup : '';
		warn.hidden = ! data.backup;
		var n = {
			todo: waiting,
			sent: 0,
			stock: data.stock.out.length + data.stock.low.length
		};
		// 1.18.0: the browser tab shows the orders waiting, "(2) Rendelés · …" (staff only; the phone page too)
		document.title = todo.length ? '(' + todo.length + ') ' + T.tabTitle + ' · ' + baseTitle : baseTitle;
		panel.querySelectorAll( '.izb-pult-tab' ).forEach( function ( b ) {
			var k = b.getAttribute( 'data-tab' );
			b.setAttribute( 'aria-selected', k === tab ? 'true' : 'false' );
			b.querySelector( '.izb-pult-n' ).textContent = n[ k ] ? String( n[ k ] ) : '';
		} );
		var keep = body.scrollTop;
		body.textContent = '';
		( { todo: drawTodo, sent: drawSent, stock: drawStock } )[ tab ]();
		body.scrollTop = keep;
		clock();
	}

	function drawTodo() {
		if ( ! data.todo.length ) {
			body.appendChild( el( 'p', 'izb-pult-empty', T.none ) );
			return;
		}
		drawPick();
		data.todo.forEach( function ( o ) {
			body.appendChild( card( o ) );
		} );
	}

	function ticks( id ) {
		try {
			return JSON.parse( localStorage.getItem( 'izb_pick_' + id ) || '[]' );
		} catch ( e ) {
			return [];
		}
	}
	function setTicks( id, list ) {
		try {
			localStorage.setItem( 'izb_pick_' + id, JSON.stringify( list ) );
		} catch ( e ) {}
	}

	function card( o ) {
		var d = el( 'details', 'izb-o' + ( o.packed ? ' is-packed' : '' ) + ( o.live ? ' is-live' : '' ) );
		d.open = !! openIds[ o.id ];
		d.addEventListener( 'toggle', function () {
			openIds[ o.id ] = d.open;
		} );
		var s = el( 'summary', 'izb-o-sum' );
		s.appendChild( el( 'span', 'izb-o-num', '#' + o.num ) );
		s.appendChild( el( 'span', 'izb-o-name', o.name ) );
		s.appendChild( el( 'span', 'izb-o-tot', o.total ) );
		var tag = el( 'span', 'izb-o-out is-' + ( o.outk || 'none' ), o.packed ? '✓ ' + T.packed : ( o.out ? T.ships + ': ' + o.out : o.status ) );
		s.appendChild( tag );
		d.appendChild( s );

		var b = el( 'div', 'izb-o-body' );
		// what to pick, with tick boxes (kept on this device only)
		b.appendChild( el( 'p', 'izb-o-h', T.items ) );
		var ul = el( 'ul', 'izb-o-items' ), done = ticks( o.id );
		o.items.forEach( function ( it ) {
			var li = el( 'li' ), lab = el( 'label' ), cb = el( 'input' );
			cb.type = 'checkbox';
			cb.checked = done.indexOf( it.id ) >= 0;
			cb.addEventListener( 'change', function () {
				var list = ticks( o.id ).filter( function ( x ) {
					return x !== it.id;
				} );
				if ( cb.checked ) {
					list.push( it.id );
				}
				setTicks( o.id, list );
				li.classList.toggle( 'is-ticked', cb.checked );
			} );
			li.classList.toggle( 'is-ticked', cb.checked );
			lab.appendChild( cb );
			lab.appendChild( el( 'b', 'izb-o-q', it.qty + '×' ) );
			lab.appendChild( el( 'span', '', it.name ) );
			if ( it.meta ) {
				lab.appendChild( el( 'small', '', it.meta ) );
			}
			if ( it.live ) {
				lab.appendChild( el( 'em', 'izb-o-live', T.live ) );
			}
			li.appendChild( lab );
			ul.appendChild( li );
		} );
		b.appendChild( ul );

		// where it goes
		b.appendChild( el( 'p', 'izb-o-h', T.to ) );
		var ad = el( 'div', 'izb-o-addr' ), lines = [ o.name ].concat( o.company ? [ o.company ] : [], o.addr );
		lines.forEach( function ( l, i ) {
			ad.appendChild( el( i ? 'span' : 'b', '', l ) );
		} );
		var cp = el( 'button', 'izb-pult-mini', T.copy );
		cp.type = 'button';
		cp.addEventListener( 'click', function () {
			var txt = lines.concat( o.phone ? [ o.phone ] : [] ).join( '\n' );
			( navigator.clipboard ? navigator.clipboard.writeText( txt ) : Promise.reject() ).then( function () {
				cp.textContent = T.copied;
				setTimeout( function () {
					cp.textContent = T.copy;
				}, 1500 );
			} ).catch( function () {} );
		} );
		ad.appendChild( cp );
		b.appendChild( ad );
		var facts = el( 'dl', 'izb-o-facts' );
		function fact( k, v, href ) {
			if ( ! v ) {
				return;
			}
			facts.appendChild( el( 'dt', '', k ) );
			var dd = el( 'dd' );
			if ( href ) {
				var a = el( 'a', '', v );
				a.href = href;
				dd.appendChild( a );
			} else {
				dd.textContent = v;
			}
			facts.appendChild( dd );
		}
		fact( T.carrier, o.method );
		if ( C.show.phone ) {
			fact( '☎', o.phone, 'tel:' + String( o.phone ).replace( /[^\d+]/g, '' ) );
		}
		if ( C.show.email ) {
			fact( '@', o.email, 'mailto:' + o.email );
		}
		if ( C.show.pay ) {
			fact( T.pay, o.pay );
		}
		fact( '', o.when + ' · ' + o.status );
		b.appendChild( facts );
		if ( C.show.note && o.note ) {
			b.appendChild( el( 'p', 'izb-o-note', T.note + ': ' + o.note ) );
		}

		// buttons
		var row = el( 'div', 'izb-o-btns' );
		if ( ! PAGE ) {
			var pk = el( 'button', 'izb-pult-btn' + ( o.packed ? ' is-on' : '' ), o.packed ? '✓ ' + T.packed : T.packed );
			pk.type = 'button';
			pk.title = o.packed ? T.unpack : T.packed;
			pk.addEventListener( 'click', function () {
				pk.disabled = true;
				req( 'izb_pult_pack', { id: o.id, on: o.packed ? '' : '1' } ).then( function ( no ) {
					data.todo = data.todo.map( function ( x ) {
						return x.id === o.id ? no : x;
					} );
					render();
				} ).catch( function () {
					pk.disabled = false;
				} );
			} );
			row.appendChild( pk );
			var sh = el( 'button', 'izb-pult-btn is-ship', T.ship );
			sh.type = 'button';
			sh.addEventListener( 'click', function () {
				shipIds[ o.id ] = ! shipIds[ o.id ];
				form.hidden = ! shipIds[ o.id ];
				if ( ! form.hidden ) {
					form.querySelector( 'input' ).focus();
				}
			} );
			row.appendChild( sh );
			if ( o.slip ) {
				var sl = el( 'a', 'izb-pult-btn is-light', T.slip );
				sl.href = o.slip;
				sl.target = '_blank';
				row.appendChild( sl );
			}
			var ed = el( 'a', 'izb-pult-btn is-light', T.edit );
			ed.href = o.edit;
			row.appendChild( ed );
		}
		b.appendChild( row );

		// "Shipped…": carrier + tracking number, then the status changes and the customer gets the mail
		var form = el( 'form', 'izb-o-ship' );
		form.hidden = ! shipIds[ o.id ];
		if ( ! PAGE ) {
			var sel = el( 'select' );
			sel.setAttribute( 'aria-label', T.carrier );
			Object.keys( C.carriers ).forEach( function ( k ) {
				var op = el( 'option', '', C.carriers[ k ] );
				op.value = k;
				op.selected = k === o.carrier;
				sel.appendChild( op );
			} );
			var inp = el( 'input' );
			inp.type = 'text';
			inp.placeholder = T.track;
			inp.value = o.track || '';
			inp.setAttribute( 'aria-label', T.track );
			inp.autocomplete = 'off';
			var go = el( 'button', 'izb-pult-btn is-ship', T.send );
			go.type = 'submit';
			form.appendChild( sel );
			form.appendChild( inp );
			form.appendChild( go );
			form.addEventListener( 'submit', function ( e ) {
				e.preventDefault();
				go.disabled = true;
				req( 'izb_pult_ship', { id: o.id, carrier: sel.value, track: inp.value.trim() } ).then( function () {
					shipIds[ o.id ] = false;
					load();
				} ).catch( function () {
					go.disabled = false;
				} );
			} );
			b.appendChild( form );
		}
		d.appendChild( b );
		return d;
	}

	// 1.18.0: the pick list sits folded at the top of "Küldésre vár": everything in the waiting orders, added up.
	var pickOpen = false;
	function drawPick() {
		if ( ! data.pick.length ) {
			return;
		}
		var d = el( 'details', 'izb-pickbox' ), s = el( 'summary' ), total = data.pick.reduce( function ( a, p ) {
			return a + p.qty;
		}, 0 );
		d.open = pickOpen;
		d.addEventListener( 'toggle', function () {
			pickOpen = d.open;
		} );
		s.appendChild( el( 'span', '', T.pickSum ) );
		s.appendChild( el( 'b', 'izb-pult-n', String( total ) ) );
		d.appendChild( s );
		var ul = el( 'ul', 'izb-pick' );
		data.pick.forEach( function ( p ) {
			var li = el( 'li' );
			li.appendChild( el( 'b', 'izb-o-q', p.qty + '×' ) );
			li.appendChild( el( 'span', '', p.name ) );
			if ( p.meta ) {
				li.appendChild( el( 'small', '', p.meta ) );
			}
			if ( p.live ) {
				li.appendChild( el( 'em', 'izb-o-live', T.live ) );
			}
			ul.appendChild( li );
		} );
		d.appendChild( ul );
		body.appendChild( d );
	}

	// 1.18.0: "Elküldve": the last 14 days, newest first, each with its tracking number (a link to the carrier's page).
	function drawSent() {
		var list = data.sent || [];
		if ( ! list.length ) {
			body.appendChild( el( 'p', 'izb-pult-empty', T.noSent ) );
			return;
		}
		body.appendChild( el( 'p', 'izb-pult-hint', T.sentHint ) );
		var ul = el( 'ul', 'izb-sent' );
		list.forEach( function ( o ) {
			var li = el( 'li' ), top = el( 'p', 'izb-o-sum' );
			top.appendChild( el( 'span', 'izb-o-num', '#' + o.num ) );
			top.appendChild( el( 'span', 'izb-o-name', o.name ) );
			top.appendChild( el( 'span', 'izb-o-tot', o.total ) );
			li.appendChild( top );
			var line = el( 'p', 'izb-sent-l' );
			line.appendChild( el( 'span', '', T.sentOn + ': ' + o.when + ( o.carrier ? ' · ' + o.carrier : '' ) + ' · ' ) );
			if ( o.track ) {
				var a = el( o.link ? 'a' : 'b', 'izb-sent-t', o.track );
				if ( o.link ) {
					a.href = o.link;
					a.target = '_blank';
					a.rel = 'noopener noreferrer';
				}
				line.appendChild( a );
			} else {
				line.appendChild( el( 'em', '', T.noTrack ) );
			}
			li.appendChild( line );
			ul.appendChild( li );
		} );
		body.appendChild( ul );
	}

	// 1.18.0: "Készlet": every product, sold out and running low first. Staff change the count with − / + or by typing
	// (saved at once through the shop's own stock call, the same as the line on the product page).
	function drawStock() {
		var all = data.stock.all || [];
		if ( ! all.length ) {
			body.appendChild( el( 'p', 'izb-pult-empty', T.allgood ) );
			return;
		}
		if ( ! PAGE && C.snonce ) {
			body.appendChild( el( 'p', 'izb-pult-hint', T.counted ) );
		}
		var ul = el( 'ul', 'izb-stock' );
		all.forEach( function ( p ) {
			ul.appendChild( stockRow( p ) );
		} );
		body.appendChild( ul );
	}
	function stockRow( p ) {
		var li = el( 'li', 'is-' + p.state ), a = el( 'a', '', p.name );
		a.href = p.url;
		li.appendChild( a );
		var tag = 'out' === p.state ? T.out + ( p.wait ? ' · ' + p.wait + ' ' + T.waiting : '' ) : ( 'low' === p.state ? T.low : '' );
		if ( tag ) {
			li.appendChild( el( 'span', 'izb-stock-t', tag ) );
		}
		var box = el( 'span', 'izb-stock-n' );
		if ( PAGE || ! C.snonce ) {
			box.textContent = null === p.left ? '–' : p.left + ( p.packs ? ' ' + T.pcs : '' );
		} else {
			var minus = el( 'button', 'izb-pult-mini', '−' ), num = el( 'input' ), plus = el( 'button', 'izb-pult-mini', '+' );
			minus.type = plus.type = 'button';
			minus.setAttribute( 'aria-label', '− 1 ' + p.name );
			plus.setAttribute( 'aria-label', '+ 1 ' + p.name );
			num.type = 'number';
			num.min = '0';
			num.step = '1';
			num.inputMode = 'numeric';
			num.placeholder = '–';
			num.value = null === p.left ? '' : String( p.left );
			num.setAttribute( 'aria-label', T.stock + ': ' + p.name );
			var save = function ( params ) {
				li.classList.add( 'is-saving' );
				var fd = new FormData();
				fd.append( 'action', 'izl_stock_set' );
				fd.append( '_ajax_nonce', C.snonce );
				fd.append( 'id', p.id );
				Object.keys( params ).forEach( function ( k ) {
					fd.append( k, params[ k ] );
				} );
				fetch( C.ajax, { method: 'POST', body: fd, credentials: 'same-origin' } ).then( function ( r ) {
					return r.json();
				} ).then( function ( r ) {
					if ( ! r || ! r.success ) {
						throw new Error( 'fail' );
					}
					p.left = r.data.left;
					num.value = null === p.left ? '' : String( p.left );
					num.defaultValue = num.value;
					p.state = null !== p.left && p.left <= 0 ? 'out' : ( r.data.low ? 'low' : ( 'out' === p.state && p.left > 0 ? 'in' : p.state ) );
					li.className = 'is-' + p.state + ' is-saved';
				} ).catch( function () {
					num.value = num.defaultValue;
					li.className = 'is-' + p.state + ' is-failed';
				} );
			};
			minus.addEventListener( 'click', function () {
				if ( null !== p.left && p.left > 0 ) {
					save( { add: -1 } );
				}
			} );
			plus.addEventListener( 'click', function () {
				save( { add: 1 } );
			} );
			num.addEventListener( 'change', function () {
				save( { set: num.value.trim() } );
			} );
			num.addEventListener( 'keydown', function ( e ) {
				if ( 'Enter' === e.key ) {
					num.blur();
				}
			} );
			box.appendChild( minus );
			box.appendChild( num );
			box.appendChild( plus );
			if ( p.packs ) {
				box.appendChild( el( 'small', '', T.pcs ) );
			}
		}
		li.appendChild( box );
		return li;
	}

	// ==========================================================================
	//  Moving and resizing (1.18.0)
	// ==========================================================================

	/* PC: drag the window by its header, resize it from any edge or corner. The place and size are kept on this device
	   (localStorage) and always fitted inside the window; a double-click on the header puts it back in its corner.
	   Phones (600px and narrower) show the desk full screen instead. */
	var BOX = 'izb_pult_box';
	function readBox() {
		try {
			return JSON.parse( localStorage.getItem( BOX ) || 'null' );
		} catch ( e ) {
			return null;
		}
	}
	function saveBox( b ) {
		try {
			if ( b ) {
				localStorage.setItem( BOX, JSON.stringify( b ) );
			} else {
				localStorage.removeItem( BOX );
			}
		} catch ( e ) {}
	}
	function small() {
		return window.matchMedia( '(max-width:600px)' ).matches;
	}
	function place( b ) {
		var st = panel.style;
		if ( ! b || small() ) {
			panel.classList.remove( 'is-free' );
			st.left = st.top = st.width = st.height = '';
			return null;
		}
		var vw = document.documentElement.clientWidth, vh = window.innerHeight, bar = document.getElementById( 'wpadminbar' );
		var top = ( bar ? Math.max( 0, bar.getBoundingClientRect().bottom ) : 0 ) + 8; // never under the WordPress bar
		var w = Math.round( Math.min( Math.max( b.w, 300 ), vw - 16 ) ), h = Math.round( Math.min( Math.max( b.h, 220 ), vh - top - 8 ) );
		var x = Math.round( Math.min( Math.max( b.x, 8 ), vw - w - 8 ) ), y = Math.round( Math.min( Math.max( b.y, top ), vh - h - 8 ) );
		panel.classList.add( 'is-free' );
		st.left = x + 'px';
		st.top = y + 'px';
		st.width = w + 'px';
		st.height = h + 'px';
		return { x: x, y: y, w: w, h: h };
	}
	function mover() {
		var start = null;
		[ 'n', 'e', 's', 'w', 'ne', 'nw', 'se', 'sw' ].forEach( function ( dir ) {
			var hd = el( 'i', 'izb-pult-rz is-' + dir );
			hd.setAttribute( 'data-d', dir );
			hd.setAttribute( 'aria-hidden', 'true' );
			panel.appendChild( hd );
		} );
		head.title = T.moveHint;
		function down( e, dir ) {
			if ( small() || ( e.button && 0 !== e.button ) ) {
				return;
			}
			var r = panel.getBoundingClientRect();
			start = { x: e.clientX, y: e.clientY, dir: dir, b: { x: r.left, y: r.top, w: r.width, h: r.height } };
			panel.classList.add( 'is-moving' );
			e.target.setPointerCapture( e.pointerId );
			e.preventDefault();
		}
		function move( e ) {
			if ( ! start ) {
				return;
			}
			var dx = e.clientX - start.x, dy = e.clientY - start.y, b = start.b, n = { x: b.x, y: b.y, w: b.w, h: b.h }, d = start.dir;
			if ( 'move' === d ) {
				n.x += dx;
				n.y += dy;
			} else {
				if ( d.indexOf( 'e' ) > -1 ) {
					n.w = Math.max( 300, b.w + dx );
				}
				if ( d.indexOf( 'w' ) > -1 ) {
					n.w = Math.max( 300, b.w - dx );
					n.x = b.x + b.w - n.w;
				}
				if ( d.indexOf( 's' ) > -1 ) {
					n.h = Math.max( 220, b.h + dy );
				}
				if ( d.indexOf( 'n' ) > -1 ) {
					n.h = Math.max( 220, b.h - dy );
					n.y = b.y + b.h - n.h;
				}
			}
			place( n );
		}
		function up() {
			if ( ! start ) {
				return;
			}
			start = null;
			panel.classList.remove( 'is-moving' );
			var r = panel.getBoundingClientRect();
			saveBox( { x: r.left, y: r.top, w: r.width, h: r.height } );
		}
		head.addEventListener( 'pointerdown', function ( e ) {
			if ( ! e.target.closest( 'button' ) ) {
				down( e, 'move' );
			}
		} );
		panel.addEventListener( 'pointerdown', function ( e ) {
			var d = e.target.getAttribute && e.target.getAttribute( 'data-d' );
			if ( d ) {
				down( e, d );
			}
		} );
		panel.addEventListener( 'pointermove', move );
		panel.addEventListener( 'pointerup', up );
		panel.addEventListener( 'pointercancel', up );
		head.addEventListener( 'dblclick', function ( e ) {
			if ( ! e.target.closest( 'button' ) ) {
				saveBox( null );
				place( null );
			}
		} );
		window.addEventListener( 'resize', function () {
			if ( isOpen ) {
				place( readBox() );
			}
		} );
	}

	// ==========================================================================
	//  Start
	// ==========================================================================

	function start() {
		build();
		if ( PAGE ) {
			load();
		} else {
			// after the page has settled: the shop comes first
			( window.requestIdleCallback || function ( f ) {
				setTimeout( f, 1500 );
			} )( load, { timeout: 3000 } );
		}
		setInterval( function () {
			if ( ! document.hidden ) {
				load();
			}
		}, ( C.poll || 60 ) * 1000 );
		setInterval( function () {
			if ( ! document.hidden ) {
				clock();
			}
		}, 20000 );
		document.addEventListener( 'visibilitychange', function () {
			if ( ! document.hidden && Date.now() - got > 30000 ) {
				load();
			}
		} );
	}
	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', start );
	} else {
		start();
	}
}() );
