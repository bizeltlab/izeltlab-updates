<?php
/**
 * Plugin Name:       Ízeltláb Bolt
 * Description:       The shop's launch kit: one-click WooCommerce settings (HUF, 27% VAT, shipping zone, free shipping), Hungarian checkout with the legal tick boxes, legal page drafts, cookie banner, GDPR tools, branded emails with a "shipped" mail and tracking number, SMTP, security hardening, SEO tags and share images, analytics after consent, "notify me" + restock list and newsletter sign-ups, packing slip, the order desk (pill + phone page + morning mail), accountant CSV, WebP photos, cache rules, backup setup, species search. Settings: WooCommerce → Ízeltláb Bolt.
 * Version:           1.2.0
 * Author:            Dan
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Text Domain:       izeltlab-bolt
 * Domain Path:       /languages
 *
 * Works without the Ízeltláb theme and without Codex; uses them when they are there.
 */

defined( 'ABSPATH' ) || exit;

define( 'IZB_VERSION', '1.2.0' );
define( 'IZB_DIR', plugin_dir_path( __FILE__ ) );
define( 'IZB_URL', plugin_dir_url( __FILE__ ) );
define( 'IZB_EMAIL', 'bizeltlab@gmail.com' ); // the company email (Dan, 2026-11-04)

// The plugin's settings, all in one option. Defaults first, so a fresh install works.
function izb_defaults() {
	return array(
		// company (the legal pages, the footer and the emails print these)
		'co_name'      => '',
		'co_form'      => '',
		'co_address'   => '',
		'co_tax'       => '',
		'co_reg'       => '',
		'co_email'     => IZB_EMAIL,
		'co_phone'     => '',
		'co_bank'      => '',
		'host_name'    => '',
		'host_address' => '',
		'host_email'   => '',
		'chamber'      => 'Budapesti Békéltető Testület, 1016 Budapest, Krisztina krt. 99. III. em. 310., bekelteto.testulet@bkik.hu',
		// shipping (gross Ft, VAT included)
		'rate_foxpost' => '',
		'rate_gls'     => '',
		'extra_closed' => '', // Dan's own closed days (holiday, fair), one Y-m-d per line
		// mail
		'smtp_on'      => 0,
		'smtp_host'    => 'smtp.gmail.com',
		'smtp_port'    => 587,
		'smtp_user'    => IZB_EMAIL,
		'smtp_pass'    => '',
		'from_name'    => 'Ízeltláb',
		// security
		'sec_limit'    => 1,
		'sec_slug'     => '',
		'sec_xmlrpc'   => 1,
		'sec_headers'  => 1,
		'sec_enum'     => 1,
		'sec_fileedit' => 1,
		// consent + analytics
		'cookie_on'    => 1,
		'ga4'          => '',
		'plausible'    => '',
		// sign-ups
		'notify_on'    => 1,
		'news_on'      => 1,
		'soldout_show' => 1, // 1.2.0: sold-out products stay in the shop
		// 1.2.0: the order desk
		'pult_on'        => 1,
		'pult_corner'    => 'br',
		'pult_admin'     => 1,
		'pult_statuses'  => 'processing,on-hold',
		'pult_phone'     => 1,
		'pult_email'     => 1,
		'pult_note'      => 1,
		'pult_pay'       => 1,
		'pult_low'       => 3,
		'pult_sound'     => 0,
		'pult_link'      => 1,
		'pult_mail'      => 1,
		'pult_mail_hour' => 7,
		'pult_mail_to'   => '',
		// 1.2.0: photos, cache, share image, search
		'img_on'       => 1,
		'img_max'      => 2000,
		'img_webp'     => 1,
		'img_quality'  => 80,
		'cache_rules'  => 1,
		'share_img'    => '',
		'search_on'    => 1,
	);
}

function izb_opt( $key = null ) {
	$all = wp_parse_args( (array) get_option( 'izb', array() ), izb_defaults() ); // 1.1.0: no static copy (WordPress caches the option)
	if ( null === $key ) {
		return $all;
	}
	return isset( $all[ $key ] ) ? $all[ $key ] : null;
}

// The company email, never empty.
function izb_email() {
	$e = sanitize_email( (string) izb_opt( 'co_email' ) );
	return $e ? $e : IZB_EMAIL;
}

add_action( 'plugins_loaded', function () {
	load_plugin_textdomain( 'izeltlab-bolt', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
} );

// 1.1.0: the shop's rules and data first (ship days, holidays, packs, free shipping, whole forints, photo frames). The
// same file is in the Ízeltláb theme; this copy loads first, so the rules keep working even after a theme change.
if ( ! defined( 'IZL_CORE' ) ) {
	require_once IZB_DIR . 'inc/shop-core.php';
}

// Then in the order an order goes: settings and setup · closed days · checkout · emails · packing slip · sign-ups ·
// cookies, privacy, analytics · search engines · mail sending · security.
// 1.2.0: + restock list · order desk · accountant export · photos · page cache · backups · search.
foreach ( array( 'settings', 'holidays', 'checkout', 'emails', 'packing', 'signups', 'restock', 'pult', 'accounting', 'consent', 'privacy', 'analytics', 'seo', 'speed', 'cache', 'backup', 'search', 'smtp', 'security' ) as $izb_part ) {
	require_once IZB_DIR . 'inc/' . $izb_part . '.php';
}
unset( $izb_part );

// The shop's own front-end bits (cookie banner, sign-up forms): one small CSS + JS, only what the page needs.
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'izeltlab-bolt', IZB_URL . 'assets/bolt.css', array(), IZB_VERSION );
	wp_enqueue_script( 'izeltlab-bolt', IZB_URL . 'assets/bolt.js', array(), IZB_VERSION, true );
	wp_localize_script( 'izeltlab-bolt', 'izbCfg', izb_front_cfg() );
}, 25 );

function izb_front_cfg() {
	return array(
		'ajax'    => admin_url( 'admin-ajax.php', 'relative' ),
		'nonce'   => wp_create_nonce( 'izb_signup' ),
		'cookie'  => izb_opt( 'cookie_on' ) ? 1 : 0,
		'tracks'  => izb_analytics_cfg(),
		'privacy' => get_privacy_policy_url(),
		'txt'     => array(
			'thanks' => __( 'Thank you! We will write to you.', 'izeltlab-bolt' ),
			'error'  => __( 'Something went wrong. Please try again.', 'izeltlab-bolt' ),
		),
	);
}

// 1.1.1: WooCommerce's order storage (HPOS, the default on new shops): every order read and write here goes through the
// order object (get_meta, update_meta_data, wc_get_page_screen_id), so it is safe with it. The cart and checkout blocks
// are not: the legal tick boxes, the address fields and the "Shipping" status mail hook into the classic checkout.
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, false );
	}
} );

// 1.1.1: warnings on the dashboard (admins only) for two set-ups that break the shop quietly.
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'manage_options' ) || ! function_exists( 'wc_get_page_id' ) ) {
		return;
	}
	$msgs = array();
	// The cart or checkout page made of WooCommerce blocks: the withdrawal tick box, the "order with obligation to pay"
	// button text and the Hungarian address fields of this plugin do not show there.
	foreach ( array( 'cart' => 'woocommerce/cart', 'checkout' => 'woocommerce/checkout' ) as $page => $block ) {
		$id = wc_get_page_id( $page );
		if ( $id > 0 && has_block( $block, $id ) ) {
			/* translators: %s: Cart or Checkout */
			$msgs[] = sprintf( 'The %s page uses the WooCommerce block. Ízeltláb Bolt needs the classic one: edit the page and replace the block with the shortcode [woocommerce_%s], or the legal tick boxes are missing.', esc_html( ucfirst( $page ) ), esc_html( $page ) );
		}
	}
	// The shop rules file is in the theme and in this plugin, and only this plugin's copy runs. When the two differ,
	// a change made in one of them only would be missed.
	$theme_core = get_stylesheet_directory() . '/inc/shop-core.php';
	if ( is_readable( $theme_core ) && md5_file( $theme_core ) !== md5_file( IZB_DIR . 'inc/shop-core.php' ) ) {
		$msgs[] = 'The shop rules file (inc/shop-core.php) differs between the Ízeltláb theme and the Ízeltláb Bolt plugin. Only the plugin\'s copy runs. Update both to the same version.';
	}
	foreach ( $msgs as $m ) {
		echo '<div class="notice notice-warning"><p><b>Ízeltláb Bolt:</b> ' . wp_kses( $m, array() ) . '</p></div>';
	}
} );

register_activation_hook( __FILE__, function () {
	izb_signups_install();
	izl_make_supplies_term(); // 1.1.0: the Kiegészítők category, as the theme makes it
	flush_rewrite_rules();
} );

// "Settings" link on the Plugins screen.
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=izeltlab-bolt' ) ) . '">Settings</a>' );
	return $links;
} );
