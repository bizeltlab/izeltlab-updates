=== Ízeltláb Bolt ===
Version: 1.3.0
Requires: WordPress 6.0+, WooCommerce. Works with the Ízeltláb theme 2.1.1+ (shipping dates, footer, look) and alone.

The shop's launch kit. Settings: WooCommerce → Ízeltláb Bolt. Activation changes no WooCommerce setting.

* Apply shop settings (button, with Undo): HUF without decimals, 27% VAT included, Hungary only, a "Magyarország"
  zone with Foxpost / GLS (prices from the settings) and Free shipping over the theme's amount, guest checkout,
  no coupons, no reviews, no stock counting, shop mails from the company email (bizeltlab@gmail.com) in the shop
  colours, admin mails to the company email, cart and checkout as the classic shortcodes.
* Create legal page drafts (button): ÁSZF, Adatkezelési tájékoztató, Elállási tájékoztató + form, Impresszum,
  Panaszkezelés, Szállítás, Érkezési garancia, GYIK, as drafts. Company data via [izb_co field="..."], links via
  [izb_page slug="..."]. A lawyer must read them before publishing.
* Checkout: "Megrendelés – fizetési kötelezettséggel jár", ÁSZF + withdrawal box, separate privacy box (both kept
  with the order), phone required, no second address line, "Sets off / Expected" line (theme rule).
* Cookie banner (own, no third party): "Csak a szükségesek" / "Elfogadom"; analytics only after Elfogadom.
  [izb_cookie_link] or any data-izb-cookies element opens it again.
* GDPR: sign-ups in WordPress's export / erase tools; order data kept (8-year invoice rule).
* Emails: retro styles, Reply-To, dispatch line, new status "Feladva" + carrier/tracking box + "Úton van a csomagod!"
  mail; tracking link on My account.
* SMTP (Gmail App password), test mail button.
* Security: login attempts limit, secret login address (optional), XML-RPC off, headers, no user-name leaks,
  file editor off. 2FA: the "Two Factor" plugin.
* SEO (steps aside when an SEO plugin is active): meta description, Open Graph (product photo), alt text fallback,
  brand + shipping + return data in the product schema, no user sitemap, account pages noindex.
* Analytics: GA4 or Plausible, after consent; view_item, add_to_cart, begin_checkout, purchase, sign_up.
* Sign-ups: "Szólj, ha újra kaphatók!" on unavailable products (one mail when Available goes on), newsletter in the
  footer ([izb_newsletter] anywhere), CSV export.
* Packing slip: order screen button and bulk action.
* Translation: languages/izeltlab-bolt-hu_HU.po / .mo.

1.3.0 (with theme 2.4.0 and Codex 1.66.0): updates from the shop's GitHub repository, inc/updater.php
(Settings → Ízeltláb updates: repository, branch, token for a private one; status, Check now, Roll back to the backup).

1.2.0 (with theme 2.2.0, QoL package): Order desk: a pill in a corner of every page for shop managers (today's count,
newest price, 14:00 countdown), opening into To pack (items, tick boxes, address copy, phone, note, Packed, Shipped +
tracking = the "Feladva" mail), Pick list and Stock; the same as a phone page through a secret link (read only), and a
morning mail. Sold-out products stay visible ("Szóljatok!" on tiles), Restock list (WooCommerce → Restock list) with
"Mail them now" and CSV. Photos: uploads scaled to 2000 px and saved as WebP, "Optimise existing photos", first
product photo loads first. Share previews: 1200×630 JPEG cut around the photo's frame. Search knows Latin, Hungarian and
trade names, tags, accents and small typos ("did you mean"), "Search words" field per product; 404 suggestions;
sitemap without cart/checkout/account. Cache rules (no cache for cart/checkout/account/order desk, scripts kept
unoptimised for WP Rocket and LiteSpeed). Backups: UpdraftPlus settings button + 2-day warning. Accountant export
(WooCommerce → Accountant export: CSV with net/VAT/gross, shipping, refunds, Számlázz.hu invoice number) and a printable
VAT summary per order (not an invoice). Analytics: view_search_results, view_cart, free_shipping_reached; consent mode.

1.1.1: declares WooCommerce order storage (HPOS) compatible and the cart/checkout blocks not compatible. Dashboard
warnings (admins): the cart or checkout page made of WooCommerce blocks (the legal tick boxes would be missing; Apply
shop settings switches them back), and the two copies of inc/shop-core.php (theme and plugin) differing. Sign-up forms
work on pages served from a page cache (the security code is checked for logged-in people only; honeypot, tick box and
email check stay). The add_to_cart event gets the product id from the theme's buy button too. The front page gets a meta
description (the hero text) when it has none.

1.1.0: inc/shop-core.php = the shop's rules (same file as the theme's: ship dates and holidays, free-shipping amount,
packs and the buy box save, photo frames, whole forints, reviews off, Kiegészítők). The plugin's copy runs first.
Fixed: Foxpost / GLS showed 27% more (1 290 → 1 638 Ft); Apply shop settings now saves the price without VAT and
fixes a rate saved by 1.0.0. Fixed: newsletter consent text no longer splits into columns in the footer.
Files load in order: settings, holidays, checkout, emails, packing, signups, consent, privacy, analytics, seo, smtp,
security.
