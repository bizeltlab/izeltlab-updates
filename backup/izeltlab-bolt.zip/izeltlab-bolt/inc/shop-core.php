<?php
// ==========================================================================
//  FILE: shop-core.php   (shared file)
//  WHAT: The shop's rules and data: Codex helpers, shop texts, whole-forint prices, packs, photo frames,
//        free shipping amount, shipping days and holidays. This one file is copied by the build into the theme (inc/) and Bolt (inc/); edit it in shared/ only.
//  SEEN: Prices, packs, shipping dates and the free-shipping bar everywhere.
//  SECTIONS IN THIS FILE:
//    1. 1. Codex helpers (all optional: the shop works without the Codex plugin)
//    2. 2. shop texts and the supplies category
//    3. 3. prices in whole forints, no reviews
//    4. 4. packs: price, base pack, pack sizes, available, stock (saved by Edit buy box)
//    5. 4b. stock: what the shop lets people buy, and what orders take and give back (3.21.0)
//    6. 5. photo frames (saved by Edit photos, shown by the theme)
//    7. 6. free shipping amount and the cart total
//    8. 7. shipping days: when it leaves, when it is expected, holidays (1.7.0, 2.1.0)
// ==========================================================================

/**
 * The shop's rules and data (shared core of the Ízeltláb theme and the Ízeltláb Bolt plugin).
 *
 * The SAME file ships in both: the plugin's copy loads first (plugins load before themes) and the theme then skips
 * its copy (both include lines check IZL_CORE first, because PHP would otherwise declare the functions twice). Without the plugin the theme's copy runs, so the shop works either way. With the plugin,
 * these rules keep working after a theme change: ship dates, holidays, packs, free shipping, whole forints, no reviews,
 * the Kiegészítők category and the saved photo frames. Everything you SEE (buy ticket, drawer, tiles, cart look) stays
 * in the theme and only calls these functions.
 *
 * Edit the two copies together (theme inc/shop-core.php = plugin inc/shop-core.php); IZL_CORE_VERSION says which ran.
 *
 * Contents: 1 Codex helpers · 2 shop texts and the Kiegészítők category · 3 prices and reviews · 4 packs (Edit buy box
 * save) · 5 photo frames (Edit photos save) · 6 free shipping and the cart total · 7 shipping days and holidays
 */

defined( 'ABSPATH' ) || exit;

// Include this file only through: if ( ! defined( 'IZL_CORE' ) ) { require_once ...; }
define( 'IZL_CORE', __FILE__ );
define( 'IZL_CORE_VERSION', '1.0.0' );

// ==========================================================================
//  1. Codex helpers (all optional: the shop works without the Codex plugin)
// ==========================================================================

function izl_has_codex() {
	return function_exists( 'fsz_opt' ) && function_exists( 'fsz_is_live' );
}

function izl_is_codex( $product_id ) {
	return izl_has_codex() && fsz_is_live( $product_id );
}

/**
 * The isopod categories: the Codex categories (settings), without the ones that sit under another chosen one.
 * With the Codex plugin off, a category with the slug "aszkak" or "isopoda" if there is one.
 */
function izl_isopod_terms() {
	$slugs = izl_has_codex() ? array_filter( array_map( 'sanitize_title', explode( ',', fsz_opt( 'categories' ) ) ) ) : array( 'aszkak', 'isopoda' );
	$terms = array();
	foreach ( $slugs as $slug ) {
		$t = get_term_by( 'slug', $slug, 'product_cat' );
		if ( $t && ! is_wp_error( $t ) ) {
			$terms[ (int) $t->term_id ] = $t;
		}
	}
	return array_values( array_filter( $terms, function ( $t ) use ( $terms ) {
		foreach ( get_ancestors( $t->term_id, 'product_cat', 'taxonomy' ) as $a ) {
			if ( isset( $terms[ $a ] ) ) {
				return false;
			}
		}
		return true;
	} ) );
}

// ==========================================================================
//  2. shop texts and the supplies category
// ==========================================================================

define( 'IZL_SUPPLIES', 'kiegeszitok' ); // slug of the supplies category (tubs, substrate, food …)

function izl_supplies_term() {
	$t = get_term_by( 'slug', IZL_SUPPLIES, 'product_cat' );
	return $t && ! is_wp_error( $t ) ? $t : null;
}

// A theme text in the shop's language, read straight from the theme's translation file. Saving in the dashboard runs
// in the admin's own language (which may be English), but this is text the customers see.
function izl_shop_text( $text ) {
	static $mo = null;
	if ( determine_locale() === get_locale() ) {
		return translate( $text, 'izeltlab' ); // phpcs:ignore WordPress.WP.I18n
	}
	if ( null === $mo ) {
		$mo   = new MO();
		$file = get_stylesheet_directory() . '/languages/' . get_locale() . '.mo';
		if ( ! is_readable( $file ) || ! $mo->import_from_file( $file ) ) {
			$mo = false;
		}
	}
	return $mo ? $mo->translate( $text ) : $text;
}

// Made once when the theme is switched on (or the Ízeltláb Bolt plugin is activated), if it is not there yet.
function izl_make_supplies_term() {
	if ( taxonomy_exists( 'product_cat' ) && ! izl_supplies_term() ) {
		// In the shop's language (the customers see it), not in the admin's own.
		wp_insert_term( izl_shop_text( 'Supplies' ), 'product_cat', array( 'slug' => IZL_SUPPLIES ) );
	}
}
add_action( 'after_switch_theme', 'izl_make_supplies_term' );

// ==========================================================================
//  3. prices in whole forints, no reviews
// ==========================================================================

// Forint has no fillér: 2 500 Ft, never 2 500,00 Ft (product pages, shop, cart, checkout, emails).
add_filter( 'wc_get_price_decimals', function ( $decimals ) {
	return function_exists( 'get_woocommerce_currency' ) && 'HUF' === get_woocommerce_currency() ? 0 : $decimals;
} );

// No reviews anywhere (no tab, no stars, no review form): the theme keeps WooCommerce's "Enable reviews" off.
add_filter( 'pre_option_woocommerce_enable_reviews', function () {
	return 'no';
} );
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	unset( $tabs['reviews'] );
	return $tabs;
}, 98 );

// ==========================================================================
//  4. packs: price, base pack, pack sizes, available, stock (saved by Edit buy box)
// ==========================================================================

// Packs (3.21.0, Dan 2026-11-24): each pack is a number of animals (10, 20, 50 … or any size Dan types), a WooCommerce
// variation of the attribute "Csomag". Its price is the base pack's price × count ÷ base pack, unless Dan typed his own
// (a bulk price). Until 3.20.0 the packs were fixed multiples (1×, 2×, 5×, variation meta _izl_mult); those still read
// as base × multiple.
//
// Stock (3.21.0): one number per product, the animals (or items) on hand, product meta _izl_stock. Empty = not counted
// (the old way: only the "Available" switch). Every pack takes from that one number (a 20 db pack takes 20), so a pack
// that needs more than what is left cannot be chosen, the basket cannot hold more than what is left, and below the
// smallest pack the product is sold out by itself. Orders take from it, cancelled / failed / refunded orders give it
// back (section 4b). WooCommerce's own stock keeping stays off: it counts packs, not animals.
// "Available" off = paused (_izl_paused): nothing can be bought, whatever the count.
// "Kevés van" below (_izl_low_at): under that number the stamp says "Utolsó N db" and the Codex light blinks.
define( 'IZL_PACK_MULTS', array( 1, 2, 5 ) ); // the packs a new product starts with (base × 1, 2, 5)
define( 'IZL_PACK_ATTR', 'Csomag' );
define( 'IZL_PACK_MAX', 8 ); // at most this many packs per product (Dan was advised 4; the phone grid has 3 a row)

// The product's group: its top-level category (the name on the Codex card), or null.
function izl_group_term( $product_id ) {
	if ( function_exists( 'fsz_group_term' ) ) {
		return fsz_group_term( $product_id );
	}
	$terms = get_the_terms( $product_id, 'product_cat' );
	if ( ! $terms || is_wp_error( $terms ) ) {
		return null;
	}
	$term = $terms[0];
	while ( $term->parent ) {
		$parent = get_term( $term->parent, 'product_cat' );
		if ( ! $parent || is_wp_error( $parent ) ) {
			break;
		}
		$term = $parent;
	}
	return $term;
}

// A group's base pack: its own setting (term meta izl_base_pack), else 10 for an isopod group, else 1.
function izl_group_base_pack( $term ) {
	if ( ! $term ) {
		return 1;
	}
	$own = (int) get_term_meta( $term->term_id, 'izl_base_pack', true );
	if ( $own > 0 ) {
		return $own;
	}
	foreach ( izl_isopod_terms() as $t ) {
		if ( (int) $t->term_id === (int) $term->term_id || in_array( (int) $term->term_id, get_ancestors( $t->term_id, 'product_cat', 'taxonomy' ), true ) ) {
			return 10;
		}
	}
	return 1;
}

// The product's base pack (its own, for rarer species), else its group's.
function izl_base_pack( $product_id ) {
	$own = (int) get_post_meta( $product_id, '_izl_base_pack', true );
	return $own > 0 ? $own : izl_group_base_pack( izl_group_term( $product_id ) );
}

// "10 db". $shop: in the shop's language, read straight from the theme's translation file, because the editor saves
// in the admin's own dashboard language (which may be English) and the label is stored on the product.
function izl_pack_label( $count, $shop = false ) {
	/* translators: %d: number of animals in the pack */
	$format = __( '%d pcs', 'izeltlab' );
	if ( $shop && determine_locale() !== get_locale() ) {
		$mo   = new MO();
		$file = get_stylesheet_directory() . '/languages/' . get_locale() . '.mo';
		$format = is_readable( $file ) && $mo->import_from_file( $file ) ? $mo->translate( '%d pcs' ) : '%d pcs';
	}
	return sprintf( $format, $count );
}

// How many animals (or items) one of this takes from the stock: a pack's own count, an old pack's base × multiple,
// 1 for anything else (a supply, a pack made by hand).
function izl_pack_count( $product ) {
	if ( ! $product instanceof WC_Product ) {
		$product = wc_get_product( $product );
	}
	if ( ! $product || ! $product->is_type( 'variation' ) ) {
		return 1;
	}
	$n = (int) $product->get_meta( '_izl_count' );
	if ( $n > 0 ) {
		return $n;
	}
	$m = (int) $product->get_meta( '_izl_mult' );
	return $m > 0 ? $m * izl_base_pack( $product->get_parent_id() ) : 1;
}

// The product a stock belongs to (a pack's parent).
function izl_stock_owner( $product ) {
	if ( ! $product instanceof WC_Product ) {
		$product = wc_get_product( $product );
	}
	if ( ! $product ) {
		return 0;
	}
	return $product->is_type( 'variation' ) ? (int) $product->get_parent_id() : (int) $product->get_id();
}

// What is left, or null when the stock is not counted.
function izl_stock_left( $id ) {
	$v = get_post_meta( $id, '_izl_stock', true );
	return '' === (string) $v ? null : max( 0, (int) $v );
}

// "Kevés van" below this many (0 = set by hand with the switch / the Codex light).
function izl_low_at( $id ) {
	return max( 0, (int) get_post_meta( $id, '_izl_low_at', true ) );
}

// Running low by the count: counted, a limit set, fewer left than the limit (and still something to sell).
function izl_count_low( $id ) {
	$left = izl_stock_left( $id );
	$at   = izl_low_at( $id );
	return null !== $left && $at > 0 && $left > 0 && $left < $at;
}

// Sets the stock (never below 0) and puts every pack in step. Returns what is left.
function izl_set_stock( $id, $n ) {
	update_post_meta( $id, '_izl_stock', max( 0, (int) $n ) );
	izl_sync_packs( $id );
	return izl_stock_left( $id );
}

// Puts the product and each pack in or out of stock from the count and the "Available" switch, keeps the Codex light
// in step when a "Kevés van" limit is set, and clears the cached page.
function izl_sync_packs( $id ) {
	$product = wc_get_product( $id );
	if ( ! $product ) {
		return;
	}
	$left   = izl_stock_left( $id );
	$paused = 'yes' === get_post_meta( $id, '_izl_paused', true );
	if ( $product instanceof WC_Product_Variable ) {
		foreach ( $product->get_children() as $vid ) {
			$v = wc_get_product( $vid );
			if ( ! $v ) {
				continue;
			}
			$in = ! $paused && ( null === $left || izl_pack_count( $v ) <= $left );
			$st = $in ? 'instock' : 'outofstock';
			if ( $v->get_manage_stock() || $v->get_stock_status() !== $st ) {
				$v->set_manage_stock( false );
				$v->set_stock_status( $st );
				$v->save();
			}
		}
		WC_Product_Variable::sync( $id );
	} else {
		$st = ! $paused && ( null === $left || $left > 0 ) ? 'instock' : 'outofstock';
		if ( $product->get_manage_stock() || $product->get_stock_status() !== $st ) {
			$product->set_manage_stock( false );
			$product->set_stock_status( $st );
			$product->save();
		}
	}
	if ( izl_low_at( $id ) > 0 && izl_is_codex( $id ) ) {
		izl_count_low( $id ) ? update_post_meta( $id, '_fsz_low', 'yes' ) : delete_post_meta( $id, '_fsz_low' );
	}
	wc_delete_product_transients( $id );
	if ( function_exists( 'wp_cache_post_change' ) ) {
		wp_cache_post_change( $id ); // WP Super Cache: this product's page (and the front page) are made again
	}
}

// The packs as the editor lists them: [count, price, own price?], in the buttons' order.
function izl_pack_list( $product ) {
	$out = array();
	if ( ! $product instanceof WC_Product_Variable ) {
		return $out;
	}
	foreach ( $product->get_children() as $vid ) {
		$v = wc_get_product( $vid );
		if ( ! $v || ( ! $v->get_meta( '_izl_count' ) && ! $v->get_meta( '_izl_mult' ) ) ) {
			continue;
		}
		$out[] = array(
			'count' => izl_pack_count( $v ),
			'price' => '' === (string) $v->get_regular_price() ? '' : (float) $v->get_regular_price(),
			'own'   => 'yes' === $v->get_meta( '_izl_own_price' ),
			'order' => (int) $v->get_menu_order(),
		);
	}
	usort( $out, function ( $a, $b ) {
		return $a['order'] - $b['order'];
	} );
	return $out;
}

// Saves the editor into WooCommerce.
function izl_buybox_save( $id, $in ) {
	$product = wc_get_product( $id );
	if ( ! $product ) {
		return new WP_Error( 'none', 'Product not found.' );
	}
	$price = isset( $in['price'] ) && '' !== trim( (string) $in['price'] ) ? max( 0, (float) str_replace( array( ' ', ',' ), array( '', '.' ), (string) $in['price'] ) ) : '';

	// 1.7.0: live animal or normal product (when it ships), and the title of the tile row under the page.
	if ( isset( $in['ship'] ) && isset( IZL_SHIP_DAYS[ $in['ship'] ] ) ) {
		update_post_meta( $id, '_izl_ship_type', $in['ship'] );
	}
	if ( isset( $in['rowTitle'] ) ) {
		update_post_meta( $id, '_izl_row_title', $in['rowTitle'] );
	}

	// 3.21.0: "Available" off = paused; the stock (empty = not counted) and the "Kevés van" limit.
	update_post_meta( $id, '_izl_paused', empty( $in['available'] ) ? 'yes' : 'no' );
	if ( array_key_exists( 'stock', $in ) && null !== $in['stock'] ) {
		'' === trim( (string) $in['stock'] ) ? delete_post_meta( $id, '_izl_stock' ) : update_post_meta( $id, '_izl_stock', max( 0, (int) $in['stock'] ) );
	}
	if ( isset( $in['lowAt'] ) ) {
		(int) $in['lowAt'] > 0 ? update_post_meta( $id, '_izl_low_at', (int) $in['lowAt'] ) : delete_post_meta( $id, '_izl_low_at' );
	}

	// 1.7.17: "Running low" makes the yellow light on the Codex card blink (the same switch as in the Codex quick edit).
	// 3.21.0: only while no "Kevés van" limit is set; with one, the count decides (izl_sync_packs()).
	if ( isset( $in['low'] ) && null !== $in['low'] && izl_is_codex( $id ) && ! izl_low_at( $id ) ) {
		$in['low'] ? update_post_meta( $id, '_fsz_low', 'yes' ) : delete_post_meta( $id, '_fsz_low' );
	}

	if ( ! izl_is_codex( $id ) ) {
		// Supplies: the price (packs made by hand keep theirs), each sold one at a time.
		if ( ! $product instanceof WC_Product_Variable ) {
			$product->set_regular_price( '' === $price ? '' : (string) $price );
			$product->save();
		}
		izl_sync_packs( $id );
		return true;
	}

	// The base pack: the product's own, or empty = its group's (3.21.0: no "whole group" switch any more).
	$base  = isset( $in['base'] ) ? absint( $in['base'] ) : 0;
	$group = izl_group_term( $id );
	if ( $base > 0 && $base !== izl_group_base_pack( $group ) ) {
		update_post_meta( $id, '_izl_base_pack', $base );
	} else {
		delete_post_meta( $id, '_izl_base_pack' );
	}
	$base = izl_base_pack( $id );

	// The packs: "count:price" (price empty = worked out from the base price). Same count twice = once.
	$packs = array();
	foreach ( isset( $in['packs'] ) ? (array) $in['packs'] : array() as $row ) {
		$bits  = explode( ':', (string) $row, 2 );
		$count = absint( $bits[0] );
		$own   = isset( $bits[1] ) && '' !== trim( $bits[1] ) ? max( 0, (float) str_replace( array( ' ', ',' ), array( '', '.' ), $bits[1] ) ) : null;
		if ( $count > 0 && ! isset( $packs[ $count ] ) && count( $packs ) < IZL_PACK_MAX ) {
			$packs[ $count ] = $own;
		}
	}
	if ( ! $packs ) {
		$packs = array( $base => null );
	}
	$start = isset( $in['start'] ) ? absint( $in['start'] ) : 0;
	if ( ! array_key_exists( $start, $packs ) ) {
		$start = (int) array_key_first( $packs );
	}

	// A simple product becomes a product with packs.
	if ( ! $product instanceof WC_Product_Variable ) {
		wp_set_object_terms( $id, 'variable', 'product_type' );
		$product = new WC_Product_Variable( $id );
		$product->set_regular_price( '' );
		$product->set_sale_price( '' );
	}
	$labels = array();
	foreach ( array_keys( $packs ) as $n ) {
		$labels[ $n ] = izl_pack_label( $n, true );
	}
	$attrs = array();
	foreach ( $product->get_attributes() as $key => $a ) {
		if ( sanitize_title( IZL_PACK_ATTR ) !== sanitize_title( $a->get_name() ) && ! $a->get_variation() ) {
			$attrs[ $key ] = $a; // other attributes stay (3.21.0: not ones that made packs by hand: those packs are gone)
		}
	}
	$attr = new WC_Product_Attribute();
	$attr->set_name( IZL_PACK_ATTR );
	$attr->set_options( array_values( $labels ) );
	$attr->set_visible( true );
	$attr->set_variation( true );
	$attr->set_position( 0 );
	$attrs[ sanitize_title( IZL_PACK_ATTR ) ] = $attr;
	$product->set_attributes( $attrs );
	$product->set_default_attributes( array( sanitize_title( IZL_PACK_ATTR ) => $labels[ $start ] ) ); // the start pack
	$product->set_manage_stock( false );
	$product->save();

	// One variation per pack, found again by its count; packs taken off (and ones made by hand) are removed.
	$keep = array();
	foreach ( $product->get_children() as $vid ) {
		$v = wc_get_product( $vid );
		$n = $v && ( $v->get_meta( '_izl_count' ) || $v->get_meta( '_izl_mult' ) ) ? izl_pack_count( $v ) : 0;
		if ( $v && array_key_exists( $n, $packs ) && ! isset( $keep[ $n ] ) ) {
			$keep[ $n ] = $v;
		} elseif ( $v ) {
			$v->delete( true );
		}
	}
	$i = 0;
	foreach ( $packs as $n => $own ) {
		$v = isset( $keep[ $n ] ) ? $keep[ $n ] : new WC_Product_Variation();
		$v->set_parent_id( $id );
		$v->set_attributes( array( sanitize_title( IZL_PACK_ATTR ) => $labels[ $n ] ) );
		$auto = '' === $price ? '' : (string) round( $price * $n / max( 1, $base ), wc_get_price_decimals() );
		$v->set_regular_price( null === $own ? $auto : (string) round( $own, wc_get_price_decimals() ) );
		$v->set_sale_price( '' );
		$v->set_manage_stock( false );
		$v->set_menu_order( $i++ );
		$v->update_meta_data( '_izl_count', $n );
		$v->update_meta_data( '_izl_own_price', null === $own ? 'no' : 'yes' );
		if ( 0 === $n % max( 1, $base ) ) {
			$v->update_meta_data( '_izl_mult', (int) ( $n / max( 1, $base ) ) ); // read by versions before 3.21.0
		} else {
			$v->delete_meta_data( '_izl_mult' );
		}
		$v->save();
	}
	izl_sync_packs( $id );
	return true;
}

add_action( 'wp_ajax_izl_buybox_save', function () {
	if ( ! check_ajax_referer( 'izl_product_text', false, false ) ) {
		wp_send_json_error( 'The security check ran out. Reload the page and try again.', 403 );
	}
	$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
	if ( ! $id || ! current_user_can( 'edit_post', $id ) ) {
		wp_send_json_error( 'Not allowed.', 403 );
	}
	$in = array(
		'price'     => isset( $_POST['price'] ) ? sanitize_text_field( wp_unslash( $_POST['price'] ) ) : '',
		'base'      => isset( $_POST['base'] ) ? absint( $_POST['base'] ) : 0,
		'packs'     => isset( $_POST['packs'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['packs'] ) ) : array(), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		'start'     => isset( $_POST['start'] ) ? absint( $_POST['start'] ) : 0,
		'available' => ! empty( $_POST['available'] ),
		'stock'     => isset( $_POST['stock'] ) ? sanitize_text_field( wp_unslash( $_POST['stock'] ) ) : null,
		'lowAt'     => isset( $_POST['lowAt'] ) ? absint( $_POST['lowAt'] ) : null,
		'low'       => isset( $_POST['low'] ) ? ! empty( $_POST['low'] ) : null,
		'ship'      => isset( $_POST['ship'] ) ? sanitize_key( wp_unslash( $_POST['ship'] ) ) : '',
		'rowTitle'  => isset( $_POST['rowTitle'] ) ? sanitize_text_field( wp_unslash( $_POST['rowTitle'] ) ) : null,
	);
	$r = izl_buybox_save( $id, $in );
	if ( is_wp_error( $r ) ) {
		wp_send_json_error( $r->get_error_message() );
	}
	wp_send_json_success();
} );

// 3.21.0: the stock − / + (and a typed number) on the product page and in the order desk's Készlet tab: saves at once.
// "add" changes it by that much, "set" sets it. Answers with what is left.
add_action( 'wp_ajax_izl_stock_set', function () {
	if ( ! check_ajax_referer( 'izl_stock', false, false ) ) {
		wp_send_json_error( 'The security check ran out. Reload the page and try again.', 403 );
	}
	$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
	if ( ! $id || ! current_user_can( 'edit_post', $id ) || ! wc_get_product( $id ) ) {
		wp_send_json_error( 'Not allowed.', 403 );
	}
	$now = izl_stock_left( $id );
	if ( isset( $_POST['set'] ) && '' === trim( (string) wp_unslash( $_POST['set'] ) ) ) {
		delete_post_meta( $id, '_izl_stock' ); // emptied: not counted any more
		izl_sync_packs( $id );
		wp_send_json_success( array( 'left' => null ) );
	}
	$n = isset( $_POST['set'] ) ? (int) $_POST['set'] : (int) $now + ( isset( $_POST['add'] ) ? (int) $_POST['add'] : 0 );
	wp_send_json_success( array( 'left' => izl_set_stock( $id, $n ), 'low' => izl_count_low( $id ) ) );
} );

// ==========================================================================
//  4b. stock: what the shop lets people buy, and what orders take and give back (3.21.0)
// ==========================================================================

// How many of this product's animals (or items) the basket holds, leaving out one line (the one being changed).
function izl_cart_takes( $owner, $skip_key = '' ) {
	$n = 0;
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return 0;
	}
	foreach ( WC()->cart->get_cart() as $key => $item ) {
		if ( $key === $skip_key || empty( $item['data'] ) || izl_stock_owner( $item['data'] ) !== $owner ) {
			continue;
		}
		$n += izl_pack_count( $item['data'] ) * (int) $item['quantity'];
	}
	return $n;
}

function izl_short_notice( $owner, $left ) {
	$name = get_the_title( $owner );
	if ( function_exists( 'fsz_names' ) && izl_is_codex( $owner ) ) {
		$names = fsz_names( $owner );
		$name  = '' === trim( (string) $names['nick'] ) ? $name : $names['nick']; // the name customers know (Boci)
	}
	// 3.22.0: a name typed in lower case ("boci") starts with a capital in the sentence
	$name = function_exists( 'mb_substr' ) ? mb_strtoupper( mb_substr( $name, 0, 1 ) ) . mb_substr( $name, 1 ) : ucfirst( $name );
	/* translators: 1: product name, 2: how many are left */
	return sprintf( __( '%1$s: only %2$d left, the basket cannot take more.', 'izeltlab' ), $name, $left );
}

// 3.22.0: the same message once only (the page and a second try used to show it twice).
function izl_short_add( $msg ) {
	if ( ! wc_has_notice( $msg, 'error' ) ) {
		wc_add_notice( $msg, 'error' );
	}
}

// 3.22.0: how many more of this product fit in the basket (null = stock not counted).
function izl_room_left( $owner ) {
	$left = izl_stock_left( $owner );
	return null === $left ? null : max( 0, $left - izl_cart_takes( $owner ) );
}

// 3.22.0: what the basket holds of each counted product: { product id: room left }. The product page greys out
// the packs that no longer fit (assets/product.js room()); it comes with the cart parts after every add or removal.
function izl_room_map() {
	$map = array();
	if ( function_exists( 'WC' ) && WC()->cart ) {
		foreach ( WC()->cart->get_cart() as $item ) {
			$owner = empty( $item['data'] ) ? 0 : izl_stock_owner( $item['data'] );
			if ( $owner && ! isset( $map[ $owner ] ) ) {
				$room = izl_room_left( $owner );
				if ( null !== $room ) {
					$map[ $owner ] = $room;
				}
			}
		}
	}
	return $map;
}
function izl_room_html() {
	return '<script type="application/json" id="izl-room">' . wp_json_encode( (object) izl_room_map() ) . '</script>';
}
add_filter( 'woocommerce_add_to_cart_fragments', function ( $fragments ) {
	$fragments['script#izl-room'] = izl_room_html();
	return $fragments;
} );

add_filter( 'woocommerce_add_to_cart_validation', function ( $ok, $product_id, $qty, $variation_id = 0 ) {
	$p     = wc_get_product( $variation_id ? $variation_id : $product_id );
	$owner = $p ? izl_stock_owner( $p ) : 0;
	$left  = $owner ? izl_stock_left( $owner ) : null;
	if ( ! $ok || null === $left ) {
		return $ok;
	}
	if ( izl_cart_takes( $owner ) + izl_pack_count( $p ) * (int) $qty > $left ) {
		// 3.22.0: the page's own add (no reload, ?wc-ajax=add_to_cart) gets the message in its answer and shows it
		// itself; no notice is kept for the next page, so it is never shown twice
		if ( wp_doing_ajax() && isset( $_GET['wc-ajax'] ) && 'add_to_cart' === $_GET['wc-ajax'] ) { // phpcs:ignore WordPress.Security.NonceVerification
			wp_send_json(
				array(
					'error'       => true,
					'izl_short'   => izl_short_notice( $owner, $left ),
					'izl_owner'   => $owner,
					'izl_room'    => izl_room_left( $owner ),
					'product_url' => get_permalink( $owner ),
				)
			);
		}
		izl_short_add( izl_short_notice( $owner, $left ) );
		return false;
	}
	return $ok;
}, 20, 4 );

add_filter( 'woocommerce_update_cart_validation', function ( $ok, $key, $values, $qty ) {
	$p     = isset( $values['data'] ) ? $values['data'] : null;
	$owner = $p ? izl_stock_owner( $p ) : 0;
	$left  = $owner ? izl_stock_left( $owner ) : null;
	if ( ! $ok || null === $left ) {
		return $ok;
	}
	if ( izl_cart_takes( $owner, $key ) + izl_pack_count( $p ) * (int) $qty > $left ) {
		izl_short_add( izl_short_notice( $owner, $left ) );
		return false;
	}
	return $ok;
}, 20, 4 );

// The basket and the checkout check again (someone else may have bought the last ones meanwhile).
add_action( 'woocommerce_check_cart_items', function () {
	$seen = array();
	foreach ( WC()->cart->get_cart() as $item ) {
		$owner = empty( $item['data'] ) ? 0 : izl_stock_owner( $item['data'] );
		if ( ! $owner || isset( $seen[ $owner ] ) ) {
			continue;
		}
		$seen[ $owner ] = true;
		$left           = izl_stock_left( $owner );
		if ( null !== $left && izl_cart_takes( $owner ) > $left ) {
			izl_short_add( izl_short_notice( $owner, $left ) );
		}
	}
} );

// The quantity box goes up to what is left (a 20 db pack with 50 left: 2).
add_filter( 'woocommerce_quantity_input_max', function ( $max, $product ) {
	$owner = $product instanceof WC_Product ? izl_stock_owner( $product ) : 0;
	$left  = $owner ? izl_stock_left( $owner ) : null;
	if ( null === $left ) {
		return $max;
	}
	$fit = (int) floor( $left / max( 1, izl_pack_count( $product ) ) );
	return $max > 0 ? min( (int) $max, $fit ) : $fit;
}, 20, 2 );

// A pack that needs more than what is left is greyed out (WooCommerce disables its button), and the page's script
// gets what is left and whether it is "Kevés van" (the stamp: "Utolsó N db").
add_filter( 'woocommerce_variation_is_active', function ( $active, $v ) {
	$left = $v instanceof WC_Product ? izl_stock_left( $v->get_parent_id() ) : null;
	return null !== $left && izl_pack_count( $v ) > $left ? false : $active;
}, 20, 2 );
add_filter( 'woocommerce_available_variation', function ( $data, $product, $v ) {
	$left = izl_stock_left( $product->get_id() );
	if ( null !== $left ) {
		$data['izl_left'] = $left;
		$data['izl_n']    = izl_pack_count( $v ); // 3.22.0: animals in this pack (product.js room())
		$data['izl_low']  = izl_count_low( $product->get_id() );
		$data['max_qty']  = max( 1, (int) floor( $left / max( 1, izl_pack_count( $v ) ) ) ); // the quantity box's top
	}
	return $data;
}, 20, 3 );

// Orders take from the stock once (paid, on hold for a transfer, or done) and give it back once when cancelled,
// failed or refunded. Each line notes what it took (_izl_taken), so nothing is counted twice.
function izl_order_stock( $order_id, $take ) {
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}
	$touched = array();
	foreach ( $order->get_items() as $item ) {
		$p     = $item->get_product();
		$owner = $p ? izl_stock_owner( $p ) : 0;
		if ( ! $owner || null === izl_stock_left( $owner ) ) {
			continue;
		}
		$taken = (int) $item->get_meta( '_izl_taken' );
		if ( $take && ! $taken ) {
			$n = izl_pack_count( $p ) * (int) $item->get_quantity();
			update_post_meta( $owner, '_izl_stock', max( 0, izl_stock_left( $owner ) - $n ) );
			$item->update_meta_data( '_izl_taken', $n );
			$item->save();
			$touched[ $owner ] = true;
		} elseif ( ! $take && $taken ) {
			update_post_meta( $owner, '_izl_stock', izl_stock_left( $owner ) + $taken );
			$item->delete_meta_data( '_izl_taken' );
			$item->save();
			$touched[ $owner ] = true;
		}
	}
	foreach ( array_keys( $touched ) as $owner ) {
		izl_sync_packs( $owner );
		/* translators: 1: product name, 2: what is left now */
		$order->add_order_note( sprintf( $take ? __( 'Stock: %1$s, %2$d left.', 'izeltlab' ) : __( 'Stock given back: %1$s, %2$d left.', 'izeltlab' ), get_the_title( $owner ), izl_stock_left( $owner ) ) );
	}
}
foreach ( array( 'processing', 'completed', 'on-hold' ) as $izl_st ) {
	add_action( 'woocommerce_order_status_' . $izl_st, function ( $order_id ) {
		izl_order_stock( $order_id, true );
	} );
}
foreach ( array( 'cancelled', 'failed', 'refunded' ) as $izl_st ) {
	add_action( 'woocommerce_order_status_' . $izl_st, function ( $order_id ) {
		izl_order_stock( $order_id, false );
	} );
}
unset( $izl_st );

// ==========================================================================
//  5. photo frames (saved by Edit photos, shown by the theme)
// ==========================================================================

// The saved frames of a product: attachment id => [ x %, y %, zoom ].
function izl_photo_frames( $product_id ) {
	$f = get_post_meta( $product_id, '_izl_frames', true );
	return is_array( $f ) ? $f : array();
}

// One photo's frame, [ 50, 50, 1 ] (centred, no zoom) when none is saved.
function izl_photo_frame( $product_id, $att_id ) {
	$all = izl_photo_frames( $product_id );
	$f   = isset( $all[ $att_id ] ) && is_array( $all[ $att_id ] ) ? array_values( $all[ $att_id ] ) : array();
	return 3 === count( $f ) ? array( (float) $f[0], (float) $f[1], (float) $f[2] ) : array( 50, 50, 1 );
}

function izl_photo_framed( $frame ) {
	return abs( $frame[0] - 50 ) > 0.05 || abs( $frame[1] - 50 ) > 0.05 || abs( $frame[2] - 1 ) > 0.001;
}

// Saves the order (first = main photo, the rest = the gallery) and the frames.
add_action( 'wp_ajax_izl_photos_save', function () {
	if ( ! check_ajax_referer( 'izl_product_text', false, false ) ) {
		wp_send_json_error( 'The security check ran out. Reload the page and try again.', 403 );
	}
	$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
	if ( ! $id || ! current_user_can( 'edit_post', $id ) ) {
		wp_send_json_error( 'Not allowed.', 403 );
	}
	$product = wc_get_product( $id );
	if ( ! $product ) {
		wp_send_json_error( 'Product not found.' );
	}
	$ids = isset( $_POST['ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['ids'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$ids = array_values( array_unique( array_filter( $ids, function ( $a ) {
		return $a && wp_attachment_is_image( $a );
	} ) ) );
	$raw    = isset( $_POST['frames'] ) ? json_decode( wp_unslash( $_POST['frames'] ), true ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$frames = array();
	foreach ( $ids as $att ) {
		if ( isset( $raw[ $att ] ) && is_array( $raw[ $att ] ) && 3 === count( $raw[ $att ] ) ) {
			$f = array_map( 'floatval', array_values( $raw[ $att ] ) );
			$f = array( max( 0, min( 100, $f[0] ) ), max( 0, min( 100, $f[1] ) ), max( 1, min( 4, $f[2] ) ) );
			if ( izl_photo_framed( $f ) ) {
				$frames[ $att ] = array( round( $f[0], 2 ), round( $f[1], 2 ), round( $f[2], 3 ) );
			}
		}
	}
	$product->set_image_id( $ids ? $ids[0] : 0 );
	$product->set_gallery_image_ids( array_slice( $ids, 1 ) );
	$product->save();
	$frames ? update_post_meta( $id, '_izl_frames', $frames ) : delete_post_meta( $id, '_izl_frames' );
	wc_delete_product_transients( $id );
	wp_send_json_success();
} );

// ==========================================================================
//  6. free shipping amount and the cart total
// ==========================================================================

define( 'IZL_FREE_SHIP_DEFAULT', 18000 );

// One amount for the whole shop (Edit buy box, or Customize → Ízeltláb product page). 0 = no free shipping line.
// Kept in the option izl_free_ship (so it survives a theme change) and, for the Customizer, as the theme setting of
// the same name; a shop that never saved it yet reads the theme setting, then the default (18 000 Ft).
function izl_free_ship() {
	$v = is_customize_preview() ? false : get_option( 'izl_free_ship' );
	if ( false === $v ) {
		$v = get_theme_mod( 'izl_free_ship', IZL_FREE_SHIP_DEFAULT );
	}
	return max( 0, (float) $v );
}

// Saves the amount and sets it as the minimum order amount of WooCommerce's Free shipping in every shipping zone (also
// "Locations not covered by your other zones"), so the ticket, the progress bar and the checkout always agree. A Free
// shipping that needed nothing now needs the amount, one that needed a coupon now needs a coupon or the amount; "a
// coupon and the amount" stays. 0 only removes the line from the ticket: WooCommerce is left as it is.
function izl_set_free_ship( $amount ) {
	$amount = max( 0, round( (float) str_replace( array( ' ', ',' ), array( '', '.' ), (string) $amount ), wc_get_price_decimals() ) );
	set_theme_mod( 'izl_free_ship', $amount );
	update_option( 'izl_free_ship', $amount );
	if ( $amount > 0 ) {
		izl_sync_free_ship( $amount );
	}
}

function izl_sync_free_ship( $amount ) {
	if ( ! class_exists( 'WC_Shipping_Zones' ) || $amount <= 0 ) {
		return;
	}
	$ids = array_merge( array( 0 ), array_map( 'intval', array_keys( WC_Shipping_Zones::get_zones() ) ) );
	foreach ( array_unique( $ids ) as $zone_id ) {
		$zone = new WC_Shipping_Zone( $zone_id );
		foreach ( $zone->get_shipping_methods( false ) as $method ) {
			if ( 'free_shipping' !== $method->id ) {
				continue;
			}
			$key  = $method->get_instance_option_key();
			$opts = get_option( $key, array() );
			$opts = is_array( $opts ) ? $opts : array();
			$req  = isset( $opts['requires'] ) ? (string) $opts['requires'] : '';
			$opts['min_amount'] = wc_format_decimal( $amount );
			if ( '' === $req ) {
				$opts['requires'] = 'min_amount';
			} elseif ( 'coupon' === $req ) {
				$opts['requires'] = 'either';
			}
			update_option( $key, $opts );
		}
	}
	if ( class_exists( 'WC_Cache_Helper' ) ) {
		WC_Cache_Helper::get_transient_version( 'shipping', true ); // carts work their shipping out again
	}
}

// The Customizer field does the same when it changes.
add_action( 'customize_save_after', function ( $manager ) {
	$values = $manager->unsanitized_post_values();
	if ( array_key_exists( 'izl_free_ship', $values ) ) {
		update_option( 'izl_free_ship', max( 0, (float) get_theme_mod( 'izl_free_ship', IZL_FREE_SHIP_DEFAULT ) ) );
		izl_sync_free_ship( izl_free_ship() );
	}
} );

// 1.7.18: what the cart counts toward free shipping, the way WooCommerce's Free shipping works it out (the shown
// subtotal less the discounts).
function izl_cart_total() {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return 0;
	}
	$cart  = WC()->cart;
	$total = (float) $cart->get_displayed_subtotal() - (float) $cart->get_discount_total();
	if ( $cart->display_prices_including_tax() ) {
		$total -= (float) $cart->get_discount_tax();
	}
	return max( 0, round( $total, wc_get_price_decimals() ) );
}

// ==========================================================================
//  7. shipping days: when it leaves, when it is expected, holidays (1.7.0, 2.1.0)
// ==========================================================================

// Everything ordered before 14:00 (Budapest) on a shipping day leaves the same day, later orders on the next shipping
// day. Live animals go out Monday to Wednesday only (never a weekend in a depot), everything else Monday to Friday.
// Foxpost and GLS deliver on the next working day, so the expected delivery is 1 working day after it leaves.
define( 'IZL_SHIP_CUTOFF', 14 ); // hour; 1.7.18: shown in the order-by nudge
define( 'IZL_NUDGE_FROM', 11 ); // 1.7.18: the nudge shows from this hour until the cutoff, on shipping days
define( 'IZL_SHIP_DAYS', array( 'live' => array( 1, 2, 3 ), 'normal' => array( 1, 2, 3, 4, 5 ) ) );

// "live" or "normal": the product's own choice (Edit buy box), else live for species, normal for everything else.
function izl_ship_type( $product_id ) {
	$own = (string) get_post_meta( $product_id, '_izl_ship_type', true );
	if ( isset( IZL_SHIP_DAYS[ $own ] ) ) {
		return $own;
	}
	return izl_is_codex( $product_id ) ? 'live' : 'normal';
}

// [the day it leaves, the expected delivery day, days from today until it leaves], days at midnight in Budapest.
function izl_ship_plan( $type, $now = null ) {
	$now  = $now ? $now : new DateTimeImmutable( 'now', new DateTimeZone( 'Europe/Budapest' ) );
	$days = IZL_SHIP_DAYS[ isset( IZL_SHIP_DAYS[ $type ] ) ? $type : 'normal' ];
	$out  = $now->setTime( 0, 0 );
	// 2.1.0: public holidays (and the shop's own closed days) are neither shipping nor delivery days (izl_is_closed()).
	// Live animals also wait when the next day is closed, so they never spend a holiday in a depot either.
	$no = function ( $d ) use ( $days, $type ) {
		return ! in_array( (int) $d->format( 'N' ), $days, true ) || izl_is_closed( $d ) || ( 'live' === $type && izl_is_closed( $d->modify( '+1 day' ) ) );
	};
	if ( $no( $out ) || (int) $now->format( 'G' ) >= IZL_SHIP_CUTOFF ) {
		do {
			$out = $out->modify( '+1 day' );
		} while ( $no( $out ) );
	}
	$arrive = $out->modify( '+1 day' );
	while ( (int) $arrive->format( 'N' ) > 5 || izl_is_closed( $arrive ) ) {
		$arrive = $arrive->modify( '+1 day' );
	}
	return array( $out, $arrive, (int) round( ( $out->getTimestamp() - $now->setTime( 0, 0 )->getTimestamp() ) / DAY_IN_SECONDS ) );
}

// The words for the day it leaves: today, tomorrow, on Monday … (index = ISO weekday).
function izl_ship_words() {
	return array(
		'today'    => _x( 'today', 'ships', 'izeltlab' ),
		'tomorrow' => _x( 'tomorrow', 'ships', 'izeltlab' ),
		'on'       => array( '', __( 'on Monday', 'izeltlab' ), __( 'on Tuesday', 'izeltlab' ), __( 'on Wednesday', 'izeltlab' ), __( 'on Thursday', 'izeltlab' ), __( 'on Friday', 'izeltlab' ), __( 'on Saturday', 'izeltlab' ), __( 'on Sunday', 'izeltlab' ) ),
		// 1.7.18: short month names for the arrival date ("kedden, nov. 3.")
		'months'   => array( _x( 'Jan', 'short month', 'izeltlab' ), _x( 'Feb', 'short month', 'izeltlab' ), _x( 'Mar', 'short month', 'izeltlab' ), _x( 'Apr', 'short month', 'izeltlab' ), _x( 'May', 'short month', 'izeltlab' ), _x( 'Jun', 'short month', 'izeltlab' ), _x( 'Jul', 'short month', 'izeltlab' ), _x( 'Aug', 'short month', 'izeltlab' ), _x( 'Sep', 'short month', 'izeltlab' ), _x( 'Oct', 'short month', 'izeltlab' ), _x( 'Nov', 'short month', 'izeltlab' ), _x( 'Dec', 'short month', 'izeltlab' ) ),
		/* translators: arrival date. 1: the day word (on Tuesday), 2: short month, 3: day of the month */
		'date'     => _x( '%1$s, %2$s %3$d', 'arrival date', 'izeltlab' ),
	);
}

// "on Tuesday, Nov 3" for a day (at midnight, Budapest).
function izl_arrive_words( $day ) {
	$w = izl_ship_words();
	return sprintf( $w['date'], $w['on'][ (int) $day->format( 'N' ) ], $w['months'][ (int) $day->format( 'n' ) - 1 ], (int) $day->format( 'j' ) );
}

// 1.7.18: the order-by nudge shows now? (a shipping day, from IZL_NUDGE_FROM until the cutoff, Budapest time)
function izl_nudge_now( $type, $now = null ) {
	$now  = $now ? $now : new DateTimeImmutable( 'now', new DateTimeZone( 'Europe/Budapest' ) );
	$days = IZL_SHIP_DAYS[ isset( IZL_SHIP_DAYS[ $type ] ) ? $type : 'normal' ];
	$hour = (int) $now->format( 'G' );
	return 0 === izl_ship_plan( $type, $now->setTime( 0, 0 ) )[2] && $hour >= IZL_NUDGE_FROM && $hour < IZL_SHIP_CUTOFF; // 2.1.0: a day it ships (holidays counted)
}

// Easter Sunday (Gregorian, anonymous algorithm), so Good Friday, Easter Monday and Whit Monday move with it.
function izl_easter( $y ) {
	$a = $y % 19;
	$b = intdiv( $y, 100 );
	$c = $y % 100;
	$d = intdiv( $b, 4 );
	$e = $b % 4;
	$f = intdiv( $b + 8, 25 );
	$g = intdiv( $b - $f + 1, 3 );
	$h = ( 19 * $a + $b - $d - $g + 15 ) % 30;
	$i = intdiv( $c, 4 );
	$k = $c % 4;
	$l = ( 32 + 2 * $e + 2 * $i - $h - $k ) % 7;
	$m = intdiv( $a + 11 * $h + 22 * $l, 451 );
	$mo = intdiv( $h + $l - 7 * $m + 114, 31 );
	$da = ( ( $h + $l - 7 * $m + 114 ) % 31 ) + 1;
	return new DateTimeImmutable( sprintf( '%04d-%02d-%02d', $y, $mo, $da ), new DateTimeZone( 'Europe/Budapest' ) );
}

// Hungary's public holidays of a year (Mt. 102. §), Y-m-d. Dec 24 is a rest day since 2024 as well.
function izl_holidays( $y ) {
	$e   = izl_easter( $y );
	$out = array( "$y-01-01", "$y-03-15", "$y-05-01", "$y-08-20", "$y-10-23", "$y-11-01", "$y-12-24", "$y-12-25", "$y-12-26" );
	foreach ( array( '-2 days', '+1 day', '+50 days' ) as $shift ) { // Good Friday, Easter Monday, Whit Monday
		$out[] = $e->modify( $shift )->format( 'Y-m-d' );
	}
	return $out;
}

// All closed days, this year and next: holidays + the shop's own (filter izl_closed_days, the Ízeltláb Bolt plugin
// adds the "Extra closed days" there).
function izl_closed_days() {
	static $all = null;
	if ( null === $all ) {
		$y   = (int) wp_date( 'Y' );
		$all = array_merge( izl_holidays( $y ), izl_holidays( $y + 1 ) );
		$all = array_values( array_unique( (array) apply_filters( 'izl_closed_days', $all ) ) );
	}
	return $all;
}

function izl_is_closed( $day ) {
	return in_array( $day->format( 'Y-m-d' ), izl_closed_days(), true );
}

// For product.js: the closed days from today on (the script works the dates out again in the browser).
function izl_closed_list() {
	$today = wp_date( 'Y-m-d' );
	return array_values( array_filter( izl_closed_days(), function ( $d ) use ( $today ) {
		return $d >= $today;
	} ) );
}
