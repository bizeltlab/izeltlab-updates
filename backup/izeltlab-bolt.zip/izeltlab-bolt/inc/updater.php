<?php
/**
 * Ízeltláb updates (2.4.0 theme, Codex 1.66.0, Bolt 1.3.0; Dan, 2026-11-06): the theme, Codex and Bolt update from
 * wp-admin like any other plugin, from a GitHub repository, instead of uploading zips by hand.
 *
 * The same file ships in all three (theme inc/updater.php, Codex updater.php, Bolt inc/updater.php); whichever loads
 * first sets it up, the others only add themselves (class_exists). Keep the three copies identical.
 *
 * The repository holds updates.json and the zips:
 *   { "codex": { "version": "1.66.0", "package": "update/codex.zip",
 *                "backup": { "version": "1.65.0", "package": "backup/codex.zip" } },
 *     "bolt":  { ... }, "theme": { ... } }
 * "package" is the newest build, offered under Dashboard → Updates (and on the Plugins / Themes screens) when it is
 * newer than what is installed. "backup" is the version that was live before it: Settings → Ízeltláb updates has a
 * "Roll back" button that puts it back. Each deploy the old backup is deleted, the version that was live becomes the
 * backup and the new build becomes the update.
 *
 * Settings → Ízeltláb updates: the repository (owner/name), the branch, and for a private repository a GitHub token
 * that can read it (a fine-grained token with "Contents: Read-only" on that one repository). The token is sent only to
 * api.github.com, only for that repository's files.
 *
 * Dashboard home (theme 2.5.1, Codex 1.67.1, Bolt 1.3.1; Dan, 2026-11-06): an "Ízeltláb updates" box at the top says
 * whether a new version is waiting and has one "Update all" button that installs every newer part in one go.
 *
 * Page cache (theme 2.8.0, Codex 1.69.0, Bolt 1.5.0; Dan, 2026-11-07): after every update (Update all, Roll back, and
 * any plugin or theme updated from WordPress's own screens) the page cache is emptied by itself, so visitors never get
 * a stored page from the old version; the box also has a "Delete cache" button. Knows WP Super Cache (the shop's),
 * LiteSpeed Cache, W3 Total Cache, WP Rocket, WP Fastest Cache, Cache Enabler and the object cache.
 *
 * @package izeltlab
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'IZL_Updater' ) ) {

	final class IZL_Updater {

		const OPT   = 'izl_updates';
		const CACHE = 'izl_updates_manifest';
		const PAGE  = 'izl-updates';

		/** @var array key => [ type 'plugin'|'theme', id (plugin file or theme folder), name, version ] */
		private static $items = array();
		private static $booted = false;
		private static $found = false;

		/** The three parts, where they are normally installed (found even when an older version without this file runs). */
		private static $known = array(
			'theme' => array( 'theme', 'izeltlab', 'Ízeltláb theme' ),
			'codex' => array( 'plugin', 'codex/codex.php', 'Codex' ),
			'bolt'  => array( 'plugin', 'izeltlab-bolt/izeltlab-bolt.php', 'Ízeltláb Bolt' ),
		);

		/**
		 * One product adds itself. $key is its name in updates.json (codex, bolt, theme).
		 */
		public static function add( $key, $type, $id, $name, $version ) {
			self::$items[ $key ] = array(
				'type'    => $type,
				'id'      => $id,
				'name'    => $name,
				'version' => $version,
			);
			if ( ! self::$booted ) {
				self::$booted = true;
				self::boot();
			}
		}

		/**
		 * Every part that is installed: the ones that added themselves, and the other known ones read from their file
		 * headers. So after a roll back to a version from before the updater (theme 2.3.0, Codex 1.65.0, Bolt 1.2.0),
		 * the update is still offered as long as one of the three has this file.
		 */
		private static function items() {
			if ( ! self::$found && did_action( 'init' ) ) {
				self::$found = true;
				foreach ( self::$known as $key => $k ) {
					if ( isset( self::$items[ $key ] ) ) {
						continue;
					}
					if ( 'plugin' === $k[0] ) {
						if ( ! function_exists( 'get_plugins' ) ) {
							require_once ABSPATH . 'wp-admin/includes/plugin.php';
						}
						$all = get_plugins();
						if ( isset( $all[ $k[1] ] ) ) {
							self::$items[ $key ] = array( 'type' => 'plugin', 'id' => $k[1], 'name' => $k[2], 'version' => (string) $all[ $k[1] ]['Version'] );
						}
					} else {
						$th = wp_get_theme( $k[1] );
						if ( $th->exists() ) {
							self::$items[ $key ] = array( 'type' => 'theme', 'id' => $k[1], 'name' => $k[2], 'version' => (string) $th->get( 'Version' ) );
						}
					}
				}
				uksort( self::$items, function ( $a, $b ) {
					return array_search( $a, array_keys( self::$known ), true ) - array_search( $b, array_keys( self::$known ), true );
				} );
			}
			return self::$items;
		}

		private static function boot() {
			add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'plugins' ) );
			add_filter( 'pre_set_site_transient_update_themes', array( __CLASS__, 'themes' ) );
			add_filter( 'plugins_api', array( __CLASS__, 'info' ), 20, 3 );
			add_filter( 'http_request_args', array( __CLASS__, 'auth' ), 10, 2 );
			add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
			add_action( 'admin_post_izl_updates_save', array( __CLASS__, 'save' ) );
			add_action( 'admin_post_izl_updates_check', array( __CLASS__, 'check' ) );
			add_action( 'admin_post_izl_updates_rollback', array( __CLASS__, 'rollback' ) );
			add_action( 'admin_post_izl_updates_all', array( __CLASS__, 'update_all' ) );
			add_action( 'admin_post_izl_updates_purge', array( __CLASS__, 'purge_now' ) );
			add_action( 'wp_dashboard_setup', array( __CLASS__, 'widget' ), 99 ); // after WooCommerce's boxes, so it can go on top
			// "Check again" under Dashboard → Updates also reads updates.json again
			add_action( 'load-update-core.php', function () {
				if ( isset( $_GET['force-check'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
					delete_site_transient( self::CACHE );
				}
			} );
			// after any update the list is read again, so the screen does not offer the version just installed
			// and the page cache is emptied: stored pages still hold the old version's HTML
			add_action( 'upgrader_process_complete', function () {
				delete_site_transient( self::CACHE );
				self::purge();
			} );
		}

		public static function opts() {
			$o = wp_parse_args( (array) get_option( self::OPT, array() ), array( 'repo' => '', 'branch' => 'main', 'token' => '' ) );
			$o['repo']   = trim( (string) $o['repo'] );
			$o['branch'] = '' !== trim( (string) $o['branch'] ) ? trim( (string) $o['branch'] ) : 'main';
			return $o;
		}

		private static function base() {
			$o = self::opts();
			return preg_match( '#^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$#', $o['repo'] ) ? 'https://api.github.com/repos/' . $o['repo'] . '/contents/' : '';
		}

		/** A file in the repository, as a download address (GitHub's API, raw file). */
		private static function url( $path ) {
			$base = self::base();
			return $base ? $base . ltrim( str_replace( '%2F', '/', rawurlencode( $path ) ), '/' ) . '?ref=' . rawurlencode( self::opts()['branch'] ) : '';
		}

		/** The token and the "raw file" header, only on requests for this repository's files. */
		public static function auth( $args, $url ) {
			$base = self::base();
			if ( ! $base || 0 !== strpos( (string) $url, $base ) ) {
				return $args;
			}
			$args['headers'] = isset( $args['headers'] ) ? (array) $args['headers'] : array();
			$args['headers']['Accept'] = 'application/vnd.github.raw';
			$args['headers']['X-GitHub-Api-Version'] = '2022-11-28';
			$token = self::opts()['token'];
			if ( '' !== $token ) {
				$args['headers']['Authorization'] = 'Bearer ' . $token;
			}
			return $args;
		}

		/** updates.json, read at most once an hour (or after "Check now" / "Check again"). Error text on failure. */
		public static function manifest( $fresh = false ) {
			if ( ! self::base() ) {
				return 'No repository set yet.';
			}
			$m = $fresh ? false : get_site_transient( self::CACHE );
			if ( is_array( $m ) ) {
				return $m;
			}
			$res = wp_remote_get( self::url( 'updates.json' ), array( 'timeout' => 15 ) );
			if ( is_wp_error( $res ) ) {
				return 'GitHub did not answer: ' . $res->get_error_message();
			}
			$code = (int) wp_remote_retrieve_response_code( $res );
			if ( 200 !== $code ) {
				$why = 404 === $code ? ' (wrong repository or branch name, or the token cannot read this repository)' : ( 401 === $code ? ' (the token is wrong or expired)' : '' );
				return 'GitHub answered ' . $code . $why . '.';
			}
			$m = json_decode( wp_remote_retrieve_body( $res ), true );
			if ( ! is_array( $m ) ) {
				return 'updates.json is not readable JSON.';
			}
			set_site_transient( self::CACHE, $m, HOUR_IN_SECONDS );
			return $m;
		}

		/** [ version, download address ] of the newest build of one product, or null. */
		private static function remote( $key, $which = 'update' ) {
			$m = self::manifest();
			if ( ! is_array( $m ) || empty( $m[ $key ] ) || ! is_array( $m[ $key ] ) ) {
				return null;
			}
			$e = 'backup' === $which ? ( isset( $m[ $key ]['backup'] ) && is_array( $m[ $key ]['backup'] ) ? $m[ $key ]['backup'] : array() ) : $m[ $key ];
			if ( empty( $e['version'] ) || empty( $e['package'] ) ) {
				return null;
			}
			return array( (string) $e['version'], self::url( (string) $e['package'] ) );
		}

		public static function plugins( $t ) {
			if ( ! is_object( $t ) ) {
				return $t;
			}
			foreach ( self::items() as $key => $it ) {
				if ( 'plugin' !== $it['type'] ) {
					continue;
				}
				$r    = self::remote( $key );
				$item = (object) array(
					'id'          => $it['id'],
					'slug'        => dirname( $it['id'] ),
					'plugin'      => $it['id'],
					'new_version' => $r ? $r[0] : $it['version'],
					'url'         => 'https://github.com/' . self::opts()['repo'],
					'package'     => $r ? $r[1] : '',
					'icons'       => array(),
					'banners'     => array(),
				);
				if ( $r && version_compare( $r[0], $it['version'], '>' ) ) {
					$t->response[ $it['id'] ] = $item;
					unset( $t->no_update[ $it['id'] ] );
				} else {
					unset( $t->response[ $it['id'] ] );
					$item->new_version          = $it['version'];
					$t->no_update[ $it['id'] ] = $item; // so the Plugins screen offers "Enable auto-updates"
				}
			}
			return $t;
		}

		public static function themes( $t ) {
			if ( ! is_object( $t ) ) {
				return $t;
			}
			foreach ( self::items() as $key => $it ) {
				if ( 'theme' !== $it['type'] ) {
					continue;
				}
				$r    = self::remote( $key );
				$item = array(
					'theme'       => $it['id'],
					'new_version' => $r ? $r[0] : $it['version'],
					'url'         => 'https://github.com/' . self::opts()['repo'],
					'package'     => $r ? $r[1] : '',
				);
				if ( $r && version_compare( $r[0], $it['version'], '>' ) ) {
					$t->response[ $it['id'] ] = $item;
					unset( $t->no_update[ $it['id'] ] );
				} else {
					unset( $t->response[ $it['id'] ] );
					$item['new_version']        = $it['version'];
					$t->no_update[ $it['id'] ] = $item;
				}
			}
			return $t;
		}

		/** The "View details" box on the Plugins screen. */
		public static function info( $res, $action, $args ) {
			if ( 'plugin_information' !== $action || empty( $args->slug ) ) {
				return $res;
			}
			foreach ( self::items() as $key => $it ) {
				if ( 'plugin' === $it['type'] && dirname( $it['id'] ) === $args->slug ) {
					$r = self::remote( $key );
					return (object) array(
						'name'          => $it['name'],
						'slug'          => $args->slug,
						'version'       => $r ? $r[0] : $it['version'],
						'author'        => 'Dan',
						'homepage'      => 'https://izeltlab.hu',
						'download_link' => $r ? $r[1] : '',
						'sections'      => array( 'description' => esc_html( $it['name'] ) . ' — the Ízeltláb shop. What changed: see the patch notes.' ),
					);
				}
			}
			return $res;
		}

		/* -------------------------------------------------------------- Settings → Ízeltláb updates */

		public static function menu() {
			add_options_page( 'Ízeltláb updates', 'Ízeltláb updates', 'update_plugins', self::PAGE, array( __CLASS__, 'page' ) );
		}

		private static function back( $msg, $ok = true ) {
			$args = array( 'izl_msg' => rawurlencode( $msg ), 'izl_ok' => $ok ? 1 : 0 );
			// a button in the Dashboard box goes back to the Dashboard, the rest to Settings → Ízeltláb updates
			if ( isset( $_POST['to'] ) && 'dash' === $_POST['to'] ) { // phpcs:ignore WordPress.Security.NonceVerification
				wp_safe_redirect( add_query_arg( $args, admin_url( 'index.php' ) ) );
			} else {
				wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE ) + $args, admin_url( 'options-general.php' ) ) );
			}
			exit;
		}

		/** Installs one zip over the installed part (plugin stays active). True, or the reason it failed. */
		private static function put( $it, $package ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
			$skin = new Automatic_Upgrader_Skin();
			$was  = 'plugin' === $it['type'] && is_plugin_active( $it['id'] );
			$up   = 'plugin' === $it['type'] ? new Plugin_Upgrader( $skin ) : new Theme_Upgrader( $skin );
			$ok   = $up->install( $package, array( 'overwrite_package' => true ) );
			if ( $was && ! is_plugin_active( $it['id'] ) ) {
				activate_plugin( $it['id'] );
			}
			if ( true === $ok ) {
				return true;
			}
			return is_wp_error( $ok ) ? $ok->get_error_message() : implode( ' ', array_map( 'wp_strip_all_tags', (array) $skin->get_upgrade_messages() ) );
		}

		/** Forget every cached answer, so the screens show what is installed now. */
		private static function forget() {
			delete_site_transient( self::CACHE );
			delete_site_transient( 'update_plugins' );
			delete_site_transient( 'update_themes' );
			wp_clean_plugins_cache( false );
			wp_clean_themes_cache( false );
			self::purge(); // the page cache shows the new version straight away
		}

		/**
		 * Empties the page cache of whichever cache plugin runs (and the object cache). Returns the names of the page
		 * caches it emptied (empty: no page cache plugin found).
		 */
		public static function purge() {
			$done = array();
			if ( function_exists( 'wp_cache_clear_cache' ) ) { // WP Super Cache
				wp_cache_clear_cache();
				$done[] = 'WP Super Cache';
			}
			if ( defined( 'LSCWP_V' ) || has_action( 'litespeed_purge_all' ) ) {
				do_action( 'litespeed_purge_all' );
				$done[] = 'LiteSpeed Cache';
			}
			if ( function_exists( 'w3tc_flush_all' ) ) {
				w3tc_flush_all();
				$done[] = 'W3 Total Cache';
			}
			if ( function_exists( 'rocket_clean_domain' ) ) {
				rocket_clean_domain();
				$done[] = 'WP Rocket';
			}
			if ( function_exists( 'wpfc_clear_all_cache' ) ) {
				wpfc_clear_all_cache( true );
				$done[] = 'WP Fastest Cache';
			}
			if ( has_action( 'cache_enabler_clear_complete_cache' ) ) {
				do_action( 'cache_enabler_clear_complete_cache' );
				$done[] = 'Cache Enabler';
			}
			if ( function_exists( 'wp_cache_flush' ) ) {
				wp_cache_flush();
			}
			return $done;
		}

		/** "Delete cache" (Dashboard box). */
		public static function purge_now() {
			if ( ! current_user_can( 'update_plugins' ) ) {
				wp_die( 'Not allowed.' );
			}
			check_admin_referer( 'izl_updates_purge' );
			$done = self::purge();
			self::back( $done ? 'Cache deleted (' . implode( ', ', $done ) . '). Visitors get fresh pages now.' : 'No page cache plugin found, nothing to delete.', (bool) $done );
		}

		/** The parts that have a newer version in the repository: key => [ item, [ version, package ] ]. */
		private static function waiting() {
			$out = array();
			foreach ( self::items() as $key => $it ) {
				$r = self::remote( $key );
				if ( $r && version_compare( $r[0], $it['version'], '>' ) ) {
					$out[ $key ] = array( $it, $r );
				}
			}
			return $out;
		}

		/** "Update all" (Dashboard box): every part with a newer version, plugins first, the theme last. */
		public static function update_all() {
			if ( ! current_user_can( 'update_plugins' ) || ! current_user_can( 'update_themes' ) ) {
				wp_die( 'Not allowed.' );
			}
			check_admin_referer( 'izl_updates_all' );
			$m = self::manifest( true ); // what the repository holds right now
			if ( ! is_array( $m ) ) {
				self::back( $m, false );
			}
			$todo = self::waiting();
			if ( ! $todo ) {
				self::forget();
				self::back( 'Everything is already up to date.' );
			}
			uasort( $todo, function ( $a, $b ) {
				return ( 'theme' === $a[0]['type'] ) - ( 'theme' === $b[0]['type'] );
			} );
			$done = array();
			$fail = array();
			foreach ( $todo as $t ) {
				$ok = self::put( $t[0], $t[1][1] );
				if ( true === $ok ) {
					$done[] = $t[0]['name'] . ' ' . $t[1][0];
				} else {
					$fail[] = $t[0]['name'] . ': ' . $ok;
				}
			}
			self::forget();
			if ( $fail ) {
				self::back( ( $done ? 'Updated: ' . implode( ', ', $done ) . '. ' : '' ) . 'Not updated: ' . implode( '; ', $fail ), false );
			}
			self::back( 'Updated: ' . implode( ', ', $done ) . '.' );
		}

		/* -------------------------------------------------------------- Dashboard box */

		public static function widget() {
			if ( ! current_user_can( 'update_plugins' ) || ! current_user_can( 'update_themes' ) ) {
				return;
			}
			wp_add_dashboard_widget( 'izl_updates_box', 'Ízeltláb updates', array( __CLASS__, 'box' ) );
			// at the top of the first column
			global $wp_meta_boxes;
			if ( isset( $wp_meta_boxes['dashboard']['normal']['core']['izl_updates_box'] ) ) {
				$mine = array( 'izl_updates_box' => $wp_meta_boxes['dashboard']['normal']['core']['izl_updates_box'] );
				unset( $wp_meta_boxes['dashboard']['normal']['core']['izl_updates_box'] );
				$high = isset( $wp_meta_boxes['dashboard']['normal']['high'] ) ? (array) $wp_meta_boxes['dashboard']['normal']['high'] : array();
				$wp_meta_boxes['dashboard']['normal']['high'] = $mine + $high; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
			}
		}

		public static function box() {
			$msg = isset( $_GET['izl_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['izl_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
			if ( '' !== $msg ) {
				echo '<div class="notice notice-' . ( empty( $_GET['izl_ok'] ) ? 'error' : 'success' ) . ' inline" style="margin:0 0 12px"><p>' . esc_html( $msg ) . '</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification
			}
			if ( ! self::base() ) {
				echo '<p>No repository set yet: <a href="' . esc_url( admin_url( 'options-general.php?page=' . self::PAGE ) ) . '">Settings → Ízeltláb updates</a>.</p>';
				return;
			}
			$m = self::manifest();
			if ( ! is_array( $m ) ) {
				echo '<p style="color:#b32d2e">' . esc_html( $m ) . '</p>';
			}
			$todo = is_array( $m ) ? self::waiting() : array();
			echo '<table class="widefat striped" style="margin-bottom:12px"><tbody>';
			foreach ( self::items() as $key => $it ) {
				$new = isset( $todo[ $key ] ) ? ' → <strong style="color:#00a32a">' . esc_html( $todo[ $key ][1][0] ) . '</strong>' : ' <span style="color:#646970">(up to date)</span>';
				echo '<tr><td>' . esc_html( $it['name'] ) . '</td><td style="text-align:right">' . esc_html( $it['version'] ) . $new . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '</tbody></table>';
			echo '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">';
			if ( $todo ) {
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="var b=this.querySelector(&quot;button&quot;);b.disabled=true;b.textContent=&quot;Updating… (about a minute)&quot;">';
				wp_nonce_field( 'izl_updates_all' );
				echo '<input type="hidden" name="action" value="izl_updates_all"><input type="hidden" name="to" value="dash">';
				echo '<button type="submit" class="button button-primary button-hero" style="min-width:12rem">Update all</button></form>';
			}
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'izl_updates_check' );
			echo '<input type="hidden" name="action" value="izl_updates_check"><input type="hidden" name="to" value="dash">';
			submit_button( 'Check now', 'secondary', 'submit', false );
			echo '</form>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" title="Visitors get fresh pages. Happens by itself after every update.">';
			wp_nonce_field( 'izl_updates_purge' );
			echo '<input type="hidden" name="action" value="izl_updates_purge"><input type="hidden" name="to" value="dash">';
			submit_button( 'Delete cache', 'secondary', 'submit', false );
			echo '</form>';
			echo '<a href="' . esc_url( admin_url( 'options-general.php?page=' . self::PAGE ) ) . '" style="margin-left:auto">Roll back…</a></div>';
		}

		public static function save() {
			if ( ! current_user_can( 'update_plugins' ) ) {
				wp_die( 'Not allowed.' );
			}
			check_admin_referer( 'izl_updates_save' );
			$o    = self::opts();
			$repo = isset( $_POST['repo'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['repo'] ) ) ) : '';
			$repo = preg_replace( '#^https?://github\.com/#i', '', rtrim( $repo, '/' ) ); // a pasted repository address works too
			$repo = preg_replace( '#\.git$#', '', $repo );
			$o['repo']   = $repo;
			$o['branch'] = isset( $_POST['branch'] ) ? sanitize_text_field( wp_unslash( $_POST['branch'] ) ) : 'main';
			if ( ! empty( $_POST['forget_token'] ) ) {
				$o['token'] = '';
			} elseif ( isset( $_POST['token'] ) && '' !== trim( wp_unslash( $_POST['token'] ) ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
				$o['token'] = trim( sanitize_text_field( wp_unslash( $_POST['token'] ) ) );
			}
			update_option( self::OPT, $o, false );
			delete_site_transient( self::CACHE );
			$m = self::manifest( true );
			wp_update_plugins();
			wp_update_themes();
			self::back( is_array( $m ) ? 'Saved. The repository answers.' : 'Saved, but: ' . $m, is_array( $m ) );
		}

		public static function check() {
			if ( ! current_user_can( 'update_plugins' ) ) {
				wp_die( 'Not allowed.' );
			}
			check_admin_referer( 'izl_updates_check' );
			delete_site_transient( self::CACHE );
			$m = self::manifest( true );
			delete_site_transient( 'update_plugins' );
			delete_site_transient( 'update_themes' );
			wp_update_plugins();
			wp_update_themes();
			self::back( is_array( $m ) ? 'Checked. Any update now shows under Dashboard → Updates.' : $m, is_array( $m ) );
		}

		/** Puts the backup version back (the zip from the repository's backup folder, over the installed files). */
		public static function rollback() {
			$key = isset( $_POST['key'] ) ? sanitize_key( wp_unslash( $_POST['key'] ) ) : '';
			if ( ! current_user_can( 'update_plugins' ) || ! isset( self::items()[ $key ] ) ) {
				wp_die( 'Not allowed.' );
			}
			check_admin_referer( 'izl_updates_rollback_' . $key );
			$it = self::items()[ $key ];
			$r  = self::remote( $key, 'backup' );
			if ( ! $r ) {
				self::back( 'There is no backup of ' . $it['name'] . ' in the repository.', false );
			}
			$ok = self::put( $it, $r[1] );
			self::forget();
			if ( true === $ok ) {
				self::back( $it['name'] . ' is back at version ' . $r[0] . '.' );
			}
			self::back( 'The roll back did not work: ' . $ok, false );
		}

		public static function page() {
			if ( ! current_user_can( 'update_plugins' ) ) {
				return;
			}
			$o   = self::opts();
			$m   = self::base() ? self::manifest() : null;
			$msg = isset( $_GET['izl_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['izl_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="wrap"><h1>Ízeltláb updates</h1>';
			if ( '' !== $msg ) {
				echo '<div class="notice notice-' . ( empty( $_GET['izl_ok'] ) ? 'error' : 'success' ) . '"><p>' . esc_html( $msg ) . '</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification
			}
			echo '<p>The theme, Codex and Bolt get their updates from this GitHub repository. New versions show under <a href="' . esc_url( admin_url( 'update-core.php' ) ) . '">Dashboard → Updates</a>, like any other plugin. If a new version misbehaves, “Roll back” puts the previous one back.</p>';

			echo '<h2>Status</h2><table class="widefat striped" style="max-width:52rem"><thead><tr><th>Part</th><th>Installed</th><th>Newest in the repository</th><th>Backup (the one before)</th><th></th></tr></thead><tbody>';
			foreach ( self::items() as $key => $it ) {
				$u = is_array( $m ) ? self::remote( $key ) : null;
				$b = is_array( $m ) ? self::remote( $key, 'backup' ) : null;
				echo '<tr><td><strong>' . esc_html( $it['name'] ) . '</strong></td><td>' . esc_html( $it['version'] ) . '</td><td>' . ( $u ? esc_html( $u[0] ) . ( version_compare( $u[0], $it['version'], '>' ) ? ' <a href="' . esc_url( admin_url( 'update-core.php' ) ) . '">update</a>' : '' ) : '–' ) . '</td><td>' . ( $b ? esc_html( $b[0] ) : '–' ) . '</td><td>';
				if ( $b ) {
					echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'' . esc_js( 'Put ' . $it['name'] . ' ' . $b[0] . ' back? The installed ' . $it['version'] . ' is replaced.' ) . '\')">';
					wp_nonce_field( 'izl_updates_rollback_' . $key );
					echo '<input type="hidden" name="action" value="izl_updates_rollback"><input type="hidden" name="key" value="' . esc_attr( $key ) . '">';
					submit_button( 'Roll back to ' . $b[0], 'secondary small', 'submit', false );
					echo '</form>';
				}
				echo '</td></tr>';
			}
			echo '</tbody></table>';
			if ( is_string( $m ) ) {
				echo '<p style="color:#b32d2e">' . esc_html( $m ) . '</p>';
			}
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:1em 0">';
			wp_nonce_field( 'izl_updates_check' );
			echo '<input type="hidden" name="action" value="izl_updates_check">';
			submit_button( 'Check now', 'secondary', 'submit', false );
			echo '</form>';

			echo '<h2>Repository</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'izl_updates_save' );
			echo '<input type="hidden" name="action" value="izl_updates_save"><table class="form-table" role="presentation">';
			echo '<tr><th scope="row"><label for="izl-repo">Repository</label></th><td><input id="izl-repo" name="repo" class="regular-text" value="' . esc_attr( $o['repo'] ) . '" placeholder="owner/name"><p class="description">The GitHub repository as owner/name (or paste its address).</p></td></tr>';
			echo '<tr><th scope="row"><label for="izl-branch">Branch</label></th><td><input id="izl-branch" name="branch" class="small-text" style="width:8em" value="' . esc_attr( $o['branch'] ) . '"></td></tr>';
			echo '<tr><th scope="row"><label for="izl-token">Token</label></th><td><input id="izl-token" name="token" type="password" class="regular-text" autocomplete="new-password" placeholder="' . esc_attr( '' !== $o['token'] ? 'saved (leave empty to keep it)' : 'only for a private repository' ) . '">';
			if ( '' !== $o['token'] ) {
				echo ' <label><input type="checkbox" name="forget_token" value="1"> forget the saved token</label>';
			}
			echo '<p class="description">Private repository only: a GitHub fine-grained token with <em>Contents: Read-only</em> on this one repository.</p></td></tr>';
			echo '</table>';
			submit_button( 'Save' );
			echo '</form></div>';
		}
	}
}
