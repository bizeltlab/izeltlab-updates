<?php
/**
 * Sign-ups, kept in one small table (wp_izb_signups): "Notify me" on a product that is not available (mailed once,
 * then removed, when the Available switch goes back on) and the footer newsletter (export CSV in the settings).
 * Both forms need the privacy tick (GDPR); the export / erase tools know them (privacy.php).
 */

defined( 'ABSPATH' ) || exit;

function izb_table() {
	global $wpdb;
	return $wpdb->prefix . 'izb_signups';
}

function izb_signups_install() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( 'CREATE TABLE ' . izb_table() . " (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		kind varchar(10) NOT NULL,
		email varchar(190) NOT NULL,
		product_id bigint(20) unsigned NOT NULL DEFAULT 0,
		created datetime NOT NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY one (kind,email,product_id),
		KEY product (product_id)
	) " . $wpdb->get_charset_collate() . ';' );
	update_option( 'izb_db', 1 );
}

add_action( 'plugins_loaded', function () {
	if ( ! get_option( 'izb_db' ) ) {
		izb_signups_install();
	}
} );

function izb_signups_count( $kind ) {
	global $wpdb;
	return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . izb_table() . ' WHERE kind = %s', $kind ) ); // phpcs:ignore
}

function izb_signups_for( $email ) {
	global $wpdb;
	return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . izb_table() . ' WHERE email = %s', $email ) ); // phpcs:ignore
}

function izb_signups_delete( $email ) {
	global $wpdb;
	return (int) $wpdb->delete( izb_table(), array( 'email' => $email ) );
}

/* ------------------------------------------------------------------ the forms */

function izb_form( $kind, $product_id = 0 ) {
	$title = 'notify' === $kind ? __( 'Tell me when they are back', 'izeltlab-bolt' ) : __( 'Letters from the colony', 'izeltlab-bolt' );
	$text  = 'notify' === $kind ? __( 'Leave your email and we write once, when they can be ordered again.', 'izeltlab-bolt' ) : __( 'New species, restocks, care tips. Rarely, never pushy.', 'izeltlab-bolt' );
	$priv  = get_privacy_policy_url();
	$h  = '<form' . ( 'notify' === $kind ? ' id="izb-notify"' : '' ) . ' class="izb-signup is-' . esc_attr( $kind ) . '" data-kind="' . esc_attr( $kind ) . '" data-product="' . (int) $product_id . '">';
	$h .= '<p class="izb-signup-title">' . esc_html( $title ) . '</p><p class="izb-signup-text">' . esc_html( $text ) . '</p>';
	$h .= '<div class="izb-signup-row"><label class="screen-reader-text" for="izb-mail-' . esc_attr( $kind ) . '">' . esc_html__( 'Email address', 'izeltlab-bolt' ) . '</label>';
	$h .= '<input type="email" required id="izb-mail-' . esc_attr( $kind ) . '" name="email" placeholder="' . esc_attr__( 'your@email.hu', 'izeltlab-bolt' ) . '" autocomplete="email">';
	$h .= '<input type="text" name="izb_hp" tabindex="-1" autocomplete="off" class="izb-hp" aria-hidden="true">';
	$h .= '<button type="submit" class="button">' . esc_html( 'notify' === $kind ? __( 'Notify me', 'izeltlab-bolt' ) : __( 'Sign me up', 'izeltlab-bolt' ) ) . '</button></div>';
	$h .= '<label class="izb-signup-ok"><input type="checkbox" name="ok" value="1" required> <span>' . ( $priv
		? sprintf( /* translators: %s: privacy notice link */ esc_html__( 'I agree, see the %s.', 'izeltlab-bolt' ), '<a href="' . esc_url( $priv ) . '">' . esc_html__( 'privacy notice', 'izeltlab-bolt' ) . '</a>' )
		: esc_html__( 'I agree that you store my email for this.', 'izeltlab-bolt' ) ) . '</span></label>';
	$h .= '<p class="izb-signup-msg" role="status" aria-live="polite"></p></form>';
	return $h;
}

// "Notify me" under the buy box when the product cannot be ordered.
add_action( 'woocommerce_single_product_summary', function () {
	global $product;
	if ( izb_opt( 'notify_on' ) && $product && ! $product->is_in_stock() ) {
		echo izb_form( 'notify', $product->get_id() ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
}, 32 );

// The newsletter: the theme's footer prints it (izl_footer_signup); other themes get it before Storefront's footer.
add_action( 'izl_footer_signup', function () {
	if ( izb_opt( 'news_on' ) ) {
		echo izb_form( 'news' ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
} );
add_shortcode( 'izb_newsletter', function () {
	return izb_form( 'news' );
} );

function izb_signup_ajax() {
	// 1.1.1: the security code is checked for logged-in people only. A visitor's page can come from a page cache for
	// days, and its old code made every sign-up fail. For visitors the honeypot, the tick box and the email check stay.
	if ( is_user_logged_in() ) {
		check_ajax_referer( 'izb_signup', 'nonce' );
	}
	global $wpdb;
	$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
	$kind  = 'notify' === ( $_POST['kind'] ?? '' ) ? 'notify' : 'news';
	$pid   = 'notify' === $kind ? absint( $_POST['product'] ?? 0 ) : 0;
	if ( ! empty( $_POST['izb_hp'] ) || empty( $_POST['ok'] ) || ! is_email( $email ) || ( 'notify' === $kind && 'product' !== get_post_type( $pid ) ) ) {
		wp_send_json_error( array( 'msg' => __( 'Please give a valid email and tick the box.', 'izeltlab-bolt' ) ) );
	}
	$wpdb->query( $wpdb->prepare( 'INSERT IGNORE INTO ' . izb_table() . ' (kind, email, product_id, created) VALUES (%s, %s, %d, %s)', $kind, $email, $pid, current_time( 'mysql' ) ) ); // phpcs:ignore
	wp_send_json_success();
}
add_action( 'wp_ajax_izb_signup', 'izb_signup_ajax' );
add_action( 'wp_ajax_nopriv_izb_signup', 'izb_signup_ajax' );

/* ------------------------------------------------------------------ back in stock: one mail each, then removed */

add_action( 'woocommerce_product_set_stock_status', 'izb_back_in_stock', 10, 3 );
add_action( 'woocommerce_variation_set_stock_status', function ( $id, $status ) {
	$v = wc_get_product( $id );
	if ( $v && $v->get_parent_id() ) {
		izb_back_in_stock( $v->get_parent_id(), $status );
	}
}, 10, 2 );

// 1.2.0: returns how many mails went out, and writes them in the restock log (restock.php).
function izb_back_in_stock( $product_id, $status, $product = null ) {
	if ( 'instock' !== $status && 'onbackorder' !== $status ) {
		return 0;
	}
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT id, email FROM ' . izb_table() . " WHERE kind = 'notify' AND product_id = %d", $product_id ) ); // phpcs:ignore
	if ( ! $rows ) {
		return 0;
	}
	$name = get_the_title( $product_id );
	$url  = get_permalink( $product_id );
	/* translators: %s: product name */
	$subj = sprintf( __( '%s can be ordered again!', 'izeltlab-bolt' ), $name );
	/* translators: 1: product name, 2: link */
	$body = sprintf( __( "Good news: %1\$s can be ordered again.\n\n%2\$s\n\nYou asked us to tell you once; we will not write about this again.", 'izeltlab-bolt' ), $name, $url );
	$sent = 0;
	foreach ( $rows as $r ) {
		if ( wp_mail( $r->email, $subj, $body, array( 'Reply-To: ' . izb_email() ) ) ) {
			$wpdb->delete( izb_table(), array( 'id' => $r->id ) );
			++$sent;
		}
	}
	if ( $sent ) {
		izb_restock_log( $product_id, $sent );
	}
	return $sent;
}

/* ------------------------------------------------------------------ newsletter CSV */

add_action( 'admin_post_izb_export', function () {
	check_admin_referer( 'izb_export' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die();
	}
	global $wpdb;
	$rows = $wpdb->get_results( 'SELECT email, created FROM ' . izb_table() . " WHERE kind = 'news' ORDER BY created", ARRAY_A ); // phpcs:ignore
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=izeltlab-hirlevel-' . gmdate( 'Y-m-d' ) . '.csv' );
	$out = fopen( 'php://output', 'w' ); // phpcs:ignore
	fputcsv( $out, array( 'email', 'created' ) );
	foreach ( $rows as $r ) {
		fputcsv( $out, $r );
	}
	exit;
} );
