<?php
/**
 * Security hardening, each part has its own switch in the settings:
 * login attempts limit, secret login address, XML-RPC off, security headers, no user-name leaks, no file editor.
 * 2FA: install the free "Two Factor" plugin (see the security guide); it is not rebuilt here.
 */

defined( 'ABSPATH' ) || exit;

/* ------------------------------------------------------------------ file editor off */
if ( izb_opt( 'sec_fileedit' ) && ! defined( 'DISALLOW_FILE_EDIT' ) ) {
	define( 'DISALLOW_FILE_EDIT', true );
}

/* ------------------------------------------------------------------ XML-RPC off */
if ( izb_opt( 'sec_xmlrpc' ) ) {
	add_filter( 'xmlrpc_enabled', '__return_false' );
	add_filter( 'wp_headers', function ( $h ) {
		unset( $h['X-Pingback'] );
		return $h;
	} );
	add_action( 'init', function () {
		if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
			status_header( 403 );
			exit;
		}
	}, 0 );
}

/* ------------------------------------------------------------------ headers */
if ( izb_opt( 'sec_headers' ) ) {
	add_action( 'send_headers', function () {
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		header( 'Permissions-Policy: camera=(), microphone=(), geolocation=()' );
	} );
}

/* ------------------------------------------------------------------ no user names */
if ( izb_opt( 'sec_enum' ) ) {
	add_action( 'template_redirect', function () {
		if ( ! is_user_logged_in() && ( isset( $_GET['author'] ) || is_author() ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	} );
	add_filter( 'rest_endpoints', function ( $e ) {
		if ( ! is_user_logged_in() ) {
			unset( $e['/wp/v2/users'], $e['/wp/v2/users/(?P<id>[\d]+)'] );
		}
		return $e;
	} );
	add_filter( 'wp_sitemaps_add_provider', function ( $p, $name ) {
		return 'users' === $name ? false : $p;
	}, 10, 2 );
	// One message for a wrong user name and a wrong password.
	add_filter( 'login_errors', function () {
		return __( 'Wrong user name or password.', 'izeltlab-bolt' );
	} );
}

/* ------------------------------------------------------------------ login attempts: 5 wrong = 15 minutes locked */
define( 'IZB_TRIES', 5 );
define( 'IZB_LOCK', 15 * MINUTE_IN_SECONDS );

function izb_ip_key() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0';
	return 'izb_fail_' . md5( $ip );
}

if ( izb_opt( 'sec_limit' ) ) {
	add_filter( 'authenticate', function ( $user ) {
		if ( (int) get_transient( izb_ip_key() ) >= IZB_TRIES ) {
			return new WP_Error( 'izb_locked', __( 'Too many wrong tries. Please wait 15 minutes.', 'izeltlab-bolt' ) );
		}
		return $user;
	}, 99 );
	add_action( 'wp_login_failed', function () {
		$k = izb_ip_key();
		set_transient( $k, (int) get_transient( $k ) + 1, IZB_LOCK );
	} );
	add_action( 'wp_login', function () {
		delete_transient( izb_ip_key() );
	} );
}

/* ------------------------------------------------------------------ secret login address */
// yoursite/<slug> shows the login; wp-login.php and wp-admin answer 404 to logged-out visitors. Password reset,
// logout and the WooCommerce "My account" login keep working.
function izb_slug() {
	return (string) izb_opt( 'sec_slug' );
}

if ( izb_slug() ) {
	add_action( 'init', function () {
		$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ), '/' ); // phpcs:ignore
		$home = trim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
		$rel  = trim( $home ? preg_replace( '#^' . preg_quote( $home, '#' ) . '#', '', $path ) : $path, '/' );
		if ( $rel === izb_slug() ) {
			setcookie( 'izb_gate', '1', 0, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true );
			wp_safe_redirect( site_url( 'wp-login.php?izb=1' ) );
			exit;
		}
	}, 1 );
	add_action( 'login_init', function () {
		$action = isset( $_REQUEST['action'] ) ? sanitize_key( $_REQUEST['action'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$ok     = ! empty( $_COOKIE['izb_gate'] ) || in_array( $action, array( 'logout', 'rp', 'resetpass', 'postpass', 'confirmaction', 'lostpassword', 'confirm_admin_email' ), true );
		if ( ! $ok && ! is_user_logged_in() ) {
			// wp-admin sends logged-out visitors here too, so both end on the shop's 404 page.
			wp_safe_redirect( home_url( '/nincs-ilyen-oldal/' ) );
			exit;
		}
	} );
}
