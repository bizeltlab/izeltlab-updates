<?php
// ==========================================================================
//  FILE: inc/upkeep.php   (Ízeltláb Bolt plugin)
//  WHAT: The "Optimise" button: one press does the shop's upkeep (photos, cache, database tidy, health check), and the
//        same runs by itself after every update and every night.
//  SEEN: Dashboard → the "Ízeltláb updates" box (the button, the last run and its warnings).
//  SECTIONS IN THIS FILE:
//    1. The run: photos, cache, database, health check
//    2. When it runs: the button, after updates, every night
//    3. The button and the last run in the updates box
// ==========================================================================

/**
 * 1.16.0 (Dan, 2026-11-19: "an Optimize button ... that fixes images, deletes cache etc and anything that i do manually
 * or dont do but i should be doing, everyday and after updates"). One run, in this order:
 * 1. Photos: the ones not at the shop's current standard yet get the "Optimise existing photos" treatment (inc/speed.php),
 *    5 at a time for up to 20 s; whatever is left goes on by itself in the background, a batch a minute.
 * 2. Cache: the page cache (WP Super Cache etc., IZL_Updater::purge()), WooCommerce's stored product data and every
 *    expired stored value, so visitors get the newest pages.
 * 3. Database tidy (keeps the 1 GB plan quick): old text versions of pages and products (the last 5 of each stay),
 *    empty drafts older than 7 days, the bin older than 30 days, spam comments older than 30 days, ended shopper
 *    sessions. Never orders, products, customers or settings.
 * 4. Health check: what Dan should do by hand, with a link each: no backup for 2 days, mail sending not set up, updates
 *    waiting, the disk nearly full, heavy photos.
 * It runs after every update (a minute later, with the new code) and every night at about 3:00 (Budapest time). WordPress
 * runs timed jobs on the next visit that is not served from the page cache (the dashboard, the basket, a search), so on
 * a quiet night it runs a little later. The last run's result shows in the updates box on the dashboard.
 * Filters: izb_upkeep_keep_revisions (5), izb_upkeep_disk_warn_mb (800).
 */

defined( 'ABSPATH' ) || exit;

// ==========================================================================
//  The run: photos, cache, database, health check
// ==========================================================================

/**
 * One upkeep run. $how: 'button', 'update' or 'nightly'. Returns the stored record:
 * array( t => time, how, done => list of lines, warn => list of array( text, link ), photos_left ).
 */
function izb_upkeep_run( $how = 'button' ) {
	if ( get_transient( 'izb_upkeep_lock' ) ) {
		return (array) get_option( 'izb_upkeep', array() ); // one run at a time
	}
	set_transient( 'izb_upkeep_lock', 1, 5 * MINUTE_IN_SECONDS );
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 180 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	}
	$done = array();

	// 1. photos
	$left = izb_upkeep_photos( 'button' === $how ? 20 : 40, $done );

	// 2. cache
	if ( function_exists( 'izb_soon_purge' ) ) {
		izb_soon_purge();
	}
	if ( function_exists( 'wc_delete_product_transients' ) ) {
		wc_delete_product_transients();
	}
	if ( class_exists( 'WC_Cache_Helper' ) ) {
		WC_Cache_Helper::get_transient_version( 'product', true );
	}
	delete_expired_transients( true );
	$done[] = 'Page cache and stored shop data emptied.';

	// 3. database
	$done = array_merge( $done, izb_upkeep_tidy() );

	// 4. health check
	$rec = array(
		't'           => time(),
		'how'         => $how,
		'done'        => $done,
		'warn'        => izb_upkeep_health( $left ),
		'photos_left' => $left,
	);
	update_option( 'izb_upkeep', $rec, false );
	delete_transient( 'izb_upkeep_lock' );
	return $rec;
}

// Photos not at the current standard yet, for up to $secs seconds. Returns how many are still left (they go on by
// themselves, a batch a minute).
function izb_upkeep_photos( $secs, &$done ) {
	if ( ! function_exists( 'izb_img_todo' ) || ! izb_opt( 'img_on' ) || ! izb_webp_ok() ) {
		return 0;
	}
	$GLOBALS['izb_no_webp'] = ! izb_opt( 'img_webp' );
	$end = microtime( true ) + $secs;
	$n   = 0;
	$b   = 0;
	$a   = 0;
	while ( microtime( true ) < $end ) {
		$ids = izb_img_todo( 5 );
		if ( ! $ids ) {
			break;
		}
		foreach ( $ids as $id ) {
			list( $x, $y ) = izb_img_redo( $id );
			$b += $x;
			$a += $y;
			$n++;
		}
	}
	$left = count( izb_img_todo( 500 ) );
	if ( $n ) {
		$done[] = sprintf( '%d photo(s) optimised (%s KB → %s KB).', $n, number_format( $b / 1024, 0, ',', ' ' ), number_format( $a / 1024, 0, ',', ' ' ) );
	}
	if ( $left ) {
		$done[] = sprintf( '%d photo(s) still to do: they go on by themselves in the background.', $left );
		if ( ! wp_next_scheduled( 'izb_upkeep_photos' ) ) {
			wp_schedule_single_event( time() + MINUTE_IN_SECONDS, 'izb_upkeep_photos' );
		}
	} elseif ( ! $n ) {
		$done[] = 'Photos: all at the current standard.';
	}
	return $left;
}

// The database tidy. Returns the lines for the report.
function izb_upkeep_tidy() {
	global $wpdb;
	$out = array();

	// old text versions: the last 5 of every page and product stay
	$keep = max( 1, (int) apply_filters( 'izb_upkeep_keep_revisions', 5 ) );
	$gone = 0;
	$rows = $wpdb->get_col( $wpdb->prepare( "SELECT post_parent FROM {$wpdb->posts} WHERE post_type = 'revision' GROUP BY post_parent HAVING COUNT(*) > %d LIMIT 200", $keep ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	foreach ( $rows as $parent ) {
		$old = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'revision' AND post_parent = %d ORDER BY post_date DESC, ID DESC LIMIT 1000 OFFSET %d", (int) $parent, $keep ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		foreach ( $old as $rid ) {
			if ( wp_delete_post_revision( (int) $rid ) ) {
				$gone++;
			}
		}
	}
	if ( $gone ) {
		$out[] = sprintf( '%d old text version(s) removed (the last %d of each page stay).', $gone, $keep );
	}

	// empty drafts older than 7 days, the bin older than 30 days (WordPress's own daily jobs, run now)
	if ( function_exists( 'wp_delete_auto_drafts' ) ) {
		wp_delete_auto_drafts();
	}
	if ( function_exists( 'wp_scheduled_delete' ) ) {
		wp_scheduled_delete();
	}

	// spam comments older than 30 days
	$spam = $wpdb->get_col( $wpdb->prepare( "SELECT comment_ID FROM {$wpdb->comments} WHERE comment_approved = 'spam' AND comment_date_gmt < %s LIMIT 500", gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	foreach ( $spam as $cid ) {
		wp_delete_comment( (int) $cid, true );
	}
	if ( $spam ) {
		$out[] = sprintf( '%d old spam comment(s) removed.', count( $spam ) );
	}

	// ended shopper sessions (baskets of visitors who left)
	if ( class_exists( 'WC_Session_Handler' ) ) {
		$h = new WC_Session_Handler();
		if ( method_exists( $h, 'cleanup_sessions' ) ) {
			$h->cleanup_sessions();
		}
	}
	$out[] = 'Database tidied (old drafts, bin, expired sessions).';
	return $out;
}

/**
 * The health check: what needs Dan's hand. Each: array( text, link ).
 */
function izb_upkeep_health( $photos_left ) {
	$w = array();

	// backups (UpdraftPlus, set up by Bolt's "Apply backup settings")
	if ( function_exists( 'izb_backup_plugin' ) ) {
		if ( ! izb_backup_plugin() ) {
			$w[] = array( 'Backups: UpdraftPlus is not installed, so nothing is backed up.', admin_url( 'plugin-install.php?s=updraftplus&tab=search&type=term' ) );
		} elseif ( function_exists( 'izb_backup_stale' ) && izb_backup_stale() ) {
			$w[] = array( 'Backups: no backup for more than 2 days. Is Dropbox still connected in UpdraftPlus?', admin_url( 'options-general.php?page=updraftplus' ) );
		}
	}

	// mail sending
	if ( ! izb_opt( 'smtp_on' ) || ! izb_opt( 'smtp_pass' ) ) {
		$w[] = array( 'Mail: sending through SMTP is not set up, so order mails may land in spam (Ízeltláb Bolt → Email sending).', admin_url( 'admin.php?page=izeltlab-bolt' ) );
	}

	// updates waiting (WordPress, plugins, themes)
	if ( function_exists( 'wp_get_update_data' ) ) {
		$u = wp_get_update_data();
		$c = isset( $u['counts'] ) ? $u['counts'] : array();
		$n = (int) ( $c['plugins'] ?? 0 ) + (int) ( $c['themes'] ?? 0 ) + (int) ( $c['wordpress'] ?? 0 );
		if ( $n ) {
			$w[] = array( sprintf( 'Updates: %d waiting (WordPress, plugins or themes).', $n ), admin_url( 'update-core.php' ) );
		}
	}

	// the disk (the hosting plan is 1 GB)
	$mb   = izb_upkeep_disk_mb();
	$warn = (int) apply_filters( 'izb_upkeep_disk_warn_mb', 800 );
	if ( $mb && $mb > $warn ) {
		$w[] = array( sprintf( 'Disk: the shop uses about %d MB of the 1 GB plan (files, backups and database).', $mb ), admin_url( 'options-general.php?page=updraftplus' ) );
	}

	// heavy photos (after optimising: a 768px file over 150 KB, usually a very busy picture)
	$heavy = $photos_left ? 0 : izb_upkeep_heavy();
	if ( $heavy ) {
		$w[] = array( sprintf( 'Photos: %d photo(s) are still heavy after optimising (over %d KB). Re-export them smaller or crop them.', $heavy, (int) apply_filters( 'izb_heavy_photo_kb', 150 ) ), admin_url( 'upload.php' ) );
	}
	// 1.20.0: the theme's fast first screen switched off for a kind of page (theme 3.34.0 inc/critical.php)
	if ( function_exists( 'izl_critical_off_lines' ) ) {
		foreach ( izl_critical_off_lines() as $line ) {
			$w[] = array( $line, admin_url( 'index.php' ) );
		}
	}

	// 1.20.0 (Dan, 2026-11-28): a product whose photo file is gone (since theme 3.33.0 a photo that fails to load just
	// hides, so a shopper sees a plain tile and nobody notices). Names the first few products, the link opens the first.
	$gone = izb_upkeep_missing_photos();
	if ( $gone ) {
		$names = implode( ', ', array_slice( wp_list_pluck( $gone, 'name' ), 0, 3 ) ) . ( count( $gone ) > 3 ? ', …' : '' );
		$w[] = array( sprintf( 'Photos: %1$d product(s) show a photo whose file is missing (%2$s). Pick the photo again on the product page.', count( $gone ), $names ), $gone[0]['edit'] );
	}
	return $w;
}

// 1.20.0: the products (published or waiting) whose main photo, gallery photo or Codex card photo has no file in the
// uploads folder. Each: name and edit link. At most 300 products, the original file only (the size files are made
// from it again by "Regenerate" tools; Bolt keeps an old size file for a day, 1.19.4).
function izb_upkeep_missing_photos() {
	$ids = get_posts( array(
		'post_type'      => 'product',
		'post_status'    => array( 'publish', 'private', 'draft', 'pending', 'future' ),
		'posts_per_page' => 300,
		'fields'         => 'ids',
	) );
	$out = array();
	foreach ( $ids as $pid ) {
		$pics = array( (int) get_post_thumbnail_id( $pid ) );
		foreach ( explode( ',', (string) get_post_meta( $pid, '_product_image_gallery', true ) ) as $g ) {
			$pics[] = (int) $g;
		}
		$card = trim( (string) get_post_meta( $pid, '_fsz_image', true ) );
		if ( '' !== $card && ctype_digit( $card ) ) {
			$pics[] = (int) $card;
		}
		foreach ( array_unique( array_filter( $pics ) ) as $a ) {
			$file = get_attached_file( $a );
			if ( 'attachment' === get_post_type( $a ) && ( ! $file || ! file_exists( $file ) ) ) { // a removed photo is simply left out by WooCommerce
				$out[] = array( 'name' => get_the_title( $pid ), 'edit' => admin_url( 'post.php?post=' . (int) $pid . '&action=edit' ) );
				break;
			}
		}
	}
	return $out;
}

// About how many MB the shop takes: its folder (with the backups in it) and the database. Counted for at most 8 s.
function izb_upkeep_disk_mb() {
	global $wpdb;
	$bytes = 0;
	$end   = microtime( true ) + 8;
	try {
		$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( ABSPATH, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::LEAVES_ONLY, RecursiveIteratorIterator::CATCH_GET_CHILD );
		foreach ( $it as $f ) {
			if ( $f->isFile() && ! $f->isLink() ) {
				$bytes += (int) $f->getSize();
			}
			if ( microtime( true ) > $end ) {
				break;
			}
		}
	} catch ( Exception $e ) {
		return 0;
	}
	$db = $wpdb->get_var( $wpdb->prepare( 'SELECT SUM(data_length + index_length) FROM information_schema.TABLES WHERE table_schema = %s', DB_NAME ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	return (int) round( ( $bytes + (int) $db ) / 1048576 );
}

// How many optimised photos are still heavy (the same test as the product page's warning in inc/speed.php).
function izb_upkeep_heavy() {
	$limit = 1024 * (int) apply_filters( 'izb_heavy_photo_kb', 150 );
	$ids   = get_posts( array(
		'post_type'      => 'attachment',
		'post_status'    => 'inherit',
		'post_mime_type' => array( 'image/jpeg', 'image/png', 'image/webp' ),
		'posts_per_page' => 300,
		'fields'         => 'ids',
	) );
	$n = 0;
	foreach ( $ids as $id ) {
		$src  = wp_get_attachment_image_src( $id, 'medium_large' );
		$file = $src ? trailingslashit( dirname( (string) get_attached_file( $id ) ) ) . wp_basename( (string) strtok( $src[0], '?' ) ) : '';
		if ( $file && is_readable( $file ) && filesize( $file ) > $limit ) {
			$n++;
		}
	}
	return $n;
}

// ==========================================================================
//  When it runs: the button, after updates, every night
// ==========================================================================

// The button (the updates box on the dashboard).
add_action( 'admin_post_izb_upkeep', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Not allowed.' );
	}
	check_admin_referer( 'izb_upkeep' );
	$r = izb_upkeep_run( 'button' );
	$w = count( (array) ( $r['warn'] ?? array() ) );
	$msg = 'Optimised.' . ( $w ? ' ' . $w . ' thing(s) need you: see the list in the box.' : ' Nothing needs you.' );
	wp_safe_redirect( add_query_arg( array( 'izl_ok' => 1, 'izl_msg' => rawurlencode( $msg ) ), admin_url( 'index.php' ) ) );
	exit;
} );

// After any update (WordPress, a plugin, the theme): a run a minute later, so it uses the newly installed code.
add_action( 'upgrader_process_complete', function () {
	if ( ! wp_next_scheduled( 'izb_upkeep_after_update' ) ) {
		wp_schedule_single_event( time() + MINUTE_IN_SECONDS, 'izb_upkeep_after_update' );
	}
} );
add_action( 'izb_upkeep_after_update', function () {
	izb_upkeep_run( 'update' );
} );

// Every night at about 3:00 shop time.
add_action( 'izb_upkeep_nightly', function () {
	izb_upkeep_run( 'nightly' );
	if ( function_exists( 'izb_img_sweep' ) ) {
		izb_img_sweep(); // 1.19.4: photo files a re-made photo stopped using, a day on (inc/speed.php)
	}
} );
add_action( 'init', function () {
	if ( wp_next_scheduled( 'izb_upkeep_nightly' ) ) {
		return;
	}
	$at = new DateTime( 'tomorrow 03:00', wp_timezone() );
	wp_schedule_event( $at->getTimestamp(), 'daily', 'izb_upkeep_nightly' );
} );
register_deactivation_hook( IZB_DIR . 'izeltlab-bolt.php', function () {
	wp_clear_scheduled_hook( 'izb_upkeep_nightly' );
	wp_clear_scheduled_hook( 'izb_upkeep_after_update' );
	wp_clear_scheduled_hook( 'izb_upkeep_photos' );
	wp_clear_scheduled_hook( 'izb_img_sweep' );
} );

// The photos left over from a run: a batch a minute until none are left, then the page cache is emptied once more.
add_action( 'izb_upkeep_photos', function () {
	$done = array();
	$left = izb_upkeep_photos( 40, $done );
	$rec  = get_option( 'izb_upkeep' );
	if ( is_array( $rec ) ) {
		$rec['photos_left'] = $left;
		if ( ! $left ) {
			$rec['done'][] = 'Background photo work finished.';
			$rec['warn']   = izb_upkeep_health( 0 );
		}
		update_option( 'izb_upkeep', $rec, false );
	}
	if ( ! $left && function_exists( 'izb_soon_purge' ) ) {
		izb_soon_purge(); // cached pages may name files that are gone
	}
} );

// ==========================================================================
//  The button and the last run in the updates box
// ==========================================================================

// Next to "Check now" and "Delete cache" (the updates box of inc/updater.php calls izl_updates_box_buttons).
add_action( 'izl_updates_box_buttons', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" title="Photos, cache, database tidy and a health check. Also runs by itself after every update and every night." onsubmit="var b=this.querySelector(&quot;button,input[type=submit]&quot;);b.disabled=true;b.value=b.textContent=&quot;Optimising… (up to a minute)&quot;">';
	wp_nonce_field( 'izb_upkeep' );
	echo '<input type="hidden" name="action" value="izb_upkeep">';
	echo '<button type="submit" class="button button-primary">Optimise</button>';
	echo '</form>';
} );

// Under the buttons: when it last ran, what it did and what needs Dan.
add_action( 'izl_updates_box_after', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$r = get_option( 'izb_upkeep' );
	$next = wp_next_scheduled( 'izb_upkeep_nightly' );
	echo '<div style="margin-top:12px;padding-top:10px;border-top:1px solid #dcdcde">';
	if ( ! is_array( $r ) || empty( $r['t'] ) ) {
		echo '<p style="margin:0;color:#646970">Optimise has not run yet. It runs by itself after every update and every night at about 3:00.</p></div>';
		return;
	}
	$how = array( 'button' => 'by the button', 'update' => 'after an update', 'nightly' => 'nightly run' );
	echo '<p style="margin:0 0 6px"><strong>Last optimise:</strong> ' . esc_html( wp_date( 'Y-m-d H:i', (int) $r['t'] ) ) . ' (' . esc_html( $how[ $r['how'] ] ?? $r['how'] ) . ')' . ( $next ? ' · <span style="color:#646970">next: ' . esc_html( wp_date( 'Y-m-d H:i', $next ) ) . '</span>' : '' ) . '</p>';
	if ( ! empty( $r['warn'] ) ) {
		echo '<ul style="margin:0 0 6px;padding-left:18px;list-style:disc">';
		foreach ( (array) $r['warn'] as $w ) {
			echo '<li style="color:#b32d2e;margin:2px 0">' . esc_html( $w[0] ) . ( ! empty( $w[1] ) ? ' <a href="' . esc_url( $w[1] ) . '">Open</a>' : '' ) . '</li>';
		}
		echo '</ul>';
	} else {
		echo '<p style="margin:0 0 6px;color:#00a32a">Nothing needs you.</p>';
	}
	echo '<details><summary style="cursor:pointer;color:#646970">What it did</summary><ul style="margin:4px 0 0;padding-left:18px;list-style:disc">';
	foreach ( (array) $r['done'] as $d ) {
		echo '<li style="margin:2px 0">' . esc_html( $d ) . '</li>';
	}
	echo '</ul></details></div>';
} );
